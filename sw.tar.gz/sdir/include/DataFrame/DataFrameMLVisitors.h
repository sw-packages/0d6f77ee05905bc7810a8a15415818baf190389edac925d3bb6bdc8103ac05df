// Hossein Moein
// October 30, 2019
/*
Copyright (c) 2019-2026, Hossein Moein
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
* Neither the name of Hossein Moein and/or the DataFrame nor the
  names of its contributors may be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Hossein Moein BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include <DataFrame/DataFrameStatsVisitors.h>
#include <DataFrame/Utils/CFTree.h>
#include <DataFrame/Utils/IsolationTree.h>
#include <DataFrame/Utils/KDTree.h>
#include <DataFrame/Utils/Matrix.h>
#include <DataFrame/Vectors/VectorPtrView.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstdlib>
#include <functional>
#include <limits>
#include <numeric>
#include <random>
#include <type_traits>
#include <unordered_set>
#include <utility>
#include <vector>

// ------------------------------------------------------------------------------

namespace hmdf
{

// One pass simple linear regression
//
template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  SLRegressionVisitor  {

public:

    DEFINE_VISIT_BASIC_TYPES_2

    inline void operator()(const index_type &idx,
                           const value_type &x, const value_type &y)  {

        if (skip_nan_ && (is_nan__(x) || is_nan__(y))) [[unlikely]]  return;

        s_xy_ += (x_stats_.get_mean() - x) *
                 (y_stats_.get_mean() - y) *
                 value_type(n_) / value_type(n_ + 1);

        x_stats_(idx, x);
        y_stats_(idx, y);
        n_ += 1;
    }
    PASS_DATA_ONE_BY_ONE_2

    inline void pre()  {

        n_ = 0;
        s_xy_ = 0;
        x_stats_.pre();
        y_stats_.pre();
    }
    inline void post()  {  }

    inline size_type get_count() const  { return (n_); }
    inline result_type get_slope() const  {

        // Sum of the squares of the difference between each x and
        // the mean x value.
        //
        const value_type    s_xx {
            x_stats_.get_variance() * value_type(n_ - 1)
        };

        return (s_xy_ / s_xx);
    }
    inline result_type get_intercept() const  {

        return (y_stats_.get_mean() - get_slope() * x_stats_.get_mean());
    }
    inline result_type get_corr() const  {

        const value_type    t { x_stats_.get_std() * y_stats_.get_std() };

        return (s_xy_ / (value_type(n_ - 1) * t));
    }

    explicit SLRegressionVisitor(bool skipnan = true)
        : x_stats_(skipnan), y_stats_(skipnan), skip_nan_(skipnan)  {   }

private:

    size_type                               n_ { 0 };

    // Sum of the product of the difference between x and its mean and
    // the difference between y and its mean.
    //
    value_type                              s_xy_ { 0 };
    StatsVisitor<value_type, index_type>    x_stats_ {  };
    StatsVisitor<value_type, index_type>    y_stats_ {  };
    const bool                              skip_nan_;
};

// ------------------------------------------------------------------------------

template<std::size_t K,
         typename T, typename I = unsigned long, std::size_t A = 0>
struct  KMeansVisitor  {

public:

    DEFINE_VISIT_BASIC_TYPES

    using result_type = std::array<value_type, K>;
    using cluster_type = std::array<VectorConstPtrView<value_type, A>, K>;
    using order_type =
        std::array<std::vector<
                       size_type,
                       typename allocator_declare<size_type, A>::type>, K>;
    using distance_func =
        std::function<double(const value_type &x, const value_type &y)>;
    using seed_t = std::random_device::result_type;

private:

    const size_type iter_num_;
    const bool      cc_;
    const seed_t    seed_;
    distance_func   dfunc_;
    result_type     result_ { };         // K Means
    cluster_type    clusters_ { };       // K Clusters
    order_type      clusters_idxs_ { };  // K Clusters indices

    template<typename H>
    inline void calc_k_means_(const H &column_begin, size_type col_s)  {

        std::random_device                          rd;
        std::mt19937                                gen {
            (seed_ != seed_t(-1)) ? seed_ : rd()
        };
        std::uniform_int_distribution<size_type>    rd_gen { 0, col_s - 1 };

        // Pick centroids as random points from the col.
        //
        for (auto &k_mean : result_) [[likely]]  {
            const value_type    &value { *(column_begin + rd_gen(gen)) };

            if (! is_nan__(value)) [[likely]]
                k_mean = value;
        }

        for (size_type iter { 0 }; iter < iter_num_; ++iter) [[likely]]  {
            result_type             new_means { value_type() };
            std::array<double, K>   counts { 0.0 };

            // Find assignments.
            //
            for (size_type point { 0 }; point < col_s; ++point) [[likely]]  {
                const value_type    &value { *(column_begin + point) };

                if (! is_nan__(value)) [[likely]]  {
                    double      best_distance {
                        std::numeric_limits<double>::max()
                    };
                    size_type   best_cluster { 0 };

                    for (size_type cluster { 0 }; cluster < K; ++cluster)  {
                        const double    distance {
                            dfunc_(value, result_[cluster])
                        };

                        if (distance < best_distance)  {
                            best_distance = distance;
                            best_cluster = cluster;
                        }
                    }

                    // Sum up and count points for each cluster.
                    //
                    auto    &nm { new_means[best_cluster] };

                    nm = nm + value;
                    counts[best_cluster] += 1.0;
                }
            }

            bool    done { true };

            // Divide sums by counts to get new centroids. A cluster that
            // picked up no points this pass is left at its previous
            // centroid -- there is nothing to average, and the old
            // 0/0 -> 0/1 guard was substituting a fabricated value_type()
            // (0 for arithmetic T), silently teleporting an empty
            // cluster's centroid to zero instead of leaving it alone.
            //
            for (size_type cluster { 0 }; cluster < K; ++cluster) [[likely]]  {
                if (counts[cluster] > 0.0)  {
                    const value_type    value {
                        new_means[cluster] / counts[cluster]
                    };
                    value_type          &result { result_[cluster] };

                    if (dfunc_(value, result) > 0.0000001)  {
                        done = false;
                        result = value;
                    }
                }
            }

            if (done)  break;
        }
    }

    // Using the calculated means, separate the given column into clusters
    //
    template<typename H>
    inline void
    calc_clusters_(const H &column_begin, size_type col_s)  {

        cluster_type    clusters;
        order_type      clusters_idxs;

        for (size_type i { 0 }; i < K; ++i) [[likely]]  {
            clusters[i].reserve(col_s / K + 2);
            clusters[i].push_back(&(result_[i]));
            clusters_idxs[i].reserve(col_s / K + 2);
        }

        for (size_type j { 0 }; j < col_s; ++j) [[likely]]  {
            const value_type    &value { *(column_begin + j) };

            if (! is_nan__(value)) [[likely]]  {
                double      min_dist { std::numeric_limits<double>::max() };
                size_type   min_idx { 0 };

                for (size_type i { 0 }; i < K; ++i)  {
                    const double    dist { dfunc_(value, result_[i]) };

                    if (dist < min_dist)  {
                        min_dist = dist;
                        min_idx = i;
                    }
                }
                clusters[min_idx].push_back(&value);
                clusters_idxs[min_idx].push_back(j);
            }
        }

        clusters_.swap(clusters);
        clusters_idxs_.swap(clusters_idxs);
    }

public:

    template<typename IV, typename H>
    inline void
    operator()(const IV &idx_begin, const IV &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        calc_k_means_(column_begin, col_s);
        if (cc_)  calc_clusters_(column_begin, col_s);
    }

    inline void pre()  {

        for (auto &iter : clusters_) iter.clear();
        for (auto &iter : clusters_idxs_) iter.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline const cluster_type &get_clusters() const  { return (clusters_); }
    inline cluster_type &get_clusters()  { return (clusters_); }
    inline const order_type &
    get_clusters_idxs() const  { return (clusters_idxs_); }

    explicit
    KMeansVisitor(size_type num_of_iter,
                  bool calc_clusters = true,
                  distance_func f =
                      [](const value_type &x, const value_type &y) -> double  {
                          return ((x - y) * (x - y));
                      },
                  seed_t seed = seed_t(-1))
        : iter_num_(num_of_iter),
          cc_(calc_clusters),
          seed_(seed),
          dfunc_(f) {  }
};

// ------------------------------------------------------------------------------

// Time complexity is O(I*n^2) where I is number of iterations
// Space complexity is O(n^2)
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AffinityPropVisitor  {

public:

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using result_type = VectorConstPtrView<value_type, A>;
    using cluster_type = vec_t<VectorConstPtrView<value_type, A>>;
    using order_type =
        std::vector<std::vector<
                        size_type,
                        typename allocator_declare<size_type, A>::type>>;
    using distance_func =
        std::function<double(const value_type &x, const value_type &y)>;

private:

    const size_type iter_num_;
    const bool      cc_;
    const double    dfactor_;
    distance_func   dfunc_;
    result_type     result_ { };         // Centers
    cluster_type    clusters_ { };       // Clusters
    order_type      clusters_idxs_ { };  // Clusters indices

    // Symmetric access into the packed (upper-triangular-inclusive)
    // similarity array. sim(i, j) == sim(j, i), but get_similarity_()
    // only ever physically stores the i <= j half -- a lookup with
    // i > j must swap to the row that was actually filled, rather
    // than reusing row i's own packed offset (which, for a column
    // less than i, silently lands on some unrelated pair's entry).
    //
    static inline double
    sim_at_(const vec_t<double> &simil, long i, long j, long col_s)  {

        if (i <= j)
            return (simil[(i * col_s) - ((i * (i + 1)) >> 1) + j]);
        return (simil[(j * col_s) - ((j * (j + 1)) >> 1) + i]);
    }

    template<typename H>
    inline vec_t<double>
    get_similarity_(const H &column_begin, long col_s)  {

        vec_t<double>   simil((col_s * (col_s + 1)) / 2, 0.0);
        double          min_dist { std::numeric_limits<double>::max() };

        // Compute similarity between distinct data points i and j
        //
        for (long i { 0 }; i < col_s - 1; ++i) [[likely]]  {
            const value_type    &i_val { *(column_begin + i) };
            const long          i_idx { (i * col_s) - ((i * (i + 1)) >> 1) };

            for (long j { i + 1 }; j < col_s; ++j)  [[likely]]  {
                const double    dist { -dfunc_(i_val, *(column_begin + j)) };

                simil[i_idx + j] = dist;
                if (dist < min_dist)  min_dist = dist;
            }
        }

        // Assign min to diagonals
        //
        for (long i { 0 }; i < col_s; ++i)
            simil[(i * col_s) + i - ((i * (i + 1)) >> 1)] = min_dist;

        return (simil);
    }

    inline void
    get_avail_and_respon_(const vec_t<double> &simil,
                          long col_s,
                          vec_t<double> &avail,
                          vec_t<double> &respon)  {

        avail.resize(col_s * col_s, 0.0);
        respon.resize(col_s * col_s, 0.0);

        const double    one_df { 1.0 - dfactor_ };

        for (size_type m { 0 }; m < iter_num_; ++m) [[likely]]  {
            // Update responsibility:
            //   r(i, k) = s(i, k) - max_{k' != k} [a(i, k') + s(i, k')]
            //
            // For fixed i, "max excluding k" only ever needs the
            // overall max and, for whichever k achieves it, the
            // second-highest value -- both obtainable in one O(n)
            // pass instead of redoing an O(n) search for every k
            // (which made this O(n^2) per row / O(n^3) per iteration
            // instead of the documented O(n) per row / O(n^2) total).
            //
            for (long i = 0; i < col_s; ++i) [[likely]]  {
                double  max1 { -std::numeric_limits<double>::max() };
                double  max2 { -std::numeric_limits<double>::max() };
                long    argmax1 { -1 };

                for (long jj { 0 }; jj < col_s; ++jj) [[likely]]  {
                    const double    value {
                        sim_at_(simil, i, jj, col_s) + avail[jj * col_s + i]
                    };

                    if (value > max1)  {
                        max2 = max1;
                        max1 = value;
                        argmax1 = jj;
                    }
                    else if (value > max2)
                        max2 = value;
                }

                for (long j { 0 }; j < col_s; ++j) [[likely]]  {
                    const double    max_diff { (j == argmax1) ? max2 : max1 };
                    const long      j_idx { j * col_s + i };

                    respon[j_idx] =
                        one_df * (sim_at_(simil, i, j, col_s) - max_diff) +
                        dfactor_ * respon[j_idx];
                }
            }

            // Update availability
            // Do diagonals first
            //
            for (long i { 0 }; i < col_s; ++i) [[likely]]  {
                const long  s1 { i * col_s };
                const long  s2 { i * col_s + i };
                double      sum { 0.0 };

                for (long ii { 0 }; ii < col_s; ++ii) [[likely]]
                    if (ii ^ i)
                        sum += std::max(0.0, respon[s1 + ii]);

                avail[s2] = one_df * sum + dfactor_ * avail[s2];
            }

            // Off-diagonals: a(i, j) needs
            // sum_{i' not in {i, j}} max(0, r(i', j)) for every i, with
            // j fixed. Rather than rescanning all n indices for every
            // (i, j) pair (O(n) work x O(n^2) pairs = O(n^3) per
            // iteration), compute the column total once per j --
            // sum_{i' != j} max(0, r(i', j)), O(n) -- and reuse it for
            // every i by subtracting out just the i'=i term.
            //
            for (long j { 0 }; j < col_s; ++j) [[likely]]  {
                const long  s1 { j * col_s };
                double      total_j { 0.0 };

                for (long ii { 0 }; ii < col_s; ++ii) [[likely]]
                    if (ii ^ j)
                        total_j += std::max(0.0, respon[s1 + ii]);

                for (long i { 0 }; i < col_s; ++i) [[likely]]  {
                    if (i ^ j) [[likely]]  {  // Not equal
                        const long      s2 { j * col_s + i };
                        const double    sum {
                            total_j - std::max(0.0, respon[s1 + i])
                        };

                        avail[s2] =
                            one_df *
                            std::min(0.0, respon[s1 + j] + sum) + dfactor_ *
                            avail[s2];
                    }
                }
            }
        }
    }

    // Using the calculated means, separate the given column into clusters
    //
    template<typename H>
    inline void
    calc_clusters_(const H &column_begin, long col_s)  {

        const long  centers_size { long(result_.size()) };

        if (! centers_size)  return;

        const auto  resv { col_s / centers_size };

        clusters_.resize(centers_size);
        clusters_idxs_.resize(centers_size);
        for (long i { 0 }; i < centers_size; ++i)  {
            clusters_[i].reserve(resv);
            clusters_idxs_[i].reserve(resv);
        }

        for (long j { 0 }; j < col_s; ++j) [[likely]]  {
            const value_type    &j_val { *(column_begin + j) };
            double              min_dist { dfunc_(j_val, result_[0]) };
            long                min_idx { 0 };

            for (long i { 1 }; i < centers_size; ++i)  {
                const double    dist { dfunc_(j_val, result_[i]) };

                if (dist < min_dist)  {
                    min_dist = dist;
                    min_idx = i;
                }
            }
            clusters_[min_idx].push_back(&j_val);
            clusters_idxs_[min_idx].push_back(size_type(j));
        }
    }

public:

    template<typename IV, typename H>
    inline void
    operator()(const IV &idx_begin, const IV &idx_end,
               const H &column_begin, const H &column_end)  {

        const long  col_s {
            long(std::min(std::distance(idx_begin, idx_end),
                          std::distance(column_begin, column_end)))
        };

        const vec_t<double> simil = get_similarity_(column_begin, col_s);
        vec_t<double>       avail;
        vec_t<double>       respon;

        get_avail_and_respon_(simil, col_s, avail, respon);

        result_.reserve(std::min(col_s / 100, long(16)));
        for (long i { 0 }; i < col_s; ++i) [[likely]]  {
            const long  idx { i * col_s + i };

            if (respon[idx] + avail[idx] > 0.0)
                result_.push_back(&*(column_begin + i));
        }

        if (cc_)  calc_clusters_(column_begin,  col_s);
    }

    inline void pre()  {

        result_.clear();
        clusters_.clear();
        clusters_idxs_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline const cluster_type &get_clusters() const  { return (clusters_); }
    inline cluster_type &get_clusters()  { return (clusters_); }
    inline const order_type &
    get_clusters_idxs() const  { return (clusters_idxs_); }

    explicit
    AffinityPropVisitor(size_type num_of_iter,
                        bool calc_clusters = true,
                        distance_func f =
                            [](const value_type &x,
                               const value_type &y) -> double  {
                                return ((x - y) * (x - y));
                            },
                        double damping_factor = 0.9)
        : iter_num_(num_of_iter),
          cc_(calc_clusters),
          dfactor_(damping_factor), dfunc_(f)  {   }
};

// ------------------------------------------------------------------------------

// Density-Based Spatial Clustering of Applications with Noise
// Average runtime complexity is O(n log n). The worst case is O(n^2).
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  DBSCANVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

public:

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using result_type = vec_t<VectorConstPtrView<value_type, A>>;
    using order_type =
        std::vector<std::vector<
                        size_type,
                        typename allocator_declare<size_type, A>::type>>;
    using distance_func =
        std::function<double(const value_type &x, const value_type &y)>;

private:

    using id_t = long;

    static constexpr id_t   UNCLASSIFIED { -1 };
    static constexpr id_t   NOISE { -2 };

    inline static distance_func
    get_dist_func_()  {

        if constexpr (! is_md_)
            return ([](const T &x, const T &y) -> double  {
                        return (static_cast<double>((x - y) * (x - y)));
                    });
        else
            return ([](const T &x, const T &y) -> double  {
                        double  sum { 0 };

                        for (size_type i { 0 }; i < size_type(x.size()); ++i)  {
                            const double    diff { x[i] - y[i] };

                            sum += diff * diff;
                        }
                        return (std::sqrt(sum));
                    });
    }

    template<typename H>
    inline void
    calculate_cluster_(const H &column_begin,
                       const id_t column_idx,
                       const id_t col_s,
                       vec_t<id_t> &cluster_index)  {

        const value_type    &value { *(column_begin + column_idx) };

        cluster_index.clear();
        for (id_t i { 0 }; i < col_s; ++i)  {
            if (dfunc_(value, *(column_begin + i)) <= max_dist_)
                cluster_index.push_back(i);
        }
    }

    template<typename H>
    inline bool
    expand_cluster_(const H &column_begin,
                    const id_t column_idx,
                    vec_t<id_t> &cluster_ids,
                    const id_t col_s,
                    const id_t cluster_id,
                    vec_t<id_t> &seeds,
                    vec_t<id_t> &cluster_neighors)  {

        calculate_cluster_(column_begin, column_idx, col_s, seeds);

        const id_t          seeds_s { id_t(seeds.size()) };
        const value_type    &value { *(column_begin + column_idx) };

        if (seeds_s < min_mems_)  {
            cluster_ids[column_idx] = NOISE;
            return (false);
        }

        id_t    core_index { 0 };

        for (id_t i { 0 }; i < seeds_s; ++i)  {
            const auto  seed_val { seeds[i] };

            cluster_ids[seed_val] = cluster_id;
            if (*(column_begin + seed_val) == value) [[unlikely]]
                core_index = i;
        }

        seeds.erase(seeds.begin() + core_index);
        for (id_t i { 0 }, n { id_t(seeds.size()) }; i < n; ++i)  {
            calculate_cluster_(column_begin, seeds[i], col_s, cluster_neighors);

            if (id_t(cluster_neighors.size()) >= min_mems_)  {
                for (id_t j { 0 }; j < id_t(cluster_neighors.size()); ++j)  {
                    auto    &cluster_val { cluster_ids[cluster_neighors[j]] };

                    if (cluster_val < 0)  {  // NOISE or UNCLASSIFIED
                        if (cluster_val == UNCLASSIFIED)  {
                            seeds.push_back(cluster_neighors[j]);
                            n = id_t(seeds.size());
                        }
                        cluster_val = cluster_id;
                    }
                }
            }
        }

        return (true);
    }

public:

    template<typename IV, typename H>
    inline void
    operator()(const IV &idx_begin, const IV &idx_end,
               const H &column_begin, const H &column_end)  {

        const id_t  col_s {
            id_t(std::min(std::distance(idx_begin, idx_end),
                          std::distance(column_begin, column_end)))
        };
        vec_t<id_t> cluster_ids(col_s, UNCLASSIFIED);
        vec_t<id_t> seeds;
        vec_t<id_t> cluster_neighors;
        id_t        cluster_id { 0 };

        seeds.reserve(col_s / 20);
        cluster_neighors.reserve(col_s / 20);
        for (id_t i { 0 }; i < col_s; ++i)  {
            if (cluster_ids[i] == UNCLASSIFIED &&
                expand_cluster_(column_begin,
                                i,
                                cluster_ids,
                                col_s,
                                cluster_id,
                                seeds,
                                cluster_neighors))  {
                cluster_id += 1;
            }
        }

        // cluster_id stays 0 whenever every point ends up NOISE (a
        // legitimate outcome for sparse data or a tight max_dist_/high
        // min_mems_, not just a contrived edge case) -- guard against
        // dividing by it. The value is moot when cluster_id is 0 anyway,
        // since the per-cluster reserve loop right below never runs.
        //
        const auto  resv { cluster_id > 0 ? col_s / cluster_id : 0 };

        clusters_.resize(cluster_id);
        clusters_idxs_.resize(cluster_id);
        noisey_idxs_.reserve(std::max(id_t(8), id_t(col_s / 500)));
        for (long i { 0 }; i < cluster_id; ++i)  {
            clusters_[i].reserve(resv);
            clusters_idxs_[i].reserve(resv);
        }
        for (id_t i { 0 }; i < col_s; ++i)  {
            const auto  this_id { cluster_ids[i] };

            if (this_id >= 0) [[likely]]  {
                clusters_[this_id].push_back(&(*(column_begin + i)));
                clusters_idxs_[this_id].push_back(i);
            }
            else [[unlikely]]  { noisey_idxs_.push_back(size_type(i)); }
        }
    }

    inline void set_dist_func(distance_func &&f)  { dfunc_ = f; }

    inline void pre()  {

        clusters_.clear();
        clusters_idxs_.clear();
        noisey_idxs_.clear();
    }
    inline void post()  {  }

    inline const result_type &get_result() const  { return (clusters_); }
    inline const order_type &
    get_clusters_idxs() const  { return (clusters_idxs_); }
    inline const vec_t<size_type> &
    get_noisey_idxs() const  { return (noisey_idxs_); }

    DBSCANVisitor(id_t min_mems, double max_dist)
        : min_mems_(min_mems),
          max_dist_(max_dist)  { dfunc_ = get_dist_func_(); }

private:

    const id_t          min_mems_;
    const double        max_dist_;
    distance_func       dfunc_ { };
    result_type         clusters_ { };       // Clusters
    order_type          clusters_idxs_ { };  // Clusters indices
    vec_t<size_type>    noisey_idxs_ { };    // Indices of noisey elements
};

// ------------------------------------------------------------------------------

// Runtime complexity is O(I * n^2) where I is number of iterations.
//
// Type T must have arithmetic operators and default constructor well defined
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  MeanShiftVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

public:

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using inner_ptr_view_t = VectorConstPtrView<value_type, A>;
    using result_type = vec_t<inner_ptr_view_t>;
    using inner_order_t =
        std::vector<size_type, typename allocator_declare<size_type, A>::type>;
    using order_type = std::vector<inner_order_t>;
    using distance_func =
        std::function<double(const value_type &x, const value_type &y)>;

private:

    inline static distance_func
    get_dist_func_()  {

        if constexpr (! is_md_)
            return ([](const T &x, const T &y) -> double  {
                        return (static_cast<double>((x - y) * (x - y)));
                    });
        else
            return ([](const T &x, const T &y) -> double  {
                        double  sum { 0 };

                        for (size_type i { 0 }; i < size_type(x.size()); ++i)  {
                            const double    diff { x[i] - y[i] };

                            sum += diff * diff;
                        }
                        return (std::sqrt(sum));
                    });
    }

    inline static double uniform_kernel_(double d)  {

        return (d <= 1.0 ? 1.0 : 0.0);
    }

    inline static double triangular_kernel_(double d)  {

        return (d <= 1.0 ? 1.0 - std::fabs(d) : 0.0);
    }

    inline static double parabolic_kernel_(double d)  {

        return (d <= 1.0 ? 1.0 - d * d : 0.0);
    }

    inline static double biweight_kernel_(double d)  {

        const auto  x { 1.0 - d * d };

        return (d <= 1.0 ? x * x : 0.0);
    }

    inline static double triweight_kernel_(double d)  {

        const auto  x { 1.0 - d * d };

        return (d <= 1.0 ? x * x * x : 0.0);
    }

    inline static double tricube_kernel_(double d)  {

        const auto  x { 1.0 - d * d * d };

        return (d <= 1.0 ? x * x * x : 0.0);
    }

    inline static double gaussian_kernel_(double d)  {

        return (std::exp(-0.5 * d * d));
    }

    inline static double cosin_kernel_(double d)  {

        return (d <= 1.0 ? std::cos(M_PI_2 * d) : 0.0);
    }

    inline static double logistic_kernel_(double d)  {

        return (1.0 / (2.0 + std::exp(d) + std::exp(-d)));
    }

    inline static double sigmoid_kernel_(double d)  {

        return (1.0 / (std::exp(d) + std::exp(-d)));
    }

    inline static double silverman_kernel_(double d)  {

        const auto  x { M_SQRT1_2 * std::abs(d) };

        return (std::exp(-x) * std::sin(x + M_PI_4));
    }

    // Convergence is "did this iteration's shift move the point much
    // from where IT was", not "is the point still near where it
    // started" -- comparing against the original, untouched data
    // (column_begin) instead of the point's own previous position
    // meant a point could freeze the moment its very first shift
    // happened to land within max_dist_ of its start, regardless of
    // whether it had reached its actual density mode. The freshly
    // computed position is always the best estimate available, so it
    // is recorded unconditionally -- previously it was discarded
    // outright on the very iteration convergence was detected.
    //
    inline void
    shift_(size_type index,
           const value_type &val,
           vec_t<value_type> &shifted,
           vec_t<bool> &shifting)  {

        if (dfunc_(val, shifted[index]) <= max_dist_)
            shifting[index] = false;
        shifted[index] = val;
    }


    template<typename H>
    inline void
    build_cluster_(const H &column_begin,
                   size_type col_s,
                   vec_t<value_type> &shifted)  {

        vec_t<value_type>   centriods;

        // Shifted points with distance <= max_dist_ go in the same cluster
        //
        centriods.reserve(32);
        clusters_.reserve(32);
        clusters_idxs_.reserve(32);
        for (size_type i { 0 }; i < shifted.size(); ++i)  {
            const auto  &shifted_val { shifted[i] };
            auto        cbegin { clusters_.begin() };
            auto        cend { clusters_.end() };
            auto        ibegin { clusters_idxs_.begin() };
            size_type   cnt_idx { 0 };

            while (cbegin != cend)  {
                if (dfunc_(centriods[cnt_idx], shifted_val) <= max_dist_)  {
                    // The point belongs to a cluster already created
                    //
                    cbegin->push_back(&(*(column_begin + i)));
                    ibegin->push_back(i);
                    break;
                }
                ++cbegin;
                ++ibegin;
                ++cnt_idx;
            }
            if (cbegin == cend)  {  // create a new cluster
                clusters_.push_back(inner_ptr_view_t { });
                clusters_idxs_.push_back(inner_order_t { });
                clusters_.back().reserve(
                    std::max(size_type(8), col_s / size_type(32)));
                clusters_idxs_.back().reserve(
                    std::max(size_type(8), col_s / size_type(32)));
                clusters_.back().push_back(&(*(column_begin + i)));
                clusters_idxs_.back().push_back(i);
                centriods.push_back(shifted_val);
            }
        }
    }

public:

    template<typename IV, typename H>
    inline void
    operator()(const IV &idx_begin, const IV &idx_end,
               const H &column_begin, const H &column_end)  {

        const size_type     col_s {
            size_type(std::min(std::distance(idx_begin, idx_end),
                               std::distance(column_begin, column_end)))
        };
        auto                k_func =
            (kernel_ == mean_shift_kernel::uniform) ? &uniform_kernel_
            : (kernel_ == mean_shift_kernel::triangular) ? &triangular_kernel_
            : (kernel_ == mean_shift_kernel::parabolic) ? &parabolic_kernel_
            : (kernel_ == mean_shift_kernel::biweight) ? &biweight_kernel_
            : (kernel_ == mean_shift_kernel::triweight) ? &triweight_kernel_
            : (kernel_ == mean_shift_kernel::tricube) ? &tricube_kernel_
            : (kernel_ == mean_shift_kernel::gaussian) ? &gaussian_kernel_
            : (kernel_ == mean_shift_kernel::cosin) ? &cosin_kernel_
            : (kernel_ == mean_shift_kernel::logistic) ? &logistic_kernel_
            : (kernel_ == mean_shift_kernel::sigmoid) ? &sigmoid_kernel_
            : &silverman_kernel_;
        vec_t<value_type>   shifted(column_begin, column_end);
        vec_t<bool>         shifting(col_s, true);
        size_type           iterations { 0 };

        // The kernel functions (uniform_kernel_, gaussian_kernel_, etc.)
        // are all written for a bandwidth-normalized argument -- the
        // d <= 1.0 cutoffs, and gaussian_kernel_'s textbook
        // exp(-0.5*d^2) shape, only mean what they look like they
        // mean when d is "how many bandwidths away", not a raw
        // distance. dfunc_ returns squared distance for scalar T and
        // true (already-rooted) Euclidean distance for MD T, so both
        // need converting to a true linear distance before dividing
        // by kband_. 3.0 (bandwidths) replaces the old radius, which
        // compared an un-normalized, type-inconsistent raw distance
        // against kband_*3.0.
        //
        constexpr double    radius { 3.0 };

        while (iterations++ < max_iter_ &&
               std::any_of(shifting.begin(), shifting.end(),
                           [](bool v) -> bool { return (v); }))  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                if (! shifting[i])  continue;

                value_type          new_val { };
                const value_type    &val_to_shift { shifted[i] };
                double              total_w { 0 };

                for (size_type j { 0 }; j < col_s; ++j)  {
                    const value_type    &this_val { *(column_begin + j) };
                    const double        raw_dist {
                        dfunc_(val_to_shift, this_val)
                    };
                    const double        lin_dist {
                        is_md_ ? raw_dist : std::sqrt(raw_dist)
                    };
                    const double        norm_dist { lin_dist / kband_ };

                    if (norm_dist <= radius)  {
                        const double    weight { k_func(norm_dist) };

                        new_val = new_val + (this_val * weight);
                        total_w += weight;
                    }
                }

                // The new position of value is the weighted average of
                // its neighbors
                //
                new_val = new_val / total_w;
                shift_(i, new_val, shifted, shifting);
            }
        }

        build_cluster_(column_begin, col_s, shifted);
    }

    inline void set_dist_func(distance_func &&f)  { dfunc_ = f; }

    inline void pre()  { clusters_.clear(); clusters_idxs_.clear(); }
    inline void post()  {  }

    inline const result_type &get_result() const  { return (clusters_); }
    inline const order_type &
    get_clusters_idxs() const  { return (clusters_idxs_); }

    MeanShiftVisitor(double kernel_bandwidth,
                     double max_dist,
                     mean_shift_kernel kernel = mean_shift_kernel::gaussian,
                     size_type max_iteration = 50)
        : kband_(kernel_bandwidth),
          kernel_(kernel),
          max_iter_(max_iteration),
          max_dist_(max_dist)  { dfunc_ = get_dist_func_();  }

private:

    const double            kband_; // Kernel is fancy name for distance weight
    const mean_shift_kernel kernel_;
    const size_type         max_iter_;
    const double            max_dist_;
    distance_func           dfunc_ { };
    result_type             clusters_ { };       // Clusters
    order_type              clusters_idxs_ { };  // Clusters indices
};

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  FastFourierTransVisitor  {

private:

    static constexpr bool   IS_SCALAR {
        std::is_arithmetic_v<T> || is_complex<T>::value
    };

    using data_t = typename std::conditional_t<IS_SCALAR,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;
    template<typename U>
    using matrix_t = Matrix<U, matrix_orient::row_major>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using channel_result_t =
        typename std::conditional_t<is_complex<data_t>::value,
                                    vec_t<data_t>,
                                    vec_t<std::complex<data_t>>>;

    using cplx_t = typename channel_result_t::value_type;
    using real_t = typename cplx_t::value_type;

    using result_type = typename std::conditional_t<IS_SCALAR,
                                                    channel_result_t,
                                                    matrix_t<cplx_t>>;
    using magnitude_type = typename std::conditional_t<IS_SCALAR,
                                                       vec_t<real_t>,
                                                       matrix_t<real_t>>;
    using angle_type = magnitude_type;

private:

    static inline channel_result_t
    convolve_(channel_result_t xvec, channel_result_t yvec, long thread_level) {

        transform_(xvec, false, thread_level);
        transform_(yvec, false, thread_level);
        xvec *= yvec;
        transform_(xvec, true, thread_level);

        xvec /= cplx_t(data_t(xvec.size()));
        return (xvec);
    }

    static inline size_type
    reverse_bits_(size_type val, size_type width)  {

        size_type   result { 0 };

        for (size_type i { 0 }; i < width; i++, val >>= 1) [[likely]]
            result = (result << 1) | (val & 1U);
        return (result);
    }

    static inline void
    fft_radix2_(channel_result_t &column, bool reverse, long thread_level)  {

        const size_type col_s { column.size() };
        size_type       levels { 0 };

        // Compute levels = floor(log2(col_s))
        //
        for (size_type i { col_s }; i > 1; i >>= 1) [[likely]]
            levels += 1;

        // Trigonometric table
        //
        const size_type     half_col_s { col_s / 2 };
        const real_t        two_pi
            { (reverse ? real_t(2) : -real_t(2)) * real_t(M_PI) };
        channel_result_t    exp_table (half_col_s);

        if (thread_level > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    half_col_s,
                    [&exp_table, two_pi, col_s]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]
                            exp_table[i] =
                                std::polar(real_t(1),
                                           two_pi * real_t(i) / real_t(col_s));
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            for (size_type i { 0 }; i < half_col_s; i++) [[likely]]
                exp_table[i] =
                    std::polar(real_t(1), two_pi * real_t(i) / real_t(col_s));
        }

        // Bit-reversed addressing permutation
        //
        for (size_type i { 0 }; i < col_s; i++) [[likely]]  {
            const size_type rb { reverse_bits_(i, levels) };

            if (rb > i)  std::swap(column[i], column[rb]);
        }

        // Cooley-Tukey decimation-in-time radix-2 FFT
        //
        for (size_type s = 2; s <= col_s; s *= 2) [[likely]]  {
            const size_type half_size { s / 2 };
            const size_type table_step { col_s / s };

            for (size_type i { 0 }; i < col_s; i += s) [[likely]]  {
                for (size_type j { i }, k = 0; j < i + half_size;
                     j++, k += table_step) [[likely]]  {
                    const cplx_t    temp
                        { column[j + half_size] * exp_table[k] };

                    column[j + half_size] = column[j] - temp;
                    column[j] += temp;
                }
            }
        }
    }

    static inline void
    fft_bluestein_(channel_result_t &column, bool reverse, long thread_level)  {

        const size_type col_s { column.size() };

        // Trigonometric table
        //
        channel_result_t    exp_table (col_s);
        const size_type     col_s_2 { col_s * 2 };
        const real_t        pi { reverse ? real_t(M_PI) : -real_t(M_PI) };

        if (thread_level > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&exp_table, pi, col_s, col_s_2]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]  {
                            const real_t    sq = real_t((i * i) % col_s_2);

                            exp_table[i] =
                                std::polar(real_t(1), pi * sq / real_t(col_s));
                        }
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            for (size_type i { 0 }; i < col_s; i++) [[likely]]  {
                const real_t    sq = real_t((i * i) % col_s_2);

                exp_table[i] = std::polar(real_t(1), pi * sq / real_t(col_s));
            }
        }

        // Find a power of 2 convolution length m such that m >= col_s * 2 + 1
        //
        size_type   m { 1 };

        while (m / 2 <= col_s)   m *= 2;

        // Temporary vectors and preprocessing
        //
        channel_result_t    xvec (m, cplx_t(0, 0));

        if (thread_level > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&exp_table, &xvec, &column]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]
                            xvec[i] = column[i] * exp_table[i];
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            for (size_type i = 0; i < col_s; i++) [[likely]]
                xvec[i] = column[i] * exp_table[i];
        }

        channel_result_t    yvec(m, cplx_t(0, 0));

        yvec[0] = exp_table[0];
        if (thread_level > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(1),
                    col_s,
                    [&exp_table, &yvec, m]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]
                            yvec[i] = yvec[m - i] = std::conj(exp_table[i]);
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            for (size_type i { 1 }; i < col_s; i++) [[likely]]
                yvec[i] = yvec[m - i] = std::conj(exp_table[i]);
        }

        // Convolution
        //
        const channel_result_t  conv (convolve_(std::move(xvec),
                                      std::move(yvec),
                                      thread_level));

        // Postprocessing
        //
        if (thread_level > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    exp_table.size(),
                    [&exp_table, &conv, &column]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]
                            column[i] = exp_table[i] * conv[i];
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(exp_table.begin(), exp_table.end(),
                           conv.begin(), column.begin(),
                           std::multiplies<cplx_t>());
        }
    }

    static inline void
    transform_(channel_result_t &column, bool reverse, long thread_level)  {

        const size_type col_s { column.size() };

        if (col_s == 0) [[unlikely]]
            return;
        if ((col_s & (col_s - 1)) == 0)  // Is power of 2
            fft_radix2_(column, reverse, thread_level);
        else  // More complicated algorithm for arbitrary sizes
            fft_bluestein_(column, reverse, thread_level);
    }

    static inline void
    itransform_(channel_result_t &column, long thread_level)  {

        const size_type col_s { column.size() };

        // Conjugate the complex numbers
        //
        if (thread_level > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&column]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]  {
                            auto    &val = column[i];

                            val = std::conj(val);
                        }
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column.begin(), column.end(),
                           column.begin(),
                           [] (const cplx_t &v) -> cplx_t  {
                               return (std::conj(v));
                           });
        }

        // Forward fft
        //
        if ((col_s & (col_s - 1)) == 0)  // Is power of 2
            fft_radix2_(column, false, thread_level);
        else  // More complicated algorithm for arbitrary sizes
            fft_bluestein_(column, false, thread_level);

        // Conjugate the complex numbers again
        // Then scale the numbers
        //
        if (thread_level > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&column]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]  {
                            auto    &val = column[i];

                            val = std::conj(val);
                        }
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column.begin(), column.end(),
                           column.begin(),
                           [](const cplx_t &v) -> cplx_t  {
                               return (std::conj(v));
                           });
        }

        column /= cplx_t(data_t(col_s));
    }

    template<typename SCALAR, typename H>
    inline void
    fill_channel_(channel_result_t &channel,
                  const H &col_begin,
                  size_type col_s) const  {

        if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&col_begin, &channel]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]  {
                            const SCALAR    val =
                                static_cast<SCALAR>(*(col_begin + i));

                            if constexpr (is_complex<SCALAR>::value)
                                channel[i] = val;
                            else
                                channel[i] = cplx_t(val, real_t(0));
                        }
                    });

            for (auto &fut : futures)  fut.get();
        }
        else  {
            if constexpr (is_complex<SCALAR>::value)  {
                std::transform(col_begin, col_begin + col_s,
                               channel.begin(),
                               [](SCALAR v) -> cplx_t  { return (v); });
            }
            else  {
                std::transform(col_begin, col_begin + col_s,
                               channel.begin(),
                               [](SCALAR v) -> cplx_t  {
                                   return (cplx_t(v, real_t(0)));
                               });
            }
        }
    }

public:

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        if constexpr (IS_SCALAR)  {
            result_type result (col_s);

            fill_channel_<T>(result, column_begin, col_s);
            if (inverse_)
                itransform_(result, thread_level_);
            else
                transform_(result, false, thread_level_);
            result_.swap(result);
        }
        else  {
            const size_type dim { column_begin->size() };

#ifdef HMDF_SANITY_EXCEPTIONS
            for (size_type i { 0 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "FastFourierTransVisitor: Inconsistent data dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

            result_.resize(col_s, dim);
            for (size_type d { 0 }; d < dim; ++d)  {
                channel_result_t    channel (col_s);

                // Populate channel from the d-th component.
                //
                if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<T>(
                            size_type(0),
                            col_s,
                            [&column_begin, &channel, d]
                            (auto begin, auto end) -> void  {
                                for (size_type i { begin }; i < end; ++i)  {
                                    const auto  &elem = *(column_begin + i);

                                    if constexpr (is_complex<T>::value)
                                        channel[i] = elem[d];
                                    else
                                        channel[i] = cplx_t(elem[d], real_t(0));
                                }
                            });

                    for (auto &fut : futures)  fut.get();
                }
                else  {
                    for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
                        const auto  &elem = *(column_begin + i);

                        if constexpr (is_complex<T>::value)
                            channel[i] = elem[d];
                        else
                            channel[i] = cplx_t(elem[d], real_t(0));
                    }
                }

                // Transform the channel.
                //
                if (inverse_)
                    itransform_(channel, thread_level_);
                else
                    transform_(channel, false, thread_level_);

                // Scatter back into result_.
                //
                if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<T>(
                            size_type(0),
                            col_s,
                            [&channel, this, d]
                            (auto begin, auto end) -> void  {
                                for (size_type i { begin }; i < end; ++i)
                                    this->result_(i, d) = channel[i];
                            });

                    for (auto &fut : futures)  fut.get();
                }
                else  {
                    for (size_type i { 0 }; i < col_s; ++i) [[likely]]
                        result_(i, d) = channel[i];
                }
            }
        }
    }

    inline void pre ()  {

        result_.clear();
        magnitude_.clear();
        angle_.clear();
    }
    inline void post ()  {  }

    inline const result_type &get_result () const  { return (result_); }
    inline result_type &get_result ()  { return (result_); }

    inline const magnitude_type &
    get_magnitude() const  {

        return (const_cast<FastFourierTransVisitor<T, I> *>
                    (this)->get_magnitude());
    }
    inline magnitude_type &
    get_magnitude()  {

        if (magnitude_.empty())  {
            if constexpr (IS_SCALAR)  {
                const size_type col_s { result_.size() };

                magnitude_.resize(col_s);
                if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                            size_type(0),
                            col_s,
                            [this]
                            (auto begin, auto end) -> void  {
                                for (size_type i { begin }; i < end; ++i)
                                    this->magnitude_[i] =
                                        std::sqrt(std::norm(this->result_[i]));
                            });

                    for (auto &fut : futures)  fut.get();
                }
                else  {
                    for (size_type i { 0 }; const auto &citer : result_)
                        magnitude_[i++] = std::sqrt(std::norm(citer));
                }
            }
            else  {
                const size_type col_s { size_type(result_.rows()) };
                const size_type dim { size_type(result_.cols()) };

                magnitude_.resize(col_s, dim);
                if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<T>(
                            size_type(0),
                            col_s,
                            [this, dim]
                            (auto begin, auto end) -> void  {
                                for (size_type i { begin }; i < end; ++i)
                                    for (size_type d { 0 }; d < dim; ++d)
                                        this->magnitude_(i, d) =
                                            std::sqrt(
                                                std::norm(this->result_(i, d)));
                            });

                    for (auto &fut : futures)  fut.get();
                }
                else  {
                    for (size_type i { 0 }; i < col_s; ++i) [[likely]]
                        for (size_type d { 0 }; d < dim; ++d)
                            magnitude_(i, d) =
                                std::sqrt(std::norm(result_(i, d)));
                }
            }
        }

        return (magnitude_);
    }
    inline const angle_type &
    get_angle() const  {

        return (const_cast<FastFourierTransVisitor<T, I> *>(this)->get_angle());
    }
    inline angle_type &
    get_angle()  {

        if (angle_.empty())  {
            if constexpr (IS_SCALAR)  {
                const size_type col_s { result_.size() };

                angle_.resize(col_s);
                if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                            size_type(0),
                            col_s,
                            [this]
                            (auto begin, auto end) -> void  {
                                for (size_type i { begin }; i < end; ++i)
                                    this->angle_[i] = std::arg(this->result_[i]);
                            });

                    for (auto &fut : futures)  fut.get();
                }
                else  {
                    for (size_type i { 0 }; const auto &citer : result_)
                        angle_[i++] = std::arg(citer);
                }
            }
            else  {
                const size_type col_s { result_.rows() };
                const size_type dim { result_.cols() };

                angle_.resize(col_s, dim);
                if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                            size_type(0),
                            col_s,
                            [this, dim]
                            (auto begin, auto end) -> void  {
                                for (size_type i { begin }; i < end; ++i)
                                    for (size_type d { 0 }; d < dim; ++d)
                                        this->angle_(i, d) =
                                            std::arg(this->result_(i, d));
                            });

                    for (auto &fut : futures)  fut.get();
                }
                else  {
                    for (size_type i { 0 }; i < col_s; ++i) [[likely]]
                        for (size_type d { 0 }; d < dim; ++d)
                            angle_(i, d) = std::arg(result_(i, d));
                }
            }
        }

        return (angle_);
    }

    explicit
    FastFourierTransVisitor(bool inverse = false)
        : inverse_(inverse),
          thread_level_(ThreadGranularity::get_thread_level())  {   }

private:

    const bool      inverse_;
    const long      thread_level_;
    result_type     result_ {  };
    magnitude_type  magnitude_ {  };
    angle_type      angle_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using fft_v = FastFourierTransVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  EntropyVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<data_t>,
                                    vec_t<std::vector<data_t>>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type  col_s {
            size_type(std::distance(column_begin, column_end))
        };

        if constexpr (is_md_)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "EntropyVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        if (roll_count_ == 0)  return;

        SimpleRollAdopter<SumVisitor<T, I>, T, I, A>  sum_v {
            SumVisitor<T, I>(), roll_count_
        };

        sum_v.pre();
        sum_v(idx_begin, idx_end, column_begin, column_end);
        sum_v.post();

        result_type     result;
        const data_t    log_log_base { std::log(log_base_) };
        auto            lbd =
            [&column_begin, &result, log_log_base]
             (auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)  {
                    if constexpr (is_md_)  {
                        auto    &r { result[i] };

                        if (r.empty())
                            r.resize(column_begin->size(), get_nan<data_t>());

                        const auto                 &val_ref {
                            *(column_begin + i) / r
                        };
                        const std::vector<data_t>   val (val_ref.begin(),
                                                         val_ref.end());

                        r = (data_t(-1) * val) * (_bc_log_(val) / log_log_base);
                    }
                    else  {
                        auto        &r { result[i] };
                        const auto  val { *(column_begin + i) / r };

                        r = (data_t(-1) * val) * (_bc_log_(val) / log_log_base);
                    }
                }
            };

        if constexpr (is_md_)
            result.assign(sum_v.get_result().begin(), sum_v.get_result().end());
        else
            result = sum_v.get_result();
        if (result.size() >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        result.size(),
                        std::move(lbd));

                for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(size_type(0), result.size());
        }

        sum_v.pre();
        sum_v(idx_begin, idx_end,  // the idx iterators are unused
              result.begin() + (roll_count_ - 1), result.end());
        sum_v.post();

        const size_type sz { sum_v.get_result().size() };

        if constexpr (! is_md_)  {
            for (size_type i { 0 }; i < roll_count_ - 1; ++i) [[likely]]
                result[i] = get_nan<data_t>();
            for (size_type i { 0 }; i < sz; ++i)
                result[i + (roll_count_ - 1)] = sum_v.get_result()[i];
        }
        else  {
            const std::vector<data_t>   nans(column_begin->size(),
                                             get_nan<data_t>());

            for (size_type i { 0 }; i < roll_count_ - 1; ++i) [[likely]]
                result[i] = nans;
            for (size_type i { 0 }; i < sz; ++i)  {
                if (sum_v.get_result()[i].empty())
                    result[i + (roll_count_ - 1)] = nans;
                else
                    result[i + (roll_count_ - 1)].assign(
                        sum_v.get_result()[i].begin(),
                        sum_v.get_result()[i].end());
            }
        }

        result_.swap(result);
    }

    inline void
    operator()(const index_type &, const value_type &val)  {
        obo_data_ = true;
        aux_val_vec_.push_back(val);
    }

    inline void pre()  {

        aux_val_vec_.clear();
        aux_idx_vec_.clear();
        obo_data_ = false;
        result_.clear();
    }
    inline void post()  {

        if (obo_data_)
            (*this)(aux_idx_vec_.begin(), aux_idx_vec_.end(),
                    aux_val_vec_.begin(), aux_val_vec_.end());
    }
    inline const result_type &get_result () const  { return (result_); }
    inline result_type &get_result ()  { return (result_); }

    explicit
    EntropyVisitor(size_type roll_count, data_t log_base = 2)
        : roll_count_(roll_count), log_base_(log_base)  {   }

private:

    using idx_vec = std::vector<I, typename allocator_declare<I, A>::type>;

    result_type aux_val_vec_ {  };
    idx_vec     aux_idx_vec_ {  };
    bool        obo_data_ { false };  // one-by-one data passing

    const size_type roll_count_;
    const data_t    log_base_;
    result_type     result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using ent_v = EntropyVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  ImpurityVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using equal_t =
        typename std::conditional_t<std::is_floating_point_v<data_t>,
                                    FloatEqual<data_t>,
                                    std::equal_to<data_t>>;

    using map_t =
        typename std::conditional_t<
            ! is_md_,
            std::unordered_map<T, double, std::hash<data_t>, equal_t>,
            std::unordered_map<T, double, VectorHasher<data_t>, equal_t>>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = vec_t<double>;

    template <typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if constexpr (is_md_)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "ImpurityVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        if (roll_count_ == 0 || roll_count_ > col_s)  return;

        map_t   table (roll_count_ / 2 + 1);

        for (size_type i { 0 }; i < roll_count_; ++i) [[likely]]  {
            auto    ret { table.insert(std::pair(*(column_begin + i), 0)) };

            ret.first->second += 1.0;
        }

        result_type result;
        auto        func =
            [this, col_s, &table, &result, &column_begin]
            (auto i, auto sum) -> bool  {
                result.push_back(sum);

                const size_type roll_end { i + roll_count_ };

                if (roll_end > col_s)  return (false);

                auto    find_ret { table.find(*(column_begin + (i - 1))) };

                find_ret->second -= 1.0; // It must find it -- no need to check
                if (find_ret->second == 0)
                    table.erase(find_ret);

                auto    insert_ret {
                    table.insert(std::pair(*(column_begin + (roll_end - 1)), 0))
                };

                insert_ret.first->second += 1.0;
                return (true);
            };

        result.reserve(col_s);
        if (imt_ == impurity_type::gini_index)  {
            for (size_type i { 1 }; i < col_s; ++i) [[likely]]  {
                double  sum { 0 };

                for (const auto &citer : table)  {
                    const auto  prob { citer.second / double(roll_count_) };

                    sum += prob * prob;
                }
                sum = 1.0 - sum;
                if (! func(i, sum))  break;
            }
        }
        else  {  // impurity_type::info_entropy
            for (size_type i { 1 }; i < col_s; ++i) [[likely]]  {
                double  sum = 0;

                for (const auto &citer : table)  {
                    const auto  prob { citer.second / double(roll_count_) };

                    if (prob > 0.0)  sum += prob * std::log2(prob);
                }
                sum = -sum;
                if (! func(i, sum))  break;
            }
        }
        result_.swap(result);
    }

    inline void
    operator()(const index_type &idx, const value_type &val)  {

        obo_data_ = true;
        aux_val_vec_.push_back(val);
        aux_idx_vec_.push_back(idx);
    }

    inline void pre()  {

        aux_val_vec_.clear();
        aux_idx_vec_.clear();
        obo_data_ = false;

        result_.clear();
    }
    inline void post()  {

        if (obo_data_)
            (*this)(aux_idx_vec_.begin(), aux_idx_vec_.end(),
                    aux_val_vec_.begin(), aux_val_vec_.end());
    }
    DEFINE_RESULT

    ImpurityVisitor(size_type roll_count, impurity_type it)
        : roll_count_(roll_count), imt_(it)  {   }

private:

    using val_vec = std::vector<T, typename allocator_declare<T, A>::type>;
    using idx_vec = std::vector<I, typename allocator_declare<I, A>::type>;
    val_vec     aux_val_vec_ {  };
    idx_vec     aux_idx_vec_ {  };
    bool        obo_data_ { false };  // one-by-one data passing

    result_type         result_ { };
    const size_type     roll_count_;
    const impurity_type imt_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using impu_v = ImpurityVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  SigmoidVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<data_t>,
                                    vec_t<std::vector<data_t>>>;

private:

    template<typename F>
    static inline void
    apply_func_(size_type col_s, long thread_level, F &&func) {

        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    std::forward<F>(func))
            };

            for (auto &fut : futures) fut.get();
        }
        else  func(size_type(0), col_s);
    }

    template<typename H>
    inline void
    logistic_(const H &column_begin, size_type col_s, long thread_level)  {

        auto    lbd =
            [&column_begin, this](auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)
                   result_[i] =
                       data_t(1) /
                       (data_t(1) + _bc_exp_(*(column_begin + i) * data_t(-1)));
            };

        apply_func_(col_s, thread_level, std::move(lbd));
    }
    template<typename H>
    inline void
    algebraic_(const H &column_begin, size_type col_s, long thread_level)  {

        auto    lbd =
            [&column_begin, this](auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)  {
                   const auto   &val { *(column_begin + i) };
                   const auto   denom {
                       _bc_sqrt_(data_t(1) + _bc_pow_(val, data_t(2)))
                   };

                   if constexpr (is_md_)  {
                       result_[i].resize(val.size());
                       for (size_type d { 0 }; d < val.size(); ++d)
                           result_[i][d] = val[d] / denom[d];
                   }
                   else
                       result_[i] = val / denom;
                }
            };

        apply_func_(col_s, thread_level, std::move(lbd));
    }
    template<typename H>
    inline void
    hyperbolic_tan_(const H &column_begin, size_type col_s, long thread_level) {

        auto    lbd =
            [&column_begin, this](auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)
                    result_[i] = _bc_tanh_(*(column_begin + i));
            };

        apply_func_(col_s, thread_level, std::move(lbd));
    }
    template<typename H>
    inline void
    arc_tan_(const H &column_begin, size_type col_s, long thread_level)  {

        auto    lbd =
            [&column_begin, this](auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)
                    result_[i] = _bc_atan_(*(column_begin + i));
            };

        apply_func_(col_s, thread_level, std::move(lbd));
    }
    template<typename H>
    inline void
    error_function_(const H &column_begin, size_type col_s, long thread_level) {

        auto    lbd =
            [&column_begin, this](auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)
                    result_[i] = _bc_erf_(*(column_begin + i));
            };

        apply_func_(col_s, thread_level, std::move(lbd));
    }
    template<typename H>
    inline void
    gudermannian_(const H &column_begin, size_type col_s, long thread_level)  {

        auto    lbd =
            [&column_begin, this](auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)
                    result_[i] = _bc_atan_(_bc_sinh_(*(column_begin + i)));
            };

        apply_func_(col_s, thread_level, std::move(lbd));
    }
    template<typename H>
    inline void
    smoothstep_(const H &column_begin, size_type col_s, long thread_level)
        requires (! is_md_)  {

        auto    lbd =
            [&column_begin, this](auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)  {
                    const value_type    &val { *(column_begin + i) };

                    if (val <= 0)
                        result_[i] = 0;
                    else if (val >= data_t(1))
                        result_[i] = data_t(1);
                    else
                        result_[i] = val * val * (data_t(3) - data_t(2) * val);
                }
            };

        apply_func_(col_s, thread_level, std::move(lbd));
    }

public:

    template<typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if constexpr (is_md_)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "SigmoidVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        const auto  thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

        result_.resize(col_s);
        switch (sigmoid_type_)  {
        case sigmoid_type::logistic:
            logistic_(column_begin, col_s, thread_level);  break;
        case sigmoid_type::algebraic:
            algebraic_(column_begin, col_s, thread_level);  break;
        case sigmoid_type::hyperbolic_tan:
            hyperbolic_tan_(column_begin, col_s, thread_level);  break;
        case sigmoid_type::arc_tan:
            arc_tan_(column_begin, col_s, thread_level);  break;
        case sigmoid_type::error_function:
            error_function_(column_begin, col_s, thread_level);  break;
        case sigmoid_type::gudermannian:
            gudermannian_(column_begin, col_s, thread_level);  break;
        case sigmoid_type::smoothstep:
            if constexpr (! is_md_)
                smoothstep_(column_begin, col_s, thread_level);
            break;
        default:
            break;
        }
    }

    OBO_PORT_OPT

    inline void pre()  {

        OBO_PORT_PRE
        result_.clear();
    }
    inline void post()  { OBO_PORT_POST }

    inline const result_type &get_result () const  { return (result_); }
    inline result_type &get_result ()  { return (result_); }

    explicit
    SigmoidVisitor(sigmoid_type st) : sigmoid_type_(st)  {   }

private:

    OBO_PORT_DECL

    result_type         result_ {  }; // Sigmoids
    const sigmoid_type  sigmoid_type_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using sigm_v = SigmoidVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  RectifyVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

public:

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            std::vector<std::future<void>>  futures;

            result_.resize(col_s);
            if (rtype_ == rectify_type::ReLU)  {
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)
                                this->result_[i] =
                                    std::max(T(0), *(column_begin + i));
                        });
            }
            else if (rtype_ == rectify_type::param_ReLU)  {
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)  {
                                const value_type    v = *(column_begin + i);

                                this->result_[i] =
                                    std::max(v * this->param_, v);
                            }
                        });
            }
            else if (rtype_ == rectify_type::GeLU)  {
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)  {
                                const value_type    v = *(column_begin + i);

                                this->result_[i] =
                                    v * this->standard_normal_dist_(v);
                            }
                        });
            }
            else if (rtype_ == rectify_type::SiLU)  {
                sigm_v<T, I, A> sigm(sigmoid_type::logistic);

                sigm.pre();
                sigm(idx_begin, idx_end, column_begin, column_end);
                sigm.post();
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, &sigm = std::as_const(sigm), this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)  {
                                const value_type    col = *(column_begin + i);
                                const value_type    sig = sigm.get_result()[i];

                                this->result_[i] = col * sig;
                            }
                        });
            }
            else if (rtype_ == rectify_type::softplus)  {
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)  {
                                const value_type    v = *(column_begin + i);

                                this->result_[i] = softp_(v, this->param_);
                            }
                        });
            }
            else if (rtype_ == rectify_type::elu)  {
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)  {
                                const value_type    v = *(column_begin + i);

                                if (v > 0)
                                    this->result_[i] = v;
                                else
                                    this->result_[i] =
                                        this->param_ * (std::exp(v) - T(1));
                            }
                        });
            }
            else if (rtype_ == rectify_type::mish)  {
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)  {
                                const value_type    v = *(column_begin + i);

                                this->result_[i] =
                                    v * std::tanh(softp_(v, this->param_));
                            }
                        });
            }
            else if (rtype_ == rectify_type::metallic_mean)  {
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)  {
                                const value_type    v = *(column_begin + i);

                                this->result_[i] =
                                    (v + std::sqrt(v * v + T(4))) / T(2);
                            }
                        });
            }

            for (auto &fut : futures)  fut.get();
        }
        else  {
            result_.reserve(col_s);
            if (rtype_ == rectify_type::ReLU)  {
                std::for_each(column_begin, column_end,
                              [this](const value_type &v) -> void  {
                                  this->result_.push_back(std::max(T(0), v));
                              });
            }
            else if (rtype_ == rectify_type::param_ReLU)  {
                std::for_each(column_begin, column_end,
                              [this](const value_type &v) -> void  {
                                  this->result_.push_back(
                                      std::max(v * this->param_, v));
                              });
            }
            else if (rtype_ == rectify_type::GeLU)  {
                std::for_each(column_begin, column_end,
                              [this](const value_type &v) -> void  {
                                  this->result_.push_back(
                                      v * this->standard_normal_dist_(v));
                              });
            }
            else if (rtype_ == rectify_type::SiLU)  {
                sigm_v<T, I, A> sigm(sigmoid_type::logistic);

                sigm.pre();
                sigm(idx_begin, idx_end, column_begin, column_end);
                sigm.post();

                std::transform(column_begin, column_end,
                               sigm.get_result().begin(),
                               std::back_inserter(result_),
                               [](auto col, auto sig) -> value_type  {
                                   return (col * sig);
                               });
            }
            else if (rtype_ == rectify_type::softplus)  {
                std::for_each(column_begin, column_end,
                              [this](const value_type &v) -> void  {
                                  this->result_.push_back(
                                      softp_(v, this->param_));
                              });
            }
            else if (rtype_ == rectify_type::elu)  {
                std::for_each(column_begin, column_end,
                              [this](const value_type &v) -> void   {
                                  if (v > 0)
                                      this->result_.push_back(v);
                                  else
                                      this->result_.push_back(
                                          this->param_ * (std::exp(v) - T(1)));
                              });
            }
            else if (rtype_ == rectify_type::mish)  {
                std::for_each(column_begin, column_end,
                              [this](const value_type &v) -> void  {
                                  this->result_.push_back(
                                      v * std::tanh(softp_(v, this->param_)));
                              });
            }
            else if (rtype_ == rectify_type::metallic_mean)  {
                std::for_each(column_begin, column_end,
                              [this](const value_type &v) -> void  {
                                  this->result_.push_back(
                                      (v + std::sqrt(v * v + T(4))) / T(2));
                              });
            }
        }
    }

    OBO_PORT_OPT

    inline void pre()  {

        OBO_PORT_PRE
        result_.clear();
    }
    inline void post()  { OBO_PORT_POST }
    DEFINE_RESULT

    explicit
    RectifyVisitor(rectify_type r_type, value_type param = 1)
        : param_(param), rtype_(r_type)  {   }

private:

    inline static value_type
    softp_(const value_type &v, const value_type &p)  {

        const value_type    y { p * v };

        return ((std::max(y, T(0)) + std::log1p(std::exp(-std::fabs(y)))) / p);
    }
    inline static value_type
    standard_normal_dist_(const value_type &v)  {

        static const value_type inv_sqrt2 {
            value_type(1) / std::sqrt(value_type(2))
        };

        return ((value_type(1) + std::erf(v * inv_sqrt2)) / value_type(2));
    }

    OBO_PORT_DECL

    result_type         result_ {  };
    const value_type    param_;
    const rectify_type  rtype_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using recf_v = RectifyVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  PolicyLearningLossVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using scale_t =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<data_t>,
                                    vec_t<std::vector<data_t>>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &action_prob_begin, const H &action_prob_end,
               const H &reward_begin, const H &reward_end)  {

        const size_type col_s {
            size_type(std::distance(action_prob_begin, action_prob_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(reward_begin, reward_end)))
            throw DataFrameError("PolicyLearningLossVisitor: All columns must "
                                 "be of equal sizes");
        if (baseline_ == policy_loss_baseline::constant &&
            ! baseline_val_.has_value())
            throw DataFrameError("PolicyLearningLossVisitor: constant baseline "
                                 "mode requires a baseline value");

        if constexpr (is_md_)  {
            const size_type dim { action_prob_begin->size() };

            for (size_type i { 0 }; i < col_s; ++i)
                if ((action_prob_begin + i)->size() != dim ||
                    (reward_begin + i)->size() != dim)
                    throw DataFrameError("PolicyLearningLossVisitor: "
                                         "Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        // Compute the effective reward adjustment depending on mode
        //
        scale_t adjust;
        scale_t scale;

        if constexpr (! is_md_)  {
            adjust = 0;
            scale = 1;
        }
        if (baseline_ == policy_loss_baseline::constant)  {
            if constexpr (is_md_)
                adjust.resize(reward_begin->size(), *baseline_val_);
            else
                adjust = *baseline_val_;
        }
        else if (baseline_ == policy_loss_baseline::mean ||
                 baseline_ == policy_loss_baseline::standardize)  {
            StdVisitor<T, I>    std_v;

            std_v.pre();
            std_v(idx_begin, idx_end, reward_begin, reward_end);
            std_v.post();

            adjust = std_v.get_mean();

            if (baseline_ == policy_loss_baseline::standardize)
                scale = std_v.get_result();
        }

        if constexpr (is_md_)  {
            if (adjust.empty())
                adjust.resize(reward_begin->size(), 0);
            if (scale.empty())
                scale.resize(reward_begin->size(), 1);
        }

        // Negative Log Likelihood
        //
        result_.resize(col_s);
        auto   lbd =
            [&action_prob_begin = std::as_const(action_prob_begin),
             &reward_begin = std::as_const(reward_begin),
             &adjust = std::as_const(adjust),
             &scale = std::as_const(scale),
             this]
            (auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)  {
                    const auto  &ap { *(action_prob_begin + i) };
                    const auto  &r { *(reward_begin + i) };
                    const auto  adjusted_r {
                        (r - adjust) / (scale + data_t(epsilon_))
                    };

                    result_[i] =
                        (_bc_log_(ap + data_t(epsilon_)) * data_t(-1)) *
                        adjusted_r;

                }
            };

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(size_type(0), col_s);
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    PolicyLearningLossVisitor(
        policy_loss_baseline baseline = policy_loss_baseline::none ,
        std::optional<double> baseline_val = std::nullopt,
        double epsilon = 1e-8)
        : baseline_(baseline),
          baseline_val_(baseline_val),
          epsilon_(epsilon)  {  }

private:

    const policy_loss_baseline  baseline_ { };
    const std::optional<data_t> baseline_val_ { };
    const double                epsilon_ { };
    result_type                 result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using plloss_v = PolicyLearningLossVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  LossFunctionVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &actual_begin, const H &actual_end,
               const H &model_begin, const H &model_end)  {

        const size_type col_s {
            size_type(std::distance(actual_begin, actual_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(model_begin, model_end)))
            throw DataFrameError("LossFunctionVisitor: All columns must be of "
                                 "equal sizes");
        if constexpr (is_md_)  {
            const size_type dim { actual_begin->size() };

            for (size_type i { 0 }; i < col_s; ++i)
                if ((actual_begin + i)->size() != dim ||
                    (model_begin + i)->size() != dim)
                    throw DataFrameError(
                        "LossFunctionVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        const bool  multi_thr {
            col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2
        };
        size_type   dim { 0 };

        if constexpr (is_md_)  dim = actual_begin->size();

#ifdef HMDF_SANITY_EXCEPTIONS
        if constexpr (is_md_)  {
            auto mit = model_begin;

            for (auto ait { actual_begin }; ait != actual_end; ++ait)
                if (ait->size() != dim || (mit++)->size() != dim)
                    throw DataFrameError("LossFunctionVisitor: "
                                         "Inconsistent data dimensions");
        }
#endif

        if (lft_ == loss_function_type::cosine_similarity)  {
            if constexpr (! is_md_)  {
                DotProdVisitor<T, I>    dot_v;

                dot_v.pre();
                dot_v (idx_begin, idx_end,
                       actual_begin, actual_end, model_begin, model_end);
                dot_v.post();

                result_ = dot_v.get_result() /
                          (dot_v.get_magnitude1() * dot_v.get_magnitude2());
            }
            else
                throw DataFrameError("LossFunctionVisitor: "
                                     "cosine_similarity type only applies to "
                                     "scalar data");
        }
        else if (lft_ == loss_function_type::kullback_leibler)  {
            auto    lbd =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &a { *(actual_begin + i) };
                        const auto  &m { *(model_begin + i) };

                        sum += _bc_log_(a / m) * a;
                    }
                    return (sum);
                };

            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd));

                for (auto &fut : futures)  result_ += fut.get();
            }
            else  {
                result_ = lbd(size_type(0), col_s);
            }
        }
        else if (lft_ == loss_function_type::mean_abs_error)  {
            auto    lbd =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &a { *(actual_begin + i) };
                        const auto  &m { *(model_begin + i) };

                        sum += _bc_fabs_(a - m);
                    }
                    return (sum);
                };

            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd));

                for (auto &fut : futures)  result_ += fut.get();
            }
            else  {
                result_ = lbd(size_type(0), col_s);
            }
            result_ /= data_t(col_s);
        }
        else if (lft_ == loss_function_type::mean_sqr_error)  {
            auto    lbd =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &val {
                            *(actual_begin + i) - *(model_begin + i)
                        };

                        sum = sum + val * val;
                    }
                    return (sum);
                };

            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd));

                for (auto &fut : futures)  result_ += fut.get();
            }
            else  {
                result_ = lbd(size_type(0), col_s);
            }
            result_ /= data_t(col_s);
        }
        else if (lft_ == loss_function_type::mean_sqr_log_error)  {
            auto    lbd =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &val {
                            _bc_log_(data_t(1) + *(actual_begin + i)) -
                            _bc_log_(data_t(1) + *(model_begin + i))
                        };

                        sum = sum + val * val;
                    }
                    return (sum);
                };

            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd));

                for (auto &fut : futures)  result_ += fut.get();
            }
            else  {
                result_ = lbd(size_type(0), col_s);
            }
            result_ /= data_t(col_s);
        }
        else if (lft_ == loss_function_type::cross_entropy)  {
            auto    lbd =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &a { *(actual_begin + i) };
                        const auto  &m { *(model_begin + i) };

                        sum += _bc_log_(m) * a;
                    }
                    return (sum);
                };

            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd));

                for (auto &fut : futures)  result_ += fut.get();
            }
            else  {
                result_ = lbd(size_type(0), col_s);
            }
            result_ = data_t(-1) * (result_ / data_t(col_s));
        }
        else if (lft_ == loss_function_type::binary_cross_entropy)  {
            auto    lbd =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &a { *(actual_begin + i) };
                        const auto  &m { *(model_begin + i) };

                        sum -= _bc_log_(m) * a +
                               (data_t(1) - a) * _bc_log_(data_t(1) - m);
                    }
                    return (sum);
                };

            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd));

                for (auto &fut : futures)  result_ += fut.get();
            }
            else  {
                result_ = lbd(size_type(0), col_s);
            }
            result_ /= data_t(col_s);
        }
        else if (lft_ == loss_function_type::categorical_hinge)  {
            auto    lbd1 =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &a { *(actual_begin + i) };
                        const auto  &m { *(model_begin + i) };

                        sum = sum + ((data_t(1) - a) * m);
                    }
                    return (sum);
                };
            auto    lbd2 =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &a { *(actual_begin + i) };
                        const auto  &m { *(model_begin + i) };

                        sum = sum + a * m;
                    }
                    return (sum);
                };

            result_type neg;
            result_type pos;

            if constexpr (is_md_)  {
                neg.resize(dim, 0);
                pos.resize(dim, 0);
            }
            else  {
                neg = 0;
                pos = 0;
            }
            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd1));

                for (auto &fut : futures)  neg += fut.get();

                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd2));
                for (auto &fut : futures)  pos += fut.get();
            }
            else  {
                neg = lbd1(size_type(0), col_s);
                pos = lbd2(size_type(0), col_s);
            }
            if constexpr (! is_md_)
                result_ = std::max(neg - pos + data_t(1), data_t(0));
            else  {
                result_ = neg - pos + data_t(1);
                for (auto &v : result_)  v = std::max(v, data_t(0));
            }
        }
        else if (lft_ == loss_function_type::log_cosh)  {
            auto    lbd =
                [&actual_begin = std::as_const(actual_begin),
                 &model_begin = std::as_const(model_begin), dim]
                (auto begin, auto end) -> result_type  {
                    result_type sum;

                    if constexpr (is_md_)  sum.resize(dim, 0);
                    else  sum = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &a { *(actual_begin + i) };
                        const auto  &m { *(model_begin + i) };

                        sum += _bc_log_(_bc_cosh_(m - a));
                    }
                    return (sum);
                };

            if (multi_thr)  {
                auto    futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd));

                for (auto &fut : futures)  result_ += fut.get();
            }
            else  {
                result_ = lbd(size_type(0), col_s);
            }
            result_ /= data_t(col_s);
        }
    }

    inline void pre()  {

        if constexpr (is_md_)  result_.clear();
        else  result_ = 0;
    }
    inline void post()  {  }

    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result() { return (result_); }

    explicit
    LossFunctionVisitor(loss_function_type lft) : lft_(lft)  {   }

private:

    result_type                 result_;
    const loss_function_type    lft_;
};

template<typename T, typename I = unsigned long>
using loss_v = LossFunctionVisitor<T, I>;

// ------------------------------------------------------------------------------

template<vector_sim_type TYP, typename T, typename I = unsigned long>
struct  VectorSimilarityVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    using equal_t =
        typename std::conditional_t<std::is_floating_point_v<data_t>,
                                    FloatEqual<data_t>,
                                    std::equal_to<data_t>>;
    using map_t =
        typename std::conditional_t<
            ! is_md_,
            std::unordered_set<T, std::hash<data_t>, equal_t>,
            std::unordered_set<T, VectorHasher<data_t>, equal_t>>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = double;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin1, const H &column_end1,
               const H &column_begin2, const H &column_end2)  {

        const size_type col_s1 {
            size_type(std::distance(column_begin1, column_end1))
        };
        const size_type col_s2 {
            size_type(std::distance(column_begin2, column_end2))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s1 != col_s2)
            throw DataFrameError(
                "VectorSimilarityVisitor: "
                "Two columns must be of the same length");

        if constexpr (is_md_)  {
            const size_type dim { column_begin1->size() };

            for (size_type i { 0 }; i < col_s1; ++i)
                if ((column_begin1 + i)->size() != dim ||
                    (column_begin2 + i)->size() != dim)
                    throw DataFrameError(
                        "VectorSimilarityVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (TYP != vector_sim_type::jaccard_similarity &&
                      TYP != vector_sim_type::hamming_dist)  {
            DotProdVisitor<T, I>    dot_v;

            dot_v.pre();
            dot_v(idx_begin, idx_end,
                  column_begin1, column_end1, column_begin2, column_end2);
            dot_v.post();

            const auto  dotp_res { dot_v.get_result() };

            if constexpr (TYP == vector_sim_type::euclidean_dist)
                result_ = dot_v.get_euclidean_dist();
            else if constexpr (TYP == vector_sim_type::manhattan_dist)
                result_ = dot_v.get_manhattan_dist();
            else if constexpr (TYP == vector_sim_type::dot_product)
                result_ = dotp_res;
            else if constexpr (TYP == vector_sim_type::cosine_similarity)  {
                if (! is_md_)
                    result_ = dotp_res /
                              (dot_v.get_magnitude1() * dot_v.get_magnitude2());
                else
                    static_assert(! is_md_,
                                  "VectorSimilarityVisitor: "
                                  "cosine_similarity type only applies to "
                                  "scalar data");
            }
            else if constexpr (TYP == vector_sim_type::simple_similarity)  {
                if (! is_md_)  {
#ifdef HMDF_SANITY_EXCEPTIONS
                    if (col_s1 != col_s2)
                        throw DataFrameError(
                            "VectorSimilarityVisitor: "
                            "All columns must be of equal sizes");
#endif // HMDF_SANITY_EXCEPTIONS

                    // Must normalize the dot product first.
                    // Raw dotp is unbounded, so dotp² can exceed 1 and produce
                    // a negative result.
                    // cosine ∈ [-1, 1], so (1 - cosine²) is always in [0, 1]
                    // and the final result is always in [0, 1/N].
                    //
                    const result_type   denom {
                        dot_v.get_magnitude1() * dot_v.get_magnitude2()
                    };
                    const result_type   cosine {
                        (denom > 0.0) ? (dotp_res / denom) : 0.0
                    };
                    result_ = (1.0 - cosine * cosine) / result_type(col_s1);
                }
                else
                    static_assert(! is_md_,
                                  "VectorSimilarityVisitor: "
                                  "simple_similarity type only applies to "
                                  "scalar data");
            }
        }
        else if constexpr (TYP == vector_sim_type::jaccard_similarity)   {
            map_t   set1, set2;

            set1.reserve(col_s1);
            set2.reserve(col_s2);

            for (size_type i { 0 }; i < col_s1; ++i)
                set1.insert(*(column_begin1 + i));
            for (size_type i { 0 }; i < col_s2; ++i)
                set2.insert(*(column_begin2 + i));

            size_type   intersection { 0 };

            for (const auto &val : set1)
                if (set2.count(val))
                    ++intersection;

            // |A ∪ B| = |A| + |B| - |A ∩ B|  (inclusion-exclusion on sets)
            //
            const size_type uni { set1.size() + set2.size() - intersection };

            result_ = uni > 0
                          ? result_type(intersection) / result_type(uni)
                          : result_type(1);  // two empty sets are identical
        }
        else if constexpr (TYP == vector_sim_type::hamming_dist)   {
#ifdef HMDF_SANITY_EXCEPTIONS
            if (col_s1 != col_s2)
               throw DataFrameError("VectorSimilarityVisitor: "
                                    "All columns must be of equal sizes");
#endif // HMDF_SANITY_EXCEPTIONS

            const equal_t   eq_perd { };

            for (size_type i { 0 }; i < col_s1; ++i)
                if (! eq_perd(*(column_begin1 + i), *(column_begin2 + i)))
                    result_ += 1;
        }
    }

    inline void pre()  { result_ = 0; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }

    VectorSimilarityVisitor() = default;

private:

    result_type result_ { 0 };
};

template<vector_sim_type TYP, typename T, typename I = unsigned long>
using vs_v = VectorSimilarityVisitor<TYP, T, I>;

// ------------------------------------------------------------------------------

template<std::size_t K,
         typename T, typename I = unsigned long, std::size_t A = 0>
struct  SpectralClusteringVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

public:

    DEFINE_VISIT_BASIC_TYPES

    using similarity_func = std::function<double(const value_type &x,
                                                 const value_type &y,
                                                 double sigma)>;
    using seed_t = std::random_device::result_type;
    using cluster_type = std::array<VectorConstPtrView<value_type, A>, K>;
    using order_type =
        std::array<std::vector<
                       size_type,
                       typename allocator_declare<size_type, A>::type>, K>;

private:

    using sym_mat_t = Matrix<double, matrix_orient::row_major, true>;
    using mat_t = Matrix<T, matrix_orient::row_major, false>;
    using lap_mat_t = Matrix<double, matrix_orient::row_major, false>;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    const size_type iter_num_;
    const seed_t    seed_;
    const double    sigma_;
    similarity_func sfunc_;
    cluster_type    clusters_ { };       // K Clusters
    order_type      clusters_idxs_ { };  // K Clusters indices

    inline static similarity_func
    get_sim_func_()  {

        if constexpr (! is_md_)
            return ([](const T &x, const T &y, double sigma) -> double  {
                        const double    diff { x - y };

                        return (std::exp(-(diff * diff) / (2 * sigma * sigma)));
            });
        else
            return ([](const T &x, const T &y, double sigma) -> double  {
                        double sum { 0 };

                        for (size_type i { 0 }; i < x.size(); ++i)  {
                            const double    diff { x[i] - y[i] };

                            sum += diff * diff;
                        }
                        return (std::exp(-sum / (2 * sigma * sigma)));
            });
    }

    template<typename H>
    inline sym_mat_t
    calc_similarity_(const H &column_begin, size_type col_s)  {

        sym_mat_t   sim_mat(col_s, col_s);

        for (long r = 0; r < sim_mat.rows(); ++r)
            for (long c = r; c < sim_mat.cols(); ++c)
                sim_mat(r, c) =
                    sfunc_(*(column_begin + c), *(column_begin + r), sigma_);

        return (sim_mat);
    }

    inline vec_t<double>
    calc_degree_(const sym_mat_t &sim_mat)  {

        vec_t<double>   deg_mat(sim_mat.rows());

        for (long r = 0; r < sim_mat.rows(); ++r)  {
            double  sum { 0 };

            for (long c = 0; c < sim_mat.cols(); ++c)
                sum += sim_mat(r, c);
            deg_mat[r] = sum;
            // deg_mat[r] = T(1) / std::sqrt(sum); // needs I - D * W * D
        }

        return (deg_mat);
    }

    inline lap_mat_t
    calc_laplacian_(const vec_t<double> &deg_mat, const sym_mat_t &sim_mat)  {

        lap_mat_t   lap_mat(sim_mat.rows(), sim_mat.cols());

        for (long r = 0; r < sim_mat.rows(); ++r)
            for (long c = 0; c < sim_mat.cols(); ++c)
                if (r == c)
                    lap_mat(r, r) = deg_mat[r] - sim_mat(r, r);
                else
                    lap_mat(r, c) = -sim_mat(r, c);

        return (lap_mat);
    }

    inline double
    distance_func_(const lap_mat_t &x, const lap_mat_t &y,
                   long xr, long yr, long cols)  {

        double  val { 0 };

        for (long c = 0; c < cols; ++c) {
            const double    diff = x(xr, c) - y(yr, c);

            val += diff * diff;
        }
        return (val);
    }

    inline vec_t<long>
    do_kmeans_(const lap_mat_t &eigenvecs)  {

        const long      rows = eigenvecs.rows();  // Samples
        vec_t<long>     cluster_idxs (rows, -1L);
        constexpr long  k = long(K);

        std::random_device                  rd;
        std::mt19937                        gen (
            (seed_ != seed_t(-1)) ? seed_ : rd());
        std::uniform_int_distribution<long> rd_gen (0, rows - 1);

        // Copy the top k rows of eigen vector.
        //
        lap_mat_t   means { k, k };

        for (long r = 0; r < k; ++r)  {
            const auto rr = rd_gen(gen);

            for (long c = 0; c < k; ++c)
                means(r, c) = eigenvecs(rr, c);
        }

        for (size_type iter = 0; iter < iter_num_; ++iter)  {
             // Assign cluster_idxs based on closest means
             //
             for (long r = 0; r < rows; ++r) {
                 double best_distance { std::numeric_limits<double>::max() };

                 for (long rr = 0; rr < k; ++rr) {
                     const double   distance =
                         distance_func_(eigenvecs, means, r, rr, k);

                     if (distance < best_distance) {
                         best_distance = distance;
                         cluster_idxs[r] = rr;
                     }
                 }
             }

             // Update means
             //
             lap_mat_t      new_means { k, k };
             vec_t<long>    counts (k, 0L);

             for (long r = 0; r < rows; ++r) {
                 for (long c = 0; c < k; ++c)
                     new_means(cluster_idxs[r], c) += eigenvecs(r, c);
                 counts[cluster_idxs[r]]++;
             }

             for (int r = 0; r < k; ++r) {
                 if (counts[r] > 0)  {
                     for (long c = 0; c < k; ++c)
                         new_means(r, c) /= double(counts[r]);
                 }
                 else  { // Reinitialize centroid if no points assigned
                     const auto rr = rd_gen(gen);

                     for (long c = 0; c < k; ++c)
                         new_means(r, c) = eigenvecs(rr, c);
                 }
             }
             if ((means - new_means).norm() <= 0.0000001)  break;

             means = new_means;
        }

        return (cluster_idxs);
    }

public:

    template<typename IV, typename H>
    inline void
    operator() (const IV &idx_begin, const IV &idx_end,
                const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s <= K)
           throw DataFrameError("SpectralClusteringVisitor: "
                                "Data size must be bigger than K");
#endif // HMDF_SANITY_EXCEPTIONS

        lap_mat_t   eigenvecs;

        {
            const auto  sim_mat = calc_similarity_(column_begin, col_s);
            const auto  deg_mat = calc_degree_(sim_mat);
            const auto  lap_mat = calc_laplacian_(deg_mat, sim_mat);
            lap_mat_t   eigenvals;

            lap_mat.eigen_space(eigenvals, eigenvecs, true);
        }  // Getting rid of the big things we don't need anymore

        const auto  cluster_idxs = do_kmeans_(eigenvecs);

        // Update the accessible data
        //
        for (size_type i = 0; i < K; ++i)  {
            const auto  val = col_s / K + 10;

            clusters_[i].reserve(val);
            clusters_idxs_[i].reserve(val);
        }
        for (size_type i = 0; i < cluster_idxs.size(); ++i)  {
            clusters_[cluster_idxs[i]].push_back(&(*(column_begin + i)));
            clusters_idxs_[cluster_idxs[i]].push_back(i);
        }
    }

    inline void set_sim_func(similarity_func &&f)  { sfunc_ = f; }

    inline void pre()  {

        for (auto &iter : clusters_) iter.clear();
        for (auto &iter : clusters_idxs_) iter.clear();
    }
    inline void post()  {  }
    inline const cluster_type &get_result() const  { return (clusters_); }
    inline cluster_type &get_result()  { return (clusters_); }
    inline const order_type &
    get_clusters_idxs() const  { return (clusters_idxs_); }

    SpectralClusteringVisitor(size_type num_of_iter,
                              double sigma,
                              seed_t seed = seed_t(-1))
        : iter_num_(num_of_iter),
          seed_(seed),
          sigma_(sigma)  { sfunc_ = get_sim_func_(); }
};

template<std::size_t K, typename T,
         typename I = unsigned long, std::size_t A = 0>
using spect_v = SpectralClusteringVisitor<K, T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  SeasonalPeriodVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = double;
    using md_result_type = std::vector<result_type>;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        const size_type         col_s {
            size_type(std::distance(column_begin, column_end))
        };
        std::vector<value_type> data(column_begin, column_end);

#ifdef HMDF_SANITY_EXCEPTIONS
        if constexpr (is_md_)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "SeasonalPeriodVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        if (params_.detrend)  {  // Take trend out
            std::vector<size_type>  xvals(col_s);
            size_type               xvalue { 0 };

            for (auto &val : xvals)  {
                val = xvalue;
                xvalue += params_.sampling_rate;
            }

            LowessVisitor<T, I> l_v {
                params_.num_loops,
                params_.frac,
                params_.delta,
                true
            };

            l_v.pre();
            l_v(idx_begin, idx_end,
                data.begin(), data.end(), xvals.begin(), xvals.end());
            l_v.post();

            if constexpr (! is_md_)  {
                // Scalar: both sides are vec_t<data_t>.
                //
                data -= l_v.get_result();
            }
            else  {
                // MD: LowessVisitor result layout is fitted[col][row],
                // but data layout is data[row] where data[row] is a T
                // (vector/array) indexed by col.
                // A direct data -= fitted would be a shape mismatch,
                // so we must subtract element-wise with transposed indexing.
                //
                const auto      &fitted { l_v.get_result() };  // [col][row]
                const size_type dim { fitted.size() };

                for (size_type r { 0 }; r < col_s; ++r) [[likely]]
                    for (size_type c { 0 }; c < dim; ++c)
                        data[r][c] -= fitted[c][r];
            }
        }

        if (params_.de_serial_corr)  {  // Take serial correlation out
            value_type  prev_val { data[0] };

            for (auto &datum : data)  {
                const value_type    tmp { datum };

                datum -= prev_val;
                prev_val = tmp;
            }
            data[0] = data[1];
        }

        FastFourierTransVisitor<T, I>   fft;

        fft.pre();
        fft(idx_begin, idx_end, data.begin(), data.end());
        fft.post();

        // mags is a vector in case of scalar input
        // mags is a matrix in case of multidimensional input
        //
        const auto  &mags { fft.get_magnitude() };

        if constexpr (! is_md_)  {
            const size_type n_bins { mags.size() };

            // For a real-valued input of length N, the FFT produces a
            // symmetric spectrum — (bin k and bin N - k carry identical
            // magnitude).
            // FIX: Restrict the scan to [1, N / 2) — the unique, non-mirrored
            //      half of the spectrum.
            //
            const size_type scan_len { n_bins / 2 + 1 };

            // Skip bin 0 (DC component) — it carries no frequency information
            // and would cause dom_freq_ = 0 and result_ = 1/0 = inf.
            //
            for (size_type i { 1 }; i < scan_len; ++i) [[likely]]  {
                const result_type   val { std::fabs(mags[i]) };

                if (val > max_mag_)  {
                    max_mag_ = val;
                    dom_idx_ = i;
                }
            }

            dom_freq_ =
                result_type(dom_idx_) *
                result_type(params_.sampling_rate) / result_type(mags.size());
            result_ = result_type(1) / dom_freq_;
        }
        else  {
            const size_type dim { size_type(mags.cols()) };
            const size_type n_bins { size_type(mags.rows()) };

            // For a real-valued input of length N, the FFT produces a
            // symmetric spectrum (bin k and bin N - k carry identical
            // magnitude).
            // FIX: Restrict the scan to [1, N / 2) — the unique, non-mirrored
            //      half of the spectrum.
            //
            const size_type scan_len {
                ((n_bins & 0x01) == 0) ? n_bins / 2 : (n_bins + 1) / 2
            };

            max_mag_vec_.resize(dim, 0);
            dom_idx_vec_.resize(dim, 0);
            dom_freq_vec_.resize(dim, 0);
            result_vec_.resize(dim, 0);

            for (size_type d { 0 }; d < dim; ++d)  {
                // Skip bin 0 (DC) for the same reason as the scalar path.
                //
                for (size_type i { 1 }; i < scan_len; ++i) [[likely]]  {
                    const result_type   val { std::fabs(mags(i, d)) };

                    if (val > max_mag_vec_[d])  {
                        max_mag_vec_[d] = val;
                        dom_idx_vec_[d] = i;
                    }
                }

                dom_freq_vec_[d] =
                    result_type(dom_idx_vec_[d]) *
                    result_type(params_.sampling_rate) / result_type(n_bins);
                result_vec_[d] = result_type(1) / dom_freq_vec_[d];
            }

            // Mirror dim-0 into scalar members for backwards compatibility.
            //
            max_mag_ = max_mag_vec_[0];
            dom_idx_ = dom_idx_vec_[0];
            dom_freq_ = dom_freq_vec_[0];
            result_ = result_vec_[0];
        }
    }

    inline void pre()  {

        result_ = max_mag_ = dom_freq_ = 0;
        dom_idx_ = 0;
        max_mag_vec_.clear();
        dom_idx_vec_.clear();
        dom_freq_vec_.clear();
        result_vec_.clear();
    }
    inline void post()  {  }

    inline result_type get_result() const  { return (result_); }
    inline result_type get_period() const  { return (result_); }
    inline result_type get_max_magnitude() const  { return (max_mag_); }
    inline result_type get_dominant_frequency() const  { return (dom_freq_); }
    inline size_type get_dominant_index() const  { return (dom_idx_); }

    // Per-dimension accessors — only meaningful for MD input.
    //
    inline const md_result_type &
    get_md_result() const  { return (result_vec_); }

    inline const md_result_type &
    get_md_period() const  { return (result_vec_); }

    inline const md_result_type &
    get_md_max_magnitude() const  { return (max_mag_vec_); }

    inline const md_result_type &
    get_md_dominant_frequency() const  { return (dom_freq_vec_); }

    inline const std::vector<size_type> &
    get_md_dominant_index() const  { return (dom_idx_vec_); }

    explicit
    SeasonalPeriodVisitor(const SeasonalityParams<result_type> params = { })
        : params_(params)  {   }

private:

    const SeasonalityParams<result_type>    params_;

    result_type             result_ { 0 };    // period
    result_type             max_mag_ { 0 };   // Max magnitude
    result_type             dom_freq_ { 0 };  // Dominant frequency
    size_type               dom_idx_ { 0 };   // Dominant index

    // Per-dimension storage — populated only when is_md_ == true.
    //
    md_result_type          result_vec_ {  };
    md_result_type          max_mag_vec_ {  };
    md_result_type          dom_freq_vec_ {  };
    std::vector<size_type>  dom_idx_vec_ {  };
};

template<typename T, typename I = unsigned long>
using ssp_v = SeasonalPeriodVisitor<T, I>;

// ------------------------------------------------------------------------------

// Dynamic Time Warping (DTW) is an algorithm for measuring similarity between
// two temporal sequences, which may vary in speed.
//
template<typename T, typename I = unsigned long>
struct  DynamicTimeWarpVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = double;
    using distance_func = std::function<result_type(const T &x, const T &y)>;

private:

    using matrix_t = Matrix<result_type, matrix_orient::row_major>;

    static result_type def_dist_(const value_type &x, const value_type &y)  {

        if constexpr (! is_md_)  {  // Scalar path
            return (std::fabs(x - y));
        }
        else  {  // Multidimensional path
            // Works for both std::vector<data_t> and std::array<data_t, N>
            // Requires x.size() == y.size() (same dimensionality)
            //
            result_type sum { 0 };
            auto        xi { std::begin(x) };
            auto        yi { std::begin(y) };

            for (; xi != std::end(x); ++xi, ++yi)  {
                const result_type   diff {
                    static_cast<result_type>(*xi) - static_cast<result_type>(*yi)
                };

                sum += diff * diff;
            }
            return (std::sqrt(sum));
        }
    }

    template<typename H>
    inline void calc_(const H &x_begin, const H &x_end,
                      const H &y_begin, const H &y_end)  {

        const long  x_col_s { long(std::distance(x_begin, x_end)) };
        const long  y_col_s { long(std::distance(y_begin, y_end)) };
        matrix_t    mt {
            x_col_s + 1, y_col_s + 1,
            std::numeric_limits<result_type>::infinity()
        };

        mt(0, 0) = 0;
        for (long i { 1 }; i <= x_col_s; ++i)  {
            const value_type    &xval { *(x_begin + (i - 1)) };

            for (long j { 1 }; j <= y_col_s; ++j)  {
                const result_type   cost { dfunc_(xval, *(y_begin + (j - 1))) };

                mt(i, j) =
                    cost +
                    std::min({ mt(i - 1, j), mt(i, j - 1), mt(i - 1, j - 1) });
            }
        }

        result_ = mt(x_col_s, y_col_s);
    }

public:

    template<typename IV, typename H>
    inline void
    operator()(const IV &idx_begin, const IV &idx_end,
               const H &x_begin, const H &x_end,
               const H &y_begin, const H &y_end)  {

        if (nt_ > normalization_type::none)  {
            NormalizeVisitor<T, I>  x_norm_v { nt_ };
            NormalizeVisitor<T, I>  y_norm_v { nt_ };

            x_norm_v.pre();
            x_norm_v(idx_begin, idx_end, x_begin, x_end);
            x_norm_v.post();

            y_norm_v.pre();
            y_norm_v(idx_begin, idx_end, y_begin, y_end);
            y_norm_v.post();

            calc_(x_norm_v.get_result().begin(), x_norm_v.get_result().end(),
                  y_norm_v.get_result().begin(), y_norm_v.get_result().end());
        }
        else  calc_(x_begin, x_end, y_begin, y_end);
    }

    inline void pre()  { result_ = 0.0; }
    inline void post()  {  }

    inline result_type get_result() const  { return (result_); }

    explicit
    DynamicTimeWarpVisitor(
        normalization_type norm_type = normalization_type::none,
        distance_func &&f = def_dist_)
        : nt_(norm_type), dfunc_(std::forward<distance_func>(f))  {   }

private:

    const normalization_type    nt_;
    distance_func               dfunc_;
    result_type                 result_ { 0 };
};

template<typename T, typename I = unsigned long>
using dtw_v = DynamicTimeWarpVisitor<T, I>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AnomalyDetectByFFTVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // The correct FFT type for the inverse pass.
    // Scalar: std::complex<T>  (same as before)
    // MD:     T                (FFT result is already a matrix of complex;
    //                           pass T itself so fft_v<T> picks the MD path)
    //
    using ifft_value_t =
        typename std::conditional_t<! is_md_, std::complex<T>, T>;

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<size_type>,
                                    vec_t<std::pair<size_type, size_type>>>;


    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (freq_num_ >= col_s)
            throw DataFrameError("AnomalyDetectByFFTVisitor: "
                                 "freq num must be < column length");
#endif // HMDF_SANITY_EXCEPTIONS

        NormalizeVisitor<T, I, A>   norm { nt_ };

        if (nt_ > normalization_type::none)  {
            norm.pre();
            norm(idx_begin, idx_end, column_begin, column_end);
            norm.post();
        }

        fft_v<T, I, A>  fft;

        fft.pre();
        if (nt_ > normalization_type::none)
            fft(idx_begin, idx_end,
                norm.get_result().begin(), norm.get_result().end());
        else
            fft(idx_begin, idx_end, column_begin, column_end);
        fft.post();

        // fft_res type:
        //   scalar --> channel_result_t = vec<complex<T>>
        //   MD     --> Matrix<cplx_t, row_major>
        //
        auto    fft_res = std::move(fft.get_result());

        if constexpr (! is_md_)  {
            // Zero out high frequencies -- but a real signal's FFT is
            // conjugate-symmetric (bin k and bin N-k are mirrors), so
            // zeroing everything from freq_num_ to the end also wipes
            // out the mirror partners (indices N-freq_num_+1 .. N-1) of
            // the very low-frequency bins we're trying to keep. Without
            // its conjugate partner, each kept bin's contribution to the
            // inverse FFT loses the term that makes it real and full-
            // amplitude -- the reconstructed signal comes back at
            // exactly half the true amplitude for every non-DC
            // frequency (confirmed: a clean single sinusoid reconstructs
            // at a flat 0.5x ratio, pre-fix). Zero only the middle,
            // mirror-safe range [freq_num_, col_s-freq_num_+1) instead,
            // leaving both the low bins and their mirrors intact. If
            // freq_num_ is large enough that this range would be empty
            // or invalid (the two kept halves would overlap), there's
            // nothing to zero -- keep everything.
            //
            const size_type mirror_bound { col_s - freq_num_ + 1 };

            if (freq_num_ < mirror_bound)
                std::fill(fft_res.begin() + freq_num_,
                          fft_res.begin() + mirror_bound,
                          typename decltype(fft_res)::value_type { });

            // Inverse FFT: input is vec<cplx_t>, fft_v<complex<T>> picks
            // the scalar path because complex<T> satisfies IS_SCALAR
            //
            fft_v<std::complex<T>, I, A>    ifft { true };

            ifft.pre();
            ifft(idx_begin, idx_end, fft_res.begin(), fft_res.end());
            ifft.post();

            // vec<complex<complex<T>>>
            //
            const auto  &ifft_res = ifft.get_result();

            result_.reserve(((col_s / 40) < 32) ? size_type(32) : col_s / 40);
            for (size_type i { 0 }; i < col_s; ++i)  {
                // When normalization is enabled, the reconstruction was
                // built from the NORMALIZED data -- comparing it against
                // the raw, un-normalized column value is a scale
                // mismatch that produces a meaningless residual unless
                // the two scales happen to coincide by chance (confirmed:
                // a clean sinusoid with a large offset/amplitude under
                // z-score normalization got EVERY point flagged as an
                // "anomaly", since the raw values are ~1000s while the
                // normalized reconstruction is on a unit scale). Compare
                // against the same-scale (normalized) value instead.
                //
                const data_t    orig_val {
                    (nt_ > normalization_type::none)
                        ? norm.get_result()[i] : *(column_begin + i)
                };
                const data_t    residual {
                    std::abs(orig_val - ifft_res[i].real())
                };

                if (residual > ath_)  result_.push_back(i);
            }
        }
        else  {
            // -----------------------------------------------------------------
            // MD PATH
            // fft_res is Matrix<cplx_t, row_major>  (rows=samples, cols=dims)
            //
            // We cannot pass fft_res through fft_v<T> because:
            //   • fft_v<T> expects iterators over T (= std::vector<double>)
            //   • fft_res iterators dereference to cplx_t
            //
            // Instead we mirror exactly what FastFourierTransVisitor does in its
            // MD operator() path: extract each column as a channel_result_t,
            // call itransform_() directly on it, then scatter back.
            //
            // We reuse FastFourierTransVisitor's static itransform_() by
            // instantiating a temporary fft_v<T> just to access the method.
            // Since itransform_() is a private static, the cleanest approach
            // that stays inside your existing design is to run a scalar inverse
            // fft_v per channel, feeding it the column vector directly.
            // -----------------------------------------------------------------

            const size_type dim { size_type(fft_res.cols()) };

            // Zero out high frequencies across all dims -- same
            // conjugate-mirror issue as the scalar path above: only zero
            // the middle, mirror-safe range so each dimension's kept low
            // bins keep their conjugate partners.
            //
            const size_type mirror_bound { col_s - freq_num_ + 1 };

            if (freq_num_ < mirror_bound)
                for (size_type i { freq_num_ }; i < mirror_bound; ++i)
                    for (size_type d { 0 }; d < dim; ++d)
                        fft_res(i, d) =
                            typename decltype(fft_res)::value_type{ };

            // We need cplx_t which is fft_v<T>::cplx_t.
            // Derive it from the matrix element type to stay consistent.
            //
            using cplx_t = typename decltype(fft_res)::value_type; // = cplx_t
            using channel_t = typename fft_v<T, I, A>::channel_result_t;
            using matrix_t = Matrix<cplx_t, matrix_orient::row_major>;

            // ifft_matrix will hold the reconstructed complex time-domain
            // signal, same shape as fft_res
            //
            matrix_t    ifft_matrix { long(col_s), long(dim) };

            for (size_type d { 0 }; d < dim; ++d)  {
                // Extract column d from fft_res into a flat channel vector
                //
                channel_t   channel(col_s);

                for (size_type i { 0 }; i < col_s; ++i)
                    channel[i] = fft_res(i, d);

                // Run a scalar inverse FFT on this channel.
                // fft_v<cplx_t> satisfies IS_SCALAR (it's complex), so
                // operator() takes the scalar path and calls itransform_()
                // on the flat channel — exactly what we need.
                //
                fft_v<cplx_t, I, A>     ifft_chan { true };

                ifft_chan.pre();
                ifft_chan(idx_begin, idx_end, channel.begin(), channel.end());
                ifft_chan.post();

                // vec<complex<cplx_t>>
                //
                const auto  &chan_res { ifft_chan.get_result() };

                // Scatter back: real part is the reconstructed signal value
                //
                for (size_type i { 0 }; i < col_s; ++i)
                    ifft_matrix(i, d) = chan_res[i];
            }

            // Anomaly detection: compare original vs reconstructed per
            // (sample, dim). Same scale-mismatch fix as the scalar path:
            // when normalized, compare against the normalized sample,
            // not the raw one.
            //
            result_.reserve(((col_s / 40) < 32) ? size_type(32) : col_s / 40);
            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &sample {
                    (nt_ > normalization_type::none)
                        ? norm.get_result()[i] : *(column_begin + i)
                };

                for (size_type d { 0 }; d < dim; ++d)  {
                    const data_t    residual {
                        std::abs(sample[d] - ifft_matrix(i, d).real())
                    };

                    if (residual > ath_)  result_.push_back({ i, d });
                }
            }
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    AnomalyDetectByFFTVisitor(
        size_type freq_num,
        data_t anomaly_threshold = data_t(1),
        normalization_type norm_type = normalization_type::none)
        : ath_(anomaly_threshold), freq_num_(freq_num), nt_(norm_type)  {   }

private:

    const data_t                ath_;
    const size_type             freq_num_;
    const normalization_type    nt_;
    result_type                 result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using and_fft_v = AnomalyDetectByFFTVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  HampelFilterVisitor {

public:

    DEFINE_VISIT_BASIC_TYPES

    using result_type =
        std::vector<size_type, typename allocator_declare<size_type, A>::type>;

private:

    template<typename K, typename H, typename AR>
    inline void
    hampel_(K idx_begin, K idx_end, H column_begin, H column_end, AR &&aggr)  {

        GET_COL_SIZE

        aggr.pre();
        aggr(idx_begin, idx_end, column_begin, column_end);
        aggr.post();

        vec_t   diff(col_s, 0);

        std::transform(aggr.get_result().begin(), aggr.get_result().end(),
                       column_begin,
                       diff.begin(),
                       [](const T &agr, const T &col) -> T  {
                           return (std::fabs(agr - col));
                       });

        // Calculate median absolute deviation
        //
        aggr.pre();
        aggr(idx_begin, idx_end, diff.begin(), diff.end());
        aggr.post();

        const value_type    factor { num_of_std_ * unbiased_factor_ };
        const auto          &aggr_res { aggr.get_result() };

        result_.reserve(diff.size() / 10);
        for (size_type i { 0 }; i < col_s; ++i)  {
            if (diff[i] > (aggr_res[i] * factor))
                result_.push_back(i);
        }
    }

public:

    template<typename K, typename H>
    inline void
    operator()(K idx_begin, K idx_end, H column_begin, H column_end)  {

        if (type_ == hampel_type::median)
            hampel_(idx_begin, idx_end, column_begin, column_end,
                    SimpleRollAdopter<MedianVisitor<T, I>, T, I>
                        (MedianVisitor<T, I>{ true }, window_size_));
        else if (type_ == hampel_type::mean)
            hampel_(idx_begin, idx_end, column_begin, column_end,
                    SimpleRollAdopter<MeanVisitor<T, I>, T, I>
                        (MeanVisitor<T, I>{ true }, window_size_));
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    HampelFilterVisitor(size_type window_size,
                        hampel_type ht = hampel_type::median,
                        value_type num_of_std = 3)
        : window_size_(window_size),
          type_(ht),
          num_of_std_(num_of_std)  {  }

private:

    using vec_t = std::vector<T, typename allocator_declare<T, A>::type>;

    static constexpr value_type unbiased_factor_ { value_type(1.4826) };
    const size_type             window_size_;
    const hampel_type           type_;
    const value_type            num_of_std_;
    result_type                 result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using hamf_v = HampelFilterVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AnomalyDetectByIQRVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    using result_type =
        std::vector<size_type, typename allocator_declare<size_type, A>::type>;

    template <typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 20)
           throw DataFrameError(
               "AnomalyDetectByIQRVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        vec_t       data(column_begin, column_end);
        const auto  thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

        if (thread_level > 2)
            ThreadGranularity::thr_pool_.parallel_sort(data.begin(), data.end());
        else
            std::sort(data.begin(), data.end());

        const size_type     mid { col_s / 2 };
        const value_type    q1 { median_(data.begin(), data.begin() + mid) };
        const value_type    q3 {
            (col_s & size_type(0x01))
                ? median_(data.begin() + (mid + 1), data.end())  // Odd
                : median_(data.begin() + mid, data.end())        // Even
        };
        const value_type    iqr { q3 - q1 };
        const value_type    low_bound { q1 - low_fence_ * iqr };
        const value_type    high_bound { q3 + high_fence_ * iqr };

        result_.reserve(32);
        for (size_type i { 0 }; i < col_s; ++i)  {
            const value_type    &val { *(column_begin + i) };

            if (val < low_bound || val > high_bound) [[unlikely]]
                result_.push_back(i);
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    AnomalyDetectByIQRVisitor(value_type high_fence = T(1.5),
                              value_type low_fence = T(1.5))
        : high_fence_(high_fence), low_fence_(low_fence)  {   }

private:

    using vec_t = std::vector<T, typename allocator_declare<T, A>::type>;

    template <typename H>
    static inline T
    median_(const H &data_begin, const H &data_end)  {

        const size_type     s { size_type(std::distance(data_begin, data_end)) };
        const size_type     mid { s / 2 };
        const value_type    &mid_val { *(data_begin + mid) };

        if (s & size_type(0x01))  // Odd
            return (mid_val);
        else                      // Even
            return ((*(data_begin + (mid - 1)) + mid_val) / T(2));
    }

    const value_type    high_fence_;
    const value_type    low_fence_;
    result_type         result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using and_iqr_v = AnomalyDetectByIQRVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AnomalyDetectByZScoreVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<size_type>,
                                    vec_t<std::pair<size_type, size_type>>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 10)
           throw DataFrameError(
               "AnomalyDetectByZScoreVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        StdVisitor<T, I>    svisit { false, true };

        svisit.pre();
        svisit(idx_begin, idx_end, column_begin, column_end);
        svisit.post();

        const auto  &mean { svisit.get_mean() };
        const auto  &stdev { svisit.get_result() };

        result_.reserve(((col_s / 40) < 32) ? size_type(32) : col_s / 40);
        if constexpr (! is_md_)  {
            for (size_type i { 0 }; i < col_s; ++i)
                if (std::abs((*(column_begin + i) - mean) / stdev) > threshold_)
                    result_.push_back(i);
        }
        else  {
            const auto  dim { column_begin->size() };

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &input { *(column_begin + i) };

                for (size_type d { 0 }; d < dim; ++d)  {
                    if (std::abs((input[d] - mean[d]) / stdev[d]) > threshold_)
                        result_.push_back({ i, d });
                }
            }
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    AnomalyDetectByZScoreVisitor(data_t threshold) : threshold_(threshold) {  }

private:

    result_type     result_ { };
    const data_t    threshold_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using and_zscr_v = AnomalyDetectByZScoreVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AnomalyDetectByLOFVisitor  {

public:

    DEFINE_VISIT_BASIC_TYPES

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using dist_vec_t = std::vector<double>;
    using pvec_t = std::vector<std::pair<double, size_type>> ;
    using knn_mat_t =
        Matrix<std::pair<double, size_type>, matrix_orient::row_major>;
    using rch_mat_t = Matrix<double, matrix_orient::row_major>;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using result_type = vec_t<size_type>;
    using distance_func = std::function<double(const T &x, const T &y)>;

    static double def_dist(const value_type &x, const value_type &y)  {

        if constexpr (! is_md_)  {  // Scalar path
            return (std::fabs(x - y));
        }
        else  {  // Multidimensional path
            double  sum { 0 };
            auto    xi { std::begin(x) };
            auto    yi { std::begin(y) };

            for (; xi != std::end(x); ++xi, ++yi)  {
                const double    diff { double(*xi - *yi) };

                sum += diff * diff;
            }
            return (std::sqrt(sum));
        }
    }

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 20 || k_ >= (col_s - 1))
            throw DataFrameError("AnomalyDetectByLOFVisitor: "
                                 "Time-series is too short or k is too large");
#endif // HMDF_SANITY_EXCEPTIONS

        NormalizeVisitor<T, I, A>   norm { nt_ };

        if (nt_ > normalization_type::none)  {
            norm.pre();
            norm(idx_begin, idx_end, column_begin, column_end);
            norm.post();
        }

        // For MD, col_s is the number of rows (observations).
        // dim is 1 for scalar, or the vector/array width for MD.
        //
        pvec_t      dists(col_s);
        knn_mat_t   neighbors { long(col_s), long(k_) };
        rch_mat_t   reach_dists { long(col_s), long(k_) };
        dist_vec_t  lrd(col_s, 0);  // Local Reachability Density

        for (size_type i { 0 }; i < col_s; ++i)  {
            if (nt_ > normalization_type::none)
                get_knn_(norm.get_result().begin(), col_s, i, neighbors, dists);
            else
                get_knn_(column_begin, col_s, i, neighbors, dists);

            double  sum_reach_dist { 0 };

            for (long j { 0 }; j < neighbors.cols(); ++j)  {
                const double    reach_d {
                    std::max(neighbors(i, j).first,
                             dfunc_(*(column_begin + j), *(column_begin + i)))
                };

                reach_dists(long(i), j) = reach_d;
                sum_reach_dist += reach_d;
            }

            lrd[i] = double(k_) / sum_reach_dist;
        }

        result_.reserve(((col_s / 40) < 32) ? size_type(32) : col_s / 40);
        for (size_type i { 0 }; i < col_s; ++i)  {
            double  sum_ratio { 0 };

            for (long j { 0 }; j < neighbors.cols(); ++j)
                sum_ratio += lrd[neighbors(long(i), j).second] / lrd[i];

            if ((sum_ratio / double(k_)) > threshold_)
                result_.push_back(i);
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    AnomalyDetectByLOFVisitor(
        size_type k,
        double threshold,
        normalization_type norm_type = normalization_type::none,
        distance_func &&f = def_dist)
        : k_(k),
          threshold_(threshold),
          nt_(norm_type),
          dfunc_(std::forward<distance_func>(f))  {   }

private:

    template <typename H>
    inline void
    get_knn_(const H &column_begin,
             size_type col_s, size_type index,
             knn_mat_t &neighbors, pvec_t &dists) const  {

        const auto  thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };
        const auto  &idx_val { *(column_begin + index) };
        auto        lbd =
            [&dists, this,
             &column_begin = std::as_const(column_begin),
             &idx_val = std::as_const(idx_val)]
            (auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)
                    dists[i] = { dfunc_(idx_val, *(column_begin + i)), i };
            };

        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0), col_s, std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
            ThreadGranularity::thr_pool_.parallel_sort(
                dists.begin(), dists.end(),
                [](const auto &lhs, const auto &rhs)  {
                    return (lhs.first < rhs.first);
                });
        }
        else  {
            lbd(size_type(0), col_s);
            std::sort(dists.begin(), dists.end(),
                      [](const auto &lhs, const auto &rhs)  {
                          return (lhs.first < rhs.first);
                      });
        }

        // Skip the first element which is 0 (distance of index with itself)
        //
        for (size_type i { 1 }; i <= k_; ++i)
            neighbors(long(index), long(i - 1)) = dists[i];
        return;
    }

    const size_type             k_;
    const double                threshold_;
    const normalization_type    nt_;
    distance_func               dfunc_;
    result_type                 result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using and_lof_v = AnomalyDetectByLOFVisitor<T, I, A>;

// ------------------------------------------------------------------------------

// Mutual Information
//
template<typename T, typename I = unsigned long>
struct  MutualInfoVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    using equal_t =
        typename std::conditional_t<std::is_floating_point_v<data_t>,
                                    FloatEqual<data_t>,
                                    std::equal_to<data_t>>;

    using x_hasher_t = std::conditional_t<std::is_floating_point_v<data_t>,
                                          FloatHash<data_t>,
                                          std::hash<data_t>>;

    using x_map_t =
        typename std::conditional_t<
            ! is_md_,
            std::unordered_map<T, double, x_hasher_t, equal_t>,
            std::unordered_map<T, double, VectorHasher<data_t>, equal_t>>;

    using xy_map_t =
        std::unordered_map<std::pair<T, T>,
                           double,
                           PairHasher<std::pair<T, T>>,
                           PairEqual<std::pair<T, T>>>;

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type = double;

    template<typename K, typename H>
    inline void
    operator()(const K & /*idx_begin*/, const K & /*idx_end*/,
               const H &column1_begin, const H &column1_end,
               const H &column2_begin, const H &column2_end)  {

        const size_type col_s {
            size_type(std::distance(column1_begin, column1_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type col2_s {
            size_type(std::distance(column2_begin, column2_end))
        };

        if (col_s != col2_s)
            throw DataFrameError("MutualInfoVisitor: "
                                 "The two variables must have the same "
                                 "number of observations");
#endif // HMDF_SANITY_EXCEPTIONS

        x_map_t     count_x;
        x_map_t     count_y;
        xy_map_t    count_xy;
        const auto  thread_level {
            (col_s < (ThreadPool::MUL_THR_THHOLD / 3))
                ? 0L : ThreadGranularity::get_thread_level()
        };

        if (thread_level > 2)  {
            auto    fut1 {
                ThreadGranularity::thr_pool_.dispatch(
                    false,
                    [&column1_begin = std::as_const(column1_begin),
                     col_s, &count_x]() -> void  {
                        for (size_type i { 0 }; i < col_s; ++i)  {
                            const auto  &val { *(column1_begin + i) };
                            auto        [it, inserted] {
                                count_x.try_emplace(val, 0.0)
                            };

                            it->second += 1.0;
                        }
                    })
            };
            auto    fut2 {
                ThreadGranularity::thr_pool_.dispatch(
                    false,
                    [&column2_begin = std::as_const(column2_begin),
                     col_s, &count_y]() -> void  {
                        for (size_type i { 0 }; i < col_s; ++i)  {
                            const auto  &val { *(column2_begin + i) };
                            auto        [it, inserted] {
                                count_y.try_emplace(val, 0.0)
                            };

                            it->second += 1.0;
                        }
                    })
            };
            auto    fut3 {
                ThreadGranularity::thr_pool_.dispatch(
                    false,
                    [&column1_begin = std::as_const(column1_begin),
                     &column2_begin = std::as_const(column2_begin),
                     col_s, &count_xy]() -> void  {
                        for (size_type i { 0 }; i < col_s; ++i)  {
                            const auto  &val1 { *(column1_begin + i) };
                            const auto  &val2 { *(column2_begin + i) };
                            auto        [it, inserted] {
                                count_xy.try_emplace({ val1, val2 }, 0.0)
                            };

                            it->second += 1.0;
                        }
                    })
            };

            fut1.get();
            fut2.get();
            fut3.get();
        }
        else  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &val1 { *(column1_begin + i) };
                const auto  &val2 { *(column2_begin + i) };

                count_x.insert({ val1, 0 }).first->second += 1.0;
                count_y.insert({ val2, 0 }).first->second += 1.0;
                count_xy.insert({ { val1, val2 }, 0 }).first->second += 1.0;
            }
        }

        // The MI formula sums p(x,y)*log(p(x,y)/(p(x)p(y))) once per
        // UNIQUE (x,y) pair (the support of the joint distribution) --
        // count_xy already holds exactly that, one entry per unique
        // pair with its occurrence count. Materialize it into a vector
        // first so the summation can still be chunk-parallelized (an
        // unordered_map has no random-access range to split), then
        // iterate over pairs, not rows: a pair seen n_xy times must
        // contribute its term exactly once, not n_xy times.
        //
        using xy_entry_t = std::pair<std::pair<T, T>, double>;

        std::vector<xy_entry_t> xy_vec(count_xy.begin(), count_xy.end());

        double  mi { 0 };
        auto    lbd =
            [&count_x = std::as_const(count_x),
             &count_y = std::as_const(count_y),
             &xy_vec = std::as_const(xy_vec),
             col_s]
            (auto begin, auto end) -> double  {
                double  mi { 0 };

                for (size_type i { begin }; i < end; ++i)  {
                    const auto  &[key, n_xy] { xy_vec[i] };
                    const auto  p_xy { n_xy / col_s };
                    const auto  p_x { count_x.find(key.first)->second / col_s };
                    const auto  p_y { count_y.find(key.second)->second / col_s };

                    if (p_xy > 0)
                        mi += p_xy * std::log(p_xy / (p_x * p_y));
                }
                return (mi);
            };

        const size_type xy_s { xy_vec.size() };

        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0), xy_s, std::move(lbd))
            };

            for (auto &fut : futures)  mi += fut.get();
        }
        else  {
            mi = lbd(size_type(0), xy_s);
        }

        // Convert from nat (natural unit) to bits (base 2)
        //
        result_ = mi / log_log_base_;
    }

    inline void pre()  { result_ = 0; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }

    explicit
    MutualInfoVisitor(double log_base = 2)
        : log_log_base_(std::log(log_base))  {   }

private:

    // template<typename M>
    // inline static void map_reserve_(M &in_map, size_type in_size)  {

    //     auto    c { std::move(in_map).extract() };
    //     auto    key_vec { std::move(c.keys) };
    //     auto    val_vec { std::move(c.values) };

    //     key_vec.reserve(in_size);
    //     val_vec.reserve(in_size);
    //     in_map.replace(std::move(key_vec), std::move(val_vec));
    // }

    result_type     result_ { 0 };
    const double    log_log_base_;
};

template<typename T, typename I = unsigned long>
using mut_i_v = MutualInfoVisitor<T, I>;

// ------------------------------------------------------------------------------

// AutoRegressive Integrated Moving Average
//
template<arithmetic T, typename I = unsigned long>
struct  ARIMAVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = std::vector<T>;

    template<typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin, const H &column_end)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        GET_COL_SIZE2

        if (col_s < 5 && n_ <= (std::max(p_, q_) + 1))
            throw DataFrameError("ARIMAVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        y_ = difference_(column_begin, column_end, d_);
        n_ = y_.size();

        if (n_ <= (std::max(p_, q_) + 1))
            throw DataFrameError("ARIMAVisitor: "
                                 "Not enough data after differencing");

        // Fit AR part via OLS
        //
        fit_ar_();

        // Fit MA part by iterative refinement (very simplified)
        //
        fit_ma_();

        // Compute residual variance
        //
        compute_residuals_();

        //
        // Now forecast
        //

        result_type diffed { y_ };
        result_type preds;

        preds.resize(periods_);
        for (long t { 0 }; t < periods_; ++t) {
            value_type  ar_part { 0 };
            value_type  ma_part { 0 };

            for (long i { 1 }; i <= p_; ++i)
                if (long(diffed.size()) >= i)
                    ar_part += ar_coeffs_[i - 1] * diffed[diffed.size() - i];

            // Use known residuals from training for the first q_ steps.
            // At step t, the residual at lag j corresponds to index (n_-j+t)
            // in the residuals_ array. Once that index >= n_, the residual is
            // from a future (unknown) period, so it contributes 0 — which is
            // the standard ARIMA forecast assumption.
            //
            for (long j { 1 }; j <= q_; ++j) {
                const long   idx { n_ - j + t };

                if (idx >= 0 && idx < n_)
                    ma_part += ma_coeffs_[j - 1] * residuals_[idx];
            }

            const value_type    pred { ar_part + ma_part };

            preds[t] = pred;
            diffed.push_back(pred);
        }

        result_ = invert_difference_(*(column_end - 1),
                                     preds.begin(), preds.end(),
                                     d_);
    }

    inline void pre()  {

        n_ = 0;
        sigma2_ = 0;
        y_.clear();
        residuals_.clear();
        ar_coeffs_.clear();
        ma_coeffs_.clear();
        result_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    inline const value_type &get_sigma_sq() const  { return (sigma2_); }
    inline const result_type &get_phi() const  { return (ar_coeffs_); }
    inline const result_type &get_theta() const  { return (ma_coeffs_); }
    inline const result_type &get_residuals() const  { return (residuals_); }

    explicit
    ARIMAVisitor(long periods = 3,
                 long autoreg_order = 2,
                 long diff = 1,
                 long mav_order = 1)
        : p_(autoreg_order), d_(diff), q_(mav_order), periods_(periods)  {   }

private:

    using matrix_t = Matrix<value_type, matrix_orient::row_major>;
    using vec_t = std::vector<value_type>;

    template<typename MA1, typename MA2>
    static inline result_type
    solve_(const MA1 &L, const result_type &D, const MA2 &b) {

        long        n { long(D.size()) };
        result_type y(n, 0), z(n, 0), x(n, 0);

        // Forward substitution: LY = b
        //
        for (long i { 0 }; i < n; ++i) {
            y[i] = b(0, i);
            for (long j { 0 }; j < i; ++j)
                y[i] -= L(i, j) * y[j];
        }

        // Diagonal solve: DZ = Y
        //
        for (long i { 0 }; i < n; ++i)
            z[i] = y[i] / D[i];

        // Backward substitution: LtX = Z
        //
        for (long i { n - 1 }; i >= 0; --i) {
            x[i] = z[i];
            for (long j { i + 1 }; j < n; ++j)
                x[i] -= L(j, i) * x[j];
        }

        return (x);
    }

    // 1) Fit AutoRegressive coefficients via Ordinary Least Squares (OLS)
    //
    void fit_ar_() {

        if (p_ <= 0 || y_.size() <= size_type(p_))
            throw DataFrameError("ARIMAVisitor::fit_ar_(): "
                                 "Invalid AutoRegressive order or data size");

        long        m { n_ - p_ };
        matrix_t    X { m, p_, 0 };
        vec_t       Y(m);

        for (long i { 0 }; i < m; ++i) {
            for (long j { 0 }; j < p_; ++j)
                X(i, j) = y_[i + p_ - j - 1];  // Lagged values
            Y[i] = y_[i + p_];  // Current value
        }

        const auto  XtX { X.transpose() * X };
        const auto  XtY { X.transpose() * Y };

        result_type D;   // Diagonal matrix
        matrix_t    L;   // Lower matrix

        XtX.ldlt(D, L);
        ar_coeffs_ = solve_(L, D, XtY.transpose());

        // Simpler but not numerically stable version
        //
        // const auto  coefs_mat { XtX.solve(XtY) };

        // ar_coeffs_.resize(coefs_mat.rows());
        // for (long r { 0 }; r < coefs_mat.rows(); ++r)
        //     ar_coeffs_[r] = coefs_mat(r, 0);
    }

    // 2) Fit Moving Average coefficients iteratively (simplified)
    //
    void fit_ma_() {

        if (q_ == 0)  return;

        ma_coeffs_.resize(q_, 0);
        residuals_.resize(n_, 0);

        result_type             prev_ma = ma_coeffs_;
        constexpr long          max_iter { 50 };
        constexpr value_type    tol { T(1e-6) };

        for (long iter { 0 }; iter < max_iter; ++iter) {
            compute_residuals_();

            // Update each MA coefficient with small step toward correlation.
            // Lag j's coefficient lives at ma_coeffs_[j-1] everywhere else
            // in this visitor (compute_residuals_, the forecast loop) --
            // j must run 1..q_ inclusive and store at j-1, or lag q_ is
            // never fit and every coefficient that IS fit lands one slot
            // off from where it's read. With the old `j=1; j<q_` bound
            // this loop body never ran at all for the default q_=1.
            //
            for (long j { 1 }; j <= q_; ++j)  {
                value_type  numer { 0 };
                value_type  denom { 0 };

                for (long t { j }; t < n_; ++t) {
                    numer += residuals_[t] * residuals_[t - j];
                    denom += residuals_[t - j] * residuals_[t - j];
                }
                if (denom != 0)
                    ma_coeffs_[j - 1] = numer / denom;
            }

            value_type  diff { 0 };

            for (long j { 0 }; j < q_; ++j)
                diff += std::fabs(ma_coeffs_[j] - prev_ma[j]);
            if (diff < tol)  break;
            prev_ma = ma_coeffs_;
        }
    }

    // 3) Compute residuals using AR and MA parts
    //
    void compute_residuals_()  {

        residuals_.resize(n_, 0);
        for (long t { 0 }; t < n_; ++t) {
            value_type  ar_part { 0 };
            value_type  ma_part { 0 };

            for (long i { 1 }; i <= p_; ++i)
                if (t >= i)
                    ar_part += ar_coeffs_[i - 1] * y_[t - i];
            for (long j { 1 }; j <= q_; ++j)
                if (t >= j)
                    ma_part += ma_coeffs_[j - 1] * residuals_[t - j];
            residuals_[t] = y_[t] - (ar_part + ma_part);
        }

        value_type  ss { 0 };

        for (const value_type r : residuals_)  ss += r * r;
        sigma2_ = ss / n_;
    }

    template<typename H>
    static inline result_type
    difference_(const H &column_begin, const H &column_end, long d)  {

        result_type diff(column_begin, column_end);

        for (long i { 0 }; i < d; ++i) {
            result_type tmp;

            tmp.reserve(diff.size());
            for (size_t j { 1 }; j < diff.size(); ++j)
                tmp.push_back(diff[j] - diff[j - 1]);
            diff = std::move(tmp);
        }

        return (diff);
    }

    template<typename K>
    static inline result_type
    invert_difference_(value_type last_data,
                       const K &diffed_begin, const K &diffed_end,
                       long d)  {

        if (d == 0)  {
            const result_type   inverted(diffed_begin, diffed_end);

            return (inverted);
        }

        const size_type diff_s {
            size_type(std::distance(diffed_begin, diffed_end))
        };
        result_type     inverted;

        inverted.resize(diff_s);
        for (size_type i { 0 }; i < diff_s; ++i)  {
            last_data += *(diffed_begin + i);
            inverted[i] = last_data;
        }

        // Apply remaining d-1 cumulative sum passes.
        // Each pass simulates one level of undifferencing.
        // We need an anchor (first element) from the original series for each
        // pass, but since we only have the last observed value, we approximate
        // by using the first element of the current inverted result as the
        // running anchor for subsequent passes.
        //
        for (long pass { 1 }; pass < d; ++pass)  {
            value_type  anchor { inverted[0] };

            for (size_type i { 1 }; i < diff_s; ++i)  {
                anchor += inverted[i];
                inverted[i] = anchor;
            }
        }

        return (inverted);
    }

    // AutoRegressive order: Number of lagged observations (past values)
    // included in the model. Determines how many previous time steps are
    // linearly combined.
    //
    const long  p_;

    // Integration order (differencing): Number of times the original series
    // is differenced to make it stationary. d=1 means use first differences
    // (i.e., Yt - Yt-1₁).
    //
    const long  d_;

    // Moving Average order: Number of lagged forecast errors (residuals) used
    // to model the noise structure.
    //
    const long  q_;

    // Number of periods to forecast
    //
    const long periods_;

    // The length of the working time series after differencing
    //
    long        n_ { 0 };
    value_type  sigma2_ { 0 };  // variance of the residuals

    result_type y_ { };
    result_type residuals_ { };
    result_type ar_coeffs_ { };
    result_type ma_coeffs_ { };
    result_type result_ { };
};

template<typename T, typename I = unsigned long>
using arima_v = ARIMAVisitor<T, I>;

// ------------------------------------------------------------------------------

// Holt–Winters Exponential Smoothing forecasting
//
template<typename T, typename I = unsigned long>
struct  HWESForecastVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    inline static T make_zero_proto_(const T &proto)  {

        if constexpr (! is_md_)  {
            return (T{ 0 });
        }
        else  {
            T   z = proto;  // copy shape

            for (auto &v : z)  v = data_t(0);
            return (z);
        }
    }

    inline static void floor_zero_(T &x)  {

        if constexpr (! is_md_)  {
            if (x == data_t(0))  x = data_t(1e-8);
        }
        else  {
            for (auto &v : x)
                if (v == data_t(0))  v = data_t(1e-8);
        }
    }

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type = std::vector<value_type>;

    template<typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 5)
           throw DataFrameError(
               "HWESForecastVisitor: Time-series is too short");
        if (col_s < (2 * season_length_))
            throw DataFrameError("HWESForecastVisitor: "
                                 "Need at least two full seasons of data to "
                                 "initialize seasonal factors reliably");
        if constexpr (is_md_)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "HWESForecastVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        zero_proto_ = make_zero_proto_(*column_begin);
        fit_(column_begin, col_s);

        result_.resize(periods_);
        if (season_length_ == 0)  {  // Holt (no seasonality)
            for (size_type i { 1 }; i <= periods_; ++i)
                result_[i - 1] = level_ + data_t(i) * trend_;
        }
        else  {  // Holt-Winters with seasonality
            // We need the most recent seasonal factors
            // (we have seasonal_factors_ as last L values)
            //
            // seasonal_factors_ holds the trailing season_length_ raw
            // seasonal values in original chronological order (position 0
            // is the oldest retained one, at absolute time col_s - m;
            // position m - 1 is the newest, at col_s - 1 -- see how fit_()
            // populates it via seasons.begin() + (col_s-season_length_)).
            // Step i's forecast target is i positions past the last
            // retained position, so the correct offset into that trailing
            // window is (i - 1) % m, counting forward from position 0
            //
            for (size_type i { 1 }; i <= periods_; ++i) {
                const size_type season_index { // index into seasonal_factors_
                    (i - 1) % season_length_
                };

                if (season_type_ == decompose_type::additive)
                    result_[i - 1] =
                        level_ + data_t(i) * trend_ +
                        seasonal_factors_[season_index];
                else
                    result_[i - 1] =
                        (level_ + data_t(i) * trend_) *
                        seasonal_factors_[season_index];
            }
        }
    }

    inline void pre()  {

        trend_ = zero_proto_;
        level_ = zero_proto_;
        fitted_.clear();
        result_.clear();
        seasonal_factors_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline const result_type &
    get_seasonal_factors() const  { return (seasonal_factors_); }
    inline const result_type &get_fitted() const  { return (fitted_); }

    explicit
    HWESForecastVisitor(long periods = 3,
                        size_type season_length = 0,
                        data_t alpha = 0.25,
                        data_t beta = 0.1,
                        data_t gamma = 0.1,
                        decompose_type season_type = decompose_type::additive)
        : periods_(periods),
          season_length_(season_length),
          alpha_(alpha),
          beta_(beta),
          gamma_(gamma),
          season_type_(season_type)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        if (! (alpha_ >= 0 && alpha_ <= 1))
            throw DataFrameError("HWESForecastVisitor: "
                                 "Alpha must be in [0, 1]");
        if (! (beta_  >= 0 && beta_ <= 1))
            throw DataFrameError("HWESForecastVisitor: "
                                 "Beta must be in [0, 1]");
        if (season_length_ > 0 && ! (gamma_ >= 0 && gamma_ <= 1))
            throw DataFrameError("HWESForecastVisitor: "
                                 "Gamma must be in [0, 1]");
#endif // HMDF_SANITY_EXCEPTIONS
    }

private:

    template<typename H>
    inline void
    fit_(const H &data_begin, size_type col_s)  {

        fitted_.resize(col_s, zero_proto_);

        if (season_length_ == 0)  {  // Simple Holt (no seasonality)
            init_level_and_trend_no_season_(data_begin, col_s);

            result_type levels(col_s, zero_proto_);
            result_type trends(col_s, zero_proto_);

            levels[0] = level_;
            trends[0] = trend_;
            fitted_[0] = levels[0];
            for (size_type t { 1 }; t < col_s; ++t)  {
                const value_type    &y { *(data_begin + t) };

                levels[t] = alpha_ * y +
                            (data_t(1) - alpha_) * (levels[t - 1] +
                            trends[t - 1]);
                trends[t] = beta_ * (levels[t] - levels[t - 1]) +
                            (data_t(1) - beta_) * trends[t - 1];
                fitted_[t] = levels[t - 1] + trends[t - 1];
            }
            level_ = levels.back();
            trend_ = trends.back();
        }
        else  {
            // Initialize seasonal indices
            //
            init_components_with_seasonality_(data_begin, col_s);

            // Containers for level, trend, seasonal (we keep history)
            //
            result_type levels(col_s, zero_proto_);
            result_type trends(col_s, zero_proto_);
            result_type seasons(col_s, zero_proto_);

            levels[0] = level_;
            trends[0] = trend_;

            // Initialize seasons[0..season_length_-1] with seasonal_factors_
            //
            for (size_type i { 0 }; i < season_length_; ++i)
                seasons[i] = seasonal_factors_[i];

            // fitted at t = 0:
            //
            fitted_[0] = (season_type_ == decompose_type::additive)
                             ? levels[0] + trends[0] + seasons[0]
                             : (levels[0] + trends[0]) * seasons[0];

            for (size_type t { 1 }; t < col_s; ++t) {
                const value_type    &y { *(data_begin + t) };
                const long          idx_season_lag {
                    long(t) - long(season_length_)
                };
                value_type          s_lag {
                    (idx_season_lag >= 0)
                        ? seasons[idx_season_lag]
                        : seasonal_factors_[(t % season_length_ +
                                             season_length_) %
                                            season_length_]
                };

                if (season_type_ == decompose_type::additive)  {
                    levels[t] =
                        alpha_ * (y - s_lag) +
                        (data_t(1) - alpha_) * (levels[t - 1] +
                        trends[t - 1]);
                    trends[t] =
                        beta_ * (levels[t] - levels[t - 1]) +
                        (data_t(1) - beta_) * trends[t - 1];
                    seasons[t] =
                        gamma_ * (y - levels[t]) + (data_t(1) - gamma_) * s_lag;

                    // forecasted value for t using previous components
                    //
                    fitted_[t] = levels[t - 1] + trends[t - 1] + s_lag;
                }
                else  {  // Multiplicative formulas
                    floor_zero_(s_lag);
                    levels[t] =
                        alpha_ * (y / s_lag) +
                        (data_t(1) - alpha_) * (levels[t - 1] + trends[t - 1]);
                    trends[t] =
                        beta_ * (levels[t] - levels[t - 1]) +
                        (data_t(1) - beta_) * trends[t - 1];

                    floor_zero_(levels[t]);
                    seasons[t] =
                        gamma_ * (y / levels[t]) + (data_t(1) - gamma_) * s_lag;
                    fitted_[t] = (levels[t - 1] + trends[t - 1]) * s_lag;
                }
            }

            // Save last states
            //
            level_ = levels.back();
            trend_ = trends.back();
            seasonal_factors_.assign(seasons.begin() + (col_s - season_length_),
                                     seasons.end()); // last season values
        }

        return;
    }

    template<typename H>
    inline void
    init_level_and_trend_no_season_(const H &data_begin, size_type col_s)  {

        // level_ as first observation, trend_ estimated by average of first
        // differences over some points
        //
        level_ = *data_begin;

        value_type      sum_diff { zero_proto_ };

        // Use up to first 10 diffs for robust estimate
        //
        const size_type upto { std::min(col_s - 1, size_type(10)) };
        size_type       count { 0 };

        for (size_type i { 0 }; i < upto; ++i)  {
            sum_diff += (*(data_begin + (i + 1)) - *(data_begin + i));
            count += 1;
        }
        trend_ = (count > 0) ? (sum_diff / data_t(count)) : zero_proto_;
    }

    template<typename H>
    inline void
    init_components_with_seasonality_(const H &data_begin, size_type col_s)  {

        // Number of complete seasons
        //
        size_type   n_seasons { col_s / season_length_ };

        // Ensure at least 2 to avoid division by zero in computations
        // (we validated earlier)
        //
        if (n_seasons < 2)  n_seasons = 2;

        // 1) Compute season_averages[j] for each season j
        //
        result_type season_averages(n_seasons, zero_proto_);

        for (size_type j { 0 }; j < n_seasons; ++j) {
            value_type  sum  { zero_proto_ };

            for (size_type i { 0 }; i < season_length_; ++i)
                sum += *(data_begin + (j * season_length_ + i));
            season_averages[j] = sum / data_t(season_length_);
        }

        // 2) Initial seasonal factors (for i=0..season_length_-1)
        //
        seasonal_factors_.resize(season_length_, zero_proto_);
        for (size_type i { 0 }; i < season_length_; ++i) {
            value_type  sum_over_seasons { zero_proto_ };
            size_type   count { 0 };

            for (size_type j { 0 }; j < n_seasons; ++j) {
                const size_type idx { j * season_length_ + i };

                if (idx < col_s) {
                    const value_type   &obs { *(data_begin + idx) };

                    if (season_type_ == decompose_type::additive) {
                        sum_over_seasons += (obs - season_averages[j]);
                    }
                    else  {
                        value_type  denom { season_averages[j] };

                        floor_zero_(denom);
                        sum_over_seasons += (obs / denom);
                    }
                    count += 1;
                }
            }
            seasonal_factors_[i] =
                (count > 0) ? (sum_over_seasons / data_t(count)) : zero_proto_;
        }

        // 3) Initial level: first season average (or overall mean)
        //
        level_ = season_averages[0];

        // 4) Initial trend: average change in season averages per
        //    time / per-period slope
        //
        value_type  sum_diff { zero_proto_ };

        if (n_seasons >= 2)  {
            for (size_type j { 0 }; j < n_seasons - 1; ++j)
                sum_diff += (season_averages[j + 1] - season_averages[j]);

            // convert difference per season into per-period trend by dividing
            // by season_length_ and by number of gaps
            //
            trend_ =
                (sum_diff / data_t(n_seasons - 1)) / data_t(season_length_);
        }
        else  {  // Fallback: average of first-season differences
            const size_type upto { std::min(season_length_ - 1, col_s - 1) };

            for (size_type i { 0 }; i < upto; ++i)
                sum_diff += (*(data_begin + (i + 1)) - *(data_begin + i));
            trend_ = (upto > 0) ? sum_diff / data_t(upto) : zero_proto_;
        }
    }

    const size_type         periods_;  // Number of periods to forecast

    // season_length tells the algorithm how many data points make up one full
    // seasonal cycle — that is, how long it takes for a pattern to repeat.
    //
    const size_type         season_length_;

    // Level smoothing, Alpha controls how much weight the algorithm gives to
    // the most recent observation when updating the level (the estimated base
    // value around which data fluctuates).
    //
    // High (close to 1), the model reacts quickly to recent changes.
    // Low (close to 0), the level is smoothed heavily, slow to react
    // (more stable).
    //
    const data_t            alpha_;

    // Trend smoothing, Beta controls how quickly the trend (slope) adapts
    // over time. In the additive model
    //
    // High (close to 1), trend changes rapidly (useful if the slope changes
    // often).
    // Low (close to 0), trend is stable (changes only slowly).
    //
    const data_t            beta_;

    // Seasonal smoothing, Gamma controls how fast the seasonal pattern
    // e.g., monthly or weekly fluctuations) is updated.
    //
    // High (close to 1), seasonal effects can shift quickly (good if the
    // pattern changes over time).
    // Low (close to 0), seasonality assumed stable.
    //
    const data_t            gamma_;

    // season_type tells the algorithm how seasonal effects combine with the
    // base signal (level + trend).
    //
    // Additive: seasonality is added on top of the baseline.
    // Multiplicative: seasonality scales the baseline.
    //
    const decompose_type    season_type_;

    value_type              trend_ { };
    value_type              level_ { };
    result_type             seasonal_factors_ { };
    result_type             fitted_ { };
    result_type             result_ { };
    value_type              zero_proto_ { };
};

template<typename T, typename I = unsigned long>
using hwes_v = HWESForecastVisitor<T, I>;

// ------------------------------------------------------------------------------

// Long Short-Term Memory (LSTM) forecasting
//
template<typename T, typename I = unsigned long>
struct  LSTMForecastVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = std::vector<value_type>;
    using seed_t = unsigned int;

private:

    using matrix_t = Matrix<data_t, matrix_orient::column_major>;
    using mat_vec_t = std::vector<matrix_t>;
    using data_vec_t = std::vector<data_t>;

    static inline data_t
    sigmoid_(data_t x)  { return (data_t(1) / (std::exp(-x) + data_t(1))); }
    static inline data_t
    dsigmoid_from_out_(data_t y)  { return (y * (data_t(1) - y)); }
    static inline data_t
    dtanh_from_out_(data_t y)  { return (data_t(1) - y * y); }

    static inline data_t
    mse_loss_and_grad_(const matrix_t &pred,
                       const matrix_t &target,
                       matrix_t &dout)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        if (pred.rows() != target.rows() || pred.cols() != target.cols())
            throw DataFrameError("LSTMForecastVisitor::mse_loss_and_grad_(): "
                                 "MSE shape mismatch");
#endif // HMDF_SANITY_EXCEPTIONS

        dout = matrix_t { pred.rows(), pred.cols(), 0 };

        data_t          sum { 0 };
        const data_t    data_s { data_t(pred.rows() * pred.cols()) };
        auto            lbd =
            [&dout, data_s,
             &pred = std::as_const(pred),
             &target = std::as_const(target)]
            (long begin, long end) -> data_t  {
                data_t  sum { 0 };

                for (long c { begin }; c < end; ++c)
                    for (long r { 0 }; r < pred.rows(); ++r)  {
                        const data_t    diff { pred(r, c) - target(r, c) };

                        sum += diff * diff;
                        dout(r, c) = data_t(2) * diff / data_s;
                    }
                return (sum);
            };
        const auto      thread_level {
            (pred.cols() < 500) ? 0L : ThreadGranularity::get_thread_level()
        };

        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, pred.cols(), std::move(lbd))
            };

            for (auto &fut : futures)  sum += fut.get();
        }
        else  {
            sum = lbd(0L, pred.cols());
        }

        return (sum / data_s);
    }

    // LSTM cell
    //
    struct  LSTMCell  {

        const long  input_size, hidden_size;
        matrix_t    W, U, b, dW, dU, db;

        LSTMCell(long in, long hid, seed_t seed)
            : input_size(in),
              hidden_size(hid),
              W(matrix_t::get_random(in,
                                     4 * hid,
                                     data_t(-0.1),
                                     data_t(0.1),
                                     seed)),
              U(matrix_t::get_random(hid,
                                     4 * hid,
                                     data_t(-0.1),
                                     data_t(0.1),
                                     seed)),
              b(1, 4 * hid, 0),
              dW(in, 4 * hid, 0),
              dU(hid, 4 * hid, 0),
              db(1, 4 * hid, 0)  {   }
        LSTMCell() = delete;

        struct  Cache  {
            matrix_t    x, h_prev, c_prev, i, f, g, o, c, h;
        };

        Cache
        forward(const matrix_t &x,
                const matrix_t &h_prev,
                const matrix_t &c_prev)  {

            const long  batch { x.rows() }, H { hidden_size };
            matrix_t    gates { x * W + h_prev * U };

            for (long c { 0 }; c < b.cols(); ++c)  {
                const auto  val { b(0, c) };

                for (long r { 0 }; r < batch; ++r)
                    gates(r, c) += val;
            }

            matrix_t    i { batch, H }, f { batch, H },
                        g { batch, H }, o { batch, H };
            auto        lbd1 =
                [H, batch, &i, &f, &g, &o, &gates = std::as_const(gates)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)  {
                        for (long r { 0 }; r < batch; ++r)  {
                            i(r, c) = sigmoid_(gates(r, c));
                            f(r, c) = sigmoid_(gates(r, H + c));
                            g(r, c) = std::tanh(gates(r, 2 * H + c));
                            o(r, c) = sigmoid_(gates(r, 3 * H + c));
                        }
                    }
                };
            const auto  thread_level {
                (H < 500) ? 0L : ThreadGranularity::get_thread_level()
            };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, H, std::move(lbd1))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd1(0L, H);
            }

            matrix_t    c_mat { batch ? matrix_t { batch, H } : matrix_t { } };

            for (long c { 0 }; c < H; ++c)
                for (long r { 0 }; r < batch; ++r)
                    c_mat(r, c) = f(r, c) * c_prev(r, c) + i(r, c) * g(r, c);

            const matrix_t  tanh_c {
                c_mat.apply([](const data_t &v) -> data_t {
                                return (std::tanh(v));
                            })
            };
            const matrix_t  h { hadamard(o, tanh_c) };

            return (Cache { x, h_prev, c_prev, i, f, g, o, c_mat, h });
        }

        std::tuple<matrix_t, matrix_t, matrix_t>
        backward(const matrix_t &dht,
                 const matrix_t &dct,
                 const Cache &cache)  {

            const long  batch { cache.x.rows() }, H { hidden_size };
            matrix_t    tanh_c {
                cache.c.apply([](const data_t &v) -> data_t {
                                  return (std::tanh(v));
                              })
            };
            const matrix_t  do_ { hadamard(dht, tanh_c) };
            const matrix_t  dc {
                dct +
                hadamard(
                    dht,
                    hadamard(cache.o,
                             tanh_c.self_apply([](const data_t &v) -> data_t {
                                                   return (data_t(1) - v * v);
                                               })))
            };
            const matrix_t  di { hadamard(dc, cache.g) };
            const matrix_t  df { hadamard(dc, cache.c_prev) };
            const matrix_t  dg { hadamard(dc, cache.i) };
            matrix_t        di_pre { batch, H }, df_pre { batch, H },
                            dg_pre { batch, H }, do_pre { batch, H };
            auto            lbd1 =
                [batch, &di_pre, &df_pre, &dg_pre, &do_pre,
                 &cache = std::as_const(cache),
                 &df = std::as_const(df),
                 &dg = std::as_const(dg),
                 &do_ = std::as_const(do_),
                 &di = std::as_const(di)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)  {
                        for (long r { 0 }; r < batch; ++r)  {
                            di_pre(r, c) =
                                di(r, c) * dsigmoid_from_out_(cache.i(r, c));
                            df_pre(r, c) =
                                df(r, c) * dsigmoid_from_out_(cache.f(r, c));
                            dg_pre(r, c) =
                                dg(r, c) * dtanh_from_out_(cache.g(r, c));
                            do_pre(r, c) =
                                do_(r, c) * dsigmoid_from_out_(cache.o(r, c));
                        }
                    }
                };
            const auto      thread_level {
                (H < 500) ? 0L : ThreadGranularity::get_thread_level()
            };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, H, std::move(lbd1))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd1(0L, H);
            }

            matrix_t    dG { batch, 4 * H };
            auto        lbd2 =
                [H, batch, &dG,
                 &di_pre = std::as_const(di_pre),
                 &df_pre = std::as_const(df_pre),
                 &do_pre = std::as_const(do_pre),
                 &dg_pre = std::as_const(dg_pre)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)  {
                        for (long r { 0 }; r < batch; ++r)  {
                            dG(r, c) = di_pre(r, c);
                            dG(r, H + c) = df_pre(r, c);
                            dG(r, 2 * H + c) = dg_pre(r, c);
                            dG(r, 3 * H + c) = do_pre(r, c);
                        }
                    }
                };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, H, std::move(lbd2))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd2(0L, H);
            }

            dW += cache.x.transpose() * dG;
            dU += cache.h_prev.transpose() * dG;

            matrix_t    db_inc { 1, 4 * H };

            for (long c { 0 }; c < (4 * H); ++c)  {
                data_t  s { 0 };

                for (long r { 0 }; r < batch; ++r)
                    s += dG(r, c);
                db_inc(0, c) = s;
            }
            db += db_inc;

            matrix_t dc_prev { batch ? matrix_t { batch, H } : matrix_t { } };

            for (long c { 0 }; c < H; ++c)
                for (long r { 0 }; r < batch; ++r)
                    dc_prev(r, c) = dc(r, c) * cache.f(r, c);

            return (std::make_tuple(dG * W.transpose(),
                                    dG * U.transpose(),
                                    dc_prev));
        }

        void zero_grad()  {

            dW.self_scale(0);
            dU.self_scale(0);
            db.self_scale(0);
        }
        void step(data_t lr)  {

            auto    lbd1 =
                [this, lr, &dW = std::as_const(dW)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)
                        for (long r { 0 }; r < W.rows(); ++r)
                            W(r, c) -= lr * dW(r, c);
                };
            auto    lbd2 =
                [this, lr, &dU = std::as_const(dU)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)
                        for (long r { 0 }; r < U.rows(); ++r)
                            U(r, c) -= lr * dU(r, c);
                };
            auto    lbd3 =
                [this, lr, &db = std::as_const(db)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)
                        for (long r { 0 }; r < b.rows(); ++r)
                            b(r, c) -= lr * db(r, c);
                };
            auto    thread_level {
                (W.cols() < 500) ? 0L : ThreadGranularity::get_thread_level()
            };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, W.cols(), std::move(lbd1))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd1(0L, W.cols());
            }

            thread_level =
                (U.cols() < 500) ? 0L : ThreadGranularity::get_thread_level();
            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, U.cols(), std::move(lbd2))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd2(0L, U.cols());
            }

            thread_level =
                (b.cols() < 500) ? 0L : ThreadGranularity::get_thread_level();
            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, b.cols(), std::move(lbd3))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd3(0L, b.cols());
            }
        }
    };

    // Linear layer
    //
    struct  Linear  {

        const long  in, out;
        matrix_t    W, b, dW, db;

        Linear(long in_dim, long out_dim, seed_t seed)
            : in(in_dim),
              out(out_dim),
              W(matrix_t::get_random(in_dim,
                                     out_dim,
                                     data_t(-0.1),
                                     data_t(0.1),
                                     seed)),
              b(1, out_dim, 0),
              dW(in_dim, out_dim, 0),
              db(1, out_dim, 0)  {   }

        matrix_t forward(const matrix_t&x)  {

            matrix_t    y { x * W };

            for (long c { 0 }; c < out; ++c)  {
                const auto  val { b(0, c) };

                for (long r { 0 }; r < x.rows(); ++r)
                    y(r, c) += val;
            }

            return (y);
        }

        matrix_t backward(const matrix_t &x, const matrix_t &dy)  {

            dW = x.transpose() * dy;
            for (long c { 0 }; c < dy.cols(); ++c){
                data_t  s { 0 };

                for (long r { 0 }; r < dy.rows(); ++r)
                    s += dy(r, c);
                db(0, c) += s;
            }

            return (dy * W.transpose());
        }

        void zero_grad()  {

            dW.self_scale(0);
            db.self_scale(0);
        }
        void step(data_t lr) {

            auto    lbd1 =
                [this, lr, &dW = std::as_const(dW)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)
                        for (long r { 0 }; r < W.rows(); ++r)
                            W(r, c) -= lr * dW(r, c);
                };
            auto    lbd2 =
                [this, lr, &db = std::as_const(db)]
                (long begin, long end) -> void  {
                    for (long c { begin }; c < end; ++c)
                        for (long r { 0 }; r < b.rows(); ++r)
                            b(r, c) -= lr * db(r, c);
                };
            auto    thread_level {
                (W.cols() < 500) ? 0L : ThreadGranularity::get_thread_level()
            };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, W.cols(), std::move(lbd1))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd1(0L, W.cols());
            }

            thread_level =
                (b.cols() < 500) ? 0L : ThreadGranularity::get_thread_level();
            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, b.cols(), std::move(lbd2))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd2(0L, b.cols());
            }
        }
    };

    // LSTM layer (sequence processing)
    //
    struct LSTMLayer  {

        using cache_t = typename LSTMForecastVisitor<T, I>::LSTMCell::Cache;

        LSTMCell                cell;
        std::vector<cache_t>    caches;
        matrix_t                h_last { }, c_last { };

        LSTMLayer(long in_sz, long hid_sz, seed_t seed)
            : cell (in_sz, hid_sz, seed)  {   }

        mat_vec_t
        forward(const std::deque<matrix_t> &X)  {

            const long  time_steps { long(X.size()) },
                        batch { X[0].rows() },
                        H { cell.hidden_size };
            matrix_t    h { batch, H, 0 }, c { batch, H, 0 };
            mat_vec_t   outs;

            caches.resize(time_steps);
            outs.resize(time_steps);
            for (long t { 0 }; t < time_steps; ++t)  {
                const auto  cache { cell.forward(X[t], h, c) };

                h = cache.h;
                c = cache.c;
                caches[t] = cache;
                outs[t] = h;
            }

            h_last = h;
            c_last = c;
            return (outs);
        }

        mat_vec_t
        backward(const mat_vec_t &douts)  {

            const long  time_steps { long(douts.size()) },
                        batch { caches[0].x.rows() },
                        H { cell.hidden_size };

            // cell.zero_grad();

            mat_vec_t   dxs(time_steps);
            matrix_t    dh_next { batch, H, 0 },
                        dc_next { batch, H, 0 };

            for (long t { time_steps - 1 }; t >= 0; --t)  {
                const matrix_t  dh_total { douts[t] + dh_next };
                const auto      [dx, dh_prev, dc_prev] {
                    cell.backward(dh_total, dc_next, caches[t])
                };

                dxs[t] = dx;
                dh_next = dh_prev;
                dc_next = dc_prev;
            }

            return (dxs);
        }

        void zero_grad()  { cell.zero_grad(); }
        void step(data_t lr)  { cell.step(lr); }
    };

public:

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 5)
            throw DataFrameError("LSTMForecastVisitor: "
                                 "Time-series is too short");
        if (col_s < size_type(double(seq_len_) * 1.5))
            throw DataFrameError("LSTMForecastVisitor: "
                                 "Time-series is too short for Number of time "
                                 "steps fed to the LSTM");

        if constexpr (is_md_)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "LSTMForecastVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        // Derive the true input size from the data when MD.
        //
        long  eff_input_size { 1 };

        if constexpr (is_md_)  eff_input_size = column_begin->size();

        // Normalization
        // norm_data[t][f] holds normalised value for time t, feature f.
        // Scalar: one element per time step (eff_input_size == 1)
        // MD:     one element per feature per time step
        //
        StdVisitor<T, I>    stdv;

        stdv.pre();
        stdv(idx_begin, idx_end, column_begin, column_end);
        stdv.post();

        std::vector<data_vec_t> norm_data(col_s, data_vec_t(eff_input_size));
        const auto              &mean { stdv.get_mean() };
        const auto              &std_dev { stdv.get_result() };


        if constexpr (! is_md_)  {
            for (long i { 0 }; i < long(col_s); ++i)
                norm_data[i][0] = (*(column_begin + i) - mean) / std_dev;
        }
        else  {
            for (long i { 0 }; i < long(col_s); ++i)  {
                const auto  &elem { *(column_begin + i) };

                for (long f { 0 }; f < eff_input_size; ++f)
                    norm_data[i][f] = (elem[f] - mean[f]) / std_dev[f];
            }
        }

        // Helper: fill one [batch_size_ x eff_input_size] input matrix
        // from normalised data at time index t
        //
        const auto  make_input_matrix =
            [this, eff_input_size, &norm_data = std::as_const(norm_data)]
            (long t) -> matrix_t  {
                matrix_t    mat { batch_size_, eff_input_size, data_t(0) };

                for (long r { 0 }; r < batch_size_; ++r)
                    for (long f { 0 }; f < eff_input_size; ++f)
                        mat(r, f) = norm_data[t][f];
                return (mat);
            };

        // Create model
        //
        LSTMLayer               lstm { eff_input_size, hidden_size_, seed_ };
        Linear                  linear { hidden_size_, eff_input_size, seed_ };
        std::deque<matrix_t>    inputs(seq_len_);

        // Training loop
        //
        for (long epoch { 0 }; epoch < epochs_; ++epoch)  {
            data_t  total_loss { 0 };

            for (long i { 0 }; i < (long(col_s) - seq_len_ - 3); ++i)  {
                for (long t { 0 }; t < seq_len_; ++t)
                    inputs[t] = make_input_matrix(i + t);

                // Target is the next time step after the input sequence
                //
                const matrix_t  target { make_input_matrix(i + seq_len_) };

                // Forward pass
                //
                const mat_vec_t outputs { lstm.forward(inputs) };
                const matrix_t  y_pred { linear.forward(outputs.back()) };

                // Compute loss + gradient
                //
                matrix_t     dloss;
                const data_t loss { mse_loss_and_grad_(y_pred, target, dloss) };

                total_loss += loss;

                // Backward pass
                //
                const matrix_t d_linear { linear.backward(lstm.h_last, dloss) };

                lstm.backward({ d_linear });

                // Parameter update
                //
                linear.step(learning_rate_);
                lstm.step(learning_rate_);
            }
        }

        // Forecast next periods_steps

        // Per-feature mean and stdev as plain data_vec_t
        // for uniform access in both scalar and MD paths
        //
        data_vec_t  feat_mean(eff_input_size),
                    feat_std (eff_input_size);

        if constexpr (! is_md_)  {
            feat_mean[0] = mean;
            feat_std [0] = std_dev;
        }
        else  {
            for (long f { 0 }; f < eff_input_size; ++f)  {
                feat_mean[f] = mean[f];
                feat_std [f] = std_dev[f];
            }
        }

        // Seed the forecast window with the last seq_len_ known points
        //
        std::deque<matrix_t>    sequence(seq_len_);

        for (long t { 0 }; t < seq_len_; ++t)
            sequence[t] = make_input_matrix(long(col_s) - seq_len_ + t);

        result_.resize(periods_);
        for (long step { 0 }; step < periods_; ++step)  {
            const mat_vec_t outputs { lstm.forward(sequence) };
            const matrix_t  next_pred { linear.forward(outputs.back()) };

            // next_input is the matrix we feed back into the sequence
            //
            matrix_t    next_input { batch_size_, eff_input_size, data_t(0) };

            if constexpr (! is_md_)  {
                const data_t    norm_pred { next_pred(0, 0) };

                result_[step] = norm_pred * feat_std[0] + feat_mean[0];
                for (long r { 0 }; r < batch_size_; ++r)
                    next_input(r, 0) = norm_pred;
            }
            else  {
                T   elem { };

                if constexpr (is_std_vector_v<T>)
                    elem.resize(eff_input_size);

                for (long f { 0 }; f < eff_input_size; ++f)  {
                    const data_t    norm_pred { next_pred(0, f) };

                    elem[f] = norm_pred * feat_std[f] + feat_mean[f];
                    for (long r { 0 }; r < batch_size_; ++r)
                        next_input(r, f) = norm_pred;
                }

                result_[step] = std::move(elem);
            }

            // Slide the forecast window forward one step
            //
            sequence.pop_front();
            sequence.push_back(std::move(next_input));
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    explicit
    LSTMForecastVisitor(long hidden_size = 32,
                        long seq_len = 10,
                        long batch_size = 1,
                        long epochs = 20,
                        data_t learning_rate = 0.001,
                        long periods = 3,
                        seed_t seed = static_cast<seed_t>(-1))
        : hidden_size_(hidden_size),
          seq_len_(seq_len),
          batch_size_(batch_size),
          epochs_(epochs),
          learning_rate_(learning_rate),
          periods_(periods),
          seed_(seed)  {   }

private:

    // Number of LSTM hidden units (neurons). Controls how much "memory" or
    // capacity the LSTM has. Larger values -> can learn more complex temporal
    // patterns, but need more data.
    //
    const long          hidden_size_;

    // Length of input sequence (T). Number of time steps fed to the LSTM
    // before forecasting the next one. Example: using 10 days of data to
    // predict day 11.
    //
    const long          seq_len_;

    // Number of sequences processed together. 1 means one sequence at a time
    // (simple for demonstration).
    //
    const long          batch_size_;

    // Number of training passes. How many times the model sees the full
    // dataset. More epochs = more training iterations.
    //
    const long          epochs_;

    // Step size for gradient descent. Controls how much weights are updated
    // during training. Too high = unstable; too low = slow learning.
    //
    const data_t        learning_rate_;

    const long          periods_;  // Number of periods to forecast
    const seed_t        seed_;     // Seed for random number generator
    result_type         result_ { };
};

template<typename T, typename I = unsigned long>
using lstm_v = LSTMForecastVisitor<T, I>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AnomalyDetectByKNNVisitor  {

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using result_type = vec_t<data_t>;
    using index_vec_t = vec_t<size_type>;

    // KDTree<double>::point_t is std::vector<double>.
    // For the scalar path, a "window" flattened to vector<data_t> is
    // just { x[0], x[1], ..., x[window-1] }.
    // For the MD path, a "window" is the concatenation of all inner elements
    // across the window: { x[0][0],...,x[0][d-1], x[1][0],...,x[w-1][d-1] }.
    //
    using tree_point_t = std::vector<data_t>;
    using tree_points_t = std::vector<tree_point_t>;

    using distance_func =
        std::function<double(const tree_point_t &x, const tree_point_t &y)>;

    static double def_dist(const tree_point_t &x, const tree_point_t &y)  {

        double           sum { 0 };
        const size_type  sz { x.size() };

        for (size_type i { 0 }; i < sz; ++i)  {
            const double    diff { double(x[i]) - double(y[i]) };

            sum += diff * diff;
        }
        return (std::sqrt(sum));
    }

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (window_ > (col_s / 2))
            throw DataFrameError("AnomalyDetectByKNNVisitor: "
                                 "Time-series is too short for window");
        if (k_ > (col_s / 2))
            throw DataFrameError("AnomalyDetectByKNNVisitor: "
                                 "Time-series is too short for K");
        if (window_ <= 1)
            throw DataFrameError("AnomalyDetectByKNNVisitor: "
                                 "Window must be > 1");

        if constexpr (is_md_)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError("AnomalyDetectByKNNVisitor: "
                                         "Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        tree_points_t   buckets;

        if (nt_ > normalization_type::none)  {
            NormalizeVisitor<T, I, A>   norm { nt_ };

            norm.pre();
            norm(idx_begin, idx_end, column_begin, column_end);
            norm.post();
            buckets = bucketize_(norm.get_result().begin(), col_s);
        }
        else
            buckets = bucketize_(column_begin, col_s);

        // tree_point dimension:
        //   scalar path: window_ (one scalar per step)
        //   MD path: window_ * inner_dim (all elements concatenated)
        //
        const size_type tree_dim {
            buckets.empty() ? window_ : buckets[0].size()
        };

        KDTree<data_t>  tree { tree_dim, std::forward<distance_func>(dfunc_) };

        tree.build(buckets);

        // Score each bucket: average distance to k nearest neighbors.
        // +1 because the nearest neighbor is always the point itself.
        //
        result_type scores;

        scores.reserve(buckets.size());
        for (const auto &pt : buckets)  {
            const auto  dists { tree.k_nearest_dists(pt, k_ + 1) };
            data_t      sum { 0 };

            for (size_type i { 1 }; i < dists.size(); ++i)
                sum += data_t(dists[i]);
            scores.push_back(sum / data_t(k_));
        }

        result_ = expand_scores_(scores, col_s);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    index_vec_t
    get_anomalous_indices(data_t threshold = data_t(0.0000001)) const  {

        const size_type col_s { result_.size() };
        size_type       idx { 0 };
        index_vec_t     anom_idxs;

        anom_idxs.reserve(64);
        while (idx < col_s)  {
            data_t  val { result_[idx] };

            if (val > threshold) [[unlikely]]  {
                size_type   max_idx { idx };
                data_t      max_val { val };

                while (val > threshold && idx < (col_s - 1))  {
                    val = result_[++idx];
                    if (val > max_val)  {
                        max_val = val;
                        max_idx = idx;
                    }
                }
                anom_idxs.push_back(max_idx);
            }
            idx += 1;
        }
        return (anom_idxs);
    }

    AnomalyDetectByKNNVisitor(
        size_type window,
        size_type k,
        normalization_type norm_type = normalization_type::none,
        distance_func &&f = def_dist)
        : window_(window),
          k_(k),
          nt_(norm_type),
          dfunc_(std::forward<distance_func>(f))  {   }

private:

    // Flatten each sliding window of value_type elements into a
    // tree_point_t (std::vector<data_t>) that KDTree<data_t> expects.
    //
    // Scalar path  (T = double):
    //   value_type = double, one element per position -> [v0, v1, ..., v_{w-1}]
    //
    // MD path (T = std::vector<double> or std::array<double, N>):
    //   Each position contributes its inner elements concatenated ->
    //   [v0[0],...,v0[d-1], v1[0],...,v_{w-1}[d-1]]
    //
    template <typename H>
    inline tree_points_t
    bucketize_(const H &column_begin, size_type col_s) const  {

        tree_points_t   result;
        size_type       inner_dim { 1 };

        if constexpr (is_md_)  inner_dim = column_begin->size();
        result.reserve(col_s - window_ + 1);
        for (size_type i { 0 }; (i + window_) <= col_s; ++i)  {
            tree_point_t    pt;

            if constexpr (! is_md_)  { // Scalar: copy window raw values directly
                pt.resize(window_);
                for (size_type j { 0 }; j < window_; ++j)
                    pt[j] = data_t(*(column_begin + i + j));
            }
            else  { // MD: concatenate inner elements across the window
                pt.reserve(window_ * inner_dim);
                for (size_type j { 0 }; j < window_; ++j)  {
                    const auto  &elem { *(column_begin + i + j) };

                    for (const auto &v : elem)
                        pt.push_back(data_t(v));
                }
            }
            result.push_back(std::move(pt));
        }
        return (result);
    }

    inline result_type
    expand_scores_(const result_type &scores, size_type col_s) const  {

        result_type             expanded(col_s, 0);
        std::vector<size_type>  counts(col_s, 0);

        for (size_type i { 0 }; i < scores.size(); ++i) {
            for (size_type j { 0 }; j < window_; ++j) {
                expanded[i + j] += scores[i];
                counts[i + j]++;
            }
        }

        for (size_type i { 0 }; i < col_s; ++i)
            if (counts[i] > 0)  expanded[i] /= data_t(counts[i]);

        return (expanded);
    }

    // This is the KDTree dimension.
    // Larger dimension makes KDTree less effective. Window stays small to keep
    // KD-tree viable. Window decides what a point looks like.
    //
    const size_type             window_;

    // This is number of neighbors used to estimate rarity.
    // K is about local density, and Independent of time series length or window
    // size. K grows with dataset size, not dimension. K decides how lonely that
    // point is.
    //
    const size_type             k_;
    const normalization_type    nt_;
    distance_func               dfunc_;
    result_type                 result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using and_knn_v = AnomalyDetectByKNNVisitor<T, I, A>;

// ------------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  BIRCHVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

public:

    using value_type = T;
    using index_type = I;
    using size_type = long;
    using result_type = std::vector<T, typename allocator_declare<T, A>::type>;
    using order_type =
        std::vector<std::vector<
                        std::size_t,
                        typename allocator_declare<std::size_t, A>::type>>;
    using distance_func =
        std::function<double(const value_type &x, const value_type &y)>;
    using seed_t = std::random_device::result_type;

private:

    const size_type     k_;   // Number of KMeans clusters
    const size_type     max_entries_;
    const size_type     iter_num_;
    const bool          cc_;
    const double        threshold_;
    distance_func       dfunc_ { };
    result_type         result_ { };         // K Means
    order_type          clusters_idxs_ { };  // K Clusters indices

    inline static distance_func
    get_dist_func_()  {

        if constexpr (! is_md_)
            return ([](const T &x, const T &y) -> double  {
                        return (static_cast<double>(std::abs(x - y)));
                    });
        else
            return ([](const T &x, const T &y) -> double  {
                        double  sum { 0 };

                        for (size_type i { 0 }; i < size_type(x.size()); ++i)  {
                            const double    diff { x[i] - y[i] };

                            sum += diff * diff;
                        }
                        return (std::sqrt(sum));
                    });
    }

    inline void calc_k_means_(const CFTree<value_type> &tree)  {

        const auto  &entries { tree.get_entries() };

        if (entries.empty())  return;

        // Initialize centroids from CF entries
        //
        std::vector<value_type> all_centroids(entries.size());

        for (size_type i { 0 }; const auto &entry : entries)
            all_centroids[i++] = entry.centroid();

        // Sort and pick evenly spaced centroids
        //
        std::sort(all_centroids.begin(), all_centroids.end());

        const size_type step {
            std::max(size_type(1), size_type(all_centroids.size()) / k_)
        };

        result_.reserve(entries.size());
        for (size_type i { 0 };
             (i < k_) && ((i * step) < size_type(all_centroids.size())); ++i)
            result_.push_back(all_centroids[i * step]);

        // Ensure we have exactly numClusters centroids
        //
        while (size_type(result_.size()) < k_ &&
               result_.size() < all_centroids.size())
            result_.push_back(all_centroids[result_.size()]);

        // K-means iterations on CF entries
        //
        bool    changed { true };

        for (size_type iter { 0 }; (iter < iter_num_) && changed; ++iter)  {
            changed = false;

            // Assign each CF to nearest cluster
            //
            std::vector<std::vector<size_type>> assignments(result_.size());

            for (size_type i { 0 }; i < size_type(entries.size()); ++i)  {
                const value_type    centroid { entries[i].centroid() };
                double              min_dist { dfunc_(centroid, result_[0]) };
                size_type           closest { 0 };

                for (size_type k { 1 }; k < size_type(result_.size()); ++k)  {
                    const double    dist { dfunc_(centroid, result_[k]) };

                    if (dist < min_dist)  {
                        min_dist = dist;
                        closest = k;
                    }
                }
                assignments[closest].push_back(i);
            }

            // Update centroids
            //
            for (size_type k { 0 }; k < size_type(result_.size()); ++k)  {
                if (assignments[k].empty())  continue;

                CF<T>   merged;

                for (const size_type idx : assignments[k])
                    merged.merge(entries[idx]);

                const value_type    new_centroid { merged.centroid() };

                if (dfunc_(new_centroid, result_[k]) > 1e-6)  {
                    result_[k] = new_centroid;
                    changed = true;
                }
            }
        }

        // Sort final centroids
        //
        std::sort(result_.begin(), result_.end());
    }

    // Using the calculated means, separate the given column into clusters
    //
    template<typename H>
    inline void
    calc_clusters_(const H &column_begin, size_type col_s)  {

        order_type  clusters_idxs(result_.size());

        for (size_type i { 0 }; i < size_type(result_.size()); ++i) [[likely]]
            clusters_idxs[i].reserve(col_s / k_ + 2);

        for (size_type j { 0 }; j < col_s; ++j) [[likely]]  {
            const value_type    &value { *(column_begin + j) };

            if (! is_nan__(value)) [[likely]]  {
                double      min_dist { std::numeric_limits<double>::max() };
                size_type   min_idx { 0 };

                for (size_type i { 0 }; i < size_type(result_.size()); ++i)  {
                    const double    dist { dfunc_(value, result_[i]) };

                    if (dist < min_dist)  {
                        min_dist = dist;
                        min_idx = i;
                    }
                }
                clusters_idxs[min_idx].push_back(std::size_t(j));
            }
        }

        clusters_idxs_.swap(clusters_idxs);
    }

public:

    template<typename IV, typename H>
    inline void
    operator()(const IV &idx_begin, const IV &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 4)
            throw DataFrameError("BIRCHVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        // Phase 1 & 2: Build CF-Tree
        //
        double              current_threshold { threshold_ };
        CFTree<value_type>  tree { };

        if constexpr (! is_md_)  {
            CFTree<value_type>  tmp_tree {
                threshold_, 1, get_dist_func_(), max_entries_
            };

            tree = std::move(tmp_tree);
        }
        else  {
            CFTree<value_type>  tmp_tree {
                threshold_,
                size_type(column_begin->size()),
                get_dist_func_(),
                max_entries_
            };

            tree = std::move(tmp_tree);
        }

        for (size_type i { 0 }; i < size_type(col_s); ++i)  {
            const value_type    &val { *(column_begin + i) };

            if (is_nan__(val))  continue;

            while (! tree.insert(val))  {
                // Tree is full, rebuild with larger threshold
                //
                current_threshold *= 1.5;

                const auto  old_entries { std::move(tree.get_entries()) };

                tree.clear();
                tree.set_threshold(current_threshold);

                for (const auto &entry : old_entries)  {
                    const value_type    &c { entry.centroid() };

                    // Simplified: insert centroid multiple times
                    //
                    for (size_type i { 0 }; i < entry.size(); i++)
                        tree.insert(c);
                }
            }
        }

        // Phase 3 & 4: Global clustering
        //
        calc_k_means_(tree);
        if (cc_)  calc_clusters_(column_begin,  col_s);
    }

    inline void set_dist_func(distance_func &&f)  { dfunc_ = f; }

    inline void pre()  {

        result_.clear();
        clusters_idxs_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline const order_type &
    get_clusters_idxs() const  { return (clusters_idxs_); }

    BIRCHVisitor(size_type k,      // Number of clusters for k-means
                 double threshold, // Maximum radius (stdev) allowed for a CF
                 size_type max_entries = 1000,
                 bool calc_clusters = true,
                 size_type max_iter = 1000)
        : k_(k),
          max_entries_(max_entries),
          iter_num_(max_iter),
          cc_(calc_clusters),
          threshold_(threshold)  { dfunc_ = get_dist_func_(); }
};

// ------------------------------------------------------------------------------

// Kriging algorithm performs spatial interpolation (a.k.a. Gaussian Process
// regression with a fixed/known covariance kernel) over scattered data.
// Kriging models are advanced geostatistical interpolation techniques used to
// predict unknown values at unsampled locations based on a set of known,
// scattered data points. Unlike simple averaging, Kriging calculates weights
// using both the distance between points and the overall spatial arrangement of
// the data, while also estimating the uncertainty of the predictions.
//
// Kriging sits at the intersection of interpolation and probabilistic
// regression — it's better categorized as a spatial interpolation / Gaussian
// Process regression algorithm. A fitting algorithm finds a compact parametric
// model (a line, a curve, coefficients) that summarizes the data, accepting
// residuals. It reduces the data to a small set of parameters. Kriging does the
// opposite: it retains all training points, and every prediction is a weighted
// combination of all observed values. There are no "fitted parameters" —
// nugget, sill, range are supplied by the user, not estimated from the data.
// The output is not a model summary but an interpolated surface.
//
// The visitor takes two parallel columns as inputs:
// Coordinates — a column of std::array<T, DIM>/std::vector<T> values, one per
// data point. Each element of the array is one spatial dimension, so DIM=1 is a
// 1D transect, DIM=2 is a 2D scatter (easting/northing, lon/lat, x/y), DIM=3 is
// volumetric, and so on. The dimensionality is a compile-time template
// parameter.
// Observations — a parallel column of scalar T values, one per data point.
// These are the measured quantities at each coordinate — the "z" values you
// want to interpolate.
// So the mental model is: given N scattered points each with a known location
// and a known value, fit the Kriging system so you can later call predict() at
// any arbitrary location and get back a value plus its uncertainty.
//
template<std::size_t DIM,
         typename T, typename I = unsigned long, std::size_t A = 0>
struct  KrigingVisitor  {

public:

    using value_type = T;
    using index_type = I;
    using size_type = long;

    using coord_type = std::array<value_type, DIM>;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // Point estimate + Kriging variance (the latter quantifies prediction
    // uncertainty -- near-zero close to known points, growing with
    // distance / sparsity).
    //
    struct  Estimate  {
        value_type  value { 0 };
        value_type  variance { 0 };
    };

    using result_type = vec_t<Estimate>;

private:

    using matrix_t = Matrix<value_type, matrix_orient::row_major>;

    const KrigingParams<value_type>    params_;

    vec_t<coord_type>   coords_ { };
    vec_t<value_type>   obs_ { };

    // Cached LDL^T factorization of the (possibly Lagrange-augmented)
    // Kriging system -- built once per fit, reused by every predict() call.
    //
    matrix_t            lower_ { };
    vec_t<value_type>   diag_ { };
    size_type           sys_dim_ { 0 };
    bool                ready_ { false };

    // Modified Bessel function of the second kind, order nu, evaluated via a
    // series/asymptotic hybrid sufficient for the half-integer and generic
    // real orders Matérn needs. For the common special cases (nu == 0.5, 1.5,
    // 2.5) closed forms are used instead (see matern_corr_ below) and this
    // generic path is only hit for arbitrary nu.
    //
    inline static double
    bessel_k_(double nu, double x)  {

        if (x <= 0)  [[unlikely]]
            return (std::numeric_limits<double>::infinity());

        // Use the well-known integral/asymptotic representation via a stable
        // recurrence starting from K_0 and K_1 computed through the standard
        // rational Chebyshev approximations (Abramowitz & Stegun 9.8).
        //
        auto    k0 = [](double t) -> double  {
            if (t <= 2.0)  {
                const double    y { t * t / 4.0 };

                return (-std::log(t / 2.0) *
                            (1.0 + y * (0.25 + y * (0.027777778 +
                             y * (0.001736111 + y * 0.0000694444)))) +
                        (-0.57721566 + y * (0.42278420 + y * (0.23069756 +
                         y * (0.03488590 + y * (0.00262698 +
                         y * (0.00010750 + y * 0.0000074)))))));
            }
            else  {
                const double    z { 2.0 / t };

                return (std::exp(-t) / std::sqrt(t) *
                        (1.25331414 + z * (-0.07832358 + z * (0.02189568 +
                         z * (-0.01062446 + z * (0.00587872 +
                         z * (-0.00251540 + z * 0.00053208)))))));
            }
        };
        auto    k1 = [](double t) -> double  {
            if (t <= 2.0)  {
                const double    y { t * t / 4.0 };

                return (std::log(t / 2.0) * t * 0.5 *
                            (1.0 + y * (0.5 + y * (0.08333333 +
                             y * (0.00694444 + y * 0.00034722)))) +
                        (1.0 / t) *
                        (1.0 + y * (0.15443144 + y * (-0.67278579 +
                         y * (-0.18156897 + y * (-0.01919402 +
                         y * (-0.00110404 + y * (-0.00004686))))))));
            }
            else  {
                const double    z { 2.0 / t };

                return (std::exp(-t) / std::sqrt(t) *
                        (1.25331414 + z * (0.23498619 + z * (-0.03655620 +
                         z * (0.01504268 + z * (-0.00780353 +
                         z * (0.00325614 + z * (-0.00068245))))))));
            }
        };

        // Forward recurrence in nu: K_{n+1}(x) = (2n/x) K_n(x) + K_{n-1}(x)
        //
        const double    frac_nu { nu - std::floor(nu) };
        double          k_prev, k_curr;

        if (frac_nu < 1e-12)  {
            k_prev = k0(x);
            k_curr = k1(x);

            const size_type n { static_cast<size_type>(std::floor(nu)) };

            if (n == 0)  return (k_prev);
            for (size_type i { 1 }; i < n; ++i)  {
                const double    k_next { (2.0 * i / x) * k_curr + k_prev };

                k_prev = k_curr;
                k_curr = k_next;
            }
            return (k_curr);
        }
        else  {
            // Half-integer / generic order: bootstrap using the identity for
            // half-integers when frac_nu == 0.5, otherwise fall back to a
            // smooth interpolation between bracketing K_0/K_1-derived values.
            // This generic branch is rarely hit in practice since most users
            // use nu in {0.5, 1.5, 2.5} which are handled by closed forms in
            // matern_corr_.
            //
            const double    sqrt_pi_over_2x { std::sqrt(M_PI / (2.0 * x)) };
            const double    ex { std::exp(-x) };

            k_prev = k0(x);
            k_curr = sqrt_pi_over_2x * ex;  // K_{0.5}(x) closed form

            double  cur_order { 0.5 };

            while (cur_order + 1.0 <= nu + 1e-9)  {
                const double    k_next {
                    (2.0 * cur_order / x) * k_curr + k_prev
                };

                k_prev = k_curr;
                k_curr = k_next;
                cur_order += 1.0;
            }
            return (k_curr);
        }
    }

    // Mahalanobis-style anisotropic distance for DIM == 2: rotates into the
    // principal axes then rescales the minor axis by 1/anisotropy_ratio
    // before taking the Euclidean norm, so the *effective* range becomes
    // direction-dependent without complicating every model formula. For
    // DIM != 2 anisotropy parameters are ignored (plain Euclidean distance).
    //
    inline value_type
    distance_(const coord_type &p1, const coord_type &p2) const noexcept  {

        if constexpr (DIM == 2)  {
            if (params_.anisotropy_ratio < (T(1) - T(1e-12)))  {
                const value_type    dx { p1[0] - p2[0] };
                const value_type    dy { p1[1] - p2[1] };
                const value_type    ca { std::cos(params_.anisotropy_angle) };
                const value_type    sa { std::sin(params_.anisotropy_angle) };
                const value_type    rx { dx * ca + dy * sa };
                const value_type    ry { -dx * sa + dy * ca };
                const value_type    ry_scaled { ry / params_.anisotropy_ratio };

                return (std::sqrt(rx * rx + ry_scaled * ry_scaled));
            }
        }

        value_type  sum { 0 };

        for (size_type i { 0 }; i < size_type(DIM); ++i)  {
            const value_type    d { p1[i] - p2[i] };

            sum += d * d;
        }
        return (std::sqrt(sum));
    }

    // Matérn correlation (sill-normalized, i.e. value in [0, 1]) using
    // closed forms for the common half-integer smoothness values and the
    // generic Bessel-function formula otherwise:
    //
    //   rho(h) = (2^(1-nu) / Gamma(nu)) * (sqrt(2*nu)*h/range)^nu
    //            * K_nu( sqrt(2*nu) * h / range )
    //
    inline value_type matern_corr_(value_type h) const  {

        if (h <= 0) [[unlikely]]  return (value_type(1));

        const double    nu { static_cast<double>(params_.matern_smoothness) };
        const double    r { static_cast<double>(params_.range) };
        const double    hd { static_cast<double>(h) };

        // Closed forms avoid the Bessel evaluation entirely for the three
        // overwhelmingly common cases -- both faster and more accurate.
        //
        if (std::fabs(nu - 0.5) < 1e-9)  {
            return (static_cast<value_type>(std::exp(-hd / r)));
        }
        else if (std::fabs(nu - 1.5) < 1e-9)  {
            const double    s3 { std::sqrt(3.0) * hd / r };

            return (static_cast<value_type>((1.0 + s3) * std::exp(-s3)));
        }
        else if (std::fabs(nu - 2.5) < 1e-9)  {
            const double    s5 { std::sqrt(5.0) * hd / r };

            return (value_type((1.0 + s5 + (s5 * s5) / 3.0) * std::exp(-s5)));
        }
        else if (nu > 50.0)  {
            // Numerically converges to the Gaussian model in this limit.
            //
            const double    z { hd / r };

            return (static_cast<value_type>(std::exp(-z * z)));
        }

        const double    scaled { std::sqrt(2.0 * nu) * hd / r };
        const double    log_coeff {
            (1.0 - nu) * M_LN2 - std::lgamma(nu) + nu * std::log(scaled)
        };
        const double    bess { bessel_k_(nu, scaled) };

        if (bess <= 0.0 || ! std::isfinite(bess))  [[unlikely]]
            return (value_type(0));

        const double    rho { std::exp(log_coeff) * bess };

        return (static_cast<value_type>(std::clamp(rho, 0.0, 1.0)));
    }

    // Semivariance gamma(h) for the configured model. Bounded models are
    // expressed as nugget + sill * (1 - correlation(h)); unbounded models
    // have no sill and grow indefinitely with h.
    //
    inline value_type semivariance_(value_type h) const  {

        if (h <= 0)  [[unlikely]]
            return (value_type(0));

        const auto  &p { params_ };

        switch (p.model)  {
            case VariogramModel::spherical:  {
                if (h >= p.range)
                    return (p.nugget + p.sill);

                const value_type    r { h / p.range };

                return (p.nugget +
                        p.sill * (value_type(1.5) * r -
                                   value_type(0.5) * r * r * r));
            }
            case VariogramModel::exponential:  {
                return (p.nugget +
                        p.sill * (value_type(1) - std::exp(-h / p.range)));
            }
            case VariogramModel::gaussian:  {
                const value_type    r { h / p.range };

                return (p.nugget +
                        p.sill * (value_type(1) - std::exp(-(r * r))));
            }
            case VariogramModel::matern:  {
                return (p.nugget + p.sill * (value_type(1) - matern_corr_(h)));
            }
            case VariogramModel::power:  {
                return (p.nugget + p.sill * std::pow(h, p.power_exponent));
            }
            case VariogramModel::linear:  {
                return (p.nugget + p.sill * h);
            }
            case VariogramModel::logarithmic:  {
                return (p.nugget + p.sill * std::log(value_type(1) + h));
            }
            default: break;
        }
        return (p.nugget + p.sill);  // unreachable
    }

    // Covariance C(h) = C(0) - gamma(h), with C(0) == nugget + sill for
    // bounded models. Unbounded models have no finite C(0); for those the
    // kriging system is instead built directly from -gamma(h) "pseudo-
    // covariances" (a standard trick for intrinsic random functions: the
    // Lagrange-multiplier constraint in Ordinary Kriging makes additive
    // constants in C cancel out, so using -gamma in place of C is valid).
    //
    inline value_type covariance_(value_type h) const  {

        const auto  &p { params_ };
        const bool  bounded {
            (p.model != VariogramModel::power &&
             p.model != VariogramModel::linear &&
             p.model != VariogramModel::logarithmic)
        };

        if (bounded)  {
            const value_type    c0 { p.nugget + p.sill };

            return (c0 - semivariance_(h));
        }
        return (-semivariance_(h));
    }

    // Builds and factorizes the Kriging system once (in pre()/operator()),
    // then predict() is a cheap O(n) dot-product per query -- the expensive
    // O(n^3) factorization is amortized across arbitrarily many predictions.
    //
    void build_system_(const vec_t<coord_type> &coords,
                       const vec_t<value_type> &obs)  {

        const size_type n { size_type(coords.size()) };

        coords_ = coords;
        obs_ = obs;

        const size_type dim_sys { params_.ordinary ? n + 1 : n };
        matrix_t        K { dim_sys, dim_sys, 0 };

        for (size_type i { 0 }; i < n; ++i)  {
            K(i, i) = covariance_(value_type(0)) + params_.ridge;

            for (size_type j { i + 1 }; j < n; ++j)  {
                const value_type    h { distance_(coords_[i], coords_[j]) };
                const value_type    c { covariance_(h) };

                K(i, j) = c;
                K(j, i) = c;
            }
        }

        if (params_.ordinary)  {
            for (size_type i { 0 }; i < n; ++i)
                K(i, n) = K(n, i) = value_type(1);
            K(n, n) = 0;
        }

        // K is symmetric -- LDL^T (via Matrix::ldlt) is roughly half the
        // FLOPs of a generic LU factorization and is numerically robust for
        // the indefinite (because of the zero corner / Lagrange row) system
        // Ordinary Kriging produces.
        //
        K.ldlt(diag_, lower_);
        sys_dim_ = dim_sys;
        ready_ = true;
    }

    // Forward/diagonal/backward solve against the cached LDL^T factors for
    // an arbitrary right-hand side -- reused for both fitting (implicitly,
    // via covariance_) and prediction.
    //
    vec_t<value_type> ldlt_solve_(const vec_t<value_type> &rhs) const  {

        vec_t<value_type>   y(sys_dim_, 0), z(sys_dim_, 0), x(sys_dim_, 0);

        for (size_type i { 0 }; i < sys_dim_; ++i)  {
            auto    &iy_val { y[i] };

            iy_val = rhs[i];
            for (size_type j { 0 }; j < i; ++j)
                iy_val -= lower_(i, j) * y[j];
            z[i] = iy_val / diag_[i];
        }
        for (size_type i { sys_dim_ - 1 }; i >= 0; --i)  {
            auto    &ix_val { x[i] };

            ix_val = z[i];
            for (size_type j { i + 1 }; j < sys_dim_; ++j)
                ix_val -= lower_(j, i) * x[j];
        }
        return (x);
    }

    // Restricts the global system to the k nearest neighbors of query_pt
    // and recurses into a small local solve -- turns O(n) memory / O(n^3)
    // factorization per prediction into O(k) / O(k^3), which is what makes
    // Kriging tractable for large point clouds (max_neighbors > 0).
    //
    Estimate predict_local_(const coord_type &query_pt) const  {

        const size_type n { size_type(coords_.size()) };
        const size_type k { std::min(size_type(params_.max_neighbors), n) };

        vec_t<std::pair<value_type, size_type>> dists(n);

        for (size_type i { 0 }; i < n; ++i)
            dists[i] = { distance_(coords_[i], query_pt), i };

        std::partial_sort(
            dists.begin(), dists.begin() + k,
            dists.end(),
            [](const auto &a, const auto &b)  { return (a.first < b.first); });

        vec_t<coord_type>   local_coords(k);
        vec_t<value_type>   local_obs(k);

        for (size_type i { 0 }; i < k; ++i)  {
            local_coords[i] = coords_[dists[i].second];
            local_obs[i] = obs_[dists[i].second];
        }

        KrigingVisitor  local { params_ };

        local.build_system_(local_coords, local_obs);
        return (local.predict_global_(query_pt));
    }

    // The core BLUE (Best Linear Unbiased Estimator) computation against
    // whatever system (global or a local neighborhood) is currently cached:
    //   weights = K^-1 * k0 (k0 = covariances to the query point)
    //   value = weights . observations (+ Lagrange handling)
    //   variance = C(0) - k0 . weights (- mu, for Ordinary Kriging)
    //
    Estimate predict_global_(const coord_type &query_pt) const  {

        const size_type     n { size_type(obs_.size()) };
        vec_t<value_type>   rhs(sys_dim_, 0);

        for (size_type i { 0 }; i < n; ++i)
            rhs[i] = covariance_(distance_(coords_[i], query_pt));
        if (params_.ordinary)
            rhs[n] = value_type(1);

        const vec_t<value_type>    weights = ldlt_solve_(rhs);
        Estimate                   est;

        if (params_.ordinary)  {
            value_type  val { 0 };

            for (size_type i { 0 }; i < n; ++i)
                val += weights[i] * obs_[i];
            est.value = val;

            const value_type    c0 { covariance_(value_type(0)) };
            value_type          k0_dot_w { 0 };

            for (size_type i { 0 }; i < n; ++i)
                k0_dot_w += weights[i] * rhs[i];

            // Lagrange multiplier (weights[n]) enters additively per the
            // standard OK variance formula: sigma^2 = C0 - sum(w*k0) - mu.
            //
            est.variance = std::max(value_type(0), c0 - k0_dot_w - weights[n]);
        }
        else  {
            value_type  val { 0 };

            for (size_type i { 0 }; i < n; ++i)
                val += weights[i] * (obs_[i] - params_.simple_mean);
            est.value = val + params_.simple_mean;

            const value_type    c0 { covariance_(value_type(0)) };
            value_type          k0_dot_w { 0 };

            for (size_type i { 0 }; i < n; ++i)
                k0_dot_w += weights[i] * rhs[i];
            est.variance = std::max(value_type(0), c0 - k0_dot_w);
        }
        return (est);
    }

public:

    template<typename IV, typename CV, typename OV>
    inline void
    operator()(const IV &/*idx_begin*/, const IV &/*idx_end*/,
               const CV &coord_begin, const CV &coord_end,
               const OV &obs_begin, const OV &obs_end)  {

        const size_type     col_s {
            static_cast<size_type>(std::distance(coord_begin, coord_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(obs_begin, obs_end)))
            throw DataFrameError("KrigingVisitor: coordinate and observation "
                                 "columns must have equal length");
#endif // HMDF_SANITY_EXCEPTIONS

        params_.sanity_check();

        vec_t<coord_type>   coords;
        vec_t<value_type>   obs;

        coords.reserve(col_s);
        obs.reserve(col_s);

        auto    cit { coord_begin };
        auto    oit { obs_begin };

        for (; cit != coord_end; ++cit, ++oit)  {
            if (is_nan__(*oit)) [[unlikely]]  continue;

            bool    has_nan { false };

            for (size_type d { 0 }; d < size_type(DIM); ++d)
                if (is_nan__((*cit)[d])) [[unlikely]] { has_nan = true; break; }
            if (has_nan) [[unlikely]]  continue;

            coords.push_back(*cit);
            obs.push_back(*oit);
        }

#ifdef HMDF_SANITY_EXCEPTIONS
        if (coords.empty())
            throw DataFrameError(
                "KrigingVisitor: no valid (non-NaN) data points supplied");
#endif // HMDF_SANITY_EXCEPTIONS

        if (params_.max_neighbors == 0)
            build_system_(coords, obs);
        else  {
            // Local Kriging defers system assembly to each predict() call,
            // but we still cache the full point set for neighbor search.
            //
            coords_ = std::move(coords);
            obs_ = std::move(obs);
            ready_ = true;
        }
    }

    inline void pre()  {

        coords_.clear();
        obs_.clear();
        lower_ = matrix_t { };
        diag_.clear();
        sys_dim_ = 0;
        ready_ = false;
    }
    inline void post()  {  }

    // Predict the value (and its Kriging variance) at an arbitrary query
    // point. Safe to call repeatedly and concurrently (read-only) once the
    // visitor has been invoked via operator() / fit().
    //
    inline Estimate predict(const coord_type &query_pt) const  {

#ifdef HMDF_SANITY_EXCEPTIONS
        if (! ready_)
            throw DataFrameError(
                "KrigingVisitor::predict(): model has not been fit yet");
#endif // HMDF_SANITY_EXCEPTIONS

        if (params_.max_neighbors > 0 && params_.max_neighbors < coords_.size())
            return (predict_local_(query_pt));
        return (predict_global_(query_pt));
    }

    // Convenience batch API -- predicts every point in [begin, end) and
    // returns results in the same order. Each prediction only re-solves
    // against the cached factorization (or local neighborhood), so this is
    // O(m * n) for m query points rather than O(m * n^3).
    //
    template<typename QV>
    inline result_type
    predict_many(const QV &begin, const QV &end) const  {

        result_type result { size_type(std::distance(begin, end)) };
        size_type   i { 0 };

        for (auto it { begin }; it != end; ++it)
            result[i++] = predict(*it);
        return (result);
    }

    // Leave-one-out cross validation: refits N times, each time omitting
    // one observation, and reports the predicted-vs-actual residual. Useful
    // for comparing variogram models/parameters objectively. This is O(N)
    // refits of an O(N^3) system, so intended for moderate N or via
    // max_neighbors-restricted local Kriging.
    //
    inline vec_t<value_type> loo_cross_validate () const  {

        const size_type                         n { size_type(coords_.size()) };
        vec_t<value_type>                       residuals(n, 0);
        const bool                              local {
            params_.max_neighbors > 0 &&
            size_type(params_.max_neighbors) < (n - 1)
        };
        const size_type                         k {
            local ? size_type(params_.max_neighbors) : (n - 1)
        };
        vec_t<coord_type>                       train_c;
        vec_t<value_type>                       train_o;
        vec_t<std::pair<value_type, size_type>> dists;

        train_c.reserve(local ? k : n - 1);
        train_o.reserve(local ? k : n - 1);
        dists.reserve(local ? n - 1 : 0);
        for (size_type leave_out { 0 }; leave_out < n; ++leave_out)  {
            train_c.clear();
            train_o.clear();

            // Restrict each refit to the max_neighbors closest other points,
            // mirroring predict_local_, so loo-cv stays tractable for large N
            // under local-Kriging configurations (each refit becomes O(k^3)
            // instead of O(n^3)) instead of silently ignoring max_neighbors.
            //
            if (local)  {
                dists.clear();
                for (size_type i { 0 }; i < n; ++i)  {
                    if (i == leave_out)  continue;
                    dists.push_back(
                        { distance_(coords_[i], coords_[leave_out]), i });
                }
                std::partial_sort(
                    dists.begin(), dists.begin() + k, dists.end(),
                    [](const auto &a, const auto &b)  {
                        return (a.first < b.first);
                    });
                for (size_type i { 0 }; i < k; ++i)  {
                    train_c.push_back(coords_[dists[i].second]);
                    train_o.push_back(obs_[dists[i].second]);
                }
            }
            else  {
                for (size_type i = 0; i < n; ++i)  {
                    if (i == leave_out)  continue;
                    train_c.push_back(coords_[i]);
                    train_o.push_back(obs_[i]);
                }
            }

            KrigingVisitor  loo(params_);

            loo.build_system_(train_c, train_o);

            const Estimate  est { loo.predict_global_(coords_[leave_out]) };

            residuals[leave_out] = obs_[leave_out] - est.value;
        }
        return (residuals);
    }
	
    explicit
    KrigingVisitor(const KrigingParams<value_type> &params = { })
        : params_(params)  {   }
};

template<std::size_t DIM, typename T, typename I = unsigned long,
         std::size_t A = 0>
using krig_v = KrigingVisitor<DIM, T, I, A>;

// ------------------------------------------------------------------------------

// Silhouette Score — Cluster Validation Metric
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  SilhouetteScoreVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

public:

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using result_type = vec_t<double>;   // per-point silhouette scores
    using distance_func =
        std::function<double(const value_type &, const value_type &)>;

private:

    // Default distance: squared Euclidean for scalar, Euclidean for MD.
    // Matches KMeansVisitor / DBSCANVisitor defaults.
    //
    inline static distance_func
    default_dist_()  {

        if constexpr (! is_md_)
            return ([](const T &x, const T &y) -> double  {
                        const double    d { static_cast<double>(x - y) };

                        return (d * d);
                    });
        else
            return ([](const T &x, const T &y) -> double  {
                        double  sum { 0.0 };

                        for (size_type i { 0 }; i < size_type(x.size()); ++i) {
                            const double    diff {
                                static_cast<double>(x[i]) -
                                static_cast<double>(y[i])
                            };

                            sum += diff * diff;
                        }
                        return (std::sqrt(sum));
                    });
    }

    static constexpr long   NOISE_1 { -1L };  // DBSCAN unclassified sentinel
    static constexpr long   NOISE_2 { -2L };  // DBSCAN noise sentinel

public:

    // Two-column operator: data column (T) and label column (long)
    //
    template<typename K, typename H1, typename H2>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H1 &col_begin, const H1 &col_end,
               const H2 &lbl_begin, const H2 &lbl_end)  {

        const size_type col_s {
            size_type(std::min({ std::distance(idx_begin, idx_end),
                                 std::distance(col_begin, col_end),
                                 std::distance(lbl_begin, lbl_end) }))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 2)
            throw DataFrameError(
                "SilhouetteScoreVisitor: Need at least 2 data points");
#endif // HMDF_SANITY_EXCEPTIONS

        scores_.assign(col_s, 0);
        mean_score_ = 0;

        // 1. Identify distinct non-noise cluster IDs
        //
        // Sorted unique non-noise cluster IDs
        //
        std::vector<long>   cluster_ids;

        cluster_ids.reserve(col_s / 4 + 2);
        for (size_type i { 0 }; i < col_s; ++i)  {
            const long  lbl { *(lbl_begin + i) };

            if (lbl != NOISE_1 && lbl != NOISE_2)
                cluster_ids.push_back(lbl);
        }
        std::sort(cluster_ids.begin(), cluster_ids.end());
        cluster_ids.erase(std::unique(cluster_ids.begin(), cluster_ids.end()),
                          cluster_ids.end());

        const size_type n_clusters { cluster_ids.size() };

        // Fewer than 2 meaningful clusters -> silhouette is undefined
        //
        if (n_clusters < 2) [[unlikely]]  return;

        // Build cluster label -> ordinal map for O(log k) lookup
        //
        std::vector<std::pair<long, size_type>> label_to_ord;

        label_to_ord.reserve(n_clusters);
        for (size_type c { 0 }; c < n_clusters; ++c)
            label_to_ord.emplace_back(cluster_ids[c], c);

        auto    label_ord =
            [&label_to_ord = std::as_const(label_to_ord)]
            (long lbl) -> size_type  {
                const auto  it {
                    std::lower_bound(
                        label_to_ord.begin(), label_to_ord.end(), lbl,
                        [](const auto &p, long v) { return (p.first < v); })
                };

                return (it->second);
            };

        // Cluster sizes (non-noise points only)
        //
        std::vector<size_type>  cluster_sz(n_clusters, 0);

        for (size_type i { 0 }; i < col_s; ++i)  {
            const long  lbl { *(lbl_begin + i) };

            if (lbl != NOISE_1 && lbl != NOISE_2)
                cluster_sz[label_ord(lbl)] += 1;
        }

        // 2. For each non-noise point i:
        //      For each cluster c:
        //        accumulate sum of distances to every other point in c
        //
        //   Then:
        //      a(i) = sum_same / (sz_same - 1)   [excluding self]
        //      b(i) = min over other clusters of (sum_other / sz_other)

        // per-point, per-cluster distance sums
        //   dist_sums[i][c] = Σⱼ∈cluster_c dist(i, j)
        //
        std::vector<std::vector<double>>    dist_sums(
            col_s, std::vector<double>(n_clusters, 0.0)
        );

        for (size_type i { 0 }; i < col_s; ++i)  {
            const long  lbl { *(lbl_begin + i) };

            if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

            const value_type   &vi { *(col_begin + i) };

            for (size_type j { 0 }; j < col_s; ++j)  {
                if (i == j) [[unlikely]]  continue;

                const long  lbl { *(lbl_begin + j) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type c_j { label_ord(lbl) };

                dist_sums[i][c_j] += dfunc_(vi, *(col_begin + j));
            }
        }

        // 3. Compute s(i) for each non-noise point
        //
        double      score_sum { 0.0 };
        size_type   scored_cnt { 0 };

        for (size_type i { 0 }; i < col_s; ++i)  {
            const long  lbl_i { *(lbl_begin + i) };

            if (lbl_i == NOISE_1 || lbl_i == NOISE_2) [[unlikely]]  continue;

            const size_type c_i { label_ord(lbl_i) };
            const size_type sz_i { cluster_sz[c_i] };

            // Singleton: a(i) undefined -> s(i) = 0
            //
            if (sz_i < 2) [[unlikely]]  {
                ++scored_cnt;
                continue;
            }

            const double    a_i { dist_sums[i][c_i] / double(sz_i - 1) };

            // b(i) = mean distance to the nearest other cluster
            //
            double          b_i { std::numeric_limits<double>::max() };

            for (size_type c { 0 }; c < n_clusters; ++c)  {
                if (c == c_i || cluster_sz[c] == 0) [[unlikely]]  continue;

                const double    mean_d {
                    dist_sums[i][c] / double(cluster_sz[c])
                };

                if (mean_d < b_i)
                    b_i = mean_d;
            }

            const double    denom { std::max(a_i, b_i) };
            const double    s_i { (denom > 0.0) ? (b_i - a_i) / denom : 0.0 };

            scores_[i] = s_i;
            score_sum += s_i;
            ++scored_cnt;
        }

        if (scored_cnt > 0)
            mean_score_ = score_sum / double(scored_cnt);
    }

    inline void pre()  { scores_.clear(); mean_score_ = 0.0; }
    inline void post()  {  }

    // Per-point silhouette coefficients s<sub>i</sub> &isin; [−1, 1].
    // Noise points in clusters with < 2 members have s<sub>i</sub> = 0.
    // Vector length equals the input column length.
    //
    inline const result_type &get_result() const  { return (scores_); }

    // Mean silhouette score over all non-noise, non-singleton points.
    // Range [−1, 1]; higher is better.
    //
    inline double get_mean_score() const  { return (mean_score_); }

    explicit
    SilhouetteScoreVisitor(distance_func f = default_dist_())
        : dfunc_(std::move(f))  {  }

private:

    distance_func   dfunc_;
    result_type     scores_ {  };
    double          mean_score_ { 0.0 };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using sil_score_v = SilhouetteScoreVisitor<T, I, A>;

// ------------------------------------------------------------------------------

// Davies-Bouldin Cluster Validity Index
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  DaviesBouldinIndexVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

public:

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using centroid_t =
        std::conditional_t<! is_md_, double, std::vector<double>>;

    using result_type = double;
    using distance_func =
        std::function<double(const value_type &, const value_type &)>;

private:

    inline static distance_func
    default_dist_()  {

        if constexpr (! is_md_)
            return ([](const T &x, const T &y) -> double  {
                        const double    d {
                            static_cast<double>(x) - static_cast<double>(y)
                        };

                        return (d * d);
                    });
        else
            return ([](const T &x, const T &y) -> double  {
                        double  sum { 0.0 };

                        for (size_type i { 0 }; i < size_type(x.size()); ++i) {
                            const double    diff {
                                static_cast<double>(x[i]) -
                                static_cast<double>(y[i])
                            };

                            sum += diff * diff;
                        }
                        return (std::sqrt(sum));
                    });
    }

    // Distance between two centroid_t values.
    // For scalar, centroid_t == double == T, so dfunc_ applies directly.
    // For MD, dfunc_ takes const T& (e.g. vector<double>) and centroid_t is
    // also vector<double>, so dfunc_ applies directly there too.
    // This ensures the user-supplied distance function is used consistently
    // for both intra-cluster scatter and inter-centroid separation.
    //
    // Known limitation for non-floating-point T (e.g. int, long): centroids
    // are inherently fractional (a sum divided by a count), but dfunc_'s
    // signature is double(const T&, const T&), so a centroid must be cast
    // back to T before every dfunc_ call here and in the scatter loop below
    // -- silently truncating it. This is unavoidable without either an
    // API-breaking change to distance_func's signature or dropping support
    // for user-supplied custom distance functions (both scatter_ and
    // centroid_dist_ must route through whatever dfunc_ the caller provided
    // to honor a custom distance, and there is no way to know at runtime
    // whether dfunc_ is the default or user-supplied). Callers with
    // non-floating-point T should be aware DB-index/scatter values will be
    // computed against truncated centroids; supplying an explicit
    // floating-point-aware distance function does not avoid this, since the
    // centroid itself is still cast to T before being passed in. This
    // mirrors the equivalent, already-documented caveat for non-double MD
    // element types below.
    //
    inline double
    centroid_dist_(const centroid_t &a, const centroid_t &b) const  {

        if constexpr (! is_md_)
            // centroid_t = double = T for scalar
            //
            return (dfunc_(static_cast<T>(a), static_cast<T>(b)));
        else  {
            // centroid_t = vector<double> = T for MD with double elements.
            // For integral-element MD (rare), this reinterprets the double
            // centroid as T — callers with non-double MD should supply an
            // explicit distance function that accepts vector<double>.
            //
            double  sum { 0.0 };

            for (size_type i { 0 }; i < size_type(a.size()); ++i)  {
                const double diff { a[i] - b[i] };

                sum += diff * diff;
            }
            return (std::sqrt(sum));
        }
    }

    static constexpr long   NOISE_1 { -1L };
    static constexpr long   NOISE_2 { -2L };
    static constexpr double BIG_R { std::numeric_limits<double>::max() / 2.0 };

public:

    template<typename K, typename H1, typename H2>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H1 &col_begin, const H1 &col_end,
               const H2 &lbl_begin, const H2 &lbl_end)  {

        const size_type col_s {
            size_type(std::min({ std::distance(idx_begin, idx_end),
                                 std::distance(col_begin, col_end),
                                 std::distance(lbl_begin, lbl_end) }))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 2)
            throw DataFrameError(
                "DaviesBouldinIndexVisitor: Need at least 2 data points");
#endif // HMDF_SANITY_EXCEPTIONS

        db_index_ = 0.0;
        scatter_.clear();
        worst_ratio_.clear();
        centroids_.clear();

        // 1. Identify sorted unique non-noise cluster IDs
        //
        std::vector<long>   cluster_ids;

        cluster_ids.reserve(col_s / 4 + 2);
        for (size_type i { 0 }; i < col_s; ++i)  {
            const long  lbl { *(lbl_begin + i) };

            if (lbl != NOISE_1 && lbl != NOISE_2)
                cluster_ids.push_back(lbl);
        }
        std::sort(cluster_ids.begin(), cluster_ids.end());
        cluster_ids.erase(std::unique(cluster_ids.begin(), cluster_ids.end()),
                          cluster_ids.end());

        const size_type k { cluster_ids.size() };

        // DB undefined for fewer than 2 clusters
        //
        if (k < 2) [[unlikely]]  return;

        // label -> ordinal (binary-search on sorted cluster_ids)
        //
        auto label_ord =
            [&cluster_ids = std::as_const(cluster_ids)]
            (long lbl) -> size_type  {
                return (size_type(
                    std::lower_bound(cluster_ids.begin(),
                                     cluster_ids.end(), lbl) -
                    cluster_ids.begin()));
            };

        // 2. Compute centroids μi
        //    Scalar: accumulate sum in double, divide by count
        //    MD: accumulate element-wise sums in vector<double>
        //
        std::vector<size_type>  counts(k, 0);

        if constexpr (! is_md_)  {
            centroids_.assign(k, centroid_t(0.0));

            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type c { label_ord(lbl) };

                centroids_[c] += static_cast<double>(*(col_begin + i));
                counts[c] += 1;
            }
            for (size_type c { 0 }; c < k; ++c)
                if (counts[c] > 0)
                    centroids_[c] /= double(counts[c]);
        }
        else  {
            // Determine dimensionality from the first non-noise point
            //
            size_type   dim { 0 };

            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2)  continue;
                dim = size_type((col_begin + i)->size());
                break;
            }

            centroids_.assign(k, centroid_t(dim, 0.0));

            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type     c { label_ord(lbl) };
                const value_type    &pt { *(col_begin + i) };

                for (size_type d { 0 }; d < dim; ++d)
                    centroids_[c][d] += static_cast<double>(pt[d]);
                counts[c] += 1;
            }
            for (size_type c { 0 }; c < k; ++c)
                if (counts[c] > 0)
                    for (auto &v : centroids_[c])
                        v /= double(counts[c]);
        }

        // 3. Compute intra-cluster scatter s(i)
        //    s(i) = mean dist(xj, μi) over all j in cluster i
        //
        //    We need dist(data_point, centroid).  For scalar T the centroid
        //    is double; we need a double-to-T-compatible call. To avoid
        //    template magic we define a separate centroid_dist_scalar_ lambda
        //    that mirrors the default_dist_ but operates on double centroids.
        //
        scatter_.assign(k, 0.0);

        if constexpr (! is_md_)  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type c { label_ord(lbl) };

                // Use dfunc_ for consistency with centroid_dist_ and the
                // user-supplied distance function. centroid_t = double = T.
                //
                scatter_[c] +=
                    dfunc_(*(col_begin + i), static_cast<T>(centroids_[c]));
            }
        }
        else  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type     c { label_ord(lbl) };
                const value_type    &pt { *(col_begin + i) };
                double              sq { 0 };

                for (size_type d { 0 }; d < size_type(pt.size()); ++d)  {
                    const double diff {
                        static_cast<double>(pt[d]) - centroids_[c][d]
                    };

                    sq += diff * diff;
                }
                scatter_[c] += std::sqrt(sq);  // Euclidean, consistent
            }
        }

        for (size_type c { 0 }; c < k; ++c)
            if (counts[c] > 0)
                scatter_[c] /= double(counts[c]);

        // 4. For each cluster i compute Dᵢ = max_{j != i} R(i, j)
        //    R(i, j) = (s(i) + s(j)) / d(μi, μj)
        //
        worst_ratio_.assign(k, 0);

        for (size_type i { 0 }; i < k; ++i)  {
            for (size_type j { 0 }; j < k; ++j)  {
                if (i == j) [[unlikely]]  continue;

                const double    dist_ij {
                    centroid_dist_(centroids_[i], centroids_[j])
                };
                double          R_ij;

                if (dist_ij <= 0.0) [[unlikely]]
                    R_ij = BIG_R;
                else
                    R_ij = (scatter_[i] + scatter_[j]) / dist_ij;

                if (R_ij > worst_ratio_[i])
                    worst_ratio_[i] = R_ij;
            }
        }

        // 5. DB = mean of Dᵢ
        //
        double  sum { 0 };

        for (const double d : worst_ratio_)
            sum += d;
        db_index_ = sum / double(k);
    }

    inline void pre()  {

        db_index_ = 0.0;
        scatter_.clear();
        worst_ratio_.clear();
        centroids_.clear();
    }
    inline void post()  {  }

    // The Davies-Bouldin index &isin; [0, &infin;). Lower is better.
    //
    inline result_type get_result() const  { return (db_index_); }

    // Per-cluster intra-cluster scatter s(i) = mean dist(point, centroid).
    // Size == number of non-noise clusters.
    //
    inline const vec_t<double> &get_scatter() const  { return (scatter_); }

    // Per-cluster worst-case similarity ratio Dᵢ = max_{j != i} R(i, j).
    // Size == number of non-noise clusters.
    //
    inline const vec_t<double> &
    get_worst_ratio() const  { return (worst_ratio_); }

    // Per-cluster centroids &mu;<sub>i</sub>.
    // Type is double for scalar T, std::vector<double> for MD T.
    // Size == number of non-noise clusters.
    //
    inline const vec_t<centroid_t> &
    get_centroids() const  { return (centroids_); }

    explicit
    DaviesBouldinIndexVisitor(distance_func f = default_dist_())
        : dfunc_(std::move(f))  {  }

private:

    distance_func       dfunc_;
    result_type         db_index_ { 0.0 };
    vec_t<double>       scatter_ {  };
    vec_t<double>       worst_ratio_ {  };
    vec_t<centroid_t>   centroids_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using db_index_v = DaviesBouldinIndexVisitor<T, I, A>;

// ------------------------------------------------------------------------------

// Calinski-Harabasz Index (Variance Ratio Criterion)
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  CalinskiHarabaszVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

public:

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // Centroid type: double for scalar T, vector<double> for MD T
    //
    using centroid_t = T;


    using result_type = double;
    using distance_func =
        std::function<double(const value_type &, const value_type &)>;

private:

    // Default: squared Euclidean for both scalar and MD (matches
    // KMeans/DBSCAN/DB's own scalar default). Calinski-Harabasz is a
    // variance-ratio statistic -- BGSS and WGSS are explicitly sums of
    // squares by definition (see the formula comments in operator() below)
    // -- so, unlike Silhouette/Davies-Bouldin where squared-vs-raw distance
    // is a free choice of metric, using raw (rooted) Euclidean distance for
    // MD here would not merely rescale the result: it would stop computing
    // a sum of squares at all, breaking the statistic's own definition.
    //
    inline static distance_func
    default_dist_()  {

        if constexpr (! is_md_)
            return ([](const T &x, const T &y) -> double  {
                        const double    d { double(x) - double(y) };

                        return (d * d);
                    });
        else
            return ([](const T &x, const T &y) -> double  {
                        double  sum { 0.0 };

                        for (size_type i { 0 }; i < x.size(); ++i)  {
                            const double    diff { double(x[i]) - double(y[i]) };

                            sum += diff * diff;
                        }
                        return (sum);
                    });
    }

    // Distance between two centroid_t values — routes through dfunc_ for
    // scalar so that custom distance functions apply to centroid comparisons
    // (same fix applied in DaviesBouldinIndexVisitor). Returns squared
    // distance for MD too, to match default_dist_ and the sum-of-squares
    // definitions of BGSS/WGSS below -- see default_dist_'s comment.
    //
    inline double
    centroid_dist_(const centroid_t &a, const centroid_t &b) const  {

        if constexpr (! is_md_)
            return (dfunc_(static_cast<T>(a), static_cast<T>(b)));
        else  {
            double  sum { 0.0 };

            for (size_type i { 0 }; i < size_type(a.size()); ++i)  {
                const double    diff { a[i] - b[i] };

                sum += diff * diff;
            }
            return (sum);
        }
    }

    static constexpr long   NOISE_1 { -1L };
    static constexpr long   NOISE_2 { -2L };

public:

    template<typename K, typename H1, typename H2>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H1 &col_begin, const H1 &col_end,
               const H2 &lbl_begin, const H2 &lbl_end)  {

        const size_type col_s {
            size_type(std::min({ std::distance(idx_begin, idx_end),
                                 std::distance(col_begin, col_end),
                                 std::distance(lbl_begin, lbl_end) }))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 2)
            throw DataFrameError(
                "CalinskiHarabaszVisitor: Need at least 2 data points");
#endif // HMDF_SANITY_EXCEPTIONS

        // 1. Sort unique non-noise cluster IDs
        //
        std::vector<long>   cluster_ids;

        cluster_ids.reserve(col_s / 4 + 2);
        for (size_type i { 0 }; i < col_s; ++i)  {
            const long  lbl { *(lbl_begin + i) };

            if (lbl != NOISE_1 && lbl != NOISE_2)
                cluster_ids.push_back(lbl);
        }
        std::sort(cluster_ids.begin(), cluster_ids.end());
        cluster_ids.erase(std::unique(cluster_ids.begin(), cluster_ids.end()),
                          cluster_ids.end());

        const size_type k { cluster_ids.size() };

        // CH requires at least 2 clusters and n > k
        //
        if (k < 2) [[unlikely]]  return;

        auto                    label_ord =
            [&cluster_ids = std::as_const(cluster_ids)]
            (long lbl) -> size_type  {
                return (size_type(std::lower_bound(cluster_ids.begin(),
                                                   cluster_ids.end(), lbl) -
                        cluster_ids.begin()));
            };
        std::vector<size_type>  counts(k, 0);

        for (size_type i { 0 }; i < col_s; ++i)  {
            const long  lbl { *(lbl_begin + i) };

            if (lbl != NOISE_1 && lbl != NOISE_2)
                counts[label_ord(lbl)] += 1;
        }

        // Count of non-noise points
        //
        size_type   clean_cnt { 0 };

        for (const auto cnt : counts)  clean_cnt += cnt;

        // CH undefined when clean_cnt == k (one point per cluster,
        // WGSS = 0, df = 0)
        //
        if (clean_cnt <= k) [[unlikely]]
            return;

        // 2. Compute per-cluster centroids μᵢ and global centroid μ
        //    Both accumulated in double regardless of T.
        //
        if constexpr (! is_md_)  {
            centroids_.assign(k, centroid_t(0.0));
            global_centroid_ = 0.0;

            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const value_type    v { *(col_begin + i) };
                const size_type     c { label_ord(lbl) };

                centroids_[c] += v;
                global_centroid_ += v;
            }
            for (size_type c { 0 }; c < k; ++c)
                centroids_[c] /= double(counts[c]);
            global_centroid_ /= double(clean_cnt);
        }
        else  {
            // Determine dimension from first non-noise point
            //
            size_type   dim { 0 };

            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2)  continue;
                dim = size_type((col_begin + i)->size());
                break;
            }

            if constexpr (! is_std_array_v<value_type>)  {
                centroids_.resize(k, centroid_t(dim, 0.0));
                global_centroid_.resize(dim, 0.0);
            }
            else  {
                centroids_.resize(k);
            }

            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type     c { label_ord(lbl) };
                const value_type    &pt { *(col_begin + i) };

                for (size_type d { 0 }; d < dim; ++d)  {
                    const double    v { static_cast<double>(pt[d]) };

                    centroids_[c][d] += v;
                    global_centroid_[d] += v;
                }
            }
            for (size_type c { 0 }; c < k; ++c)
                for (auto &v : centroids_[c])  v /= double(counts[c]);
            for (auto &v : global_centroid_)  v /= double(clean_cnt);
        }

        // 3. BGSS = Σᵢ nᵢ · d²(μᵢ, μ)
        //
        bgss_ = 0.0;
        for (size_type c { 0 }; c < k; ++c)
            bgss_ += double(counts[c]) *
                     centroid_dist_(centroids_[c], global_centroid_);

        // 4. WGSS = Σᵢ Σⱼ∈Cᵢ d²(xⱼ, μᵢ)
        //    Also accumulate per-cluster within-cluster dispersion.
        //
        cluster_wgss_.assign(k, 0.0);

        if constexpr (! is_md_)  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type c { label_ord(lbl) };

                cluster_wgss_[c] +=
                    dfunc_(*(col_begin + i), static_cast<T>(centroids_[c]));
            }
        }
        else  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                const long  lbl { *(lbl_begin + i) };

                if (lbl == NOISE_1 || lbl == NOISE_2) [[unlikely]]  continue;

                const size_type     c  { label_ord(lbl) };
                const value_type    &pt { *(col_begin + i) };
                double              sq { 0.0 };

                for (size_type d { 0 }; d < size_type(pt.size()); ++d)  {
                    const double    diff { double(pt[d]) - centroids_[c][d] };

                    sq += diff * diff;
                }

                // squared, matching BGSS/WGSS's own sum-of-squares definition
                //
                cluster_wgss_[c] += sq;
            }
        }

        wgss_ = 0.0;
        for (const double w : cluster_wgss_)
            wgss_ += w;

        // 5. CH = [BGSS / (k−1)] / [WGSS / (clean_cnt−k)]
        //    Guard WGSS = 0 (all points exactly on centroids).
        //
        if (wgss_ <= 0.0) [[unlikely]]  {
            ch_index_ = std::numeric_limits<double>::max();
            return;
        }

        ch_index_ = (bgss_ / double(k - 1)) / (wgss_ / double(clean_cnt - k));
    }

    inline void pre()  {

        ch_index_ = bgss_ = wgss_ = 0.0;
        cluster_wgss_.clear();
        centroids_.clear();
        global_centroid_ = centroid_t { };
    }
    inline void post() {  }

    // The Calinski-Harabasz index &isin; [0, &infin;). Higher is better.
    //
    inline result_type get_result() const  { return (ch_index_); }

    inline double get_bgss() const  { return (bgss_); }
    inline double get_wgss() const  { return (wgss_); }
    inline const vec_t<double> &
    get_cluster_wgss() const  { return (cluster_wgss_); }
    inline const vec_t<centroid_t> &
    get_centroids() const  { return (centroids_); }

    // Global centroid μ of all non-noise points.
    //
    inline const centroid_t &
    get_global_centroid() const  { return (global_centroid_); }

    explicit
    CalinskiHarabaszVisitor(distance_func f = default_dist_())
        : dfunc_(std::move(f))  {  }

private:

    distance_func       dfunc_;
    result_type         ch_index_ { 0.0 };
    double              bgss_ { 0.0 };
    double              wgss_ { 0.0 };
    vec_t<double>       cluster_wgss_ {  };
    vec_t<centroid_t>   centroids_ {  };
    centroid_t          global_centroid_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using ch_index_v = CalinskiHarabaszVisitor<T, I, A>;

// ------------------------------------------------------------------------------

// Isolation Forest Anomaly Detection Visitor
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AnomalyDetectByIsoForestVisitor  {

    DEFINE_VISIT_BASIC_TYPES

private:

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using result_type = vec_t<size_type>;  // indices of anomalies
    using scores_type = vec_t<double>;     // per-point scores ∈ (0,1]

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 8)
            throw DataFrameError(
                "AnomalyDetectByIsoForestVisitor: "
                "Time-series is too short (need >= 8)");
#endif // HMDF_SANITY_EXCEPTIONS

        result_.clear();
        scores_.assign(col_s, 0.0);

        // Optional normalisation
        //
        NormalizeVisitor<T, I, A>   norm { nt_ };

        if (nt_ > normalization_type::none)  {
            norm.pre();
            norm(idx_begin, idx_end, column_begin, column_end);
            norm.post();
        }

        // Fit the Isolation Forest on the (optionally normalized) column
        //
        IsoForest<T>    forest { num_trees_, max_depth_ };

        if (nt_ > normalization_type::none)  {
            const auto  &nr { norm.get_result() };

            forest.fit(nr.begin(), nr.end());
        }
        else
            forest.fit(column_begin, column_begin + col_s);

        // Score every point; flag anomalies above threshold_
        //
        const auto  data_size {
            static_cast<typename IsoForest<T>::size_type>(col_s)
        };

        result_.reserve(col_s / 10 + 4);
        if (nt_ > normalization_type::none)  {
            const auto  &nr { norm.get_result() };

            for (size_type i { 0 }; i < col_s; ++i)  {
                const double    s { forest.outlier_score(nr[i], data_size) };

                scores_[i] = s;
                if (s > threshold_)  result_.push_back(i);
            }
        }
        else  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                const double    s {
                    forest.outlier_score(*(column_begin + i), data_size)
                };

                scores_[i] = s;
                if (s > threshold_)  result_.push_back(i);
            }
        }
    }

    DEFINE_PRE_POST

    // This returns the indices of detected anomalies in the input column.
    //
    inline const result_type &get_result() const  { return (result_); }

    // Per-point anomaly scores s(x) &isin; (0, 1].
    // Higher -> more anomalous. It is parallel to the input column.
    //
    inline const scores_type &get_scores() const  { return (scores_); }

    explicit
    AnomalyDetectByIsoForestVisitor(
        long num_trees = 100,
        long max_depth = 10,
        double threshold = 0.6,
        normalization_type norm_type = normalization_type::none)
        : num_trees_(num_trees),
          max_depth_(max_depth),
          threshold_(threshold),
          nt_(norm_type)  {   }

private:

    // Number of isolation trees. The original paper uses 100; 50–200 is
    // typical. More trees -> lower variance of scores.
    //
    const long                  num_trees_;

    // Maximum depth of each tree. The original paper recommends ceil(log₂(ψ))
    // where ψ is the subsample size, but passing the full column size works
    // well in practice. Default: 10 (same as IsoTree's default).
    //
    const long                  max_depth_;

    // Points with score > threshold are flagged as anomalies. The canonical
    // threshold from the paper is 0.6 (points scoring above 0.6 are considered
    // anomalous with moderate confidence; > 0.7 is stronger). Default: 0.6.
    //
    const double                threshold_;

    // Optional pre-normalisation of the input column.
    // normalization_type::none (default) skips normalisation.
    //
    const normalization_type    nt_;

    result_type                 result_ { };
    scores_type                 scores_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using and_isoforest_v = AnomalyDetectByIsoForestVisitor<T, I, A>;

} // namespace hmdf

// ------------------------------------------------------------------------------

// Local Variables:
// mode:C++
// tab-width:4
// c-basic-offset:4
// End:
