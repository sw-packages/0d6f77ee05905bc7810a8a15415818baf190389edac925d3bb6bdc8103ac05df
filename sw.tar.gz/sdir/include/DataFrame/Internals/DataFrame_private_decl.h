// Hossein Moein
// April 21, 2021
/*
Copyright (c) 2019-2026, Hossein Moein
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
* Neither the name of Hossein Moein and/or the DataFrame nor the
  names of its contributors may be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Hossein Moein BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include <cstdio>
#include <ranges>

// ----------------------------------------------------------------------------

// This file was factored out so DataFrame.h doesn't become a huge file.
// This was meant to be included inside the private section of DataFrame class.
// This file, by itself, is not useable/compile-able.

// ----------------------------------------------------------------------------

template<typename DF, template<typename> class OPT, typename ... Ts>
friend DF
binary_operation(const DF &lhs, const DF &rhs);

template<typename DF, typename ST,
         template<typename> class OPT, typename ... Ts>
friend DF
sc_binary_operation(const DF &lhs, const ST &rhs);

// ----------------------------------------------------------------------------

// Maps row number -> number of missing column(s)
//
using DropRowMap = DFMap<size_type, size_type>;
using IndexIdxVector = StlVecType<std::tuple<size_type, size_type>>;

template<typename T>
using JoinSortingPair = std::pair<const T *, size_type>;

// ----------------------------------------------------------------------------

template<typename S>
void read_json_(S &file, bool columns_only);

// -------------------------------------

template<typename S>
size_type read_binary_(S &file,
                       bool columns_only,
                       size_type starting_row,
                       size_type num_rows,
                       BinaryReadState *ext_state = nullptr);

// -------------------------------------

template<typename S>
void read_csv_(S &file, bool columns_only, char delim);

// - Return type changed void -> size_type: the number of data rows parsed
//   by this particular call, used by ChunkedReader to detect an
//   exhausted stream. Existing callers (DataFrame::read()/read_async())
//   simply discard the return value, so they are unaffected.
// - New, optional trailing parameter ext_state: when non-null, parser
//   state (has the header been read yet? what are the column specs?) is
//   read from / written back to *ext_state instead of being local to this
//   one call, which is what allows a sequence of calls sharing the same
//   ext_state to resume exactly where the previous call left off, rather
//   than re-parsing the header and re-scanning already-consumed rows each
//   time. Defaults to nullptr, so every existing call site is unaffected.
//
template<typename S>
size_type read_csv2_(S &stream,
                     bool columns_only,
                     size_type starting_row,
                     size_type num_rows,
                     bool skip_first_line,
                     const std::vector<ReadSchema> &schema,
                     char delim,
                     CSV2ReadState *ext_state = nullptr);

// -------------------------------------

// Grants ChunkedReader (defined in the separate header
// <DataFrame/Utils/IO/ChunkedReader.h>) access to the read_csv2_() overload
// above, so it can drive resumable chunked reads without read_csv2_()
// otherwise needing to be part of DataFrame's public API surface.
//
template<typename FS, typename FDF>
friend class DataFrameChunkedReader;

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename ... Ts>
static DataFrame<I, HeteroVector<std::size_t(H::align_value)>>
index_join_helper_(const LHS_T &lhs,
                   const RHS_T &rhs,
                   const IndexIdxVector &joined_index_idx);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename T, typename ... Ts>
static DataFrame<unsigned long, HeteroVector<std::size_t(H::align_value)>>
column_join_helper_(const LHS_T &lhs,
                    const RHS_T &rhs,
                    const char *col_name,
                    const IndexIdxVector &joined_index_idx);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename T1, typename T2,
         typename ... Ts>
static DataFrame<unsigned long, HeteroVector<std::size_t(H::align_value)>>
column_join_helper2_(const LHS_T &lhs,
                     const RHS_T &rhs,
                     const char *lhs_col_name,
                     const char *rhs_col_name,
                     const IndexIdxVector &joined_index_idx);

// -------------------------------------

template<typename LHS_T, typename RHS_T,
         typename LHS_COL1_T, typename RHS_COL1_T,
         typename LHS_COL2_T, typename RHS_COL2_T,
         typename ... Ts>
static DataFrame<unsigned long, HeteroVector<std::size_t(H::align_value)>>
column_join_helper4_(const LHS_T &lhs,
                     const RHS_T &rhs,
                     const char *lhs_col1_name,
                     const char *rhs_col1_name,
                     const char *lhs_col2_name,
                     const char *rhs_col2_name,
                     const IndexIdxVector &joined_index_idx);

// -------------------------------------

template<typename T>
static IndexIdxVector
get_inner_index_idx_vector_(const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
                            const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename ... Ts>
static DataFrame<I, HeteroVector<std::size_t(H::align_value)>>
index_inner_join_(const LHS_T &lhs, const RHS_T &rhs,
                  const StlVecType<JoinSortingPair<IndexType>> &col_vec_lhs,
                  const StlVecType<JoinSortingPair<IndexType>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename T, typename ... Ts>
static DataFrame<unsigned long, HeteroVector<std::size_t(H::align_value)>>
column_inner_join_(const LHS_T &lhs,
                   const RHS_T &rhs,
                   const char *col_name,
                   const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
                   const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// -------------------------------------

template<typename T>
static IndexIdxVector
get_left_index_idx_vector_(const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
                           const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename ... Ts>
static DataFrame<I, HeteroVector<std::size_t(H::align_value)>>
index_left_join_(const LHS_T &lhs, const RHS_T &rhs,
                 const StlVecType<JoinSortingPair<IndexType>> &col_vec_lhs,
                 const StlVecType<JoinSortingPair<IndexType>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename T, typename ... Ts>
static DataFrame<unsigned long, HeteroVector<std::size_t(H::align_value)>>
column_left_join_(const LHS_T &lhs,
                  const RHS_T &rhs,
                  const char *col_name,
                  const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
                  const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// -------------------------------------

template<typename T>
static IndexIdxVector
get_right_index_idx_vector_(const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
                            const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename ... Ts>
static DataFrame<I, HeteroVector<std::size_t(H::align_value)>>
index_right_join_(const LHS_T &lhs, const RHS_T &rhs,
                  const StlVecType<JoinSortingPair<IndexType>> &col_vec_lhs,
                  const StlVecType<JoinSortingPair<IndexType>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename T, typename ... Ts>
static DataFrame<unsigned long, HeteroVector<std::size_t(H::align_value)>>
column_right_join_(const LHS_T &lhs,
                   const RHS_T &rhs,
                   const char *col_name,
                   const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
                   const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename ... Ts>
static void
concat_helper_(LHS_T &lhs, const RHS_T &rhs, bool add_new_columns);

// -------------------------------------

template<typename T>
static IndexIdxVector
get_left_right_index_idx_vector_(
    const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
    const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename ... Ts>
static DataFrame<I, HeteroVector<std::size_t(H::align_value)>>
index_left_right_join_(
    const LHS_T &lhs, const RHS_T &rhs,
    const StlVecType<JoinSortingPair<IndexType>> &col_vec_lhs,
    const StlVecType<JoinSortingPair<IndexType>> &col_vec_rhs);

// -------------------------------------

template<typename LHS_T, typename RHS_T, typename T, typename ... Ts>
static DataFrame<unsigned long, HeteroVector<std::size_t(H::align_value)>>
column_left_right_join_(const LHS_T &lhs,
                        const RHS_T &rhs,
                        const char *col_name,
                        const StlVecType<JoinSortingPair<T>> &col_vec_lhs,
                        const StlVecType<JoinSortingPair<T>> &col_vec_rhs);

// ----------------------------------------------------------------------------

// asof_join helpers
// Build the (lhs_idx, rhs_idx) mapping vector for asof_join.
// rhs_index must be sorted ascending.  For each lhs entry the function
// binary-searches rhs and records the matched rhs position (or max() when
// tolerance is positive and the nearest rhs row is too far away).
//
template<typename RHS_T>
IndexIdxVector
get_asof_index_idx_vector_(const RHS_T &rhs,
                           asof_policy ap,
                           const IndexType &tolerance) const;

// Materialise the asof IndexIdxVector into a result DataFrame.
// The result carries lhs's index and uses index_join_helper_'s column
// scatter logic, so common columns get lhs./rhs. prefixes exactly as in
// join_by_index.
//
template<typename RHS_T, typename ... Ts>
DataFrame<I, HeteroVector<std::size_t(H::align_value)>>
index_asof_join_(const RHS_T &rhs,
                 const IndexIdxVector &joined_index_idx) const;

// ----------------------------------------------------------------------------

template<typename T, typename ITR>
void
setup_view_column_(const char *name, Index2D<ITR> range)  {

    static_assert(
        std::is_base_of<HeteroView<align_value>, DataVec>::value ||
        std::is_base_of<HeteroConstView<align_value>, DataVec>::value ||
        std::is_base_of<HeteroPtrView<align_value>, DataVec>::value ||
        std::is_base_of<HeteroConstPtrView<align_value>, DataVec>::value,
        "Only a DataFrameView or DataFramePtrView can "
        "call setup_view_column_()");

    DataVec dv;

    if (range.begin < range.end)
        dv.set_begin_end_special(&*(range.begin), &*(range.end - 1));
    else
        dv.template set_empty_vec<T>();

    const SpinGuard guard { lock_ };

    data_.emplace_back(dv);
    column_tb_.emplace(name, data_.size() - 1);
    column_list_.emplace_back(name, data_.size() - 1);

    return;
}

// ----------------------------------------------------------------------------

template<typename T1, typename T2>
size_type
load_pair_(std::pair<T1, T2> &col_name_data, bool do_lock = true)  {

    return (load_column<typename decltype(col_name_data.second)::value_type>(
                col_name_data.first, // column name
                std::forward<T2>(col_name_data.second),
                nan_policy::pad_with_nans,
                do_lock));
}

// ----------------------------------------------------------------------------

template<typename ITR>
inline size_type
load_column_(const char *name,
             Index2D<const ITR &> range,
             nan_policy padding,
             bool do_lock)  {

    static_assert(std::is_base_of<HeteroVector<align_value>, H>::value,
                  "Only a StdDataFrame can call load_column()");

    using value_t = decltype(ITR::begin);

    const auto          iter { column_tb_.find (name) };
    StlVecType<value_t> *vec_ptr { nullptr };

    {
        const SpinGuard guard { do_lock ? lock_ : nullptr };

        if (iter == column_tb_.end()) [[likely]]
            vec_ptr = &(create_column<value_t>(name, false));
        else  {
            DataVec &hv { data_[iter->second] };

            vec_ptr = &(hv.template get_vector<value_t>());
        }
    }

    vec_ptr->clear();
    vec_ptr->insert (vec_ptr->end(), range.begin, range.end);

    size_type       ret_cnt { std::distance(range.begin, range.end) };
    const size_type idx_s { indices_.size() };
    const size_type s { vec_ptr->size() };

    if (padding == nan_policy::pad_with_nans && s < idx_s)  {
        for (size_type i { 0 }; i < idx_s - s; ++i)  {
            vec_ptr->push_back (std::move(get_nan<value_t>()));
            ret_cnt += 1;
        }
    }
    return (ret_cnt);
}

// ----------------------------------------------------------------------------

template<typename T>
inline size_type
load_column_(const char *name,
             StlVecType<T> &&column,
             nan_policy padding,
             bool do_lock)  {

    static_assert(std::is_base_of<HeteroVector<align_value>, H>::value,
                  "Only a StdDataFrame can call load_column()");

    const size_type idx_s { indices_.size() };
    const size_type data_s { column.size() };

    using value_t = typename StlVecType<T>::value_type;

    size_type   ret_cnt { data_s };

    if (padding == nan_policy::pad_with_nans && data_s < idx_s)  {
        for (size_type i { 0 }; i < idx_s - data_s; ++i)  {
            column.push_back (std::move(get_nan<value_t>()));
            ret_cnt += 1;
        }
    }

    const auto          iter { column_tb_.find (name) };
    StlVecType<value_t> *vec_ptr { nullptr };
    const SpinGuard     guard { do_lock ? lock_ : nullptr };

    if (iter == column_tb_.end())  { [[likely]]
        vec_ptr = &(create_column<value_t>(name, false));
    }
    else  {
        DataVec &hv { data_[iter->second] };

        vec_ptr = &(hv.template get_vector<value_t>());
    }

    *vec_ptr = std::move(column);
    return (ret_cnt);
}

// ----------------------------------------------------------------------------

template<typename T>
size_type
append_row_(std::pair<const char *, T> &row_name_data)  {

    return (append_column<T>(row_name_data.first, // column name
                             std::forward<T>(row_name_data.second),
                             nan_policy::dont_pad_with_nans));
}

// ----------------------------------------------------------------------------

template<typename T>
static void
drop_missing_rows_(T &vec,
                   const DropRowMap &missing_row_map,
                   drop_policy policy,
                   size_type threshold,
                   size_type col_num)  {

    size_type   erase_count { 0 };
    auto        dropper =
        [&vec, &erase_count](const auto &idx) -> void  {
            vec.erase(vec.begin() + (idx - erase_count++));
        };

    if (policy == drop_policy::all)  {
        for (const auto &[idx, count] : missing_row_map)
            if (count == col_num)  dropper(idx);
    }
    else if (policy == drop_policy::any)  {
        for (const auto &[idx, count] : missing_row_map)
            if (count > 0)  dropper(idx);
    }
    else if (policy == drop_policy::threshold)  {
        for (const auto &[idx, count] : missing_row_map)
            if (count > threshold)  dropper(idx);
    }

    return;
}

// ----------------------------------------------------------------------------

template<typename T>
static void
fill_missing_value_(ColumnVecType<T> &vec,
                    const T &value,
                    int limit,
                    size_type col_num)  {

    const size_type vec_size { vec.size() };
    int             count { 0 };

    if (limit < 0)
        vec.reserve(col_num);
    for (size_type i { 0 }; i < col_num; ++i)  {
        if (limit >= 0 && count >= limit)  break;
        if (i >= vec_size)  {
            vec.push_back(value);
            count += 1;
        }
        else if (is_nan<T>(vec[i]))  {
            vec[i] = value;
            count += 1;
        }
    }
    return;
}

// ----------------------------------------------------------------------------

template<typename T>
static void
fill_missing_ffill_(ColumnVecType<T> &vec, int limit, size_type col_num)  {

    const size_type vec_size { vec.size() };

    if (vec_size == 0)  return;

    int count { 0 };
    T   last_value { vec[0] };

    for (size_type i { 1 }; i < col_num; ++i)  {
        if (limit >= 0 && count >= limit)  break;
        if (i >= vec_size)  {
            if (! is_nan(last_value))  {
                vec.reserve(col_num);
                vec.push_back(last_value);
                count += 1;
            }
            else  break;
        }
        else  {
            if (! is_nan<T>(vec[i]))
                last_value = vec[i];
            else if (! is_nan<T>(last_value))  {
                vec[i] = last_value;
                count += 1;
            }
        }
    }
    return;
}

// ----------------------------------------------------------------------------

template<typename T,
         typename std::enable_if<
             supports_arithmetic<T>::value &&
             supports_arithmetic<IndexType>::value>::type* = nullptr>
static void
fill_missing_midpoint_(ColumnVecType<T> &vec, int limit, size_type)  {

    const size_type vec_size { vec.size() };

    if (vec_size < 3) [[unlikely]]  return;

    int         count { 0 };
    T           last_value { vec[0] };

    // next_known tracks the index of the next non-NaN value at or after
    // i + 1. It only ever moves forward across the ENTIRE loop (never
    // resets backward), so the total work spent advancing it is O(n) for
    // the whole function -- not O(gap length) re-spent on every element
    // inside a gap, which is what the original forward rescan from i + 1
    // on every iteration cost. Same fill values, same semantics, just
    // without redoing the search.
    //
    size_type   next_known { 1 };

    for (size_type i { 1 }; i < (vec_size - 1); ++i)  {
        if (limit >= 0 && count >= limit)  break;

        if (! is_nan<T>(vec[i]))  {
            last_value = vec[i];
            if (next_known <= i)  next_known = i + 1;
        }
        else if (! is_nan<T>(last_value))  {
            if (next_known <= i)  next_known = i + 1;
            while (next_known < vec_size && is_nan<T>(vec[next_known]))
                ++next_known;

            if (next_known < vec_size)  {
                vec[i] = (last_value + vec[next_known]) / T(2);
                last_value = vec[i];
                count += 1;
            }
        }
    }
    return;
}

// ----------------------------------------------------------------------------

template<typename T,
         typename std::enable_if<
             ! supports_arithmetic<T>::value ||
             ! supports_arithmetic<IndexType>::value>::type* = nullptr>
static void
fill_missing_midpoint_(ColumnVecType<T> &, int, size_type)  {

    throw NotFeasible("fill_missing_midpoint_(): ERROR: Mid-point filling is "
                      "not feasible on non-arithmetic types");
}

// ----------------------------------------------------------------------------

template<typename T>
static void
fill_missing_bfill_(ColumnVecType<T> &vec, int limit)  {

    const long  vec_size { static_cast<long>(vec.size()) };

    if (vec_size == 0)  return;

    int count { 0 };
    T   last_value { vec[vec_size - 1] };

    for (long i { vec_size - 1 }; i >= 0; --i)  {
        if (limit >= 0 && count >= limit)  break;
        if (! is_nan<T>(vec[i]))  last_value = vec[i];
        if (is_nan<T>(vec[i]) && ! is_nan<T>(last_value))  {
            vec[i] = last_value;
            count += 1;
        }
    }
    return;
}

// ----------------------------------------------------------------------------

template<typename T,
         typename std::enable_if<
             supports_arithmetic<T>::value &&
             supports_arithmetic<IndexType>::value>::type* = nullptr>
static void
fill_missing_linter_(ColumnVecType<T> &vec,
                     const IndexVecType &index,
                     int limit)  {

    const long  vec_size { static_cast<long>(vec.size()) };

    if (vec_size < 3)  return;

    int             count { 0 };
    const T         *y1 { &(vec[0]) };
    const T         *y2 { &(vec[2]) };
    const IndexType *x { &(index[1]) };
    const IndexType *x1 { &(index[0]) };
    const IndexType *x2 { &(index[2]) };

    // next_known tracks a lower bound on the index of the next non-NaN
    // value at or after i + 1, and only ever advances forward across the
    // WHOLE loop. The backward search for y1 is left exactly as it was --
    // it's only reachable right after a gap starts (vec[i-1] is otherwise
    // always already-known-good), so it never re-scans the same ground
    // twice and isn't the source of the quadratic behavior. The forward
    // search for y2 is what used to restart from i + 1 on every single
    // element of a gap; that's now bounded to O(n) total for the column
    // instead of O(gap length) re-paid per element inside one gap.
    //
    long            next_known { 2 };

    for (long i { 1 }; i < vec_size - 1; ++i)  {
        if (limit >= 0 && count >= limit)  break;
        if (is_nan<T>(vec[i]))  {
            if (is_nan<T>(*y2))  {
                if (next_known <= i)  next_known = i + 1;
                while (next_known < vec_size && is_nan(vec[next_known]))
                    ++next_known;

                if (next_known >= vec_size)  break;
                y2 = &(vec[next_known]);
                x2 = &(index[next_known]);
            }
            if (is_nan<T>(*y1))  {
                for (long j { i - 1 }; j >= 0; --j)  {
                    if (! is_nan(vec[j]))  {
                        y1 = &(vec[j]);
                        x1 = &(index[j]);
                        break;
                    }
                }
            }
            vec[i] = *y1 + (T(*x - *x1) / T(*x2 - *x1)) * (*y2 - *y1);
            count += 1;
        }
        if (i < (vec_size - 2))  {
            y1 = &(vec[i]);
            y2 = &(vec[i + 2]);
            x = &(index[i + 1]);
            x1 = &(index[i]);
            x2 = &(index[i + 2]);
            if (next_known <= i + 1)  next_known = i + 2;
        }
    }
    return;
}

// ----------------------------------------------------------------------------

template<typename T,
         typename std::enable_if<
             supports_arithmetic<T>::value &&
             supports_arithmetic<IndexType>::value>::type* = nullptr>
static void
fill_missing_lagrange_(ColumnVecType<T> &vec,
                       const IndexVecType &index,
                       int limit)  {

    const size_type vec_size { vec.size() };

    if (vec_size < 3)  return;

    int count { 0 };

    for (size_type k { 0 }; k < vec_size; ++k)  {
        if (limit >= 0 && count >= limit) [[unlikely]]  break;

        if (is_nan<T>(vec[k])) [[unlikely]]  {
            const auto  x { index[k] };
            T           y { 0 };

            for (size_type i { 0 }; i < vec_size; ++i)  {
                T   product { T(index[i]) };

                for (size_type j { 0 }; j < vec_size; ++j)
                    if (i != j && index[i] != index[j]) [[likely]]
                        product *= T(x - index[j]) / T(index[i] - index[j]);

                y += product;
            }

            vec[k] = y;
            count += 1;
        }
    }
    return;
}

// ----------------------------------------------------------------------------

template<typename T,
         typename std::enable_if<
             ! supports_arithmetic<T>::value ||
             ! supports_arithmetic<IndexType>::value>::type* = nullptr>
static void
fill_missing_linter_(ColumnVecType<T> &, const IndexVecType &, int)  {

    throw NotFeasible("fill_missing_linter_(): ERROR: Interpolation is "
                      "not feasible on non-arithmetic types");
}

// ----------------------------------------------------------------------------

// Removes the elements at the positions listed in sel_indices from vec in a
// single O(n) pass. sel_indices must be sorted in ascending order. Positions
// that are beyond the end of vec are ignored. This is only for real vectors
// (not views), since it assigns elements.
//
template<typename VEC>
static inline void
remove_sorted_positions_(VEC &vec, const StlVecType<size_type> &sel_indices)  {

    const size_type vec_s { vec.size() };
    const size_type sel_s { sel_indices.size() };

    if (sel_s == 0 || sel_indices[0] >= vec_s)  return;

    size_type   next { 0 };
    size_type   w { sel_indices[0] };

    for (size_type r { w }; r < vec_s; ++r)  {
        if (next < sel_s && sel_indices[next] == r)  {
            while (next < sel_s && sel_indices[next] == r)  ++next;
            continue;
        }
        vec[w++] = std::move(vec[r]);
    }
    vec.erase(vec.begin() + w, vec.end());
}

// ----------------------------------------------------------------------------

template<typename ... Ts>
void remove_data_by_sel_common_(const StlVecType<size_type> &col_indices)  {

    const auto  thread_level {
        (indices_.size() < ThreadPool::MUL_THR_THHOLD)
            ? 0L : get_thread_level()
    };
    SpinGuard   guard { lock_ };

    if (thread_level > 2)  {
        auto    lbd =
            [&col_indices = std::as_const(col_indices), this]
            (const auto &begin, const auto &end) -> void  {
                const sel_remove_functor_<Ts ...>   functor { col_indices };

                for (auto citer { begin }; citer < end; ++citer)
                    data_[citer->second].change(functor);
            };
        auto    lbd_idx =
            [&col_indices = std::as_const(col_indices), this] () -> void  {
                if constexpr (
                    std::is_base_of<HeteroVector<align_value>, H>::value)
                    remove_sorted_positions_(indices_, col_indices);
                else  {
                    const size_type col_indices_s { col_indices.size() };
                    size_type       del_count { 0 };

                    for (size_type i { 0 }; i < col_indices_s; ++i)
                        indices_.erase(col_indices[i] - del_count++);
                }
            };
        auto    futures {
            thr_pool_.parallel_loop<double>(column_list_.begin(),
                                            column_list_.end(),
                                            std::move(lbd))
        };
        auto    future_idx { thr_pool_.dispatch(false, lbd_idx) };

        for (auto &fut : futures)  fut.get();
        future_idx.get();
    }
    else  {
        const sel_remove_functor_<Ts ...>   functor { col_indices };

        for (const auto &citer : column_list_)
            data_[citer.second].change(functor);
        guard.release();

        if constexpr (std::is_base_of<HeteroVector<align_value>, H>::value)
            remove_sorted_positions_(indices_, col_indices);
        else  {
            const size_type col_indices_s { col_indices.size() };
            size_type       del_count { 0 };

            for (size_type i { 0 }; i < col_indices_s; ++i)
                indices_.erase(col_indices[i] - del_count++);
        }
    }

    return;
}

// ----------------------------------------------------------------------------

// Read-only view of the keys of a vector of JoinSortingPair (sorted by key).
// It lets the sorted-merge helpers, that handle runs of duplicate keys on both
// sides (i.e. the full Cartesian product), serve the unsorted case too.
//
template<typename T>
struct  JoinKeyView_  {

    using value_type = T;

    const StlVecType<JoinSortingPair<T>>    &pairs;

    inline size_type size() const  { return (pairs.size()); }
    inline const T &
    operator [](size_type i) const  { return (*(pairs[i].first)); }
};

// ----------------------------------------------------------------------------

// The sorted-merge helpers return positions in the sorted vectors. This
// replaces them with the original row numbers.
//
template<typename T>
static void
remap_join_idx_(IndexIdxVector &idx_vec,
                const StlVecType<JoinSortingPair<T>> &lhs,
                const StlVecType<JoinSortingPair<T>> &rhs)  {

    constexpr size_type NONE { std::numeric_limits<size_type>::max() };

    for (auto &item : idx_vec)  {
        if (std::get<0>(item) != NONE)
            std::get<0>(item) = lhs[std::get<0>(item)].second;
        if (std::get<1>(item) != NONE)
            std::get<1>(item) = rhs[std::get<1>(item)].second;
    }
}

// ----------------------------------------------------------------------------

template<typename LHS_T, typename RHS_T, typename IDX_T, typename ... Ts>
static void
join_helper_common_(
    const LHS_T &lhs,
    const RHS_T &rhs,
    const IndexIdxVector &joined_index_idx,
    DataFrame<IDX_T, HeteroVector<std::size_t(H::align_value)>> &result,
    const char *lhs_skip_name1 = nullptr,
    const char *rhs_skip_name1 = nullptr,
    const char *lhs_skip_name2 = nullptr,
    const char *rhs_skip_name2 = nullptr)  {

    using res_t = decltype(result);

    std::vector<std::future<void>>  futures;
    const auto                      thread_level {
        (lhs.indices_.size() < ThreadPool::MUL_THR_THHOLD)
            ? 0L : get_thread_level()
    };


    if (thread_level > 2)
        futures.reserve(lhs.column_list_.size() + rhs.column_list_.size());

    const SpinGuard guard { lock_ };
    char            buffer[MAX_COL_NAME_SIZE];

    // NOTE: I had to do this in two separate loops. Otherwise, it would
    //       occasionally crash in multithreaded mode under MacOS.
    //
    for (const auto &[name, idx] : lhs.column_list_) [[likely]]  {
        if (lhs_skip_name1 && name == lhs_skip_name1)  continue;
        if (lhs_skip_name2 && name == lhs_skip_name2)  continue;

        if (rhs_skip_name1 && name == rhs_skip_name1)  {
            ::snprintf(buffer, sizeof(buffer) - 1, "lhs.%s", rhs_skip_name1);

            create_col_functor_<res_t, Ts ...>  create_f { buffer, result };

            lhs.data_[idx].change(create_f);
        }
        else if (rhs_skip_name2 && name == rhs_skip_name2)  {
            ::snprintf(buffer, sizeof(buffer) - 1, "lhs.%s", rhs_skip_name2);

            create_col_functor_<res_t, Ts ...>  create_f { buffer, result };

            lhs.data_[idx].change(create_f);
        }
        else  {
            if (rhs.column_tb_.find(name) != rhs.column_tb_.end())  {
                create_join_common_col_functor_<res_t, Ts ...>   create_f {
                    name.c_str(), result
                };

                lhs.data_[idx].change(create_f);
            }
            else  {
                create_col_functor_<res_t, Ts ...>  create_f {
                    name.c_str(), result
                };

                lhs.data_[idx].change(create_f);
            }
        }
    }

    // Load the common and lhs columns
    //
    for (const auto &[name, idx] : lhs.column_list_) [[likely]]  {
        if (lhs_skip_name1 && name == lhs_skip_name1)  continue;
        if (lhs_skip_name2 && name == lhs_skip_name2)  continue;

        if (rhs_skip_name1 && name == rhs_skip_name1)  {
            ::snprintf(buffer, sizeof(buffer) - 1, "lhs.%s", rhs_skip_name1);

            auto    jlhs_lbd =
                [idx,
                 &lhs = std::as_const(lhs),
                 &joined_index_idx = std::as_const(joined_index_idx),
                 &result](std::string name) -> void  {
                    // 0 = Left
                    index_join_functor_oneside_<0, res_t, Ts ...>   functor {
                        name.c_str(), joined_index_idx, result
                    };

                    lhs.data_[idx].change(functor);
                };

            if (thread_level > 2)
                futures.emplace_back(thr_pool_.dispatch(
                    false, jlhs_lbd, std::string(buffer)));
            else
                jlhs_lbd(std::string(buffer));
        }
        else if (rhs_skip_name2 && name == rhs_skip_name2)  {
            ::snprintf(buffer, sizeof(buffer) - 1, "lhs.%s", rhs_skip_name2);

            auto    jlhs_lbd =
                [idx,
                 &lhs = std::as_const(lhs),
                 &joined_index_idx = std::as_const(joined_index_idx),
                 &result](std::string name) -> void  {
                    // 0 = Left
                    index_join_functor_oneside_<0, res_t, Ts ...>   functor {
                        name.c_str(), joined_index_idx, result
                    };

                    lhs.data_[idx].change(functor);
                };

            if (thread_level > 2)
                futures.emplace_back(thr_pool_.dispatch(
                    false, jlhs_lbd, std::string(buffer)));
            else
                jlhs_lbd(std::string(buffer));
        }
        else  {
            // Common column between two frames
            //
            if (rhs.column_tb_.find(name) != rhs.column_tb_.end())  {
                auto    jcomm_lbd =
                    [&name = std::as_const(name),
                     idx,
                     &lhs = std::as_const(lhs),
                     &rhs = std::as_const(rhs),
                     &joined_index_idx = std::as_const(joined_index_idx),
                     &result] () -> void  {
                        index_join_functor_common_<res_t, RHS_T, Ts ...>
                            functor {
                                name.c_str(),
                                rhs,
                                joined_index_idx,
                                result
                        };

                        lhs.data_[idx].change(functor);
                    };

                if (thread_level > 2)
                    futures.emplace_back(thr_pool_.dispatch(false, jcomm_lbd));
                else
                    jcomm_lbd();
            }
            else  {  // lhs only column
                auto    jlhs_lbd =
                    [&name = std::as_const(name),
                     idx,
                     &lhs = std::as_const(lhs),
                     &joined_index_idx = std::as_const(joined_index_idx),
                     &result] () -> void  {
                        // 0 = Left
                        index_join_functor_oneside_<0, res_t, Ts ...> functor {
                            name.c_str(), joined_index_idx, result
                        };

                        lhs.data_[idx].change(functor);
                    };

                if (thread_level > 2)
                    futures.emplace_back(thr_pool_.dispatch(false, jlhs_lbd));
                else
                    jlhs_lbd();
            }
        }
    }

    // Load the rhs columns
    //
    for (const auto &[name, idx] : rhs.column_list_) [[likely]]  {
        if (rhs_skip_name1 && name == rhs_skip_name1)  continue;
        if (rhs_skip_name2 && name == rhs_skip_name2)  continue;

        auto    jrhs_lbd =
            [idx,
             &rhs = std::as_const(rhs),
             &joined_index_idx = std::as_const(joined_index_idx),
             &result](std::string name) -> void  {
                // 1 = Right
                index_join_functor_oneside_<1, res_t, Ts ...>   functor {
                    name.c_str(), joined_index_idx, result
                };

                rhs.data_[idx].change(functor);
            };

        if (lhs_skip_name1 && rhs_skip_name1 && name == lhs_skip_name1)  {
            ::snprintf(buffer, sizeof(buffer) - 1, "rhs.%s", lhs_skip_name1);
            if (thread_level > 2)
                futures.emplace_back(thr_pool_.dispatch(
                    false, jrhs_lbd, std::string(buffer)));
            else
                jrhs_lbd(std::string(buffer));
        }
        else if (lhs_skip_name2 && rhs_skip_name2 && name == lhs_skip_name2)  {
            ::snprintf(buffer, sizeof(buffer) - 1, "rhs.%s", lhs_skip_name2);
            if (thread_level > 2)
                futures.emplace_back(thr_pool_.dispatch(
                    false, jrhs_lbd, std::string(buffer)));
            else
                jrhs_lbd(std::string(buffer));
        }
        else  {
            const auto  lhs_citer = lhs.column_tb_.find(name);

            if (lhs_citer == lhs.column_tb_.end())  {  // rhs only column
                create_col_functor_<res_t, Ts ...>  create_f {
                    name.c_str(), result
                };

                rhs.data_[idx].change(create_f);
            }

            if (lhs_citer == lhs.column_tb_.end())  {  // rhs only column
                if (thread_level > 2)
                    futures.emplace_back(thr_pool_.dispatch(
                        false, jrhs_lbd, std::string(name.c_str())));
                else
                    jrhs_lbd(std::string(name.c_str()));
            }
        }
    }

    for (auto &fut : futures)  fut.get();
}

// ----------------------------------------------------------------------------

//
// Optimized join helpers.
//
// The existing JoinSortingPair representation stores:
//
//     pointer-to-key + original-index
//
// That is convenient for the original implementation, but unnecessarily
// expensive when the keys are already sorted. These helpers operate directly
// on the original vectors and return the same IndexIdxVector consumed by the
// existing result-building machinery.
//
// NONE means "no corresponding row".
//

template<typename LHS_V, typename RHS_V>
static IndexIdxVector
get_inner_index_idx_vector_sorted_(const LHS_V &lhs, const RHS_V &rhs)  {

    using value_t = typename LHS_V::value_type;

    const size_type lhs_s { lhs.size() };
    const size_type rhs_s { rhs.size() };

    IndexIdxVector result;

    // The minimum is only a lower bound because duplicate keys can produce
    // a Cartesian product.
    //
    result.reserve(std::min(lhs_s, rhs_s));

    size_type   li { 0 };
    size_type   ri { 0 };

    while (li < lhs_s && ri < rhs_s) [[likely]]  {
        if (lhs[li] < rhs[ri])  {
            li += 1;
            continue;
        }
        if (rhs[ri] < lhs[li])  {
            ri += 1;
            continue;
        }

        // Equal key.  We need the Cartesian product of the equal-key
        // runs on both sides.
        //
        const value_t   &key { lhs[li] };
        const size_type lhs_begin { li };
        const size_type rhs_begin { ri };

        while (li < lhs_s && lhs[li] == key)  li += 1;
        while (ri < rhs_s && rhs[ri] == key)  ri += 1;

        for (size_type l { lhs_begin }; l < li; ++l)
            for (size_type r { rhs_begin }; r < ri; ++r)
                result.emplace_back(l, r);
    }
    return (result);
}

// ----------------------------------------------------------------------------

template<typename LHS_V, typename RHS_V>
static IndexIdxVector
get_left_index_idx_vector_sorted_(const LHS_V &lhs, const RHS_V &rhs)  {

    using value_t = typename LHS_V::value_type;

    constexpr size_type NONE { std::numeric_limits<size_type>::max() };

    const size_type lhs_s { lhs.size() };
    const size_type rhs_s { rhs.size() };
    IndexIdxVector  result;

    result.reserve(lhs_s);

    size_type   li { 0 };
    size_type   ri { 0 };

    while (li < lhs_s) [[likely]]  {
        if (ri >= rhs_s) {
            result.emplace_back(li++, NONE);
            continue;
        }
        if (lhs[li] < rhs[ri])  {
            result.emplace_back(li++, NONE);
            continue;
        }
        if (rhs[ri] < lhs[li])  {
            ++ri;
            continue;
        }

        // Equal key.
        //
        const value_t   &key { lhs[li] };
        const size_type lhs_begin { li };
        const size_type rhs_begin { ri };

        while (li < lhs_s && lhs[li] == key)  ++li;
        while (ri < rhs_s && rhs[ri] == key)  ++ri;

        for (size_type l { lhs_begin }; l < li; ++l)
            for (size_type r { rhs_begin }; r < ri; ++r)
                result.emplace_back(l, r);
    }
    return (result);
}

// ----------------------------------------------------------------------------

template<typename LHS_V, typename RHS_V>
static IndexIdxVector
get_right_index_idx_vector_sorted_(const LHS_V &lhs, const RHS_V &rhs)  {

    using value_t = typename LHS_V::value_type;

    constexpr size_type NONE { std::numeric_limits<size_type>::max() };

    const size_type lhs_s { lhs.size() };
    const size_type rhs_s { rhs.size() };
    IndexIdxVector  result;

    result.reserve(rhs_s);

    size_type   li { 0 };
    size_type   ri { 0 };

    while (ri < rhs_s) [[likely]]  {
        if (li >= lhs_s)  {
            result.emplace_back(NONE, ri++);
            continue;
        }
        if (lhs[li] < rhs[ri])  {
            ++li;
            continue;
        }
        if (rhs[ri] < lhs[li]) { 
            result.emplace_back(NONE, ri++);
            continue;
        }

        // Equal key.
        //
        const value_t   &key { rhs[ri] };
        const size_type lhs_begin { li };
        const size_type rhs_begin { ri };

        while (li < lhs_s && lhs[li] == key)  ++li;
        while (ri < rhs_s && rhs[ri] == key)  ++ri;

        for (size_type r { rhs_begin }; r < ri; ++r)
            for (size_type l { lhs_begin }; l < li; ++l)
                result.emplace_back(l, r);
    }
    return (result);
}

// ----------------------------------------------------------------------------

template<typename LHS_V, typename RHS_V>
static IndexIdxVector
get_left_right_index_idx_vector_sorted_(const LHS_V &lhs, const RHS_V &rhs)  {

    using value_t = typename LHS_V::value_type;

    constexpr size_type NONE { std::numeric_limits<size_type>::max() };

    const size_type lhs_s { lhs.size() };
    const size_type rhs_s { rhs.size() };
    IndexIdxVector  result;

    result.reserve(lhs_s + rhs_s);

    size_type li { 0 };
    size_type ri { 0 };

    while (li < lhs_s || ri < rhs_s) [[likely]]  {
        if (li >= lhs_s)  {
            result.emplace_back(NONE, ri++);
            continue;
        }
        if (ri >= rhs_s)  {
            result.emplace_back(li++, NONE);
            continue;
        }
        if (lhs[li] < rhs[ri])  {
            result.emplace_back(li++, NONE);
            continue;
        }
        if (rhs[ri] < lhs[li])  {
            result.emplace_back(NONE, ri++);
            continue;
        }

        // Equal key.
        //
        const value_t   &key { rhs[ri] };
        const size_type lhs_begin { li };
        const size_type rhs_begin { ri };

        while (li < lhs_s && lhs[li] == key)  ++li;
        while (ri < rhs_s && rhs[ri] == key)  ++ri;

        for (size_type l { lhs_begin }; l < li; ++l)
            for (size_type r { rhs_begin }; r < ri; ++r)
                result.emplace_back(l, r);
    }
    return (result);
}

// ----------------------------------------------------------------------------

// Build a permutation containing [0, 1, ..., n).
//
// This is only used for unsorted joins. It is considerably smaller than the
// old JoinSortingPair<T>:
//
//     old: pointer + size_type
//     new:  size_type
//
static StlVecType<size_type>
make_identity_permutation_(size_type n)  {

    StlVecType<size_type>   result(n);

    std::iota(result.begin(), result.end(), size_type(0));
    return (result);
}

// ----------------------------------------------------------------------------

template<typename MAP, typename ... Ts>
static
DataFrame<I, HeteroVector<std::size_t(H::align_value)>>
remove_dups_common_(const DataFrame &s_df,
                    remove_dup_spec rds,
                    const MAP &row_table,
                    const IndexVecType &index)  {

    using res_t = DataFrame<I, HeteroVector<std::size_t(H::align_value)>>;

    // Every row appears in exactly one of the row_table's index vectors. So,
    // a plain per-row mask is both exact and much cheaper than a hash set,
    // since each column is then scanned with no hashing at all.
    //
    const size_type     idx_s { index.size() };
    StlVecType<char>    del_mask(idx_s, 0);
    size_type           del_count { 0 };
    auto                mark =
        [&del_mask, &del_count](auto first, auto last) -> void  {
            for ( ; first != last; ++first)  {
                del_mask[*first] = 1;
                del_count += 1;
            }
        };

    if (rds == remove_dup_spec::keep_first)  {
        for (const auto &[val_tuple, idx_vec] : row_table)  {
            if (idx_vec.size() > 1)  mark(idx_vec.begin() + 1, idx_vec.end());
        }
    }
    else if (rds == remove_dup_spec::keep_last)  {
        for (const auto &[val_tuple, idx_vec] : row_table)  {
            if (idx_vec.size() > 1)  mark(idx_vec.begin(), idx_vec.end() - 1);
        }
    }
    else  {  // remove_dup_spec::keep_none
        for (const auto &[val_tuple, idx_vec] : row_table)
            if (idx_vec.size() > 1)  mark(idx_vec.begin(), idx_vec.end());
    }

    res_t                        new_df;
    typename res_t::IndexVecType new_index;
    const SpinGuard              guard { lock_ };

    // Load the index
    //
    new_index.reserve(idx_s - del_count);
    for (size_type i { 0 }; i < idx_s; ++i)  {
        if (! del_mask[i])  new_index.push_back(index[i]);
    }

    new_df.load_index(std::move(new_index));

    // Create the columns, so loading can proceed in parallel
    //
    for (const auto &citer : s_df.column_list_)  {
        create_col_functor_<res_t, Ts ...>  functor {
            citer.first.c_str(), new_df
        };

        s_df.data_[citer.second].change(functor);
    }

    const auto  thread_level {
        (new_df.get_index().size() < ThreadPool::MUL_THR_THHOLD)
            ? 0L : get_thread_level()
    };

    if (thread_level > 2)  {
        auto    lbd =
            [&del_mask = std::as_const(del_mask),
             del_count,
             &s_df = std::as_const(s_df),
             &new_df]
            (const auto &begin, const auto &end) -> void  {
                for (auto citer { begin }; citer < end; ++citer)  {
                    copy_remove_functor_<res_t, Ts ...> functor {
                        citer->first.c_str(), del_mask, del_count, new_df
                    };

                    s_df.data_[citer->second].change(functor);
                }
            };
        auto    futures {
            thr_pool_.parallel_loop<double>(s_df.column_list_.begin(),
                                            s_df.column_list_.end(),
                                            std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  {
        for (const auto &citer : s_df.column_list_)  {
            copy_remove_functor_<res_t, Ts ...> functor {
                citer.first.c_str(), del_mask, del_count, new_df
            };

            s_df.data_[citer.second].change(functor);
        }
    }
    return (new_df);
}

// ----------------------------------------------------------------------------

template<typename ... Ts>
DataFrame<I, HeteroVector<align_value>>
data_by_sel_common_(const StlVecType<size_type> &col_indices,
                    size_type idx_s) const  {

    using res_t = DataFrame<I, HeteroVector<align_value>>;
    using idx_vec_t = res_t::IndexVecType;

    res_t       ret_df;
    idx_vec_t   new_index;

    new_index.reserve(col_indices.size());
    for (const auto &citer: col_indices) [[likely]]
        new_index.push_back(indices_[citer]);
    ret_df.load_index(std::move(new_index));

    const SpinGuard guard { lock_ };

    for (const auto &[name, idx] : column_list_) [[likely]]  {
        create_col_functor_<res_t, Ts ...>  functor { name.c_str(), ret_df };

        data_[idx].change(functor);
    }

    const auto  thread_level {
        (idx_s < ThreadPool::MUL_THR_THHOLD) ? 0L : get_thread_level()
    };

    if (thread_level > 2)  {
        auto    lbd =
            [&col_indices = std::as_const(col_indices), idx_s, &ret_df, this]
            (const auto &begin, const auto &end) -> void  {
                for (auto citer { begin }; citer < end; ++citer)  {
                    sel_load_functor_<res_t, size_type, Ts ...> functor {
                        citer->first.c_str(), col_indices, idx_s, ret_df
                    };

                    data_[citer->second].change(functor);
                }
            };

        auto    futures {
            thr_pool_.parallel_loop<double>(column_list_.begin(),
                                            column_list_.end(),
                                            std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  {
        for (const auto &[name, idx] : column_list_) [[likely]]  {
            sel_load_functor_<res_t, size_type, Ts ...> functor {
                name.c_str(), col_indices, idx_s, ret_df
            };

            data_[idx].change(functor);
        }
    }

    return (ret_df);
}

// ----------------------------------------------------------------------------

template<typename ... Ts>
PtrView
view_by_sel_common_(const StlVecType<size_type> &col_indices,
                    size_type idx_s)  {

    using TheView = PtrView;

    TheView                         ret_dfv;
    typename TheView::IndexVecType  new_index;

    new_index.reserve(col_indices.size());
    for (const auto &citer : col_indices) [[likely]]
        new_index.push_back(&(indices_[citer]));
    ret_dfv.indices_ = std::move(new_index);

    const SpinGuard guard { lock_ };

    for (const auto &[name, idx] : column_list_) [[likely]]  {
        sel_load_view_functor_<size_type, TheView, Ts ...>   functor {
            name.c_str(), col_indices, idx_s, ret_dfv
        };

        data_[idx].change(functor);
    }

    return (ret_dfv);
}

// ----------------------------------------------------------------------------

template<typename ... Ts>
ConstPtrView
view_by_sel_common_(const StlVecType<size_type> &col_indices,
                    size_type idx_s) const  {

    using TheView = ConstPtrView;

    TheView                         ret_dfv;
    typename TheView::IndexVecType  new_index;

    new_index.reserve(col_indices.size());
    for (const auto &citer: col_indices) [[likely]]
        new_index.push_back(&(indices_[citer]));
    ret_dfv.indices_ = std::move(new_index);

    const SpinGuard guard { lock_ };

    for (const auto &[name, idx] : column_list_) [[likely]]  {
        sel_load_view_functor_<size_type, TheView, Ts ...>   functor {
            name.c_str(), col_indices, idx_s, ret_dfv
        };

        data_[idx].change(functor);
    }

    return (ret_dfv);
}

// ----------------------------------------------------------------------------

template<typename T, typename V, typename R, typename ... Ts>
void top_n_common_(const char *col_name, V &&visitor, R &result) const  {

    using res_t = R;

    const ColumnVecType<T>  *vec { nullptr };

    if (! ::strcmp(col_name, DF_INDEX_COL_NAME))
        vec = (const ColumnVecType<T> *) &(get_index());
    else
        vec = (const ColumnVecType<T> *) &(get_column<T>(col_name));

    visitor.pre();
    visitor(indices_.begin(), indices_.end(), vec->begin(), vec->end());
    visitor.post();
    visitor.sort_by_index_idx();

    typename res_t::IndexVecType    new_index;
    StlVecType<size_type>           idxs;

    new_index.reserve(visitor.get_result().size());
    idxs.reserve(visitor.get_result().size());
    for (const auto &res : visitor.get_result())  {
        if constexpr (std::is_same_v<res_t,
                                     DataFrame<I, HeteroVector<align_value>>>)
            new_index.push_back(indices_[res.index_idx]);
        else  // Views
            new_index.push_back(
                &(const_cast<DataFrame *>(this)->indices_[res.index_idx]));
        idxs.push_back(res.index_idx);
    }
    result.indices_ = std::move(new_index);

    const SpinGuard guard { lock_ };

    if constexpr (std::is_same_v<res_t,
                                 DataFrame<I, HeteroVector<align_value>>>)  {
        for (const auto &[name, idx] : column_list_) [[likely]]  {
            sel_load_functor_<res_t, size_type, Ts ...> functor {
                name.c_str(), idxs, 0, result
            };

            data_[idx].change(functor);
        }
    }
    else  {  // Views
        for (const auto &[name, idx] : column_list_) [[likely]]  {
            sel_load_view_functor_<size_type, res_t, Ts ...>    functor {
                name.c_str(), idxs, 0, result
            };

            data_[idx].change(functor);
        }
    }
}

// ----------------------------------------------------------------------------

template<typename T, typename C, typename R, typename ... Ts>
void
above_quantile_common_(const char *col_name,
                       double quantile,
                       C &&comp_func,
                       R &result) const  {

    using res_t = R;

    const ColumnVecType<T>  *vec { nullptr };

    if (! ::strcmp(col_name, DF_INDEX_COL_NAME))
        vec = (const ColumnVecType<T> *) &(get_index());
    else
        vec = (const ColumnVecType<T> *) &(get_column<T>(col_name));

    QuantileVisitor<T, I>   quant { quantile };

    quant.pre();
    quant(indices_.begin(), indices_.end(), vec->begin(), vec->end());
    quant.post();

    typename res_t::IndexVecType    new_index;
    StlVecType<size_type>           idxs;

    new_index.reserve(vec->size() / 2);
    idxs.reserve(vec->size() / 2);
    for (size_type i { 0 }; i < vec->size(); ++i)  {
        if (comp_func((*vec)[i], quant.get_result()))  {
            if constexpr (std::is_same_v<
                              res_t,
                              DataFrame<I, HeteroVector<align_value>>>)
                new_index.push_back(indices_[i]);
            else  // Views
                new_index.push_back(
                    &(const_cast<DataFrame *>(this)->indices_[i]));
            idxs.push_back(i);
        }
    }
    result.indices_ = std::move(new_index);

    const SpinGuard guard { lock_ };

    if constexpr (std::is_same_v<res_t,
                                  DataFrame<I, HeteroVector<align_value>>>)  {
        for (const auto &[name, idx] : column_list_) [[likely]]  {
            sel_load_functor_<res_t, size_type, Ts ...> functor {
                name.c_str(), idxs, 0, result
            };

            data_[idx].change(functor);
        }
    }
    else  {  // Views
        for (const auto &[name, idx] : column_list_) [[likely]]  {
            sel_load_view_functor_<size_type, res_t, Ts ...>    functor {
                name.c_str(), idxs, 0, result
            };

            data_[idx].change(functor);
        }
    }
}

// ----------------------------------------------------------------------------

template<typename V, typename T>
inline static void
replace_vector_vals_(V &data_vec,
                     const StlVecType<T> &old_values,
                     const StlVecType<T> &new_values,
                     std::size_t &count,
                     long limit)  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (old_values.size() != new_values.size())
        throw DataFrameError("replace_vector_vals_(): "
                             "old/new vector sizes don't match");
#endif // HMDF_SANITY_EXCEPTIONS

    using map_t = DFUnorderedMap<T, T>;

    const auto  v_zip { std::ranges::views::zip(old_values, new_values) };
    const map_t v_map(v_zip.begin(), v_zip.end());
    const auto  thread_level {
        (data_vec.size() < ThreadPool::MUL_THR_THHOLD || limit >= 0)
            ? 0L : get_thread_level()
    };
    auto        lbd =
        [&v_map = std::as_const(v_map)]
        (auto begin, auto end) -> std::size_t  {
            std::size_t count { 0 };

            for (auto iter { begin }; iter < end; ++iter)  {
                const auto  map_iter { v_map.find(*iter) };

                if (map_iter != v_map.end())  {
                    *iter = map_iter->second;
                    count += 1;
                }
            }
            return (count);
        };

    if (thread_level > 2)  {
        auto    futures {
            thr_pool_.parallel_loop<T>(data_vec.begin(),
                                       data_vec.end(),
                                       std::move(lbd))
        };

        for (auto &fut : futures)  count += fut.get();
    }
    else  {
        if (limit < 0) [[likely]]  {
            count = lbd(data_vec.begin(), data_vec.end());
        }
        else  {
            for (auto &data : data_vec)  {
                if (count >= static_cast<std::size_t>(limit))  return;

                const auto  map_iter { v_map.find(data) };

                if (map_iter != v_map.end())  {
                    data = map_iter->second;
                    count += 1;
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------

template<typename V>
inline static void
col_vector_push_back_func_(
    typename V::value_type(*converter)(const char *, int),
    std::istream &file,
    V &vec,
    io_format file_type,
    char delim)  {

    std::streambuf  *rdbuf { file.rdbuf() };
    std::string     value;
    int             ch;
    char            c { 0 };

    while ((ch = rdbuf->sbumpc()) != std::char_traits<char>::eof())  {
        c = static_cast<char>(ch);
        value.clear();
        if (file_type == io_format::csv && c == '\n')  break;
        else if (file_type == io_format::json && c == ']')  break;
        rdbuf->sungetc();
        _get_token_from_file_(file, delim, value,
                              file_type == io_format::json ? ']' : '\0');
        vec.push_back(converter(value.c_str(), int(value.size())));
    }
}

// ----------------------------------------------------------------------------

template<typename T, typename V>
inline static void
col_vector_push_back_func_(V &vec,
                           std::istream &file,
                           T (*converter)(const char *, char **, int),
                           io_format file_type,
                           char delim)  {

    std::streambuf  *rdbuf { file.rdbuf() };
    std::string     value;
    int             ch;
    char            c { 0 };

    value.reserve(1024);
    while ((ch = rdbuf->sbumpc()) != std::char_traits<char>::eof())  {
        c = static_cast<char>(ch);
        value.clear();
        if (file_type == io_format::csv && c == '\n')  break;
        else if (file_type == io_format::json && c == ']')  break;
        rdbuf->sungetc();
        _get_token_from_file_(file, delim, value,
                              file_type == io_format::json ? ']' : '\0');
        vec.push_back(static_cast<T>(converter(value.c_str(), nullptr, 0)));
    }
}

// ----------------------------------------------------------------------------

template<typename T, typename V>
inline static void
col_vector_push_back_cont_func_(V &vec,
                                std::istream &file,
                                T (*converter)(const char *),
                                char delim)  {

    std::streambuf  *rdbuf { file.rdbuf() };
    std::string     value;
    int             ch;
    char            c { 0 };

    value.reserve(2048);
    while ((ch = rdbuf->sbumpc()) != std::char_traits<char>::eof())  {
        c = static_cast<char>(ch);
        if (c == '\n') [[unlikely]] break;
        rdbuf->sungetc();
        value.clear();
        _get_token_from_file_(file, delim, value, '\0');
        vec.push_back(converter(value.c_str()));
    }
}

// ----------------------------------------------------------------------------

template<typename NEW_COL_T, typename COL_T, typename ... Ts>
inline void
explode_helper_(DataFrame &result,
                size_type total_cnt,
                const char *col_name,
                const StlVecType<size_type> &idx_mask,
                const COL_T &col) const {

    ColumnVecType<NEW_COL_T>    new_col;

    new_col.reserve(total_cnt);
    for (size_type i { 0 }; i < col.size(); ++i)
        for (const auto &val : col[i])
            new_col.push_back(val);

    SpinGuard   guard { lock_ };

    result.template load_column<NEW_COL_T>(col_name,
                                           std::move(new_col),
                                           nan_policy::dont_pad_with_nans,
                                           false);
    for (const auto &[name, idx] : column_list_) [[likely]]
        if (name != col_name)  {
            explode_functor_<Ts ...>   functor {
                name.c_str(), result, idx_mask
            };

            data_[idx].change(functor);
        }

    return;
}

// ----------------------------------------------------------------------------

template<typename T, typename V, typename Dummy = void>
struct  ColVectorPushBack_  {

    inline void
    operator ()(V &vec,
                std::istream &file,
                T (*converter)(const char *, char **),
                io_format file_type,
                char delim) const  {

        std::streambuf  *rdbuf { file.rdbuf() };
        std::string     value;
        int             ch;
        char            c { 0 };

        value.reserve(1024);
        while ((ch = rdbuf->sbumpc()) != std::char_traits<char>::eof())  {
            c = static_cast<char>(ch);
            if (file_type == io_format::csv && c == '\n')  break;
            else if (file_type == io_format::json && c == ']')  break;
            rdbuf->sungetc();
            value.clear();
            _get_token_from_file_(file, delim, value,
                                  file_type == io_format::json ? ']' : '\0');
            vec.push_back(static_cast<T>(converter(value.c_str(), nullptr)));
        }
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  ColVectorPushBack_<const char *, StlVecType<std::string>, Dummy>  {

    inline void
    operator ()(StlVecType<std::string> &vec,
                std::istream &file,
                const char * (*)(const char *, char **),
                io_format file_type,
                char delim) const  {

        std::streambuf  *rdbuf { file.rdbuf() };
        std::string     value;
        int             ch;
        char            c { 0 };

        value.reserve(1024);
        while ((ch = rdbuf->sbumpc()) != std::char_traits<char>::eof())  {
            c = static_cast<char>(ch);
            if (file_type == io_format::csv && c == '\n')  break;
            else if (file_type == io_format::json && c == ']')  break;
            rdbuf->sungetc();
            value.clear();
            _get_token_from_file_(file, delim, value,
                                  file_type == io_format::json ? ']' : '\0');

            if (file_type == io_format::json)  { // Get rid of "'s
                value.pop_back();
                value.erase(value.begin());
            }

            vec.push_back(value);
        }
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  ColVectorPushBack_<DateTime, StlVecType<DateTime>, Dummy>  {

    inline void
    operator ()(StlVecType<DateTime> &vec,
                std::istream &file,
                DateTime (*)(const char *, char **),
                io_format file_type,
                char delim) const  {

        std::streambuf  *rdbuf { file.rdbuf() };
        std::string     value;
        int             ch;
        char            c { 0 };

        value.reserve(1024);
        while ((ch = rdbuf->sbumpc()) != std::char_traits<char>::eof())  {
            c = static_cast<char>(ch);
            if (file_type == io_format::csv && c == '\n')  break;
            else if (file_type == io_format::json && c == ']')  break;
            rdbuf->sungetc();
            value.clear();
            _get_token_from_file_(file, delim, value,
                                  file_type == io_format::json ? ']' : '\0');

            time_t      t;
            int         n;
            DateTime    dt;

#ifdef _MSC_VER
            ::sscanf(value.c_str(), "%lld.%d", &t, &n);
#else
            ::sscanf(value.c_str(), "%ld.%d", &t, &n);
#endif // _MSC_VER
            dt.set_time(t, n);
            vec.emplace_back(std::move(dt));
        }
    }
};

// ----------------------------------------------------------------------------

template<typename STR>
inline static void
json_str_col_vector_push_back_(StlVecType<STR> &vec,
                               std::istream &file,
                               char delim)  {

    char    value[2048];
    char    c { 0 };

    while (file.get(c))
        if (c != ' ' && c != '\n' && c != '\t')  {
            file.unget();
            break;
        }

    while (file.get(c)) [[likely]] {
        if (c == ']')  break;
        file.unget();

        std::size_t count { 0 };

        while (file.get(c))
            if (c != ' ' && c != '\n' && c != '\t')  break;
        if (c != '"')
            throw DataFrameError(
                "json_str_col_vector_push_back_(): ERROR: Expected '\"' (0)");

        while (file.get(c))  {
            if (c == '"')  break;
            else  value[count++] = c;
        }
        if (c != '"')
            throw DataFrameError(
                "DataFrame::read_json_(): ERROR: Expected '\"' (1)");

        value[count] = 0;
        vec.push_back(value);

        while (file.get(c))
            if (c != ' ' && c != '\n' && c != '\t')  break;
        if (c == ']')  break;
        else if (c != delim)
            throw DataFrameError(
                "json_str_col_vector_push_back_(): ERROR: Expected ',' (2)");
    }
}

// ----------------------------------------------------------------------------

template<typename T, typename Dummy = void>
struct  IdxParserFunctor_  {

    void
    operator()(StlVecType<T> &, std::istream &, io_format, char delim)  {   }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<float, Dummy>  {

    inline void operator()(StlVecType<float> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        const ColVectorPushBack_<float, StlVecType<float>>  slug;

        slug(vec, file, &::strtof, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<double, Dummy>  {

    inline void operator()(StlVecType<double> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        const ColVectorPushBack_<double, StlVecType<double>>  slug;

        slug(vec, file, &::strtod, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<long double, Dummy>  {

    inline void operator()(StlVecType<long double> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        const ColVectorPushBack_<long double, StlVecType<long double>>  slug;

        slug(vec, file, &::strtold, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<int, Dummy>  {

    inline void operator()(StlVecType<int> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        col_vector_push_back_func_(&_atoi_<int>, file, vec, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<long, Dummy>  {

    inline void operator()(StlVecType<long> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        col_vector_push_back_func_(&_atoi_<long>, file, vec, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<long long, Dummy>  {

    inline void operator()(StlVecType<long long> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        col_vector_push_back_func_(&_atoi_<long long>, file, vec,
                                   file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<unsigned int, Dummy>  {

    inline void operator()(StlVecType<unsigned int> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        col_vector_push_back_func_(&_atoi_<unsigned int>, file, vec,
                                   file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<unsigned long, Dummy>  {

    inline void operator()(StlVecType<unsigned long> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        col_vector_push_back_func_(&_atoi_<unsigned long>,
                                   file, vec, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<unsigned long long, Dummy>  {

    inline void operator()(StlVecType<unsigned long long> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        col_vector_push_back_func_(&_atoi_<unsigned long long>,
                                   file, vec, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<std::string, Dummy>  {

    inline void operator()(StlVecType<std::string> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        auto                   converter =
            [](const char *s, char **)-> const char * { return (s); };
        const ColVectorPushBack_<const char *, StlVecType<std::string>>  slug;

        slug(vec, file, converter, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<DateTime, Dummy>  {

    inline void operator()(StlVecType<DateTime> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        auto                    converter =
            [](const char *, char **)-> DateTime  { return (DateTime()); };
        const ColVectorPushBack_<DateTime, StlVecType<DateTime>>  slug;

        slug(vec, file, converter, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  IdxParserFunctor_<bool, Dummy>  {

    inline void operator()(StlVecType<bool> &vec,
                           std::istream &file,
                           io_format file_type,
                           char delim) const  {

        col_vector_push_back_func_(vec, file, &::strtol, file_type, delim);
    }
};

// ----------------------------------------------------------------------------

template<typename T, typename Dummy = void>
struct  GenerateTSIndex_  {

    inline void
    operator ()(StlVecType<T> &index_vec,
                DateTime &start_di,
                const DateTime &end_di,
                time_frequency t_freq,
                long increment) const  {

        switch(t_freq)  {
        case time_frequency::annual:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.date()));
                    start_di.add_years(increment);
                }
            }
            break;
        case time_frequency::monthly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.date()));
                    start_di.add_months(increment);
                }
            }
            break;
        case time_frequency::weekly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.date()));
                    start_di.add_days(increment * 7);
                }
            }
            break;
        case time_frequency::daily:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.date()));
                    start_di.add_days(increment);
                }
            }
            break;
        case time_frequency::hourly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.time()));
                    start_di.add_seconds(increment * 60 * 60);
                }
            }
            break;
        case time_frequency::minutely:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.time()));
                    start_di.add_seconds(increment * 60);
                }
            }
            break;
        case time_frequency::secondly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.time()));
                    start_di.add_seconds(increment);
                }
            }
            break;
        case time_frequency::millisecondly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(static_cast<T>(start_di.long_time()));
                    start_di.add_nanoseconds(increment * 1000000);
                }
            }
            break;
        default:
            break;
        }
    }
};

// ----------------------------------------------------------------------------

template<typename Dummy>
struct  GenerateTSIndex_<DateTime, Dummy>  {

    inline void
    operator ()(StlVecType<DateTime> &index_vec,
                DateTime &start_di,
                const DateTime &end_di,
                time_frequency t_freq,
                long increment) const  {

        switch(t_freq)  {
        case time_frequency::annual:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_years(increment);
                }
            }
            break;
        case time_frequency::monthly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_months(increment);
                }
            }
            break;
        case time_frequency::weekly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_days(increment * 7);
                }
            }
            break;
        case time_frequency::daily:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_days(increment);
                }
            }
            break;
        case time_frequency::hourly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_seconds(increment * 60 * 60);
                }
            }
            break;
        case time_frequency::minutely:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_seconds(increment * 60);
                }
            }
            break;
        case time_frequency::secondly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_seconds(increment);
                }
            }
            break;
        case time_frequency::millisecondly:
            {
                while (start_di < end_di)  {
                    index_vec.push_back(start_di);
                    start_di.add_nanoseconds(increment * 1000000);
                }
            }
            break;
        default:
            break;
        }
    }
};

// ----------------------------------------------------------------------------

template<typename T>
inline static void
get_mem_numbers_(const VectorView<T, align_value> &,
                 size_t &used_mem,
                 size_t &capacity_mem) {

    used_mem = sizeof(T *) * 2;
    capacity_mem = sizeof(T *) * 2;
}

// ----------------------------------------------------------------------------

template<typename T>
inline static void
get_mem_numbers_(const VectorPtrView<T, align_value> &container,
                 size_t &used_mem,
                 size_t &capacity_mem) {

    used_mem = container.size() * sizeof(T *);
    capacity_mem = container.capacity() * sizeof(T *);
}

// ----------------------------------------------------------------------------

template<typename T>
inline static void
get_mem_numbers_(const StlVecType<T> &container,
                 size_t &used_mem,
                 size_t &capacity_mem) {

    used_mem = container.size() * sizeof(T);
    capacity_mem = container.capacity() * sizeof(T);
}

// ----------------------------------------------------------------------------

template<typename MA>
inline CanonCorrResult<double>
canon_corr_imp_(const MA &X, const MA &Y) const  {

    using value_type = typename MA::data_t;
    using col_mat_t = Matrix<value_type, matrix_orient::column_major>;

    const auto  XY_cov { _calc_centered_cov_(X, Y) };
    const auto  X_cov { _calc_centered_cov_(X, X) };
    const auto  Y_cov { _calc_centered_cov_(Y, Y) };
    const auto  sq_root_mat {
        X_cov.inverse() * XY_cov * Y_cov.inverse() * XY_cov.transpose()
    };
    col_mat_t   U;
    col_mat_t   S;
    col_mat_t   V;

    sq_root_mat.svd(U, S, V, false);

    CanonCorrResult<value_type> result;

    // min(p, q) after relaxing the p==q constraint
    //
    const long  n_pairs { S.rows() };

    result.coeffs.reserve(n_pairs);
    for (long i { 0 }; i < n_pairs; ++i)
        result.coeffs.push_back(std::sqrt(S(i, 0)));

    // Canonical loadings for X
    // alpha_k  = X_cov_inv * U[:,k]
    // Var(u_k) = U[:,k]^T * X_cov_inv * U[:,k]
    // Lambda_X[j,k] = U[j,k] / (sqrt(X_cov[j,j]) * sqrt(Var(u_k)))
    //
    const auto  X_cov_inv { X_cov.inverse() };
    const auto  X_cov_inv_U { X_cov_inv * U };   // p x p
    col_mat_t   lambda_X { X_cov.rows(), n_pairs, 0 };

    for (long k { 0 }; k < n_pairs; ++k)  {
        value_type  var_uk { 0 };

        // U[:,k]^T * X_cov_inv * U[:,k]
        //
        for (long j { 0 }; j < X_cov.rows(); ++j)
            var_uk += U(j, k) * X_cov_inv_U(j, k);

        const value_type    denom_k { std::sqrt(var_uk) };

        for (long j { 0 }; j < X_cov.rows(); ++j)
            lambda_X(j, k) = U(j, k) / (std::sqrt(X_cov(j, j)) * denom_k);
    }

    // Canonical loadings for Y
    // Y side: decompose
    //     sq_root_mat_Y = Y_cov_inv * XY_cov^T * X_cov_inv * XY_cov
    // Its eigenvectors U_Y play the same role as U did for X.
    //
    const auto      Y_cov_inv { Y_cov.inverse() };
    const col_mat_t sq_root_Y {
        Y_cov_inv * XY_cov.transpose() * X_cov_inv * XY_cov
    };
    col_mat_t       U_Y, S_Y, V_Y;

    sq_root_Y.svd(U_Y, S_Y, V_Y, false);

    const col_mat_t Y_cov_inv_UY { Y_cov_inv * U_Y };   // q x q
    col_mat_t       lambda_Y { Y_cov.rows(), n_pairs, 0 };

    for (long k { 0 }; k < n_pairs; ++k)  {
        value_type  var_vk { 0 };

        for (long j { 0 }; j < Y_cov.rows(); ++j)
            var_vk += U_Y(j, k) * Y_cov_inv_UY(j, k);

        const value_type    denom_k { std::sqrt(var_vk) };

        for (long j { 0 }; j < Y_cov.rows(); ++j)
            lambda_Y(j, k) = U_Y(j, k) / (std::sqrt(Y_cov(j, j)) * denom_k);
    }

    // Stewart-Love redundancy indices
    // R_X|Y = sum_k( rho_k^2 * V_k^X )
    // where V_k^X = (1/p) * sum_j Lambda_X[j,k]^2
    // R_Y|X = sum_k( rho_k^2 * V_k^Y )
    // where V_k^Y = (1/q) * sum_j Lambda_Y[j,k]^2
    //
    const long  p { X_cov.rows() };
    const long  q { Y_cov.rows() };
    value_type  x_redun { 0 };
    value_type  y_redun { 0 };

    for (long k { 0 }; k < n_pairs; ++k)  {
        // S(k,0) = rho_k^2 from sq_root_mat SVD
        //
        const value_type    rho_sq { S(k, 0) };
        value_type          vx { 0 };

        for (long j { 0 }; j < p; ++j)
            vx += lambda_X(j, k) * lambda_X(j, k);

        value_type  vy { 0 };

        for (long j { 0 }; j < q; ++j)
            vy += lambda_Y(j, k) * lambda_Y(j, k);

        x_redun += rho_sq * (vx / value_type(p));
        y_redun += rho_sq * (vy / value_type(q));
    }
    result.x_red_idx = double(x_redun);
    result.y_red_idx = double(y_redun);

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T>
inline Matrix<T, matrix_orient::column_major>
get_scaled_data_matrix_(std::vector<const char *> &&col_names,
                        normalization_type norm_type) const  {

    const size_type                         col_num { col_names.size() };
    size_type                               min_col_s { indices_.size() };
    std::vector<const ColumnVecType<T> *>   columns(col_num, nullptr);
    SpinGuard                               guard { lock_ };

    for (size_type i { 0 }; i < col_num; ++i)  {
        columns[i] = &get_column<T>(col_names[i], false);
        if (columns[i]->size() < min_col_s)
            min_col_s = columns[i]->size();
    }
    guard.release();

    Matrix<T, matrix_orient::column_major>  data_mat {
        long(min_col_s), long(col_num)
    };
    auto                                    lbd =
        [norm_type, &data_mat, &columns = std::as_const(columns), this]
        (auto begin, auto end) -> void  {
            if (norm_type > normalization_type::none)  {
                NormalizeVisitor<T, I>  norm_v { norm_type };

                for (size_type c { begin }; c < end; ++c)  {
                    norm_v.pre();
                    norm_v(indices_.begin(), indices_.end(),
                           columns[c]->begin(), columns[c]->end());
                    norm_v.post();
                    data_mat.set_column(norm_v.get_result().begin(), c);
                }
            }
            else  {
                for (size_type c { begin }; c < end; ++c)
                    data_mat.set_column(columns[c]->begin(), c);
            }
        };
    const auto                              thread_level {
        (min_col_s >= ThreadPool::MUL_THR_THHOLD || col_num >= 20 )
            ? get_thread_level() : 0L
    };

    if (thread_level > 2)  {
        auto    futures {
            thr_pool_.parallel_loop<T>(size_type(0), col_num, std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  lbd(size_type(0), col_num);

    return (data_mat);
}

// ----------------------------------------------------------------------------

// It returns the first n entries (or all of them, if n is greater than the
// column length) of what permutation_vec(name, dir) would return. If n is
// small compared to the column, there is no need to sort the whole column. A
// partial sort is much faster (O(n log n) instead of O(n log n)), and the
// result is the same up to the order of equal values, which is not defined by
// sort() anyway.
//
template<comparable T>
StlVecType<size_type>
n_permutation_vec_(const char *name, sort_spec dir, size_type n) const  {

    const ColumnVecType<T>  *vec { nullptr };

    {
        const SpinGuard guard { lock_ };

        if (! ::strcmp(name, DF_INDEX_COL_NAME))
            vec = reinterpret_cast<const ColumnVecType<T> *>(&indices_);
        else
            vec = &(get_column<T>(name, false));
    }

    const size_type col_s { vec->size() };
    const size_type k { std::min(n, col_s) };

    // For a large n, the full (and possibly parallel) sort is as good or
    // better
    //
    if (k > (col_s / 32))  {
        const auto              full = permutation_vec<T>(name, dir);
        StlVecType<size_type>   result(std::min(k, full.size()));

        std::copy_n(full.begin(), result.size(), result.begin());
        return (result);
    }

    StlVecType<size_type>   result(col_s);
    auto                    part_sort =
        [&result, k](auto &&comp) -> void  {
            std::partial_sort(result.begin(), result.begin() + k,
                              result.end(), comp);
        };
    const auto              &v = *vec;

    std::iota(result.begin(), result.end(), 0);
    if (dir == sort_spec::ascen)
        part_sort([&v](size_type l, size_type r) { return (v[l] < v[r]); });
    else if (dir == sort_spec::desce)
        part_sort([&v](size_type l, size_type r) { return (v[l] > v[r]); });
    else if (dir == sort_spec::abs_ascen)
        part_sort([&v](size_type l, size_type r)  {
                      return (abs__(v[l]) < abs__(v[r]));
                  });
    else if (dir == sort_spec::abs_desce)
        part_sort([&v](size_type l, size_type r)  {
                      return (abs__(v[l]) > abs__(v[r]));
                  });

    result.resize(k);
    return (result);
}

// ----------------------------------------------------------------------------

// Local Variables:
// mode:C++
// tab-width:4
// c-basic-offset:4
// End:
