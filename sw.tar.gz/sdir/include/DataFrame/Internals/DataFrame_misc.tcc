// Hossein Moein
// September 12, 2017
/*
Copyright (c) 2019-2026, Hossein Moein
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
* Neither the name of Hossein Moein and/or the DataFrame nor the
  names of its contributors may be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Hossein Moein BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <DataFrame/DataFrame.h>
#include <DataFrame/Utils/PrettyPrint.h>

#include <type_traits>

// ----------------------------------------------------------------------------

namespace hmdf
{

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::consistent_functor_<Ts ...>::operator()(T &vec) const  {

    using ValueType =
        typename std::remove_reference<decltype(vec)>::type::value_type;

    vec.resize(size, ValueType());
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::shrink_to_fit_functor_<Ts ...>::operator()(T &vec) const  {

    using value_type = typename T::value_type;

    vec.shrink_to_fit();

    const size_type s = vec.capacity() * sizeof(value_type);

    if (s && ! (s & (s - 1)))  // Avoid cache line aliasing misses
        vec.reserve(vec.size() + 1);  // Knock it off the power of 2
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::remove_column_functor_<Ts ...>::operator()(T &) const  {

    using value_type = typename T::value_type;

    df.remove_column<value_type>(col_name);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T2>
void
DataFrame<I, H>::sort_functor_<Ts ...>::operator()(T2 &vec)  {

    // Gather: result[i] = vec[sorted_idxs[i]]. Random reads with sequential
    // writes, followed by a sequential copy back, is far more cache friendly
    // than following the permutation cycles in place (random reads AND random
    // writes). The column's buffer is deliberately kept (not swapped out), so
    // pointers, iterators and views into the column stay valid across sort().
    //
    T2  result(vec.get_allocator());

    result.reserve(idx_s);
    for (size_t i { 0 }; i < idx_s; ++i) [[likely]]  {
        auto    &&item { vec[sorted_idxs[i]] };

        if constexpr (std::is_same_v<typename T2::value_type, bool>)
            result.push_back(item);  // std::vector<bool> proxy reference
        else
            result.push_back(std::move_if_noexcept(item));
    }
    std::move(result.begin(), result.end(), vec.begin());
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename LHS, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::create_col_functor_<LHS, Ts ...>::operator()(const T &)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    df.template create_column<ValueType>(name, false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename LHS, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::load_functor_<LHS, Ts ...>::operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const auto  [col_begin, col_end] =
        _get_inclusive_indices_(vec, begin, end, incld_);

    df.template load_column<ValueType>(
        name,
        { vec.begin() + col_begin, vec.begin() + col_end },
        nan_p,
        false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename DF, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::load_all_functor_<DF, Ts ...>::operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    df.template load_column<ValueType>(name, { vec.begin(), vec.end() },
                                       nan_policy::pad_with_nans,
                                       false);
    return;
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::remove_functor_<Ts ...>::operator()(T &vec)  {

    vec.erase(vec.begin() + begin, vec.begin() + end);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::truncate_functor_<Ts ...>::operator()(T &vec)  {

    if (after < vec.size())
        vec.erase(vec.begin() + after, vec.end());
    if (before < vec.size())
        vec.erase(vec.begin(), vec.begin() + before);
    else  vec.clear();
}

// ----------------------------------------------------------------------------
template<typename I, typename H>
template<typename LHS, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::view_setup_functor_<LHS, Ts ...>::
operator()(T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    if (! vec.empty()) [[likely]]  {
        const auto  [col_begin, col_end] =
            _get_inclusive_indices_(vec, begin, end, incld_);

        dfv.template setup_view_column_<ValueType, typename VecType::iterator>(
            name,
            { vec.begin() + col_begin, vec.begin() + col_end });
    }
    else  {
        dfv.template setup_view_column_<ValueType, typename VecType::iterator>(
            name,
            { vec.begin(), vec.begin() });
    }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::add_col_functor_<Ts ...>::operator()(const T &)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    df.create_column<ValueType>(name, false);
    return;
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::print_csv_functor_<Ts ...>::operator()(const T &vec)  {

    if (vec.empty())  return;

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const long  vec_size { long(vec.size()) };
    const long  sr { long(std::min(start_row, vec_size)) };
    const long  er { long(std::min(end_row, vec_size)) };

    _write_csv_df_header_<std::ostream, ValueType>(os, name, er - sr) << ':';

    for (long i { sr }; i < er; ++i)
        _write_csv_df_index_(os, vec[i]) << delim;
    os << '\n';

    return;
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::print_binary_functor_<Ts ...>::operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    // Zero-filled, so the last byte written is never garbage
    //
    char    col_name[MAX_COL_NAME_SIZE] { };

    std::strncpy(col_name, name, sizeof(col_name) - 1);
    os.write(col_name, sizeof(col_name));

    const long  local_start_row { std::min (long(vec.size()), start_row) };
    const long  local_end_row { std::min (long(vec.size()), end_row) };

    if constexpr (std::is_same_v<ValueType, std::string> ||
                  std::is_same_v<ValueType, String8> ||
                  std::is_same_v<ValueType, String16> ||
                  std::is_same_v<ValueType, String32> ||
                  std::is_same_v<ValueType, String64> ||
                  std::is_same_v<ValueType, String128> ||
                  std::is_same_v<ValueType, String512> ||
                  std::is_same_v<ValueType, String1K> ||
                  std::is_same_v<ValueType, String2K>)
        _write_binary_string_(os, vec, local_start_row, local_end_row);
    else if constexpr (std::is_same_v<ValueType, DateTime>)
        _write_binary_datetime_(os, vec, local_start_row, local_end_row);
    else if constexpr (std::is_same_v<ValueType, std::vector<double>>)
        _write_binary_dbl_vec_(os, vec, local_start_row, local_end_row);
    else if constexpr (std::is_same_v<ValueType, std::vector<std::string>> ||
                       std::is_same_v<ValueType, std::vector<const char *>>)
        _write_binary_str_vec_(os, vec, local_start_row, local_end_row);
    else if constexpr (std::is_same_v<ValueType, std::set<double>>)
        _write_binary_dbl_set_(os, vec, local_start_row, local_end_row);
    else if constexpr (std::is_same_v<ValueType, std::set<std::string>> ||
                       std::is_same_v<ValueType, std::set<const char *>>)
        _write_binary_str_set_(os, vec, local_start_row, local_end_row);
    else if constexpr (
        std::is_same_v<ValueType, std::map<std::string, double>> ||
        std::is_same_v<ValueType, std::unordered_map<std::string, double>>)
        _write_binary_str_dbl_map_(os, vec, local_start_row, local_end_row);
    else if constexpr (
         std::is_same_v<ValueType, std::pair<std::string, double>>)
        _write_binary_str_dbl_pair_(os, vec, local_start_row, local_end_row);
    else if constexpr (
        std::is_same_v<ValueType, std::pair<std::string, std::string>>)
        _write_binary_str_str_pair_(os, vec, local_start_row, local_end_row);
    else if constexpr (
         std::is_same_v<ValueType, std::pair<double, double>>)
        _write_binary_dbl_dbl_pair_(os, vec, local_start_row, local_end_row);
    else
        _write_binary_data_(os, vec, local_start_row, local_end_row);

    return;
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::print_json_functor_<Ts ...>::operator()(const T &vec)  {

    if (vec.empty())  return;

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    if (need_pre_comma)
        os << ",\n";

    const long  vec_size { long(vec.size()) };
    const long  sr { long(std::min(start_row, vec_size)) };
    const long  er { long(std::min(end_row, vec_size)) };

    _write_json_df_header_<std::ostream, ValueType>(os, name, er - sr);

    os << "\"D\":[";
    if (er > sr)  {
        _write_json_df_index_(os, vec[sr]);
        for (long i { sr + 1 }; i < er; ++i)  {
            os << ',';
            _write_json_df_index_(os, vec[i]);
        }
    }
    os << "]}";

    return;
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename S, typename ... Ts>
template<typename T>
void DataFrame<I, H>::
print_csv2_header_functor_<S, Ts ...>::operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    if constexpr (std::same_as<ValueType, DateTime>)  {
        _write_csv_df_header_<S, ValueType>(
            os, name, std::min(col_size, long(vec.size())), dt_format);
    }
    else  {
        _write_csv_df_header_<S, ValueType>(
            os, name, std::min(col_size, long(vec.size())));
    }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename S, typename ... Ts>
template<typename T>
void DataFrame<I, H>::
print_csv2_data_functor_<S, Ts ...>::operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    if (vec.size() > index)  {
        if constexpr (std::same_as<ValueType, DateTime>)
            _write_csv_df_index_(os, vec[index], dt_format);
        else
            _write_csv_df_index_(os, vec[index]);
    }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
equal_functor_<Ts ...>::operator()(const T &lhs_vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const auto  &iter = df.column_tb_.find(name);

    if (iter == df.column_tb_.end()) [[unlikely]]  {
        result = false;
        return;
    }

    const DataVec   &hv = df.data_[iter->second];
    const T         &rhs_vec = hv.template get_vector<ValueType>();

    if (lhs_vec != rhs_vec)
        result = false;
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
mod_by_idx_functor_<Ts ...>::operator()(T &lhs_vec) const  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const auto  &iter { rhs_df.column_tb_.find(name) };

    if (iter != rhs_df.column_tb_.end())  {
        const ColumnVecType<ValueType>  &rhs_vec {
            rhs_df.get_column<ValueType>(name, false)
        };
        const size_type                 lhs_s { lhs_vec.size() };
        const size_type                 rhs_s { rhs_vec.size() };

        // The column lookup is done once per column, not once per row. A
        // column could be shorter than the index.
        //
        for (const auto &[lhs_i, rhs_i] : matches)  {
            if (lhs_i < lhs_s && rhs_i < rhs_s)
                lhs_vec[lhs_i] = rhs_vec[rhs_i];
        }
    }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename LHS, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
create_join_common_col_functor_<LHS, Ts ...>::operator()(const T &)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    char    lhs_str[256];
    char    rhs_str[256];

    ::snprintf(lhs_str, sizeof(lhs_str) - 1, "lhs.%s", name);
    ::snprintf(rhs_str, sizeof(rhs_str) - 1, "rhs.%s", name);
    df.template create_column<ValueType>(lhs_str, false);
    df.template create_column<ValueType>(rhs_str, false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename RES_T, typename RHS_T, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::index_join_functor_common_<RES_T, RHS_T, Ts ...>::
operator()(const T &lhs_vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const auto              &rhs_vec =
        rhs.template get_column<ValueType>(name);
    StlVecType<ValueType>   lhs_result_col;
    StlVecType<ValueType>   rhs_result_col;

    lhs_result_col.reserve(joined_index_idx.size());
    rhs_result_col.reserve(joined_index_idx.size());
    for (const auto &citer : joined_index_idx)  {
        const size_type left_i = std::get<0>(citer);
        const size_type right_i = std::get<1>(citer);

        lhs_result_col.push_back(
            left_i != std::numeric_limits<size_type>::max()
                ? lhs_vec[left_i] : get_nan<ValueType>());
        rhs_result_col.push_back(
            right_i != std::numeric_limits<size_type>::max()
                ? rhs_vec[right_i] : get_nan<ValueType>());
    }

    char    lhs_str[256];
    char    rhs_str[256];

    ::snprintf(lhs_str, sizeof(lhs_str) - 1, "lhs.%s", name);
    ::snprintf(rhs_str, sizeof(rhs_str) - 1, "rhs.%s", name);
    result.template load_column<ValueType>(lhs_str,
                                           std::move(lhs_result_col),
                                           nan_policy::pad_with_nans,
                                           false);
    result.template load_column<ValueType>(rhs_str,
                                           std::move(rhs_result_col),
                                           nan_policy::pad_with_nans,
                                           false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<int SIDE, typename RES_T, typename ... Ts>
template<typename T>
void DataFrame<I, H>::index_join_functor_oneside_<SIDE, RES_T, Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    StlVecType<ValueType>   result_col;

    result_col.reserve(joined_index_idx.size());
    for (const auto &citer : joined_index_idx)  {
        const size_type i = std::get<SIDE>(citer);

        result_col.push_back(
            i != std::numeric_limits<size_type>::max()
                ? vec[i] : get_nan<ValueType>());
    }

    result.template load_column<ValueType>(name,
                                           std::move(result_col),
                                           nan_policy::pad_with_nans,
                                           false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename IT, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
concat_load_view_functor_<IT, Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const size_type rhs_s { vec.size() };
    const bool      has_col { result.has_column(name) };

    if (has_col)  {
        auto            &result_vec {
            result.template get_column<ValueType>(name)
        };
        const size_type min_s {
            std::min(result_vec.size() + rhs_s, result.get_index().size())
        };
        size_type       count { result_vec.size() };

        result_vec.reserve(min_s);
        for (size_type i { 0 }; i < rhs_s && count < min_s; ++i, ++count)
            result_vec.push_back(const_cast<ValueType *>(&(vec[i])));
    }
    else  {
        T   &nc_vec { const_cast<T &>(vec) };

        result.template setup_view_column_<ValueType,
                                           typename VecType::iterator>(
            name, { nc_vec.begin(), nc_vec.end() });
    }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename RES_T, typename ... Ts>
template<typename T>
void DataFrame<I, H>::concat_functor_<RES_T, Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;
    using res_vec =
        typename
        std::remove_reference<RES_T>::type::template ColumnVecType<ValueType>;

    if (insert_col)  {
        StlVecType<ValueType>   res_vec(original_index_s + vec.size(),
                                        get_nan<ValueType>());

        std::copy(vec.begin(), vec.end(), res_vec.begin() + original_index_s);
        result.template load_column<ValueType>(name,
                                               std::move(res_vec),
                                               nan_policy::pad_with_nans,
                                               false);
    }
    else  {
        res_vec &res_vec { result.template get_column<ValueType>(name) };

        // If the column is shorter than the original index, pad it so the
        // appended values line up with the appended index rows.
        //
        if (res_vec.size() < original_index_s)
            res_vec.resize(original_index_s, get_nan<ValueType>());
        res_vec.insert(res_vec.end(), vec.begin(), vec.end());
    }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void DataFrame<I, H>::vertical_shift_functor_<Ts ...>::
operator()(T &vec) const  {

    if (sp == shift_policy::up)
        shift_left(vec, n);
    else
        shift_right(vec, n);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void DataFrame<I, H>::rotate_functor_<Ts ...>::
operator()(T &vec) const  {

    if (sp == shift_policy::up)  // Rotate left
        // There is no checking the value of n
        std::rotate(vec.begin(), vec.begin() + n, vec.end());
    else  // Rotate right
        // There is no checking the value of n
        std::rotate(vec.rbegin(), vec.rbegin() + n, vec.rend());
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename TST, template<typename> class OPT, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
operator_functor_<TST, OPT, Ts ...>::
operator()(const T &lhs_vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const auto  rhs_citer { rhs_df.column_tb_.find(col_name) };

    if (rhs_citer == rhs_df.column_tb_.end())  return;

    const DataVec           &rhs_hv { rhs_df.data_[rhs_citer->second] };
    const auto              &rhs_vec {
        rhs_hv.template get_vector<ValueType>()
    };
    const size_type         new_col_size {
        std::min(std::min(lhs_vec.size(), rhs_vec.size()), new_idx.size())
    };
    StlVecType<ValueType>   new_col;
    auto                    opt = OPT<ValueType>{ };
    size_type               lcounter { 0 };
    size_type               rcounter { 0 };

    new_col.reserve(new_col_size);
    for (size_type idx { 0 }; idx < new_col_size &&
                              lcounter < lhs_vec.size() &&
                              rcounter < rhs_vec.size(); )  {
        if (lhs_idx[lcounter] == rhs_idx[rcounter])  {
            new_col.push_back(opt(lhs_vec[lcounter], rhs_vec[rcounter]));
            lcounter += 1;
            rcounter += 1;
            idx += 1;
        }
        else if (lhs_idx[lcounter] > rhs_idx[rcounter])  {
            rcounter += 1;
        }
        else  {
            lcounter += 1;
        }

    }

    if (! new_col.empty())
        result_df.template load_column<ValueType>(col_name,
                                                  std::move(new_col),
                                                  nan_policy::pad_with_nans,
                                                  false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ST, template<typename> class OPT, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
scaler_operator_functor_<ST, OPT, Ts ...>::
operator()(const T &lhs_vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    auto    new_col = lhs_vec;;
    auto    opt = OPT<ValueType> { };

    for (auto &item : new_col)
        item = opt(item, static_cast<ValueType>(value));

    if (! new_col.empty())
        result_df.template load_column<ValueType>(col_name,
                                                  std::move(new_col),
                                                  nan_policy::pad_with_nans,
                                                  false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
map_missing_rows_functor_<Ts ...>::
operator()(const T &vec)  {

    const size_type vec_size = vec.size();

    for (size_type idx = 0; idx < index_rows; ++idx)  {
        if (idx >= vec_size || is_nan(vec[idx]))  {
            auto result = missing_row_map.emplace(idx, 0);

            result.first->second += 1;
        }
    }

}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
drop_missing_rows_functor_<Ts ...>::
operator()(T &vec)  {

    if (thread_level  > 2)
        futures.emplace_back(
            thr_pool_.dispatch(false,
                               &DataFrame::drop_missing_rows_<T>,
                               std::ref(vec),
                               std::cref(missing_row_map),
                               policy,
                               threshold,
                               col_num));
    else
        drop_missing_rows_(vec, missing_row_map, policy, threshold, col_num);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
get_row_functor_<Ts ...>::
operator()(const T &vec)  {

    result.template reserve<typename T::value_type>(1);
    if (row_num < vec.size())
        result.push_back(vec[row_num]);
    else
        result.push_back(get_nan<typename T::value_type>());
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename DF, typename IT, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
sel_load_functor_<DF, IT, Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    StlVecType<ValueType>   new_col;
    const size_type         vec_size = vec.size();

    new_col.reserve(std::min(sel_indices.size(), vec_size));
    for (auto citer : sel_indices) [[likely]]  {
        const size_type index =
            citer >= 0 ? citer : static_cast<IT>(indices_size) + citer;

        if (index < vec_size)
            new_col.push_back(vec[index]);
        else
            break;
    }

    df.template load_column<ValueType>(name,
                                       std::move(new_col),
                                       nan_policy::dont_pad_with_nans,
                                       false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename IT, typename DF, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
sel_load_view_functor_<IT, DF, Ts ...>::
operator()(T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;
    using ViewColType = typename DF::template ColumnVecType<ValueType>;

    ViewColType     new_col;
    const size_type vec_size = vec.size();

    new_col.reserve(std::min(sel_indices.size(), vec_size));
    for (auto citer : sel_indices) [[likely]]  {
        const size_type index =
            citer >= 0 ? citer : static_cast<IT>(indices_size) + citer;

        if (index < vec_size)
            new_col.push_back(&(vec[index]));
        else
            break;
    }

    using data_vec_t = typename DF::DataVec;

    dfv.data_.emplace_back(data_vec_t(std::move(new_col)));
    dfv.column_tb_.emplace (name, dfv.data_.size() - 1);
    dfv.column_list_.emplace_back (name, dfv.data_.size() - 1);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
sel_remove_functor_<Ts ...>::
operator()(T &vec) const  {

    if constexpr (std::is_base_of<HeteroVector<align_value>, H>::value)
        remove_sorted_positions_(vec, sel_indices);
    else  {
        const size_type sel_indices_s { sel_indices.size() };
        const size_type vec_s { vec.size() };
        size_type       del_count { 0 };

        for (size_type i { 0 }; i < sel_indices_s; ++i)  {
            if (sel_indices[i] < vec_s)
                vec.erase(sel_indices[i] - del_count++);
            else
                break;
        }
    }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
shuffle_functor_<Ts ...>::
operator()(T &vec) const  {

    std::shuffle(vec.begin(), vec.end(), g_);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename DF, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::
random_load_data_functor_<DF, Ts ...>::operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const size_type                                 vec_s { vec.size() };
    const size_type                                 n_rows {
        rand_indices.size()
    };
    typename DF::template ColumnVecType<ValueType>  new_vec;
    size_type                                       prev_value { 0 };

    new_vec.reserve(n_rows);
    for (size_type i { 0 }; i < n_rows; ++i) [[likely]]  {
        if (rand_indices[i] < vec_s)  {
            if (i == 0 || rand_indices[i] != prev_value)
                new_vec.push_back(vec[rand_indices[i]]);
            prev_value = rand_indices[i];
        }
        else
            break;
    }

    df.template load_column<ValueType>(name,
                                       std::move(new_vec),
                                       nan_policy::dont_pad_with_nans,
                                       false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename DF, typename ... Ts>
template<typename T>
void DataFrame<I, H>::
random_load_view_functor_<DF, Ts ...>::operator()(const T &vec) {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;
    using ViewType = typename DF::template ColumnVecType<ValueType>;

    const size_type vec_s { vec.size() };
    const size_type n_rows { rand_indices.size() };
    ViewType        new_vec;
    size_type       prev_value { 0 };

    new_vec.reserve(n_rows);
    for (size_type i { 0 }; i < n_rows; ++i) [[likely]]  {
        if (rand_indices[i] < vec_s)  {
            if (i == 0 || rand_indices[i] != prev_value)
                new_vec.push_back(
                    const_cast<ValueType *>(&(vec[rand_indices[i]])));
            prev_value = rand_indices[i];
        }
        else
            break;
    }

    using data_vec_t = typename DF::DataVec;

    dfv.data_.emplace_back(data_vec_t(std::move(new_vec)));
    dfv.column_tb_.emplace (name, dfv.data_.size() - 1);
    dfv.column_list_.emplace_back (name, dfv.data_.size() - 1);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::columns_info_functor_<Ts ...>::operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    result.emplace_back(name, vec.size(), std::type_index(typeid(ValueType)));
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename DF, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::copy_remove_functor_<DF, Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;
    using NewVecType = typename DF::template ColumnVecType<ValueType>;

    NewVecType  new_vec;

    const size_type vec_s { vec.size() };
    const size_type mask_s { del_mask.size() };

    // The column could be shorter than the index (and the delete count is
    // based on the index)
    //
    new_vec.reserve(vec_s > del_count ? vec_s - del_count : 0);
    for (size_type i { 0 }; i < vec_s; ++i)  {
        if (i >= mask_s || ! del_mask[i])
            new_vec.push_back(vec[i]);
    }

    df.template load_column<ValueType>(name,
                                       std::move(new_vec),
                                       nan_policy::dont_pad_with_nans,
                                       false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename DF, typename ... Ts>
template<typename T>
void
DataFrame<I, H>::fill_missing_functor_<DF, Ts ...>::operator()(T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    try  {
        const auto      &rhs_vec {
            rhs.template get_column<ValueType>(col_name, false)
        };
        const size_type col_s {
            std::min({ vec.size(),
                       rhs_vec.size(),
                       self_idx.size(),
                       rhs_idx.size() })
        };

        for (size_type i { 0 }; i < col_s; ++i)
            if (is_nan(vec[i]) && self_idx[i] == rhs_idx[i])
                vec[i] = rhs_vec[i];
    }
    catch (const ColNotFound &)  {   }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::describe_functor_<Ts ...>::operator()(const T &vec)  {

    const size_type vec_s { vec.size() };

    if (vec_s < 3)  return;

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    StlVecType<double>  col_to_load;

    col_to_load.reserve(describe_index_col.size());
    col_to_load.push_back(double(vec_s));

    size_type   missing_cnt { 0 };
    ValueType   minv { get_nan<ValueType>() };
    ValueType   maxv { get_nan<ValueType>() };
    double      sum { get_nan<double>() };
    bool        found_valid { false };

    for (size_type i { 0 }; i < vec_s; ++i)  {
        if (is_nan<ValueType>(vec[i]))
            missing_cnt += 1;
        else if (! found_valid)  {
            minv = maxv = vec[i];
            sum = double(vec[i]);
            found_valid = true;
        }
        else  {
            if (vec[i] > maxv)  maxv = vec[i];
            if (vec[i] < minv)  minv = vec[i];
            sum += double(vec[i]);
        }
    }
    col_to_load.push_back(double(missing_cnt));
    col_to_load.push_back(sum  / double(vec_s - missing_cnt));

    // The visitors are instantiated on double so that integral and float
    // columns are not accumulated (or interpolated) in their narrow type.
    //
    StdVisitor<double, double>  stdev;

    stdev.pre();
    stdev(vec.begin(), vec.end(), vec.begin(), vec.end());
    stdev.post();

    col_to_load.push_back(double(stdev.get_result()));
    col_to_load.push_back(double(minv));
    col_to_load.push_back(double(maxv));

    QuantileVisitor<double, double> qt25 { 0.25 };

    qt25.pre();
    qt25(vec.begin(), vec.end(), vec.begin(), vec.end());
    qt25.post();
    col_to_load.push_back(double(qt25.get_result()));

    QuantileVisitor<double, double> qt50 { 0.5 };

    qt50.pre();
    qt50(vec.begin(), vec.end(), vec.begin(), vec.end());
    qt50.post();
    col_to_load.push_back(double(qt50.get_result()));

    QuantileVisitor<double, double> qt75 { 0.75 };

    qt75.pre();
    qt75(vec.begin(), vec.end(), vec.begin(), vec.end());
    qt75.post();
    col_to_load.push_back(double(qt75.get_result()));

    result.template load_column<double>(name,
                                        std::move(col_to_load),
                                        nan_policy::pad_with_nans,
                                        false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::change_freq_functor_<Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;
    using NewVecType = ColumnVecType<ValueType>;

    const auto  &new_idx { res.get_index() };
    const auto  new_s { new_idx.size() };
    const auto  old_s { std::min(old_idx.size(), vec.size()) };
    NewVecType  new_vec(new_s, get_nan<ValueType>());
    size_type   i { 0 }, j { 0 };

    if (new_s >= old_s)  {  // Frequency has increased
        // Note: old_s is unsigned, so "old_s - 1" must not be used when old_s
        // could be zero. An empty column stays all NaN.
        //
        while (i < new_s && (j + 1) < old_s)  {
            if (new_idx[i] < old_idx[j + 1])
                new_vec[i] = vec[j];
            else
                new_vec[i] = vec[++j];
            i += 1;
        }
        if (old_s > 0)  {
            const ValueType &last = vec[old_s - 1];

            for ( ; i < new_s; ++i)
                new_vec[i] = last;
        }
    }
    else  {  // Frequency has decreased
        while (i < new_s && j < old_s)  {
            if (old_idx[j] == new_idx[i])
                new_vec[i++] = vec[j++];
            else if (old_idx[j] > new_idx[i])
                new_vec[i++] = vec[j++ - 1];
            else
                j += 1;
        }

        if (i < new_s)  {
            const ValueType &last = vec[old_s - 1];

            for ( ; i < new_s; ++i)
                new_vec[i] = last;
        }
    }


    res.template load_column<ValueType>(name,
                                        std::move(new_vec),
                                        nan_policy::dont_pad_with_nans,
                                        false);
}


// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::dup_mask_functor_<Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;
    using NewVecType = ColumnVecType<int>;

    using data_tuple = std::tuple<const ValueType &, const IndexType &>;
    using map_t = DFUnorderedMap<data_tuple, int, TupleHash>;

    const IndexType dummy_idx { };
    const auto      col_s = std::min(idx_vec.size(), vec.size());
    map_t           table;
    size_type       i { 0 };

    table.reserve(col_s);
    for (const auto &val : vec)  {
        const auto  insert_res =
            table.emplace(
                std::forward_as_tuple(val,
                                      incl_idx ? idx_vec[i++] : dummy_idx),
                0);

        insert_res.first->second += 1;
    }

    NewVecType  new_vec;

    new_vec.reserve(col_s);
    i = 0;
    if (! binary)  {
        for (const auto &val : vec)  {
            const auto  find_res =
                table.find(std::make_tuple(
                    val, incl_idx ? idx_vec[i++] : dummy_idx));

            if (find_res != table.end())
                new_vec.push_back(find_res->second);
        }
    }
    else  {
        for (const auto &val : vec)  {
            const auto  find_res =
                table.find(std::make_tuple(
                    val, incl_idx ? idx_vec[i++] : dummy_idx));

            if (find_res != table.end())
                new_vec.push_back(find_res->second == 1 ? 0 : 1);
        }
    }

    res.template load_column<int>(name,
                                  std::move(new_vec),
                                  nan_policy::dont_pad_with_nans,
                                  false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::explode_functor_<Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const size_type total_cnt { idx_mask.size() };
    const size_type vec_sz { vec.size() };
    VecType         new_col(total_cnt);

    for (size_type i { 0 }; i < total_cnt; ++i)  {
        const auto  idx { idx_mask[i] };
        
        if (idx < vec_sz) [[likely]]  new_col[i] = vec[idx_mask[i]];
    }

    res.template load_column<ValueType>(name,
                                        std::move(new_col),
                                        nan_policy::dont_pad_with_nans,
                                        false);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::difference_functor_<Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    try  {
        const auto      &other_vec {
            other.template get_column<ValueType>(name, false)
        };
        const size_type col_s { std::min(vec.size(), other_vec.size()) };
        size_type       last_idx { 0 };
        size_type       i { 0 };
        VecType         self_new_col;
        VecType         other_new_col;

        self_new_col.reserve(vec.size() / 3);
        other_new_col.reserve(other_vec.size() / 3);
        for ( ; i < col_s; ++i) [[likely]]  {
            if (vec[i] != other_vec[i])  {
                for ( ; last_idx < i; ++last_idx)  {
                    self_new_col.push_back(get_nan<ValueType>());
                    other_new_col.push_back(get_nan<ValueType>());
                    idx_set.insert(last_idx);
                }
                last_idx += 1;
                self_new_col.push_back(vec[i]);
                other_new_col.push_back(other_vec[i]);
                idx_set.insert(i);
            }
        }

        // The two columns could be of different lengths. The extra rows of
        // the longer one (the tail) must stay aligned with the rows they
        // belong to. So, the equal rows between the last difference and the
        // tail must be padded first, the same way the equal rows between
        // two differences are padded above.
        //
        if (vec.size() > col_s || other_vec.size() > col_s)  {
            for ( ; last_idx < col_s; ++last_idx)  {
                if (vec.size() > col_s)
                    self_new_col.push_back(get_nan<ValueType>());
                if (other_vec.size() > col_s)
                    other_new_col.push_back(get_nan<ValueType>());
                idx_set.insert(last_idx);
            }
        }
        for (size_type j { i }; j < vec.size(); ++j) [[unlikely]]  {
            self_new_col.push_back(vec[j]);
            idx_set.insert(j);
        }
        for (size_type j { i }; j < other_vec.size(); ++j) [[unlikely]]  {
            other_new_col.push_back(other_vec[j]);
            idx_set.insert(j);
        }

        ColNameType self_name { "self_" };
        ColNameType other_name { "other_" };

        self_name += name;
        other_name += name;

        if (self_new_col.size() > 0 || other_new_col.size() > 0)  {
            res.template load_column_<ValueType>(
                self_name.c_str(),
                std::move(self_new_col),
                nan_policy::dont_pad_with_nans,
                false);
            res.template load_column_<ValueType>(
                other_name.c_str(),
                std::move(other_new_col),
                nan_policy::dont_pad_with_nans,
                false);
        }
    }
    catch (const ColNotFound &)  {   }
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename ... Ts>
template<typename T>
void
DataFrame<I, H>::stringfy_functor_<Ts ...>::
operator()(const T &vec)  {

    using VecType = typename std::remove_reference<T>::type;
    using ValueType = typename VecType::value_type;

    const long  sr = std::min(start_row, long(vec.size()));
    const long  er = std::min(end_row, long(vec.size()));

    names.push_back(name);
    vvec.push_back(_stringfy_(vec, dt_format, sr, er, precision));
    is_numeric.push_back(std::is_arithmetic_v<ValueType>);
}

// ----------------------------------------------------------------------------

template<typename I, typename H>
template<typename T>
void DataFrame<I, H>::gather_vecs_functor_<T>::
operator()(const ColumnVecType<T> &vec)  {

    if (max_rows < vec.size())  max_rows = vec.size();
    vecs.push_back(&vec);
}

} // namespace hmdf

// ----------------------------------------------------------------------------

// Local Variables:
// mode:C++
// tab-width:4
// c-basic-offset:4
// End:
