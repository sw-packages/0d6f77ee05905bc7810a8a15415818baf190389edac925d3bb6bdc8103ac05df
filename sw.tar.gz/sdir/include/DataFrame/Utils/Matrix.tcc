// Hossein Moein
// August 9, 2023
/*
Copyright (c) 2023-2028, Hossein Moein
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
* Neither the name of Hossein Moein and/or the DataFrame nor the
  names of its contributors may be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Hossein Moein BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunknown-pragmas"
#pragma warning( disable : 4068 )
#pragma clang diagnostic ignored "-Wunknown-pragmas"

#include <DataFrame/RandGen.h>
#include <DataFrame/Utils/Matrix.h>

#include <cassert>
#include <cmath>
#include <cstdlib>
#include <ranges>

// ----------------------------------------------------------------------------

namespace hmdf
{

// Forward elimination with partial pivoting. Only the first pivot_cols
// columns are searched for pivots, but every column takes part in the row
// operations (so any columns to the right of pivot_cols, i.e. an augmented
// right-hand side, ride along). Each pivot row is scaled to have a leading 1.
// It returns the number of pivots found (the rank of the pivot-column block).
// A pivot whose absolute value is <= tol is treated as zero.
//
template<typename M>
static inline typename M::size_type
_echelon_(M &m, typename M::size_type pivot_cols,
          typename M::value_type tol) noexcept  {

    using size_type = typename M::size_type;
    using value_type = typename M::value_type;

    size_type   rank { 0 };

    for (size_type c { 0 }; c < pivot_cols && rank < m.rows(); ++c)  {
        size_type   max_row { rank };
        value_type  max_val { value_type(std::abs(m(rank, c))) };

        for (size_type r { rank + 1 }; r < m.rows(); ++r)  {
            const value_type    tmp { value_type(std::abs(m(r, c))) };

            if (tmp > max_val)  { max_val = tmp; max_row = r; }
        }

        if (max_val <= tol)  {
            for (size_type r { rank }; r < m.rows(); ++r)  m(r, c) = 0;
            continue;
        }

        if (max_row != rank)  {
            for (size_type cc { c }; cc < m.cols(); ++cc)
                std::swap(m(rank, cc), m(max_row, cc));
        }

        const value_type    diag { m(rank, c) };

        for (size_type cc { c }; cc < m.cols(); ++cc)  m(rank, cc) /= diag;
        m(rank, c) = 1;

        for (size_type r { rank + 1 }; r < m.rows(); ++r)  {
            const value_type    f { m(r, c) };

            if (f != value_type(0))  {
                for (size_type cc { c + 1 }; cc < m.cols(); ++cc)
                    m(r, cc) -= f * m(rank, cc);
                m(r, c) = 0;
            }
        }
        rank += 1;
    }

    return (rank);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::
Matrix(size_type rows, size_type cols, const_reference def_v)
    : rows_(rows),
      cols_(cols),
      matrix_((! IS_SYM) ? rows * cols : (cols * (cols + 1L)) / 2L, def_v)  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if constexpr (IS_SYM)  {
        if (cols != rows)
            throw DataFrameError(
                "Matrix::Matrix(): Symmetric matrix must be square");
    }
#endif // HMDF_SANITY_EXCEPTIONS
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename M2>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::operator =(const M2 &lhs)  {

    rows_ = lhs.rows();
    cols_ = lhs.cols();

    // A symmetric matrix stores only one triangle, n * (n + 1) / 2 elements.
    //
    const size_type msize {
        IS_SYM ? (cols_ * (cols_ + 1L)) / 2L : rows_ * cols_
    };

    if (msize != size_type(matrix_.size()))
        matrix_.resize(msize);

    if constexpr (MO == matrix_orient::column_major)  {
        for (size_type c { 0 }; c < cols_; ++c)
            for (size_type r { 0 }; r < rows_; ++r)
                at(r, c) = lhs(r, c);
    }
    else  {
        for (size_type r { 0 }; r < rows_; ++r)
            for (size_type c { 0 }; c < cols_; ++c)
                at(r, c) = lhs(r, c);
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
void
Matrix<T, MO, IS_SYM>::clear() noexcept  {

    rows_ = cols_ = 0;
    matrix_.clear();
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
void
Matrix<T, MO, IS_SYM>::swap(Matrix &rhs) noexcept  {

    std::swap(rows_, rhs.rows_);
    std::swap(cols_, rhs.cols_);
    matrix_.swap(rhs.matrix_);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
bool
Matrix<T, MO, IS_SYM>::empty() const noexcept  {

    return (rows_ == 0 && cols_ == 0);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
void
Matrix<T, MO, IS_SYM>::reserve(size_type rows, size_type cols)  {

    if constexpr (IS_SYM)  {
#ifdef HMDF_SANITY_EXCEPTIONS
        if (cols != rows)
            throw DataFrameError(
                "Matrix::reserve(): Symmetric matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS
        matrix_.reserve((cols * (cols + 1L)) / 2L);
    }
    else  {
        matrix_.reserve(rows * cols);
    }
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::size_type
Matrix<T, MO, IS_SYM>::rows() const noexcept  { return (rows_); }

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::size_type
Matrix<T, MO, IS_SYM>::cols() const noexcept  { return (cols_); }

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
void Matrix<T, MO, IS_SYM>::
resize(size_type rows, size_type cols, const_reference def_v) {

    if constexpr (IS_SYM)  {
#ifdef HMDF_SANITY_EXCEPTIONS
        if (cols != rows)
            throw DataFrameError(
                "Matrix::resize(): Symmetric matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS
        matrix_.resize((cols * (cols + 1L)) / 2L, def_v);
    }
    else
        matrix_.resize(rows * cols, def_v);
    rows_ = rows;
    cols_ = cols;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::reference
Matrix<T, MO, IS_SYM>::at(size_type row, size_type col)  {

    if constexpr (IS_SYM)  {
        if constexpr (MO == matrix_orient::column_major)  {
            if (row > col)  std::swap(row, col);
            return (matrix_[(row * cols_) + col - ((row * (row + 1)) >> 1)]);
        }
        else  {
            if (col > row)  std::swap(row, col);
            return (matrix_[(col * rows_) + row - ((col * (col + 1)) >> 1)]);
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            return (matrix_[col * rows_ + row]);
        else
            return (matrix_[row * cols_ + col]);
    }
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::const_reference
Matrix<T, MO, IS_SYM>::at(size_type row, size_type col) const  {

    if constexpr (IS_SYM)  {
        if constexpr (MO == matrix_orient::column_major)  {
            if (row > col)  std::swap(row, col);
            return (matrix_[(row * cols_) + col - ((row * (row + 1)) >> 1)]);
        }
        else  {
            if (col > row)  std::swap(row, col);
            return (matrix_[(col * rows_) + row - ((col * (col + 1)) >> 1)]);
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            return (matrix_[col * rows_ + row]);
        else
            return (matrix_[row * cols_ + col]);
    }
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
bool
Matrix<T, MO, IS_SYM>::is_square() const noexcept  {

    return (rows() == cols());
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
bool
Matrix<T, MO, IS_SYM>::is_symmetric() const noexcept  {

    if constexpr (IS_SYM)  return (true);
    if (! is_square())  return (false);

    for (size_type r { 1 }; r < rows(); ++r)
        for (size_type c { 0 }; c < r; ++c)
            if (at(r, c) != at(c, r))
                return (false);

    return (true);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::reference
Matrix<T, MO, IS_SYM>::operator()(size_type row, size_type col)  {

    return (at(row, col));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::const_reference
Matrix<T, MO, IS_SYM>::operator()(size_type row, size_type col) const  {

    return (at(row, col));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::reference
Matrix<T, MO, IS_SYM>::operator[](size_type row, size_type col)  {

    return (at(row, col));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::const_reference
Matrix<T, MO, IS_SYM>::operator[](size_type row, size_type col) const  {

    return (at(row, col));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>
Matrix<T, MO, IS_SYM>::corner(size_type nrows, size_type ncols) const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (rows() < nrows || cols() < ncols)
        throw NotFeasible("Matrix::corner(): nrows or ncols is out of bounds");
#endif // HMDF_SANITY_EXCEPTIONS

    Matrix result { nrows, ncols };

    if constexpr (IS_SYM)  {
        if constexpr (MO == matrix_orient::column_major)  {
            for (size_type c { 0 }; c < ncols; ++c)
                for (size_type r { c }; r < nrows; ++r)
                    result(r, c) = at(r, c);
        }
        else  {
            for (size_type r { 0 }; r < nrows; ++r)
                for (size_type c { r }; c < ncols; ++c)
                    result(r, c) = at(r, c);
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)  {
            for (size_type c { 0 }; c < ncols; ++c)
                for (size_type r { 0 }; r < nrows; ++r)
                    result(r, c) = at(r, c);
        }
        else  {
            for (size_type r { 0 }; r < nrows; ++r)
                for (size_type c { 0 }; c < ncols; ++c)
                    result(r, c) = at(r, c);
        }
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename I>
void
Matrix<T, MO, IS_SYM>::set_column(I col_data, size_type col)  {

    for (size_type r { 0 }; r < rows(); ++r)
        at(r, col) = *col_data++;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename I>
void
Matrix<T, MO, IS_SYM>::set_row(I row_data, size_type row)  {

    for (size_type c { 0 }; c < cols(); ++c)
        at(row, c) = *row_data++;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
std::vector<T>
Matrix<T, MO, IS_SYM>::get_column_vec(size_type col) const noexcept  {

    std::vector<value_type> result;

    if constexpr (MO == matrix_orient::column_major && (! IS_SYM))  {
        result.insert(result.begin(), &(at(0, col)), (&(at(0, col))) + rows());
    }
    else  {
        result.resize(rows());
        for (size_type r { 0 }; r < rows(); ++r)
            result[r] = at(r, col);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
std::vector<T>
Matrix<T, MO, IS_SYM>::get_row_vec(size_type row) const noexcept  {

    std::vector<value_type> result;

    if constexpr (MO == matrix_orient::row_major && (! IS_SYM))  {
        result.insert(result.begin(), &(at(row, 0)), (&(at(row, 0))) + cols());
    }
    else  {
        result.resize(cols());
        for (size_type c { 0 }; c < cols(); ++c)
            result[c] = at(row, c);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
typename Matrix<T, MO, IS_SYM>::non_sym_ma_t
Matrix<T, MO, IS_SYM>::get_column_mat(size_type col) const noexcept  {

    non_sym_ma_t    result { rows(), 1 };

    for (size_type r { 0 }; r < rows(); ++r)
        result(r, 0) = at(r, col);

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
typename Matrix<T, MO, IS_SYM>::non_sym_ma_t
Matrix<T, MO, IS_SYM>::get_row_mat(size_type row) const noexcept  {

    non_sym_ma_t    result { 1, cols() };

    for (size_type c { 0 }; c < cols(); ++c)
        result(0, c) = at(row, c);

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
constexpr matrix_orient
Matrix<T, MO, IS_SYM>::orientation()  { return (MO); }

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::trans_result_t
Matrix<T, MO, IS_SYM>::transpose() const noexcept  {

    trans_result_t  result { cols(), rows() };

    if constexpr (IS_SYM)  {
        if constexpr (MO == matrix_orient::column_major)  {
            for (size_type c { 0 }; c < cols(); ++c)
                for (size_type r { c }; r < rows(); ++r)
                    result[r, c] = at(r, c);
        }
        else  {
            for (size_type r { 0 }; r < rows(); ++r)
                for (size_type c { r }; c < cols(); ++c)
                    result[r, c] = at(r, c);
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)  {
            for (size_type c { 0 }; c < cols(); ++c)
                for (size_type r { 0 }; r < rows(); ++r)
                    result[c, r] = at(r, c);
        }
        else  {
            for (size_type r { 0 }; r < rows(); ++r)
                for (size_type c { 0 }; c < cols(); ++c)
                    result[c, r] = at(r, c);
        }
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>
Matrix<T, MO, IS_SYM>::transpose2() const noexcept  {

    Matrix  result { cols(), rows() };

    if constexpr (IS_SYM)  {
        result = *this;
    }
    else  {
        // Blocked/tiled transpose: whichever side of at()/result[] isn't
        // naturally sequential for this orientation gets a stride equal to
        // a full row/column, which is a cache miss on nearly every element
        // for any matrix bigger than cache. Processing in small blocks
        // means both the source and destination sub-regions for a whole
        // block stay cache-resident while it's processed, so the cost of
        // that stride is paid roughly once per block instead of once per
        // element.
        //
        constexpr size_type block_size { 32 };

        if constexpr (MO == matrix_orient::column_major)  {
            for (size_type cb { 0 }; cb < cols(); cb += block_size)  {
                const size_type c_end { std::min(cb + block_size, cols()) };

                for (size_type rb { 0 }; rb < rows(); rb += block_size)  {
                    const size_type r_end { std::min(rb + block_size, rows()) };

                    for (size_type c { cb }; c < c_end; ++c)
                        for (size_type r { rb }; r < r_end; ++r)
                            result[c, r] = at(r, c);
                }
            }
        }
        else  {
            for (size_type rb { 0 }; rb < rows(); rb += block_size)  {
                const size_type r_end { std::min(rb + block_size, rows()) };

                for (size_type cb { 0 }; cb < cols(); cb += block_size)  {
                    const size_type c_end { std::min(cb + block_size, cols()) };

                    for (size_type r { rb }; r < r_end; ++r)
                        for (size_type c { cb }; c < c_end; ++c)
                            result[c, r] = at(r, c);
                }
            }
        }
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline void Matrix<T, MO, IS_SYM>::zero_out_(value_type &val) const  {

    if (empty())  return;

    if constexpr (! IS_MD)  val = 0;
    else  {
        if constexpr (resizable_)
            val.resize(at(0, 0).size(), 0);
        else
            val.fill(0);
    }
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM>::size_type Matrix<T, MO, IS_SYM>::
ppivot_(size_type pivot_row,
        size_type self_rows,
        size_type self_cols) noexcept  {

    size_type   max_row { pivot_row };
    value_type  max_value { value_type(std::abs(at(pivot_row, pivot_row))) };

    for (size_type r { pivot_row + 1 }; r < self_rows; ++r)  {
        const value_type    tmp { value_type(std::abs(at(r, pivot_row))) };

        if (tmp > max_value && tmp != value_type(0))  {
            max_value = tmp;
            max_row = r;
        }
    }

    if (at(max_row, pivot_row) == value_type(0))
        return (NOPOS_);

    if (max_row != pivot_row)  {
        for (size_type c { 0 }; c < self_cols; ++c)
            std::swap(at(pivot_row, c), at(max_row, c));
        return (max_row);
    }

    return (0);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>
Matrix<T, MO, IS_SYM>::inverse() const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (rows() != cols())
        throw NotFeasible("Matrix::inverse(): Matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS

    if constexpr (IS_SYM)  {
        // The elimination below applies row operations, which do not
        // preserve symmetry. On packed symmetric storage (r, c) and (c, r)
        // are the same element, so work on a general copy instead.
        //
        non_sym_ma_t    dense { rows(), cols() };

        for (size_type c { 0 }; c < cols(); ++c)
            for (size_type r { 0 }; r < rows(); ++r)
                dense(r, c) = at(r, c);

        const auto  inv { dense.inverse() };
        Matrix      sym_result { rows(), cols() };

        for (size_type c { 0 }; c < cols(); ++c)
            for (size_type r { c }; r < rows(); ++r)
                sym_result(r, c) = inv(r, c);
        return (sym_result);
    }

    const size_type self_rows { rows() };
    const size_type self_cols { cols() };
    Matrix          aux_mat { *this };
    Matrix          result { self_rows, self_cols, 0 };

    // First make identity matrix
    //
    for (size_type d { 0 }; d < self_cols; ++d)
        result.at(d, d) = value_type(1);

    for (size_type r { 0 }; r < self_rows; ++r)  {
        const size_type idx { aux_mat.ppivot_(r, self_rows, self_cols) };

        if (idx == NOPOS_)
            throw NotFeasible("Matrix::inverse(): Singular matrix");

        if (idx != 0)
            for (size_type c { 0 }; c < self_cols; ++c)
                std::swap(result.at(r, c), result.at(idx, c));

        const value_type    diag { aux_mat.at(r, r) };

        // Columns 0 .. r - 1 of aux_mat are already eliminated (zero), so
        // only columns r .. n - 1 of it need to be touched.
        //
        for (size_type c { r }; c < self_cols; ++c)
            aux_mat.at(r, c) /= diag;
        for (size_type c { 0 }; c < self_cols; ++c)
            result.at(r, c) /= diag;

        for (size_type r2 { 0 }; r2 < self_rows; ++r2)  {
            if (r2 != r)  {
                const value_type    off_diag { aux_mat.at(r2, r) };

                if (off_diag == value_type(0))  continue;

                for (size_type c { r }; c < self_cols; ++c)
                    aux_mat.at(r2, c) -= off_diag * aux_mat.at(r, c);
                for (size_type c { 0 }; c < self_cols; ++c)
                    result.at(r2, c) -= off_diag * result.at(r, c);
            }
        }
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::self_scale(value_type factor) noexcept  {

    const size_type msize { size_type(matrix_.size()) };
    const long      thread_level {
        (msize >= 500L) ? ThreadGranularity::get_thread_level() : 0
    };
    auto            lbd =
        [factor, this]
        (auto begin, auto end) -> void  {
            for (size_type i { begin }; i < end; ++i)
                matrix_[i] *= factor;
        };

    if (thread_level > 2)  {
        auto    futures {
            ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                0L, msize, std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, msize);
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM>
Matrix<T, MO, IS_SYM>::scale(value_type factor) const noexcept  {

    Matrix  result { *this };

    result.self_scale(factor);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM> &Matrix<T, MO, IS_SYM>::
self_apply(std::function<value_type (const value_type &)> &&fn)  {

    for (auto &val : matrix_)  val = fn(val);
    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM> Matrix<T, MO, IS_SYM>::
apply(std::function<value_type (const value_type &)> &&fn) const  {

    using func_t = std::function<value_type (const value_type &)>;

    Matrix  result { *this };

    result.self_apply(std::forward<func_t>(fn));
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::rref(size_type &rank) noexcept  {

    // Reduced row echelon form. Pivots are searched for in every column
    // (a column that has no pivot is skipped, it does not end the process),
    // and entries above as well as below each leading 1 are eliminated.
    // A pivot is treated as zero when it is not larger than
    // norm_inf(A) * eps * min(1e6, 1 / sqrt(eps)) (about 2e-10 relative for
    // double). Elimination with partial pivoting leaves round-off residue in
    // rows that are dependent, which can exceed the tighter
    // eps * max(rows, cols) * norm_inf(A) that suits SVD based ranks.
    //
    value_type  scale { 0 };   // The infinity norm, max row sum of |a_ij|

    for (size_type r { 0 }; r < rows(); ++r)  {
        value_type  row_sum { 0 };

        for (size_type c { 0 }; c < cols(); ++c)
            row_sum += value_type(std::abs(at(r, c)));
        scale = std::max(scale, row_sum);
    }

    constexpr value_type    eps { std::numeric_limits<value_type>::epsilon() };
    const value_type        tol {
        scale * eps * std::min(value_type(1e6), value_type(1) / std::sqrt(eps))
    };

    rank = 0;
    for (size_type c { 0 }; c < cols() && rank < rows(); ++c)  {
        size_type   max_row { rank };
        value_type  max_val { value_type(std::abs(at(rank, c))) };

        for (size_type r { rank + 1 }; r < rows(); ++r)  {
            const value_type    tmp { value_type(std::abs(at(r, c))) };

            if (tmp > max_val)  { max_val = tmp; max_row = r; }
        }

        if (max_val <= tol)  {
            for (size_type r { rank }; r < rows(); ++r)  at(r, c) = 0;
            continue;
        }

        if (max_row != rank)
            for (size_type cc { c }; cc < cols(); ++cc)
                std::swap(at(rank, cc), at(max_row, cc));

        const value_type    diag { at(rank, c) };

        for (size_type cc { c }; cc < cols(); ++cc)  at(rank, cc) /= diag;
        at(rank, c) = 1;

        for (size_type r { 0 }; r < rows(); ++r)  {
            if (r == rank)  continue;

            const value_type    f { at(r, c) };

            if (f != value_type(0))  {
                for (size_type cc { c + 1 }; cc < cols(); ++cc)
                    at(r, cc) -= f * at(rank, cc);
                at(r, c) = 0;
            }
        }
        rank += 1;
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::rref(Matrix &that, size_type &rank) const noexcept  {

    that = *this;
    return (that.rref(rank));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::value_type
Matrix<T, MO, IS_SYM>::norm() const noexcept  {

    auto        lbd = [this](auto begin, auto end) -> value_type  {
        value_type  result { 0 };

        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { c + 1 }; r < rows(); ++r)  {
                        const auto  val { at(r, c) };

                        result += val * val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { r + 1 }; c < cols(); ++c)  {
                        const auto  val { at(r, c) };

                        result += val * val;
                    }
                }
            }

            result *= T(2);
            for (size_type c { begin }; c < end; ++c)  {
                const auto  val { at(c, c) };

                result += val * val;
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { 0 }; r < rows(); ++r)  {
                        const auto  val { at(r, c) };

                        result += val * val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { 0 }; c < cols(); ++c)  {
                        const auto  val { at(r, c) };

                        result += val * val;
                    }
                }
            }
        }
        return (result);
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };
    value_type  result { 0 };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  result += fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  result += fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            result = lbd(0L, cols());
        else
            result = lbd(0L, rows());
    }

    return (std::sqrt(result));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::value_type
Matrix<T, MO, IS_SYM>::mean() const noexcept  {

    auto        lbd = [this](auto begin, auto end) -> value_type  {
        value_type  result { 0 };

        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { c + 1 }; r < rows(); ++r)
                        result += at(r, c);
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { r + 1 }; c < cols(); ++c)
                        result += at(r, c);
            }

            result *= T(2);
            for (size_type c { begin }; c < end; ++c)
                result += at(c, c);
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { 0 }; r < rows(); ++r)
                        result += at(r, c);
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { 0 }; c < cols(); ++c)
                        result += at(r, c);
            }
        }
        return (result);
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };
    value_type  result { 0 };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  result += fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  result += fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            result = lbd(0L, cols());
        else
            result = lbd(0L, rows());
    }

    return (result / value_type(rows() * cols()));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>
Matrix<T, MO, IS_SYM>::degree_matrix() const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (rows() != cols())
        throw NotFeasible("Matrix::degree_matrix(): Matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS

    Matrix  result { cols(), cols(), T(0) };

    for (size_type r { 0 }; r < rows(); ++r)  {
        value_type  connections { 0 };

        for (size_type c { 0 }; c < cols(); ++c)
            connections += at(r, c);
        result[r, r] = connections;
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>
Matrix<T, MO, IS_SYM>::laplacian_matrix() const  {

    return (degree_matrix() - *this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA1, typename MA2>
void Matrix<T, MO, IS_SYM>::
red_to_hessenberg_(MA1 &e_vecs, MA2 &hess_form) noexcept  {

    Matrix<T, matrix_orient::row_major> ortho { 1, e_vecs.cols() };

    for (size_type c { 1 }; c <= e_vecs.cols() - 2; ++c)  {
        value_type  scale { 0 };

        // Scale column.
        //
        for (size_type r { c }; r <= e_vecs.rows() - 1; ++r)
            scale += std::abs(hess_form[r, c - 1]);

        if (scale != T(0))  {
            value_type  h { 0 };

            // Compute Householder transformation.
            //
            for (size_type cc { e_vecs.cols() - 1 }; cc >= c; --cc)  {
                const auto  val { hess_form[cc, c - 1] / scale };

                ortho[0, cc] = val;
                h += val * val;
            }

            const value_type    g {
                ortho[0, c] > T(0) ? -std::sqrt(h) : std::sqrt(h)
            };

            h -= ortho[0, c] * g;
            ortho[0, c] -= g;

            // Apply Householder similarity transformation
            // H = (I - u * u' / h) * H * (I - u * u') / h)
            //
            for (size_type cc { c }; cc < e_vecs.cols(); ++cc)  {
                value_type  f { 0 };

                for (size_type r { e_vecs.rows() - 1 }; r >= c; --r)
                    f += ortho[0, r] * hess_form[r, cc];
                f /= h;

                for (size_type r { c }; r <= e_vecs.rows() - 1; ++r)
                    hess_form[r, cc] -= f * ortho[0, r];
            }

            for (size_type r { 0 }; r <= e_vecs.rows() - 1; ++r)  {
                value_type  f { 0 };

                for (size_type cc { e_vecs.cols() - 1 }; cc >= c; --cc)
                    f += ortho[0, cc] * hess_form[r, cc];
                f /= h;

                for (size_type cc { c }; cc <= e_vecs.cols() - 1; ++cc)
                    hess_form[r, cc] -= f * ortho[0, cc];
            }

            ortho[0, c] *= scale;
            hess_form[c, c - 1] = scale * g;
        }
    }

    // Accumulate transformations (Algol's ortran).
    //
    for (size_type r { 0 }; r < e_vecs.rows(); ++r)
        for (size_type c { 0 }; c < e_vecs.cols(); ++c)
            e_vecs[r, c] = r == c ? T(1) : T(0);

    for (size_type c { e_vecs.cols() - 2 }; c >= 1; --c)
        if (hess_form[c, c - 1] != T(0))  {
            for (size_type r { c + 1 }; r <= e_vecs.rows() - 1; ++r)
                ortho[0, r] = hess_form[r, c - 1];

            for (size_type cc { c }; cc <= e_vecs.cols() - 1; ++cc)  {
                value_type  g { 0 };

                for (size_type r { c }; r <= e_vecs.rows() - 1; ++r)
                    g += ortho[0, r] * e_vecs[r, cc];

                // Double division avoids possible underflow
                //
                g = (g / ortho[0, c]) / hess_form[c, c - 1];
                for (size_type r { c }; r <= e_vecs.rows() - 1; ++r)
                    e_vecs[r, cc] += g * ortho[0, r];
            }
        }

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA1, typename MA2, typename MA3, typename MA4>
void Matrix<T, MO, IS_SYM>::
hessenberg_to_schur_(MA1 &e_vecs,
                     MA2 &e_vals,
                     MA3 &imagi,
                     MA4 &hess_form) noexcept  {

    // Store roots isolated by balanc and compute matrix norm
    //
    value_type  norm { 0 };

    for (size_type r { 0 }; r < e_vecs.rows(); ++r)
        for (size_type c { r }; c < e_vecs.cols(); ++c)
            norm += std::abs(hess_form(r, c));

    size_type   iter { 0 };
    size_type   n { e_vecs.cols() - 1 };
    value_type  exshift { 0 };
    value_type  p { 0 };
    value_type  q { 0 };
    value_type  oo { 0 };
    value_type  s { 0 };
    value_type  z { 0 };
    value_type  w { 0 };
    value_type  x { 0 };
    value_type  y { 0 };

    // Outer loop over eigenvalue index
    //
    while (n >= 0)  {
        size_type   l { n };

        // Look for single small sub-diagonal element
        //
        while (l > 0)  {
            s = std::abs(hess_form(l - 1, l - 1)) +
                std::abs(hess_form(l, l));

            if (s == T(0))
                s = norm;
            if (std::abs(hess_form(l, l - 1)) < (value_type(EPSILON_) * s))
                break;

            l -= 1;
        }

        // Check for convergence
        //
        if (l == n)  {  // One root found
            hess_form(n, n) += exshift;
            e_vals(0, n) = hess_form(n, n);
            imagi (0, n--) = T(0);
            iter = 0;
        }
        else if (l == n - 1)  {  // Two roots found
            w = hess_form(n, n - 1) * hess_form(n - 1, n);
            p = (hess_form(n - 1, n - 1) - hess_form(n, n)) / T(2);
            q = p * p + w;
            z = std::sqrt(std::abs(q));

            hess_form(n, n) += exshift;
            hess_form(n - 1, n - 1) += exshift;

            const value_type    &xx { hess_form(n, n) };

            if (q >= T(0))  {  // Real pair
                z = p >= T(0) ? p + z : p - z;

                e_vals(0, n - 1) = xx + z;
                e_vals(0, n) = z != T(0) ? xx - w / z : e_vals (0, n - 1);

                imagi(0, n - 1) = 0;
                imagi(0, n) = 0;

                const value_type    &cref { hess_form(n, n - 1) };

                s = std::abs(cref) + std::abs(z);
                p = cref / s;
                q = z / s;
                oo = std::sqrt(p * p + q * q);
                p /= oo;
                q /= oo;

                // Row modification
                //
                for (size_type c { n - 1 }; c < e_vecs.cols (); ++c)  {
                    const value_type    cref { hess_form(n - 1, c) };

                    hess_form(n - 1, c) = q * cref + p * hess_form(n, c);
                    hess_form(n, c) = q * hess_form(n, c) - p * cref;
                }

                // Column modification
                //
                for (size_type r { 0 }; r <= n; ++r)  {
                    const value_type    cref { hess_form(r, n - 1) };

                    hess_form(r, n - 1) = q * cref + p * hess_form(r, n);
                    hess_form(r, n) = q * hess_form(r, n) - p * cref;
                }

                // Accumulate transformations
                //
                for (size_type r { 0 }; r <= e_vecs.rows() - 1; ++r)  {
                    const value_type    cref { e_vecs(r, n - 1) };

                    e_vecs(r, n - 1) = q * cref + p * e_vecs(r, n);
                    e_vecs(r, n) = q * e_vecs(r, n) - p * cref;
                }
            }
            else  {  // Complex pair
                e_vals(0, n - 1) = xx + p;
                e_vals(0, n) = xx + p;
                imagi(0, n - 1) = z;
                imagi(0, n) = -z;
            }

            n -= 2;
            iter = 0;
        }
        else  {  // No convergence yet

            // Form shift
            //
            x = hess_form(n, n);
            y = 0;
            w = 0;
            if (l < n)  {
                y = hess_form(n - 1, n - 1);
                w = hess_form(n, n - 1) * hess_form(n - 1, n);
            }

            // Wilkinson's original ad hoc shift
            //
            if (iter == 10)  {
                exshift += x;
                for (size_type r { 0 }; r <= n; ++r)
                    hess_form(r, r) -= x;

                s = std::abs(hess_form(n, n - 1)) +
                    std::abs(hess_form(n - 1, n - 2));
                x = y = T(0.75) * s;
                w = T(-0.4375) * s * s;
            }

            // MATLAB's new ad hoc shift
            //
            if (iter == 30)  {
                s = (y - x) / T(2);
                s = s * s + w;

                if (s > 0)  {
                    s = y < x ? -std::sqrt(s) : std::sqrt(s);
                    s = x - w / ((y - x) / T(2) + s);

                    for (size_type r { 0 }; r <= n; ++r)
                        hess_form(r, r) -= s;

                    exshift += s;
                    x = y = w = T(0.964);
                }
            }

            iter += 1;  // Could check iteration count here?

            // Look for two consecutive small sub-diagonal elements
            //
            size_type   m { n - 2 };

            while (m >= l)  {
                const value_type    &cref { hess_form(m, m) };

                oo = x - cref;
                s = y - cref;
                p = (oo * s - w) / hess_form(m + 1, m) + hess_form(m, m + 1);
                q = hess_form(m + 1, m + 1) - cref - oo - s;
                oo = hess_form(m + 2, m + 1);
                s = std::abs(p) + std::abs(q) + std::abs(oo);

                p /= s;
                q /= s;
                oo /= s;

                if (m == l)
                    break;

                if (std::abs(hess_form(m, m - 1)) *
                    (std::abs(q) + std::abs(oo)) <
                        value_type(EPSILON_) *
                        (std::abs(p) *
                         (std::abs(hess_form (m - 1, m - 1)) +
                          std::abs(cref) +
                          std::abs(hess_form (m + 1, m + 1)))))
                    break;

                m -= 1;
            }

            for (size_type r { m + 2 }; r <= n; ++r)  {
                hess_form (r, r - 2) = 0;

                if (r > m + 2)
                    hess_form (r, r - 3) = 0;
            }

            // Double QR step involving rows l to n and columns m to n
            //
            for (size_type k { m }; k <= n - 1; ++k)  {
                const bool  notlast { k != n - 1 };

                if (k != m)  {
                    p = hess_form(k, k - 1);
                    q = hess_form(k + 1, k - 1);
                    oo = notlast ? hess_form(k + 2, k - 1) : T(0);
                    x = std::abs(p) + std::abs(q) + std::abs(oo);

                    if (x != T(0))  {
                        p /= x;
                        q /= x;
                        oo /= x;
                    }
                }
                if (x == T(0))
                    break;

                s = p < T(0) ? -std::sqrt(p * p + q * q + oo * oo)
                             :  std::sqrt(p * p + q * q + oo * oo);

                if (s != T(0))  {
                    if (k != m)
                        hess_form(k, k - 1) = -s * x;
                    else if (l != m)
                        hess_form(k, k - 1) = -hess_form(k, k - 1);

                    p += s;
                    x = p / s;
                    y = q / s;
                    z = oo / s;

                    q /= p;
                    oo /= p;

                    // Row modification
                    //
                    for (size_type c { k }; c < e_vecs.cols(); ++c)  {
                        p = hess_form(k, c) + q * hess_form(k + 1, c);

                        if (notlast)  {
                            p += oo * hess_form(k + 2, c);
                            hess_form(k + 2, c) -= p * z;
                        }

                        hess_form(k, c) -= p * x;
                        hess_form(k + 1, c) -= p * y;
                    }

                    // Column modification
                    //
                    for (size_type r { 0 }; r <= std::min(n, k + 3); ++r)  {
                        p = x * hess_form(r, k) + y * hess_form(r, k + 1);

                        if (notlast)  {
                            p += z * hess_form(r, k + 2);
                            hess_form(r, k + 2) -= p * oo;
                         }

                         hess_form(r, k) -= p;
                         hess_form(r, k + 1) -= p * q;
                    }

                    // Accumulate transformations
                    //
                    for (size_type r { 0 }; r <= e_vecs.rows () - 1; ++r)  {
                        p = x * e_vecs(r, k) + y * e_vecs(r, k + 1);

                        if (notlast)  {
                            p += z * e_vecs(r, k + 2);
                            e_vecs(r, k + 2) -= p * oo;
                        }

                        e_vecs(r, k) -= p;
                        e_vecs(r, k + 1) -= p * q;
                    }
                }
            }
        }
    }

    if (norm == T(0))
        return;

    // Backsubstitute to find vectors of upper triangular form
    //
    for (size_type c { e_vecs.cols() - 1 }; c >= 0; --c)  {
        p = e_vals(0, c);
        q = imagi(0, c);

        if (q == T(0))  {  // Real vector
            size_type   l { c };

            hess_form(c, c) = 1;

            for (size_type r { c - 1 }; r >= 0; --r)  {
                const value_type    ww { hess_form(r, r) - p };

                oo = 0;
                for (size_type cc { l }; cc <= c; ++cc)
                    oo += hess_form(r, cc) * hess_form(cc, c);

                if (imagi(0, r) < T(0))  {
                    z = ww;
                    s = oo;
                }
                else  {
                    l = r;

                    if (imagi(0, r) == T(0))
                        hess_form(r, c) =
                            ww != T(0) ? -oo / ww
                                       : -oo / (value_type(EPSILON_) * norm);
                    else  {  // Solve real equations
                        q = (e_vals(0, r) - p) * (e_vals(0, r) - p) +
                            imagi(0, r) * imagi(0, r);

                        const value_type    &xx { hess_form(r, r + 1) };
                        const value_type    tt { (xx * s - z * oo) / q };

                        hess_form(r, c) = tt;

                        hess_form(r + 1, c) =
                            std::abs(xx) > std::abs(z)
                                ? (-oo - ww * tt) / xx
                                : (-s - hess_form(r + 1, r) * tt) / z;
                    }

                    // Overflow control
                    //
                    const value_type    t { std::abs(hess_form(r, c)) };

                    if ((value_type(EPSILON_) * t * t) > T(1))
                        for (size_type rr { r }; rr <= c; ++rr)
                            hess_form(rr, c) /= t;
                }
            }
        }
        else if (q < T(0))  {  // Complex vector
            size_type   l { c - 1 };
            value_type  cdivr;
            value_type  cdivi;

            // Last vector component imaginary so matrix is triangular
            //
            if (std::abs(hess_form(c, c - 1)) >
                    std::abs(hess_form(c - 1, c)))  {
                hess_form(c - 1, c - 1) = q / hess_form(c, c - 1);
                hess_form(c - 1, c) =
                    -(hess_form(c, c) - p) / hess_form(c, c - 1);
            }
            else  {
                cdiv_(0,
                      -hess_form(c - 1, c),
                      hess_form(c - 1, c - 1) - p,
                      q,
                      cdivr,
                      cdivi);
                hess_form(c - 1, c - 1) = cdivr;
                hess_form(c - 1, c) = cdivi;
            }

            hess_form(c, c - 1) = 0;
            hess_form(c, c) = 1;

            for (size_type r { c - 2 }; r >= 0; --r)  {
                value_type  ra { 0 };
                value_type  sa { 0 };

                for (size_type cc { l }; cc <= c; ++cc)  {
                    ra += hess_form(r, cc) * hess_form(cc, c - 1);
                    sa += hess_form(r, cc) * hess_form(cc, c);
                }

                const value_type    ww { hess_form(r, r) - p };

                if (imagi(0, r) < T(0))  {
                    z = ww;
                    oo = ra;
                    s = sa;
                }
                else  {
                    l = r;

                    if (imagi(0, r) == T(0))  {
                        cdiv_(-ra, -sa, ww, q, cdivr, cdivi);
                        hess_form(r, c - 1) = cdivr;
                        hess_form(r, c) = cdivi;
                    }
                    else  {  // Solve complex equations
                        const value_type    &xx { hess_form(r, r + 1) };
                        const value_type    &yy { hess_form(r + 1, r) };
                        const value_type    vi {
                            (e_vals (0, r) - p) * T(2.0) * q
                        };
                        value_type          vr {
                            (e_vals (0, r) - p) * (e_vals (0, r) - p) +
                            imagi (0, r) * imagi (0, r) -
                            q * q
                        };

                        if (vr == T(0) && vi == T(0))
                            vr = value_type(EPSILON_) *
                                 norm *
                                 (std::abs(ww) +
                                  std::abs(q) +
                                  std::abs(xx) +
                                  std::abs(yy) +
                                  std::abs(z));

                        cdiv_(xx * oo - z * ra + q * sa,
                              xx * s - z * sa - q * ra,
                              vr,
                              vi,
                              cdivr, cdivi);
                        hess_form(r, c - 1) = cdivr;
                        hess_form(r, c) = cdivi;

                        if (std::abs(xx) > std::abs(z) + std::abs(q))  {
                            hess_form(r + 1, c - 1) =
                                (-ra -
                                 ww * hess_form(r, c - 1) +
                                 q * hess_form(r, c)) /
                                xx;
                            hess_form(r + 1, c) =
                                (-sa - ww * hess_form (r, c) -
                                 q * hess_form(r, c - 1)) /
                                xx;
                        }
                        else  {
                            cdiv_(-oo - yy * hess_form (r, c - 1),
                                  -s - yy * hess_form (r, c),
                                  z,
                                  q,
                                  cdivr, cdivi);
                            hess_form(r + 1, c - 1) = cdivr;
                            hess_form(r + 1, c) = cdivi;
                        }
                    }

                   // Overflow control
                   //
                    const value_type    t {
                        std::max(std::abs(hess_form (r, c - 1)),
                                 std::abs(hess_form (r, c)))
                    };

                    if (value_type(EPSILON_) * t * t > 1)
                        for (size_type rr { r }; rr <= c; ++rr)  {
                            hess_form(rr, c - 1) /= t;
                            hess_form(rr, c) /= t;
                        }
                }
            }
        }
    }

    // Back transformation to get eigenvectors of original matrix
    //
    for (size_type c { e_vecs.cols() - 1 }; c >= 0; --c)
        for (size_type r { 0 }; r <= e_vecs.rows() - 1; ++r)  {
            z = 0;

            for (size_type k { 0 }; k <= std::min(c, e_vecs.cols() - 1); ++k)
                z += e_vecs(r, k) * hess_form(k, c);

            e_vecs(r, c) = z;
        }

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
void Matrix<T, MO, IS_SYM>::
cdiv_(value_type xr,
      value_type xi,
      value_type yr,
      value_type yi,
      value_type &cdivr,
      value_type &cdivi) noexcept  {

    if (std::abs(yr) > std::abs(yi))  {
        const value_type    r { yi / yr };
        const value_type    d { yr + r * yi };

        cdivr = (xr + r * xi) / d;
        cdivi = (xi - r * xr) / d;
    }
    else  {
        const value_type    r { yr / yi };
        const value_type    d { yi + r * yr };

        cdivr = (r * xr + xi) / d;
        cdivi = (r * xi - xr) / d;
    }

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA1, typename MA2, typename MA3>
void Matrix<T, MO, IS_SYM>::
tridiagonalize_(MA1 &e_vecs, MA2 &e_vals, MA3 &imagi) noexcept  {

    for (size_type r { e_vecs.rows() - 1 }; r > 0; --r)  {
        // Scale to avoid under/overflow.
        //
        value_type  scale { 0 };

        for (size_type c { 0 }; c < r; ++c)
            scale += std::abs(e_vals(0, c));

        value_type  h { 0 };

        if (scale == T(0))  {
            imagi(0, r) = e_vals(0, r - 1);
            for (size_type c { 0 }; c < r; ++c)  {
                e_vals(0, c) = e_vecs(r - 1, c);
                e_vecs(r, c) = 0;
                e_vecs(c, r) = 0;
            }
        }
        else  {
            // Generate Householder vector.
            //
            for (size_type c { 0 }; c < r; ++c)  {
                e_vals(0, c) /= scale;
                h += e_vals(0, c) * e_vals(0, c);
            }

            const value_type    &f { e_vals(0, r - 1) };
            value_type          g { f > T(0) ? -std::sqrt(h) : std::sqrt(h) };

            imagi(0, r) = scale * g;
            h -= f * g;
            e_vals(0, r - 1) = f - g;

            for (size_type c { 0 }; c < r; ++c)
                imagi (0, c) = 0;

            // Apply similarity transformation to remaining columns.
            //
            for (size_type c { 0 }; c < r; ++c)  {
                const value_type    &ff { e_vals(0, c) };

                e_vecs(c, r) = ff;
                g = imagi(0, c) + e_vecs(c, c) * ff;

                for (size_type cc { c + 1 }; cc <= r - 1; ++cc)  {
                    g += e_vecs(cc, c) * e_vals(0, cc);
                    imagi(0, cc) += e_vecs(cc, c) * ff;
                }
                imagi(0, c) = g;
            }

            value_type  ff { 0 };

            for (size_type c { 0 }; c < r; ++c)  {
                imagi(0, c) /= h;
                ff += imagi(0, c) * e_vals(0, c);
            }

            const value_type    hh { ff / (h + h) };

            for (size_type c { 0 }; c < r; ++c)
                imagi(0, c) -= hh * e_vals(0, c);

            for (size_type c { 0 }; c < r; ++c)  {
                for (size_type cc { c }; cc <= r - 1; ++cc)
                    e_vecs(cc, c) -= e_vals(0, c) * imagi(0, cc) +
                                     imagi(0, c) * e_vals(0, cc);

                e_vals(0, c) = e_vecs(r - 1, c);
                e_vecs(r, c) = 0;
            }
        }

        e_vals(0, r) = h;
    }

    // Accumulate transformations.
    //
    for (size_type r { 0 }; r < e_vecs.rows() - 1; ++r)  {
        e_vecs(e_vecs.rows() - 1, r) = e_vecs(r, r);
        e_vecs(r, r) = 1;

        const value_type    &h { e_vals(0, r + 1) };

        if (h != T(0))  {
            for (size_type c { 0 }; c <= r; ++c)
                e_vals(0, c) = e_vecs(c, r + 1) / h;

            for (size_type c { 0 }; c <= r; ++c)  {
                value_type  g { 0 };

                for (size_type rr { 0 }; rr <= r; ++rr)
                    g += e_vecs(rr, r + 1) * e_vecs(rr, c);

                for (size_type rr { 0 }; rr <= r; ++rr)
                    e_vecs(rr, c) -= g * e_vals(0, rr);
            }
        }
        for (size_type rr { 0 }; rr <= r; ++rr)
            e_vecs(rr, r + 1) = 0;
    }

    for (size_type c { 0 }; c < e_vecs.cols(); ++c)  {
        e_vals(0, c) = e_vecs(e_vecs.rows() - 1, c);
        e_vecs(e_vecs.rows() - 1, c) = 0;
    }
    e_vecs(e_vecs.rows() - 1, e_vecs.cols() - 1) = 1;
    imagi(0, 0) = 0;

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA1, typename MA2, typename MA3>
void Matrix<T, MO, IS_SYM>::
diagonalize_ (MA1 &e_vecs, MA2 &e_vals, MA3 &imagi) noexcept  {

    for (size_type c { 1 }; c < e_vecs.cols(); ++c)
        imagi(0, c - 1) = imagi(0, c);
    imagi(0, e_vecs.cols() - 1) = 0;

    value_type  f { 0 };
    value_type  tst1 { 0 };

    for (size_type c { 0 }; c < e_vecs.cols(); ++c)  {
        // Find small subdiagonal element
        //
        tst1 = std::max(tst1, std::abs(e_vals(0, c)) + std::abs(imagi(0, c)));

        size_type   m { c };

        while (m < e_vecs.cols())  {
            if (std::abs(imagi(0, m)) <= (value_type(EPSILON_) * tst1))
                break;
            m += 1;
        }

        // If m == l, e_vals(0, c) is an eigenvalue,
        // otherwise, iterate.
        //
        if (m > c)  {
            do  {
               // Compute implicit shift
               //
                value_type  g { e_vals (0, c) };
                value_type  p { (e_vals(0, c + 1) - g) / (T(2) * imagi(0, c)) };

                // Euclidean distance func
                //
                value_type  dis { p < T(0) ? -hypot(p, T(1)) : hypot(p, T(1)) };

                e_vals(0, c) = imagi(0, c) / (p + dis);
                e_vals(0, c + 1) = imagi(0, c) * (p + dis);

                const value_type    dl1 { e_vals(0, c + 1) };
                value_type          h { g - e_vals(0, c) };

                for (size_type cc { c + 2 }; cc < e_vecs.cols(); ++cc)
                    e_vals(0, cc) -= h;

                f += h;

                // Implicit QL transformation.
                //
                p = e_vals (0, m);

                value_type  cunit { 1 };
                value_type  c2 { 1 };
                value_type  c3 { 1 };
                value_type  el1 { imagi(0, c + 1) };
                value_type  s { 0 };
                value_type  s2 { 0 };

                for (size_type cc { m - 1 }; cc >= c; --cc)  {
                    c3 = c2;
                    c2 = cunit;
                    s2 = s;
                    g = cunit * imagi(0, cc);
                    h = cunit * p;
                    dis = hypot(p, imagi (0, cc));
                    imagi(0, cc + 1) = s * dis;
                    s = imagi(0, cc) / dis;
                    cunit = p / dis;
                    p = cunit * e_vals(0, cc) - s * g;
                    e_vals(0, cc + 1) =
                        h + s * (cunit * g + s * e_vals(0, cc));

                    // Accumulate transformation.
                    //
                    for (size_type r { 0 }; r < e_vecs.rows (); ++r)  {
                        h = e_vecs(r, cc + 1);
                        e_vecs(r, cc + 1) = s * e_vecs(r, cc) + cunit * h;
                        e_vecs(r, cc) = cunit * e_vecs(r, cc) - s * h;
                    }
                }

                p = -s * s2 * c3 * el1 * imagi(0, c) / dl1;
                imagi(0, c) = s * p;
                e_vals(0, c) = cunit * p;

               // Check for convergence.
               //
            }  while (std::abs(imagi(0, c)) > (value_type(EPSILON_) * tst1));
        }

        e_vals(0, c) = e_vals(0, c) + f;
        imagi(0, c) = 0;
    }

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA1, typename MA2>
void Matrix<T, MO, IS_SYM>::
eigen_space(MA1 &eigenvalues, MA2 &eigenvectors, bool sort_values) const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (! is_square() || cols() < 2)
        throw NotFeasible("Matrix::eigen_space(): Matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS

    MA1     tmp_evals { 1, cols() };
    MA2     tmp_evecs { rows(), cols() };
    Matrix  imagi { 1, cols() }; // Imaginary part

    if (is_symmetric())  {
        for (size_type r { 0 }; r < rows(); ++r)
            for (size_type c { 0 }; c < cols(); ++c)
                tmp_evecs(r, c) = at(r, c);

        for (size_type c { 0 }; c < cols(); ++c)
            tmp_evals(0, c) = at(rows() - 1, c);

        tridiagonalize_(tmp_evecs, tmp_evals, imagi);
        diagonalize_(tmp_evecs, tmp_evals, imagi);
    }
    else  {
        Matrix  hess_form { rows(), cols() };

        for (size_type r { 0 }; r < rows(); ++r)
            for (size_type c { 0 }; c < cols(); ++c)
                hess_form(r, c) = at(r, c);

        red_to_hessenberg_(tmp_evecs, hess_form);
        hessenberg_to_schur_(tmp_evecs, tmp_evals, imagi, hess_form);
    }

    if (sort_values)  {
        for (size_type c { 0 }; c < cols() - 1; ++c)  {
            size_type   min_col { c };
            value_type  abs_min_val { std::abs(tmp_evals(0, c)) };
            value_type  min_val { tmp_evals(0, c) };

            for (size_type cc { c + 1 }; cc < cols(); ++cc)
                if (std::abs(tmp_evals(0, cc)) < abs_min_val)  {
                    min_col = cc;
                    abs_min_val = std::abs(tmp_evals(0, cc));
                    min_val = tmp_evals(0, cc);
                }

            if (min_col != c)  {
                tmp_evals(0, min_col) = tmp_evals(0, c);
                tmp_evals(0, c) = min_val;
                for (size_type r { 0 }; r < rows(); ++r)  {
                    min_val = tmp_evecs(r, c);
                    tmp_evecs(r, c) = tmp_evecs(r, min_col);
                    tmp_evecs(r, min_col) = min_val;
                }
            }
        }
    }

    eigenvalues.swap(tmp_evals);
    eigenvectors.swap(tmp_evecs);
    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
typename Matrix<T, MO, IS_SYM>::scalar_ma_t Matrix<T, MO, IS_SYM>::
covariance(bool is_unbiased) const  {

    const data_t   denom { data_t(is_unbiased ? rows() - 1 : rows()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (denom <= data_t(0) || cols() < 2)
        throw NotFeasible("Matrix::covariance(): Not solvable");
#endif // HMDF_SANITY_EXCEPTIONS

    scalar_ma_t result;

    if constexpr (! IS_MD)  {
        // Column means are computed once. They used to be recomputed inside
        // the inner loop, for every column pair.
        //
        std::vector<value_type> means(cols());

        for (size_type c { 0 }; c < cols(); ++c)  {
            value_type  mean;

            zero_out_(mean);
            for (size_type r { 0 }; r < rows(); ++r)
                mean += at(r, c);
            means[c] = mean / data_t(rows());
        }

        auto        lbd =
            [&result, &means = std::as_const(means), this, denom]
            (auto begin, auto end) -> void  {
                for (size_type cr { begin }; cr < end; ++cr)  {
                    const value_type    mean { means[cr] };

                    for (size_type c { cr }; c < cols(); ++c)  {
                        const value_type    mean_c { means[c] };
                        value_type          var_covar;

                        zero_out_(var_covar);
                        for (size_type r { 0 }; r < rows(); ++r)
                            var_covar +=
                                (at(r, cr) - mean) * (at(r, c) - mean_c);

                        result(cr, c) = result(c, cr) = var_covar / denom;
                    }
                }
            };
        const long  thread_level {
            (cols() >= 500L || rows() >= 100'000L)
                ? ThreadGranularity::get_thread_level() : 0
        };

        result.resize(cols(), cols(), data_t(0));
        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  lbd(0L, cols());
    }
    else  {
        // Multidimensional path: T is vector<double> or array<double, N>.
        // Each element has inner dimension d = at(0,0).size().
        // Result is a (cols * d) x (cols * d) scalar matrix holding the full
        // outer-product covariance tensor:
        //   result(cr * d + di, c * d + dj)
        //       = Cov(col cr dim di, col c dim dj)
        //       = Σ_r (x[r,cr][di] - mean_cr[di]) *
        //             (x[r,c ][dj] - mean_c [dj]) / denom
        //
        // Pre-compute per-column means: means[c] is a (vector/array)
        // holding the mean of each dimension across all rows.
        //
        std::vector<value_type> means(cols());

        for (size_type c { 0 }; c < cols(); ++c)  {
            value_type  m;

            zero_out_(m);
            for (size_type r { 0 }; r < rows(); ++r)
                m += at(r, c);
            m /= data_t(rows());
            means[c] = std::move(m);
        }

        const size_type dim { size_type(at(0, 0).size()) };

        auto    lbd =
            [&result, &means = std::as_const(means), this, denom, dim]
            (auto begin, auto end) -> void  {
                for (size_type cr { begin }; cr < end; ++cr)  {
                    const value_type    &mean_cr { means[cr] };

                    for (size_type c { cr }; c < cols(); ++c)  {
                        const value_type    &mean_c { means[c] };

                        // Accumulate the dim x dim outer-product matrix for
                        // this column pair into a flat buffer, then write
                        // it into the result. Using a local buffer avoids
                        // repeated indexed writes into the large result
                        // matrix during the inner loop.
                        //
                        std::vector<data_t> outer(dim * dim, data_t(0));

                        for (size_type r { 0 }; r < rows(); ++r)  {
                            const value_type    &xr_cr { at(r, cr) };
                            const value_type    &xr_c  { at(r, c) };

                            for (size_type di { 0 }; di < dim; ++di)  {
                                const data_t    delta_cr {
                                    xr_cr[di] - mean_cr[di]
                                };

                                for (size_type dj { 0 }; dj < dim; ++dj)
                                    outer[di * dim + dj] +=
                                        delta_cr * (xr_c[dj] - mean_c[dj]);
                            }
                        }

                        // Write the accumulated block and its symmetric
                        // counterpart into the result matrix.
                        //
                        for (size_type di { 0 }; di < dim; ++di)
                            for (size_type dj { 0 }; dj < dim; ++dj)  {
                                const data_t    val {
                                    outer[di * dim + dj] / denom
                                };

                                result(cr * dim + di, c  * dim + dj) = val;
                                result(c  * dim + dj, cr * dim + di) = val;
                            }
                    }
                }
            };
        const long  thread_level {
            (cols() >= 20L || rows() >= 100'000L)
                ? ThreadGranularity::get_thread_level() : 0
        };

        const size_type result_dim { cols() * dim };

        result.resize(result_dim, result_dim, data_t(0));
        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  lbd(0L, cols());
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA1, typename MA2, typename MA3>
void Matrix<T, MO, IS_SYM>::
svd(MA1 &U, MA2 &S, MA3 &V, bool full_size) const  {

    const size_type min_dem { std::min(rows(), cols()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (min_dem < 2)
        throw NotFeasible("Matrix::svd(): Matrix is too small");
#endif // HMDF_SANITY_EXCEPTIONS

    // The Golub-Kahan-Reinsch iteration below requires rows >= cols. For a
    // wide matrix, decompose its transpose, A' = (V) S (U'), and swap the
    // roles of U and V. U is rows x rows. V is then cols x rows (economy
    // size), since the extra cols - rows right singular vectors belong to
    // the null space and carry no singular value.
    //
    if (rows() < cols())  {
        non_sym_ma_t    at_mat { cols(), rows() };

        for (size_type c { 0 }; c < cols(); ++c)
            for (size_type r { 0 }; r < rows(); ++r)
                at_mat(c, r) = at(r, c);

        MA1 u_t;
        MA3 v_t;

        at_mat.svd(u_t, S, v_t, full_size);
        if constexpr (std::is_same_v<MA1, MA3>)  {
            U.swap(v_t);
            V.swap(u_t);
        }
        else  {
            U = v_t;
            V = u_t;
        }
        return;
    }

    Matrix                  self_tmp { *this };
    MA1                     u_tmp { rows(), min_dem };
    std::vector<value_type> s_tmp(std::min(rows() + 1, cols()));
    MA3                     v_tmp { cols(), cols() };
    Matrix                  imagi { 1, cols() }; // Imaginary part
    std::vector<value_type> sandbox(rows());
    const size_type         min_col_cnt { std::min(rows() - 1, cols()) };
    const size_type         max_row_cnt {
        std::max(0L, std::min(cols() - 2, rows()))
    };

    // Reduce A to bidiagonal form, storing the diagonal elements
    // in s and the super-diagonal elements in e.
    //
    for (size_type c { 0 }; c < std::max(min_col_cnt, max_row_cnt); ++c)  {
        if (c < min_col_cnt)  {
           // Compute the transformation for the k-th column and
           // place the k-th diagonal in S (0, c).
           // Compute 2-norm of k-th column without under / overflow.
           //
            s_tmp[c] = 0;
            for (size_type r { c }; r < rows(); ++r)
                s_tmp[c] = hypot(s_tmp[c], self_tmp(r, c));

            if (s_tmp[c] != T(0))  {
                if (self_tmp(c, c) < T(0))
                    s_tmp[c] = -s_tmp[c];

                for (size_type r { c }; r < rows(); ++r)
                    self_tmp(r, c) /= s_tmp[c];

                self_tmp(c, c) += 1;
            }
            s_tmp[c] = -s_tmp[c];
        }
        for (size_type cc { c + 1 }; cc < cols(); ++cc)  {
            if (c < min_col_cnt && s_tmp[c] != T(0))  {
                // Apply the transformation.
                //
                value_type  t { 0 };

                for (size_type r { c }; r < rows(); ++r)
                    t += self_tmp(r, c) * self_tmp(r, cc);

                t /= -self_tmp(c, c);
                for (size_type r { c }; r < rows(); ++r)
                    self_tmp(r, cc) += t * self_tmp(r, c);

            }

            // Place the k-th row of A into e for the
            // subsequent calculation of the row transformation.
            //
            imagi(0, cc) = self_tmp(c, cc);
        }
        if (c < min_col_cnt)
            // Place the transformation in U for subsequent back
            // multiplication.
            //
            for (size_type r { c }; r < rows(); ++r)
                u_tmp(r, c) = self_tmp(r, c);

        if (c < max_row_cnt)  {

            // Compute the k-th row transformation and place the
            // k-th super-diagonal in imagi(0, c).
            // Compute 2-norm without under / overflow.
            //
            imagi(0, c) = 0;
            for (size_type cc { c + 1 }; cc < cols(); ++cc)
                imagi(0, c) = hypot(imagi(0, c), imagi(0, cc));

            if (imagi(0, c) != T(0))  {
                if (imagi(0, c + 1) < T(0))
                    imagi(0, c) = -imagi(0, c);

                for (size_type cc { c + 1 }; cc < cols(); ++cc)
                    imagi(0, cc) /= imagi(0, c);

                imagi(0, c + 1) += T(1);
            }
            imagi(0, c) = -imagi(0, c);

            if (c + 1 < rows() && imagi(0, c) != T(0))  {

                // Apply the transformation.
                //
                for (size_type r { c + 1 }; r < rows(); ++r)
                    sandbox[r] = 0;

                for (size_type cc { c + 1 }; cc < cols(); ++cc)
                    for (size_type r { c + 1 }; r < rows(); ++r)
                        sandbox[r] += imagi(0, cc) * self_tmp(r, cc);

                for (size_type cc { c + 1 }; cc < cols(); ++cc)  {
                    const value_type    t { -imagi(0, cc) / imagi(0, c + 1) };

                    for (size_type r { c + 1 }; r < rows(); ++r)
                        self_tmp(r, cc) += t * sandbox[r];
                }
            }

            // Place the transformation in V for subsequent
            // back multiplication.
            //
            for (size_type cc { c + 1 }; cc < cols(); ++cc)
                v_tmp(cc, c) = imagi(0, cc);
        }
    }

    // Set up the final bidiagonal matrix of order p.
    //
    size_type   p { std::min(cols(), rows() + 1) };

    if (min_col_cnt < cols())
        s_tmp[min_col_cnt] = self_tmp(min_col_cnt, min_col_cnt);

    if (rows() < p)
        s_tmp[p - 1] = 0;

    if ((max_row_cnt + 1) < p)
        imagi(0, max_row_cnt) = self_tmp(max_row_cnt, p - 1);

    imagi(0, p - 1) = 0;

    for (size_type c { min_col_cnt }; c < min_dem; ++c)  {
        for (size_type r { 0 }; r < rows(); ++r)
            u_tmp(r, c) = 0;
        u_tmp(c, c) = 1;
    }

    for (size_type c { min_col_cnt - 1 }; c >= 0; --c)  {
        if (s_tmp[c] != T(0))  {
            for (size_type cc { c + 1 }; cc < min_dem; ++cc)  {
                value_type  t { 0 };

                for (size_type r { c }; r < rows(); ++r)
                    t += u_tmp(r, c) * u_tmp(r, cc);

                t /= -u_tmp(c, c);
                for (size_type r { c }; r < rows(); ++r)
                    u_tmp(r, cc) += t * u_tmp(r, c);
            }
            for (size_type r { c }; r < rows(); ++r )
                u_tmp(r, c) = -u_tmp(r, c);

            u_tmp(c, c) += T(1);
            for (size_type r { 0 }; r < c - 1; ++r)
                u_tmp(r, c) = 0;
        }
        else  {
            for (size_type r { 0 }; r < rows(); ++r)
                u_tmp(r, c) = 0;
            u_tmp(c, c) = 1;
        }
    }

    for (size_type c { cols() - 1 }; c >= 0; --c)  {
        if ((c < max_row_cnt) && (imagi(0, c) != T(0)))
            for (size_type cc { c + 1 }; cc < min_dem; ++cc)  {
                value_type  t { 0 };

                for (size_type r { c + 1 }; r < cols(); ++r)
                    t += v_tmp(r, c) * v_tmp(r, cc);

                t /= -v_tmp(c + 1, c);
                for (size_type r { c + 1 }; r < cols(); ++r)
                    v_tmp(r, cc) += t * v_tmp(r, c);
            }

        for (size_type r { 0 }; r < cols(); ++r)
            v_tmp(r, c) = 0;
        v_tmp(c, c) = 1;
    }

    const size_type pp { p - 1 };

    // Main iteration loop for the singular values.
    //
    while (p > T(0))  {
        size_type   c;
        size_type   kase;

        // Here is where a test for too many iterations would go.
        //
        // This section of the routine inspects for
        // negligible elements in the s and imagi arrays.  On
        // completion the variables kase and c are set as follows.
        //
        // case == 1 --> if s(p) and imagi(0, c - 1) are negligible and k < p
        // case == 2 --> if s(c) is negligible and c < p
        // case == 3 --> if imagi(0, c - 1) is negligible, c < p, and
        //               s(c), ..., s(p) are not negligible (qr step).
        // case == 4 --> if e(p - 1) is negligible (convergence).
        //
        for (c = p - 2; c >= -1; --c)  {
            if (c == -1)
                break;

            if (std::abs(imagi(0, c)) <=
                    value_type(EPSILON_) * (std::abs(s_tmp[c]) +
                                            std::abs(s_tmp[c + 1])))  {
                imagi(0, c) = 0;
                break;
            }
        }
        if (c == p - 2)
            kase = 4;

        else  {
            size_type ks;

            for (ks = p - 1; ks >= c; --ks)  {
                if (ks == c)
                    break;

                const value_type    t {
                    (ks != p ? std::abs(imagi(0, ks)) : T(0)) +
                    (ks != c + 1 ? std::abs(imagi(0, ks - 1)) : T(0))
                };

                if (std::abs(s_tmp[ks]) <= (value_type(EPSILON_) * t))  {
                    s_tmp[ks] = 0;
                    break;
                }
            }

            if (ks == c)
                kase = 3;
            else if (ks == p - 1)
                kase = 1;
            else  {
                kase = 2;
                c = ks;
            }
        }
        c += 1;

        // Perform the task indicated by kase.
        //
        switch (kase)  {
            // Deflate negligible s(p).
            //
            case 1:
            {
                value_type  f { imagi(0, p - 2) };

                imagi(0, p - 2) = 0;
                for (size_type cc { p - 2 }; cc >= c; --cc)  {
                    value_type  t { hypot(s_tmp[cc], f) };
                    value_type  cs { s_tmp[cc] / t };
                    value_type  sn { f / t };

                    s_tmp [cc] = t;
                    if (cc != c)  {
                        f = -sn * imagi(0, cc - 1);
                        imagi(0, cc - 1) *= cs;
                    }

                    for (size_type r { 0 }; r < cols(); ++r)  {
                        t = cs * v_tmp(r, cc) + sn * v_tmp(r, p - 1);
                        v_tmp(r, p - 1) =
                            -sn * v_tmp(r, cc) + cs * v_tmp(r, p - 1);
                        v_tmp(r, cc) = t;
                    }
                }
            }
            break;

            // Split at negligible s(c).
            //
            case 2:
            {
                value_type  f { imagi(0, c - 1) };

                imagi(0, c - 1) = T(0.0);
                for (size_type cc { c }; cc < p; ++cc)  {
                    value_type  t { hypot(s_tmp[cc], f) };
                    value_type  cs { s_tmp[cc] / t };
                    value_type  sn { f / t };

                    s_tmp[cc] = t;
                    f = -sn * imagi(0, cc);
                    imagi(0, cc) *= cs;

                    for (size_type r { 0 }; r < rows(); ++r)  {
                        t = cs * u_tmp(r, cc) + sn * u_tmp(r, c - 1);
                        u_tmp(r, c - 1) =
                            -sn * u_tmp(r, cc) + cs * u_tmp(r, c - 1);
                        u_tmp(r, cc) = t;
                    }
                }
            }
            break;

            // Perform one qr step.
            //
            case 3:
            {

                // Calculate the shift.
                //
                const value_type    scale {
                    std::max(
                        std::max(
                            std::max(
                                std::max(std::abs(s_tmp [p - 1]),
                                         std::abs(s_tmp [p - 2])),
                                std::abs(imagi(0, p - 2))),
                            std::abs(s_tmp[c])),
                        std::abs(imagi(0, c)))
                };
                const value_type    sp { s_tmp[p - 1] / scale };
                const value_type    spm1 { s_tmp[p - 2] / scale };
                const value_type    epm1 { imagi(0, p - 2) / scale };
                const value_type    sk { s_tmp[c] / scale };
                const value_type    ek { imagi(0, c) / scale };
                const value_type    b {
                    ((spm1 + sp) * (spm1 - sp) + epm1 * epm1) / T(2)
                };
                const value_type    dd { (sp * epm1) * (sp * epm1) };
                value_type          shift { 0 };

                if (b != T(0) || dd != T(0))  {
                    shift = b < T(0)
                                ? -std::sqrt(b * b + dd)
                                :  std::sqrt(b * b + dd);
                    shift = dd / (b + shift);
                }

                value_type  f { (sk + sp) * (sk - sp) + shift };
                value_type  g { sk * ek };

                // Chase zeros.
                //
                for (size_type cc { c }; cc < p - 1; ++cc)  {
                    value_type  t { hypot(f, g) };
                    value_type  cs { f / t };
                    value_type  sn { g / t };

                    if (cc != c)
                        imagi(0, cc - 1) = t;

                    f = cs * s_tmp[cc] + sn * imagi(0, cc);
                    imagi(0, cc) = cs * imagi(0, cc) - sn * s_tmp[cc];
                    g = sn * s_tmp[cc + 1];
                    s_tmp[cc + 1] *= cs;

                    for (size_type r { 0 }; r < cols(); ++r)  {
                        t = cs * v_tmp(r, cc) + sn * v_tmp(r, cc + 1);
                        v_tmp(r, cc + 1) =
                            -sn * v_tmp(r, cc) + cs * v_tmp(r, cc + 1);
                        v_tmp(r, cc) = t;
                    }

                    t = hypot(f, g);
                    cs = f / t;
                    sn = g / t;
                    s_tmp[cc] = t;
                    f = cs * imagi(0, cc) + sn * s_tmp[cc + 1];
                    s_tmp[cc + 1] = -sn * imagi(0, cc) + cs * s_tmp[cc + 1];
                    g = sn * imagi(0, cc + 1);
                    imagi(0, cc + 1) = cs * imagi(0, cc + 1);

                    if (cc < rows() - 1)
                        for (size_type r { 0 }; r < rows(); ++r)  {
                            t = cs * u_tmp(r, cc) + sn * u_tmp(r, cc + 1);
                            u_tmp(r, cc + 1) =
                                -sn * u_tmp(r, cc) + cs * u_tmp(r, cc + 1);
                            u_tmp(r, cc) = t;
                        }
                }

                imagi(0, p - 2) = f;
            }
            break;

            // Convergence.
            //
            case 4:
            {
                // Make the singular values positive.
                //
                if (s_tmp[c] <= T(0))  {
                    s_tmp[c] = s_tmp [c] < T(0) ? -s_tmp[c] : T(0);

                    for (size_type r { 0 }; r <= pp; ++r)
                        v_tmp(r, c) = -v_tmp(r, c);
                }

                // Order the singular values.
                //
                while (c < pp)  {
                    if (s_tmp[c] >= s_tmp[c + 1])
                        break;

                    value_type  t { s_tmp[c] };

                    s_tmp[c] = s_tmp[c + 1];
                    s_tmp[c + 1] = t;

                    if (c < cols() - 1)
                        for (size_type r { 0 }; r < cols(); ++r) {
                            t = v_tmp(r, c + 1);
                            v_tmp(r, c + 1) = v_tmp(r, c);
                            v_tmp(r, c) = t;
                        }

                    if (c < rows() - 1)
                        for (size_type r { 0 }; r < rows(); ++r)  {
                            t = u_tmp(r, c + 1);
                            u_tmp(r, c + 1) = u_tmp(r, c);
                            u_tmp(r, c) = t;
                        }

                    c += 1;
                }

                p -= 1;
            }
            break;
        }
    }

    U.swap(u_tmp);

    S.resize(s_tmp.size(), full_size ? s_tmp.size() : 1, T(0));
    if (full_size)
        for (size_type i { 0 }; i < size_type(s_tmp.size()); ++i)
            S(i, i) = s_tmp[i];
    else
        for (size_type i { 0 }; i < size_type(s_tmp.size()); ++i)
            S(i, 0) = s_tmp[i];

    V.swap(v_tmp);

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA1, typename MA2>
void Matrix<T, MO, IS_SYM>::
lud(MA1 &L, MA2 &U) const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (! is_square())
        throw NotFeasible("Matrix::lud(): Matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS

    MA1 l_tmp { rows(), cols(), 0 };
    MA2 u_tmp { rows(), cols(), 0 };

    // Scale the singularity test to the matrix. An absolute epsilon rejects
    // perfectly good matrices with small entries.
    //
    value_type  scale { 0 };

    for (const auto &v : matrix_)
        scale = std::max(scale, value_type(std::abs(v)));

    const value_type    tol {
        std::numeric_limits<T>::epsilon() * scale * value_type(rows())
    };

    for (size_type i { 0 }; i < rows(); ++i) {
        value_type  sum { 0 };

        // Upper Triangular
        //
        for (size_type k { i }; k < rows(); ++k) {
            sum = 0;
            for (size_type j { 0 }; j < i; ++j)
                sum += l_tmp(i, j) * u_tmp(j, k);
            u_tmp(i, k) = at(i, k) - sum;
        }

        // Lower Triangular
        //
        l_tmp(i, i) = 1;  // Diagonal of L is 1
        for (size_type k { i + 1 }; k < rows(); ++k) {
            sum = 0;
            for (size_type j { 0 }; j < i; ++j)
                sum += l_tmp(k, j) * u_tmp(j, i);

            if (std::abs(u_tmp(i, i)) <= tol) [[unlikely]]
                throw NotFeasible("Matrix::lud(): Matrix is singular");

            l_tmp(k, i) = (at(k, i) - sum) / u_tmp(i, i);
        }
    }

    L.swap(l_tmp);
    U.swap(u_tmp);
    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA>
void Matrix<T, MO, IS_SYM>::
ldlt(std::vector<T> &D, MA &L) const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (! is_symmetric())
        throw NotFeasible("Matrix::ldlt(): Matrix must be symmetric");
#endif // HMDF_SANITY_EXCEPTIONS

    std::vector<value_type> d_tmp(rows(), 0);
    MA                      l_tmp { rows(), cols(), 0 };
    value_type              scale { 0 };

    for (const auto &v : matrix_)
        scale = std::max(scale, value_type(std::abs(v)));

    const value_type    tol {
        std::numeric_limits<T>::epsilon() * scale * value_type(rows())
    };

    // Initialize L as identity
    //
    for (size_type i { 0 }; i < rows(); ++i)  l_tmp(i, i) = 1;

    for (size_type k { 0 }; k < rows(); ++k) {
        value_type  sum { 0 };

        // Compute D[k]
        //
        for (size_type j { 0 }; j < k; ++j)
            sum += l_tmp(k, j) * l_tmp(k, j) * d_tmp[j];
        d_tmp[k] = at(k, k) - sum;

        if (std::abs(d_tmp[k]) <= tol) [[unlikely]]
            throw NotFeasible("Matrix::ldlt(): Matrix is singular");

        // Compute L(i,k) for i = k+1 .. rows-1
        //
        for (size_type i { k + 1 }; i < rows(); ++i) {
            value_type  sum2 { 0 };

            for (size_type j { 0 }; j < k; ++j)
                sum2 += l_tmp(i, j) * l_tmp(k, j) * d_tmp[j];
            l_tmp(i, k) = (at(i, k) - sum2) / d_tmp[k];
        }
    }

    D.swap(d_tmp);
    L.swap(l_tmp);

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA>
typename Matrix<T, MO, IS_SYM>::non_sym_ma_t Matrix<T, MO, IS_SYM>::
solve(const MA &rhs) const  {

    constexpr bool  is_vec { is_std_vector_v<MA> };

    size_type   rhs_size;
    size_type   rhs_cols;

    if constexpr (is_vec)  { rhs_size = rhs.size(); rhs_cols = 1; }
    else  { rhs_size = rhs.rows(); rhs_cols = rhs.cols(); }

#ifdef HMDF_SANITY_EXCEPTIONS
    if (! is_square() || cols() != rhs_size)
        throw NotFeasible(
            "Matrix::solve(): Matrix must be square and compatible with rhs");
#endif // HMDF_SANITY_EXCEPTIONS

    non_sym_ma_t    tmp { rows(), cols() + rhs_cols };

    for (size_type r { 0 }; r < rows(); ++r)  {
        for (size_type c { 0 }; c < cols(); ++c)
            tmp(r, c) = at(r, c);
        if constexpr (is_vec)  {
            tmp(r, cols()) = rhs[r];
        }
        else  {
            // A vector RHS is always a single column, but a matrix RHS
            // can have any number of columns -- append them all here
            // instead of only rhs(r, 0), or every column past the first
            // is silently dropped (the augmented system, and hence the
            // solved-for result below, never sees it).
            //
            for (size_type rc { 0 }; rc < rhs_cols; ++rc)
                tmp(r, cols() + rc) = rhs(r, rc);
        }
    }

    // Gaussian elimination with partial pivoting on A. Only an exactly zero
    // pivot means singular, the same convention LAPACK's gesv uses.
    //
    const size_type rank { _echelon_(tmp, cols(), value_type(0)) };

    if (rank != rows())
        throw NotFeasible("Matrix::solve(): Matrix is singular");

    non_sym_ma_t    sol { rhs_size, rhs_cols };

    // Back-substitute each RHS column into its own column of sol -- a
    // single-column loop here (rc fixed at 0) is exactly what this
    // function used to do; the loop just repeats it once per RHS column.
    //
    for (size_type rc { 0 }; rc < rhs_cols; ++rc)  {
        for (size_type r { rows() - 1 }; r >= 0; --r)  {
            sol(r, rc) = tmp(r, cols() + rc);
            for (size_type c { r + 1 }; c < cols(); ++c)
                sol(r, rc) -= tmp(r, c) * sol(c, rc);
        }
    }

    return (sol);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
typename Matrix<T, MO, IS_SYM>::non_sym_ma_t Matrix<T, MO, IS_SYM>::
solve() const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (rows() != (cols() - 1))
        throw NotFeasible("Matrix::solve(): Matrix must be square and "
                          "and last column is the rhs");
#endif // HMDF_SANITY_EXCEPTIONS

    non_sym_ma_t    tmp { rows(), cols() };

    for (size_type r { 0 }; r < rows(); ++r)  {
        for (size_type c { 0 }; c < cols() - 1; ++c)
            tmp(r, c) = at(r, c);
        tmp(r, cols() - 1) = at(r, cols() - 1);
    }

    const size_type rank { _echelon_(tmp, cols() - 1, value_type(0)) };

    if (rank != rows())
        throw NotFeasible("Matrix::solve(): Matrix is singular");

    non_sym_ma_t    sol { rows(), 1 };

    for (size_type r { rows() - 1 }; r >= 0; --r)  {
        sol(r, 0) = tmp(r, cols() - 1);
        for (size_type c { r + 1 }; c < cols() - 1; ++c)
            sol(r, 0) -= tmp(r, c) * sol(c, 0);
    }

    return (sol);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::value_type
Matrix<T, MO, IS_SYM>::determinant() const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (! is_square())
        throw NotFeasible("Matrix::determinant(): Matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS

    if constexpr (IS_SYM)  {
        // Row operations do not preserve symmetry, and on packed symmetric
        // storage (r, c) and (c, r) are one element. Use a general copy.
        //
        non_sym_ma_t    dense { rows(), cols() };

        for (size_type c { 0 }; c < cols(); ++c)  {
            for (size_type r { 0 }; r < rows(); ++r)
                dense(r, c) = at(r, c);
        }
        return (dense.determinant());
    }

    const size_type sz { rows() };
    value_type      result { 1 };

    if (sz == 2)  {
        result = at(0, 0) * at(1, 1) - at(0, 1) * at(1, 0);
    }
    else  {
        // Gaussian elimination with partial pivoting, for every size. The
        // unpivoted LU decomposition that used to handle n >= 8 threw
        // "singular" on matrices such as a permutation matrix.
        //
        Matrix                  tmp { *this };
        std::vector<value_type> mult(sz);

        for (size_type r { 0 }; r < sz; ++r)  {
            const size_type indx { tmp.ppivot_(r, sz, sz) };

            if (indx == NOPOS_)
                return (value_type(0));

            if (indx != 0)
                result = -result;

            const value_type    diag { tmp(r, r) };

            result *= diag;
            for (size_type rr { r + 1 }; rr < sz; ++rr)
                mult[rr] = tmp(rr, r) / diag;

            // Walk memory in its natural order: down a column for
            // column-major storage, along a row for row-major.
            //
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { r + 1 }; c < sz; ++c)  {
                    const value_type    top { tmp(r, c) };

                    if (top == value_type(0))  continue;
                    for (size_type rr { r + 1 }; rr < sz; ++rr)
                        tmp(rr, c) -= mult[rr] * top;
                }
            }
            else  {
                for (size_type rr { r + 1 }; rr < sz; ++rr)  {
                    const value_type    piv { mult[rr] };

                    if (piv == value_type(0))  continue;
                    for (size_type c { r + 1 }; c < sz; ++c)
                        tmp(rr, c) -= piv * tmp(r, c);
                }
            }
        }
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA>
inline MA &Matrix<T, MO, IS_SYM>::
get_minor(MA &mmatrix, size_type drow, size_type dcol) const noexcept  {

    mmatrix.resize(rows() - 1, cols() - 1, 0);

    size_type   mrow { 0 };

    for (size_type r { 0 }; r < rows(); ++r)  {
        if (r != drow)  {
            size_type   mcol { 0 };

            for (size_type c { 0 }; c < cols(); ++c)  {
                if (c != dcol)
                    mmatrix(mrow, mcol++) = at(r, c);
            }

            mrow += 1;  // Increase minor row-count
        }
    }

    return (mmatrix);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline typename Matrix<T, MO, IS_SYM>::value_type
Matrix<T, MO, IS_SYM>::cofactor(size_type row, size_type column) const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (! is_square())
        throw NotFeasible("Matrix::cofactor(): Matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS

    Matrix<T, matrix_orient::row_major, false>  tmp;

    get_minor(tmp, row, column);
    return ((row + column) % 2 ? -tmp.determinant() : tmp.determinant());
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA>
inline MA &Matrix<T, MO, IS_SYM>::adjoint(MA &that) const  {

#ifdef HMDF_SANITY_EXCEPTIONS
    if (! is_square())
        throw NotFeasible("Matrix::adjoint(): Matrix must be square");
#endif // HMDF_SANITY_EXCEPTIONS

    if constexpr (IS_SYM)  {
        // The elimination below applies row operations, which do not
        // preserve symmetry. Work on a general copy.
        //
        non_sym_ma_t    dense { rows(), cols() };

        for (size_type c { 0 }; c < cols(); ++c)  {
            for (size_type r { 0 }; r < rows(); ++r)
                dense(r, c) = at(r, c);
        }
        return (dense.adjoint(that));
    }
    else  {
        const size_type n { rows() };

        that.resize(n, n);

        // The adjoint of a 1 x 1 matrix is 1 and of a 2 x 2 matrix has a
        // closed form. Both are exact.
        //
        if (n == 1)  { that(0, 0) = value_type(1); return (that); }
        if (n == 2)  {
            that(0, 0) = at(1, 1);
            that(0, 1) = -at(0, 1);
            that(1, 0) = -at(1, 0);
            that(1, 1) = at(0, 0);
            return (that);
        }

        // Adjoint(A) = Determinant(A) * Inverse(A).
        //
        // The inverse and the determinant come out of one Gauss-Jordan
        // elimination with partial pivoting, O(n^3). The textbook way, a
        // determinant of an (n - 1) x (n - 1) minor for each of the n^2
        // elements, is O(n^5) and allocates a matrix per element.
        //
        // The result is as accurate as the cofactor way, including for
        // matrices that are numerically singular. The one case it cannot
        // handle is an exactly zero pivot, where the matrix has no inverse
        // but the adjoint still exists (it is zero for rank <= n - 2 and
        // rank one for rank n - 1). That falls back to the cofactors.
        //
        Matrix      aux_mat { *this };
        Matrix      inv { n, n, 0 };
        value_type  det { 1 };
        bool        singular { false };

        for (size_type d { 0 }; d < n; ++d)  inv.at(d, d) = value_type(1);

        for (size_type r { 0 }; r < n; ++r)  {
            const size_type idx { aux_mat.ppivot_(r, n, n) };

            if (idx == NOPOS_ ||
                std::abs(aux_mat.at(r, r)) <=
                    std::numeric_limits<value_type>::min())  {
                singular = true;
                break;
            }

            if (idx != 0)  {
                det = -det;
                for (size_type c { 0 }; c < n; ++c)
                    std::swap(inv.at(r, c), inv.at(idx, c));
            }

            const value_type    diag { aux_mat.at(r, r) };

            det *= diag;

            // Columns 0 .. r - 1 of aux_mat are already eliminated (zero)
            //
            for (size_type c { r }; c < n; ++c)
                aux_mat.at(r, c) /= diag;
            for (size_type c { 0 }; c < n; ++c)
                inv.at(r, c) /= diag;

            for (size_type r2 { 0 }; r2 < n; ++r2)  {
                if (r2 != r)  {
                    const value_type    off_diag { aux_mat.at(r2, r) };

                    if (off_diag == value_type(0))  continue;

                    for (size_type c { r }; c < n; ++c)
                        aux_mat.at(r2, c) -= off_diag * aux_mat.at(r, c);
                    for (size_type c { 0 }; c < n; ++c)
                        inv.at(r2, c) -= off_diag * inv.at(r, c);
                }
            }
        }

        if (! singular)  {
            for (size_type c { 0 }; c < n; ++c)
                for (size_type r { 0 }; r < n; ++r)
                    that(r, c) = det * inv.at(r, c);
            return (that);
        }

        // Exactly singular: the cofactors
        //
        auto        row_lbd =
            [&that, this](auto begin, auto end) -> void  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { 0 }; c < cols(); ++c)
                        that(c, r) = cofactor(r, c);
            };
        auto        col_lbd =
            [&that, this](auto begin, auto end) -> void  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { 0 }; r < cols(); ++r)
                        that(c, r) = cofactor(r, c);
            };
        const long  thread_level {
            (cols() >= 20L) ? ThreadGranularity::get_thread_level() : 0
        };

        if (thread_level > 2)  {
            std::vector<std::future<void>>  futures;

            if constexpr (MO == matrix_orient::column_major)
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, cols(), std::move(col_lbd));
            else
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        0L, cols(), std::move(row_lbd));

            for (auto &fut : futures)  fut.get();
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)
                col_lbd(0L, cols());
            else
                row_lbd(0L, cols());
        }

        return (that);
    }
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
void Matrix<T, MO, IS_SYM>::center() noexcept  {

    for (size_type c { 0 }; c < cols(); ++c)  {
        value_type  mean { 0 };

        for (size_type r { 0 }; r < rows(); ++r)
            mean += at(r, c);
        mean /= value_type(rows());

        for (size_type r { 0 }; r < rows(); ++r)
            at(r, c) -= mean;
    }

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA>
void Matrix<T, MO, IS_SYM>::get_centered(MA &cmatrix) const noexcept  {

    cmatrix.resize(rows(), cols(), 0);
    if constexpr (MO == matrix_orient::column_major)  {
        for (size_type c { 0 }; c < cols(); ++c)
            for (size_type r { 0 }; r < rows(); ++r)
                cmatrix(r, c) = at(r, c);
    }
    else  {
        for (size_type r { 0 }; r < rows(); ++r)
            for (size_type c { 0 }; c < cols(); ++c)
                cmatrix(r, c) = at(r, c);
    }
    cmatrix.center();

    return;
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_square() noexcept  {

    auto        lbd = [this](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { c }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val *= val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { r }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val *= val;
                    }
                }
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { 0 }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val *= val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { 0 }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val *= val;
                    }
                }
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_cube() noexcept  {

    auto        lbd = [this](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { c }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val *= val * val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { r }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val *= val * val;
                    }
                }
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { 0 }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val *= val * val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { 0 }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val *= val * val;
                    }
                }
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_sqrt() noexcept  {

    auto        lbd = [this](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { c }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val = std::sqrt(val);
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { r }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val = std::sqrt(val);
                    }
                }
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { 0 }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val = std::sqrt(val);
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { 0 }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val = std::sqrt(val);
                    }
                }
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_tanh() noexcept  {

    auto        lbd = [this](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { c }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val = std::tanh(val);
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { r }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val = std::tanh(val);
                    }
                }
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { 0 }; r < rows(); ++r)  {
                        auto  &val { at(r, c) };

                        val = std::tanh(val);
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { 0 }; c < cols(); ++c)  {
                        auto  &val { at(r, c) };

                        val = std::tanh(val);
                    }
                }
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_inverse() noexcept  {

    auto        lbd = [this](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { c }; r < rows(); ++r)  {
                        auto  &val = at(r, c);

                        val = T(1) / val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { r }; c < cols(); ++c)  {
                        auto  &val = at(r, c);

                        val = T(1) / val;
                    }
                }
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)  {
                    for (size_type r { 0 }; r < rows(); ++r)  {
                        auto  &val = at(r, c);

                        val = T(1) / val;
                    }
                }
            }
            else  {
                for (size_type r { begin }; r < end; ++r)  {
                    for (size_type c { 0 }; c < cols(); ++c)  {
                        auto  &val = at(r, c);

                        val = T(1) / val;
                    }
                }
            }
        }
    };
    const long  thread_level =
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0;

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_add(value_type val) noexcept  {

    auto        lbd = [this, val](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { c }; r < rows(); ++r)
                        at(r, c) += val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { r }; c < cols(); ++c)
                        at(r, c) += val;
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { 0 }; r < rows(); ++r)
                        at(r, c) += val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { 0 }; c < cols(); ++c)
                        at(r, c) += val;
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_minus(value_type val) noexcept  {

    auto        lbd = [this, val](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { c }; r < rows(); ++r)
                        at(r, c) -= val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { r }; c < cols(); ++c)
                        at(r, c) -= val;
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { 0 }; r < rows(); ++r)
                        at(r, c) -= val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { 0 }; c < cols(); ++c)
                        at(r, c) -= val;
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_multiply(value_type val) noexcept  {

    auto        lbd = [this, val](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { c }; r < rows(); ++r)
                        at(r, c) *= val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { r }; c < cols(); ++c)
                        at(r, c) *= val;
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { 0 }; r < rows(); ++r)
                        at(r, c) *= val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { 0 }; c < cols(); ++c)
                        at(r, c) *= val;
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::ew_divide(value_type val) noexcept  {

    auto        lbd = [this, val](auto begin, auto end) -> void  {
        if constexpr (IS_SYM)  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { c }; r < rows(); ++r)
                        at(r, c) /= val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { r }; c < cols(); ++c)
                        at(r, c) /= val;
            }
        }
        else  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (size_type c { begin }; c < end; ++c)
                    for (size_type r { 0 }; r < rows(); ++r)
                        at(r, c) /= val;
            }
            else  {
                for (size_type r { begin }; r < end; ++r)
                    for (size_type c { 0 }; c < cols(); ++c)
                        at(r, c) /= val;
            }
        }
    };
    const long  thread_level {
        (cols() >= 500L || rows() >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        if constexpr (MO == matrix_orient::column_major)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, cols(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    0L, rows(), std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
    }
    else  {
        if constexpr (MO == matrix_orient::column_major)
            lbd(0L, cols());
        else
            lbd(0L, rows());
    }

    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::value_type Matrix<T, MO, IS_SYM>::
row_inner_prod(size_type row1, size_type row2) const  {

    const size_type data_s { cols() };
    const long      thread_level {
        (data_s >= ThreadPool::MUL_THR_THHOLD)
            ? ThreadGranularity::get_thread_level() : 0
    };
    auto            lbd =
        [this, row1, row2]
        (auto begin, auto end) -> value_type  {
            auto    sum { at(row1, begin) * at(row2, begin) };

            for (size_type c { begin + 1 }; c < end; ++c)
                sum += at(row1, c) * at(row2, c);
            return (sum);
        };
    value_type      result { 0 };

    if (thread_level > 2)  {
        auto    futures {
            ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                0L, data_s, std::move(lbd))
        };

        if (! futures.empty())  result = futures[0].get();
        for (size_type i { 1 }; i < size_type(futures.size()); ++i)
            result += futures[i].get();
    }
    else  {
        result = lbd(0L, data_s);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM>::value_type Matrix<T, MO, IS_SYM>::
col_inner_prod(size_type col1, size_type col2) const  {

    const size_type data_s { rows() };
    const long      thread_level {
        (data_s >= ThreadPool::MUL_THR_THHOLD)
            ? ThreadGranularity::get_thread_level() : 0
    };
    auto            lbd =
        [this, col1, col2]
        (auto begin, auto end) -> value_type  {
            auto    sum { at(begin, col1) * at(begin, col2) };

            for (size_type r { begin + 1 }; r < end; ++r)
                sum += at(r, col1) * at(r, col2);
            return (sum);
        };
    value_type      result { 0 };

    if (thread_level > 2)  {
        auto    futures {
            ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                0L, data_s, std::move(lbd))
        };

        if (! futures.empty())  result = futures[0].get();
        for (size_type i { 1 }; i < size_type(futures.size()); ++i)
            result += futures[i].get();
    }
    else  {
        result = lbd(0L, data_s);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
typename Matrix<T, MO, IS_SYM>::scalar_ma_t Matrix<T, MO, IS_SYM>::
get_flatten(bool col_wise) const requires (IS_MD)  {

    const size_type dim { size_type(at(0, 0).size()) };
    scalar_ma_t     result;

    if (col_wise)  {
        result.resize(rows(), cols() * dim);
        if constexpr (MO == matrix_orient::column_major)  {
            for (size_type c { 0 }; c < cols(); ++c)
                for (size_type r { 0 }; r < rows(); ++r)
                    for (size_type d { 0 }; d < dim; ++d)
                        result(r, c * dim + d) = at(r, c)[d];
        }
        else  {
            for (size_type r { 0 }; r < rows(); ++r)
                for (size_type c { 0 }; c < cols(); ++c)
                    for (size_type d { 0 }; d < dim; ++d)
                        result(r, c * dim + d) = at(r, c)[d];
        }
    }
    else  {
        result.resize(rows() * dim, cols());
        if constexpr (MO == matrix_orient::column_major)  {
            for (size_type c { 0 }; c < cols(); ++c)
                for (size_type r { 0 }; r < rows(); ++r)
                    for (size_type d { 0 }; d < dim; ++d)
                        result(r * dim + d, c) = at(r, c)[d];
        }
        else  {
            for (size_type r { 0 }; r < rows(); ++r)
                for (size_type c { 0 }; c < cols(); ++c)
                    for (size_type d { 0 }; d < dim; ++d)
                        result(r * dim + d, c) = at(r, c)[d];
        }
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> &Matrix<T, MO, IS_SYM>::sqrt() noexcept  {

    Matrix  eigenvals;
    Matrix  eigenvecs;

    eigen_space(eigenvals, eigenvecs, false);
    eigenvals.ew_sqrt();  // Better not have negative values

    // Make it diagonal
    //
    Matrix  daig_vals { eigenvals.cols(), eigenvals.cols(), 0 };

    for (size_type i { 0 }; i < daig_vals.cols(); ++i)
        daig_vals(i, i) = eigenvals(0, i);

    const auto  result { eigenvecs * daig_vals * eigenvecs.transpose() };

    *this = result;
    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA>
MA &Matrix<T, MO, IS_SYM>::get_sqrt(MA &that) const noexcept  {

    that = *this;
    return (that.sqrt());
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
inline Matrix<T, MO, IS_SYM> &
Matrix<T, MO, IS_SYM>::whiten(bool do_center) noexcept  {

    if (do_center)  center();

    Matrix  eigenvals;
    Matrix  eigenvecs;

    covariance().eigen_space(eigenvals, eigenvecs, false);
    eigenvals.ew_sqrt();
    eigenvals.ew_inverse();

    // Make it diagonal
    //
    Matrix  daig_vals { eigenvals.cols(), eigenvals.cols(), 0 };

    for (size_type i { 0 }; i < daig_vals.cols(); ++i)
        daig_vals(i, i) = eigenvals(0, i);

    *this = *this * eigenvecs * daig_vals;
    return (*this);
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
template<typename MA>
MA &Matrix<T, MO, IS_SYM>::
get_whiten(MA &that, bool do_center) const noexcept  {

    that = *this;
    return (that.whiten(do_center));
}

// ----------------------------------------------------------------------------

template<typename T,  matrix_orient MO, bool IS_SYM>
Matrix<T, MO, IS_SYM> Matrix<T, MO, IS_SYM>::
get_random(size_type rows, size_type cols, T low, T high, unsigned int seed)
    requires std::floating_point<T>  {

    Matrix              result;
    RandGenParams<T>    rp;

    rp.min_value = low;
    rp.max_value = high;
    rp.seed = seed;
    result.rows_ = rows;
    result.cols_ = cols;
    if constexpr (IS_SYM)  {
        assert(rows == cols);
        result.matrix_ = gen_uniform_real_dist<T>((rows * (rows + 1)) / 2, rp);
    }
    else  {
        result.matrix_ = gen_uniform_real_dist<T>(rows * cols, rp);
    }

    return (result);
}

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline bool
operator != (const Matrix<T, MO1, IS_SYM1> &lhs,
             const Matrix<T, MO2, IS_SYM2> &rhs)  {

    if (lhs.rows() == rhs.rows() && lhs.cols() == rhs.cols())  {
        if constexpr (IS_SYM1 && IS_SYM2)  {
            if constexpr (MO1 == matrix_orient::column_major)  {
                for (long c { 0 }; c < lhs.cols(); ++c)
                    for (long r { c }; r < lhs.rows(); ++r)
                        if (lhs(r, c) != rhs(r, c))  return (true);
            }
            else  {
                for (long r { 0 }; r < lhs.rows(); ++r)
                    for (long c { r }; c < lhs.cols(); ++c)
                        if (lhs(r, c) != rhs(r, c))  return (true);
            }
        }
        else  {
            if constexpr (MO1 == matrix_orient::column_major)  {
                for (long c { 0 }; c < lhs.cols(); ++c)
                    for (long r { 0 }; r < lhs.rows(); ++r)
                        if (lhs(r, c) != rhs(r, c))  return (true);
            }
            else  {
                for (long r { 0 }; r < lhs.rows(); ++r)
                    for (long c { 0 }; c < lhs.cols(); ++c)
                        if (lhs(r, c) != rhs(r, c))  return (true);
            }
        }
    }
    else  return (true);

    return (false);
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline bool
operator == (const Matrix<T, MO1, IS_SYM1> &lhs,
             const Matrix<T, MO2, IS_SYM2> &rhs)  {

    return (! (lhs != rhs));
}

// ----------------------------------------------------------------------------

static constexpr long   HMDF_MAT_BLOCK = ThreadPool::CLINE_SIZE;

// ----------------------------------------------------------------------------

// Smallest m * k * n product for which the packed kernel beats the plain
// blocked loops (packing is O(n^2) overhead).
//
#ifndef HMDF_GEMM_MIN_WORK
#  define HMDF_GEMM_MIN_WORK 400'000L
#endif // HMDF_GEMM_MIN_WORK

// Packed, register-tiled matrix multiply, C += A * B, for the column range
// [j_begin, j_end) of C. The operands are copied into small contiguous panels
// (through the at() accessors, so any storage orientation, and symmetric
// storage, work), and an MR x NR block of C is accumulated in registers
// across the whole depth of the panel. This is what lets the compiler keep
// the multiply-add chain in vector registers instead of re-loading and
// re-storing C for every product, as the plain blocked loop must.
//
template<typename T, typename MA, typename MB, typename MC>
static inline void
_gemm_packed_(const MA &A, const MB &B, MC &C,
              long m, long k, long j_begin, long j_end)  {

    // An 8 x 4 block of C is 4 accumulator vectors of 8 doubles' worth of
    // lanes (or fewer registers for float): a tile that fits the register
    // file. A taller tile (16 rows) spills and runs about 8 times slower.
    //
    constexpr long  MR { 8 };
    constexpr long  NR { 4 };
    constexpr long  KC { 256 };
    constexpr long  MCB { 128 };  // A multiple of MR
    constexpr long  NC { 512 };

    std::vector<T>  a_pack(MCB * KC);
    std::vector<T>  b_pack(KC * NC);

    for (long jc { j_begin }; jc < j_end; jc += NC)  {
        const long  nc { std::min(NC, j_end - jc) };

        for (long pc { 0 }; pc < k; pc += KC)  {
            const long  kc { std::min(KC, k - pc) };

            // Pack B(pc:pc+kc, jc:jc+nc) into NR wide panels, zero padded
            //
            for (long j { 0 }; j < nc; j += NR)  {
                T   *dst { &b_pack[(j / NR) * KC * NR] };

                for (long p { 0 }; p < kc; ++p)
                    for (long t { 0 }; t < NR; ++t)
                        dst[p * NR + t] =
                            (j + t < nc) ? B(pc + p, jc + j + t) : T(0);
            }

            for (long ic { 0 }; ic < m; ic += MCB)  {
                const long  mc { std::min(MCB, m - ic) };

                // Pack A(ic:ic+mc, pc:pc+kc) into MR tall panels, zero padded
                //
                for (long i { 0 }; i < mc; i += MR)  {
                    T   *dst { &a_pack[(i / MR) * KC * MR] };

                    for (long p { 0 }; p < kc; ++p)
                        for (long u { 0 }; u < MR; ++u)
                            dst[p * MR + u] =
                                (i + u < mc) ? A(ic + i + u, pc + p) : T(0);
                }

                for (long j { 0 }; j < nc; j += NR)  {
                    const long  nr { std::min(NR, nc - j) };
                    const T     *bp { &b_pack[(j / NR) * KC * NR] };

                    for (long i { 0 }; i < mc; i += MR)  {
                        const long  mr { std::min(MR, mc - i) };
                        const T     *ap { &a_pack[(i / MR) * KC * MR] };
                        T           acc[NR][MR] = { };

                        for (long p { 0 }; p < kc; ++p)  {
                            const T *a { ap + p * MR };
                            const T *b { bp + p * NR };

                            for (long t { 0 }; t < NR; ++t)  {
                                const T bt { b[t] };

                                for (long u { 0 }; u < MR; ++u)
                                    acc[t][u] += a[u] * bt;
                            }
                        }

                        for (long t { 0 }; t < nr; ++t)
                            for (long u { 0 }; u < mr; ++u)
                                C(ic + i + u, jc + j + t) += acc[t][u];
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline typename std::conditional<IS_SYM1 && IS_SYM2,
                                        Matrix<T, MO1, true>,
                                        Matrix<T, MO1, false>>::type
operator + (const Matrix<T, MO1, IS_SYM1> &lhs,
            const Matrix<T, MO2, IS_SYM2> &rhs)  {

    using result_t =
        typename std::conditional<IS_SYM1 && IS_SYM2,
                                  Matrix<T, MO1, true>,
                                  Matrix<T, MO1, false>>::type;

    const long  lhs_rows { lhs.rows() };
    const long  lhs_cols { lhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (lhs_rows != rhs.rows() || lhs_cols != rhs.cols())
        throw NotFeasible("Incompatible matrix + matrix operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result;

    if constexpr (IS_SYM1 && (! IS_SYM2))  {
        result.resize(lhs.rows(), lhs.cols());
        for (long r { 0 }; r < lhs.rows(); ++r)
            for (long c { 0 }; c < lhs.cols(); ++c)
                result(r, c) = lhs(r, c);
    }
    else  {
        result = lhs;
    }

    auto        lbd__eq =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result.matrix_[i + j] += rhs.matrix_[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result.matrix_[i] += rhs.matrix_[i];
        };
    auto        col_lbd =
        [lhs_rows, &result, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long c { begin }; c < end; ++c)
                    for (long r { c }; r < lhs_rows; ++r)
                        result(r, c) += rhs(r, c);
            }
            else  {
                for (long c { begin }; c < end; ++c)
                    for (long r { 0 }; r < lhs_rows; ++r)
                        result(r, c) += rhs(r, c);
            }
        };
    auto        row_lbd =
        [lhs_cols, &result, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long r { begin }; r < end; ++r)
                    for (long c = r; c < lhs_cols; ++c)
                        result(r, c) += rhs(r, c);
            }
            else  {
                for (long r { begin }; r < end; ++r)
                    for (long c { 0 }; c < lhs_cols; ++c)
                        result(r, c) += rhs(r, c);
            }
        };
    const long  thread_level =
        (lhs_cols >= 2000L || lhs_rows >= 2000L)
            ? ThreadGranularity::get_thread_level() : 0;

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        if constexpr (MO1 == MO2 && IS_SYM1 == IS_SYM2)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, long(lhs.matrix_.size()), std::move(lbd__eq));
        else if constexpr (MO1 == matrix_orient::column_major)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_cols, std::move(col_lbd));
        else  // matrix_orient::row_major
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_rows, std::move(row_lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        if constexpr (MO1 == MO2 && IS_SYM1 == IS_SYM2)
            lbd__eq(0L, long(lhs.matrix_.size()));
        else if constexpr (MO1 == matrix_orient::column_major)
            col_lbd(0L, lhs_cols);
        else  // matrix_orient::row_major
            row_lbd(0L, lhs_rows);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline typename std::conditional<IS_SYM1 && IS_SYM2,
                                        Matrix<T, MO1, true>,
                                        Matrix<T, MO1, false>>::type
operator - (const Matrix<T, MO1, IS_SYM1> &lhs,
            const Matrix<T, MO2, IS_SYM2> &rhs)  {

    using result_t =
        typename std::conditional<IS_SYM1 && IS_SYM2,
                                  Matrix<T, MO1, true>,
                                  Matrix<T, MO1, false>>::type;

    const long  lhs_rows { lhs.rows() };
    const long  lhs_cols { lhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (lhs_rows != rhs.rows() || lhs_cols != rhs.cols())
        throw NotFeasible("Incompatible matrix - matrix operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result;

    if constexpr (IS_SYM1 && (! IS_SYM2))  {
        result.resize(lhs.rows(), lhs.cols());
        for (long r { 0 }; r < lhs.rows(); ++r)
            for (long c { 0 }; c < lhs.cols(); ++c)
                result(r, c) = lhs(r, c);
    }
    else  {
        result = lhs;
    }

    auto        lbd__eq =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result.matrix_[i + j] -= rhs.matrix_[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result.matrix_[i] -= rhs.matrix_[i];
        };
    auto        col_lbd =
        [lhs_rows, &result, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long c { begin }; c < end; ++c)
                    for (long r { c }; r < lhs_rows; ++r)
                        result(r, c) -= rhs(r, c);
            }
            else  {
                for (long c { begin }; c < end; ++c)
                    for (long r { 0 }; r < lhs_rows; ++r)
                        result(r, c) -= rhs(r, c);
            }
        };
    auto        row_lbd =
        [lhs_cols, &result, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long r { begin }; r < end; ++r)
                    for (long c { r }; c < lhs_cols; ++c)
                        result(r, c) -= rhs(r, c);
            }
            else  {
                for (long r { begin }; r < end; ++r)
                    for (long c { 0 }; c < lhs_cols; ++c)
                        result(r, c) -= rhs(r, c);
            }
        };
    const long  thread_level {
        (lhs_cols >= 2000L || lhs_rows >= 2000L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        if constexpr (MO1 == MO2 && IS_SYM1 == IS_SYM2)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, long(lhs.matrix_.size()), std::move(lbd__eq));
        else if constexpr (MO1 == matrix_orient::column_major)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_cols, std::move(col_lbd));
        else  // matrix_orient::row_major
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_rows, std::move(row_lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        if constexpr (MO1 == MO2 && IS_SYM1 == IS_SYM2)
            lbd__eq(0L, long(lhs.matrix_.size()));
        else if constexpr (MO1 == matrix_orient::column_major)
            col_lbd(0L, lhs_cols);
        else  // matrix_orient::row_major
            row_lbd(0L, lhs_rows);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
Matrix<T, MO1, IS_SYM1> &
operator += (Matrix<T, MO1, IS_SYM1> &lhs,
             const Matrix<T, MO2, IS_SYM2> &rhs)  {

    static_assert((IS_SYM1 && IS_SYM2) ||
                  ((! IS_SYM1) && IS_SYM2) ||
                  ((! IS_SYM1) && (! IS_SYM2)),
                  "Incompatible matrix += matrix operation");

    const long  lhs_rows { lhs.rows() };
    const long  lhs_cols { lhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (lhs_rows != rhs.rows() || lhs_cols != rhs.cols())
        throw NotFeasible("Incompatible matrix += matrix operation");
#endif // HMDF_SANITY_EXCEPTIONS

    auto        col_lbd =
        [lhs_rows, &lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long c { begin }; c < end; ++c)
                    for (long r { c }; r < lhs_rows; ++r)
                        lhs(r, c) += rhs(r, c);
            }
            else  {
                for (long c { begin }; c < end; ++c)
                    for (long r { 0 }; r < lhs_rows; ++r)
                        lhs(r, c) += rhs(r, c);
            }
        };
    auto        row_lbd =
        [lhs_cols, &lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long r { begin }; r < end; ++r)
                    for (long c { r }; c < lhs_cols; ++c)
                        lhs(r, c) += rhs(r, c);
            }
            else  {
                for (long r { begin }; r < end; ++r)
                    for (long c { 0 }; c < lhs_cols; ++c)
                        lhs(r, c) += rhs(r, c);
            }
        };
    const long  thread_level {
        (lhs_cols >= 2000L || lhs_rows >= 2000L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        if constexpr (MO1 == matrix_orient::column_major)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_cols, std::move(col_lbd));
        else  // matrix_orient::row_major
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_rows, std::move(row_lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        if constexpr (MO1 == matrix_orient::column_major)
            col_lbd(0L, lhs_cols);
        else  // matrix_orient::row_major
            row_lbd(0L, lhs_rows);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
Matrix<T, MO1, IS_SYM1> &
operator -= (Matrix<T, MO1, IS_SYM1> &lhs,
             const Matrix<T, MO2, IS_SYM2> &rhs)  {

    static_assert((IS_SYM1 && IS_SYM2) ||
                  ((! IS_SYM1) && IS_SYM2) ||
                  ((! IS_SYM1) && (! IS_SYM2)),
                  "Incompatible matrix -= matrix operation");

    const long  lhs_rows { lhs.rows() };
    const long  lhs_cols { lhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (lhs_rows != rhs.rows() || lhs_cols != rhs.cols())
        throw NotFeasible("Incompatible matrix -= matrix operation");
#endif // HMDF_SANITY_EXCEPTIONS

    auto        col_lbd =
        [lhs_rows, &lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long c { begin }; c < end; ++c)
                    for (long r { c }; r < lhs_rows; ++r)
                        lhs(r, c) -= rhs(r, c);
            }
            else  {
                for (long c { begin }; c < end; ++c)
                    for (long r { 0 }; r < lhs_rows; ++r)
                        lhs(r, c) -= rhs(r, c);
            }
        };
    auto        row_lbd =
        [lhs_cols, &lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (IS_SYM1 && IS_SYM2)  {
                for (long r { begin }; r < end; ++r)
                    for (long c { r }; c < lhs_cols; ++c)
                        lhs(r, c) -= rhs(r, c);
            }
            else  {
                for (long r { begin }; r < end; ++r)
                    for (long c { 0 }; c < lhs_cols; ++c)
                        lhs(r, c) -= rhs(r, c);
            }
        };
    const long  thread_level {
        (lhs_cols >= 2000L || lhs_rows >= 2000L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        if constexpr (MO1 == matrix_orient::column_major)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_cols, std::move(col_lbd));
        else  // matrix_orient::row_major
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_rows, std::move(row_lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        if constexpr (MO1 == matrix_orient::column_major)
            col_lbd(0L, lhs_cols);
        else  // matrix_orient::row_major
            row_lbd(0L, lhs_rows);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO, bool IS_SYM>
static Matrix<T, MO, false>
operator * (const std::vector<T> &lhs,
            const Matrix<T, MO, IS_SYM> &rhs)  {
    const long  lhs_cols { long(lhs.size()) };
    const long  rhs_cols { rhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (lhs_cols != rhs.rows())
        throw NotFeasible("Incompatible vector * matrix operation");
#endif // HMDF_SANITY_EXCEPTIONS

    Matrix<T, MO, false>    result { 1L, rhs_cols, 0 };
    const long              thread_level {
        (lhs_cols >= 400L || rhs_cols >= 400L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    // Each task owns a range of result columns. The loop nest is chosen so
    // that the innermost loop walks contiguous memory for either orientation:
    // a column-major matrix is read column by column (dot products), a
    // row-major one row by row (axpy into the result range).
    //
    auto    lbd =
        [lhs_cols, &result,
         &lhs = std::as_const(lhs), &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (long c { begin }; c < end; ++c)  {
                    T   sum { 0 };

                    for (long k { 0 }; k < lhs_cols; ++k)
                        sum += lhs[k] * rhs(k, c);
                    result(0, c) = sum;
                }
            }
            else  {
                for (long k { 0 }; k < lhs_cols; ++k)  {
                    const T lk { lhs[k] };

                    for (long c { begin }; c < end; ++c)
                        result(0, c) += lk * rhs(k, c);
                }
            }
        };

    if (thread_level > 2)  {
        auto    futures {
            ThreadGranularity::thr_pool_.parallel_loop<T>(
                0L, rhs_cols, std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, rhs_cols);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO, bool IS_SYM>
static Matrix<T, MO, false>
operator * (const Matrix<T, MO, IS_SYM> &lhs,
            const std::vector<T> &rhs)  {

    const long  lhs_rows { lhs.rows() };
    const long  lhs_cols { lhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (lhs_cols != long(rhs.size()))
        throw NotFeasible("Incompatible matrix * vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    Matrix<T, MO, false>    result { lhs_rows, 1L, 0 };
    const long              thread_level {
        (lhs_cols >= 400L || lhs_rows >= 400L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    // Each task owns a range of result rows. For a column-major matrix the
    // old code computed one strided dot product per row (a cache miss per
    // element). Here the matrix is read column by column, the result range
    // is updated in place, and the summation order per row stays the same.
    //
    auto    lbd =
        [lhs_cols, &result,
         &lhs = std::as_const(lhs), &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            if constexpr (MO == matrix_orient::column_major)  {
                for (long k { 0 }; k < lhs_cols; ++k)  {
                    const T rk { rhs[k] };

                    for (long r { begin }; r < end; ++r)
                        result(r, 0) += lhs(r, k) * rk;
                }
            }
            else  {
                for (long r { begin }; r < end; ++r)  {
                    T   sum { 0 };

                    for (long k { 0 }; k < lhs_cols; ++k)
                        sum += lhs(r, k) * rhs[k];
                    result(r, 0) = sum;
                }
            }
        };

    if (thread_level > 2)  {
        auto    futures {
            ThreadGranularity::thr_pool_.parallel_loop<T>(
                0L, lhs_rows, std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_rows);
    }

    return (result);
}

// ----------------------------------------------------------------------------

// Naïve but cache friendly O(n^3) algorithm
//
template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static Matrix<T, MO1, false>
operator * (const Matrix<T, MO1, IS_SYM1> &lhs,
            const Matrix<T, MO2, IS_SYM2> &rhs)  {

    const long  lhs_rows { lhs.rows() };
    const long  lhs_cols { lhs.cols() };
    const long  rhs_cols { rhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (lhs_cols != rhs.rows())
        throw NotFeasible("Incompatible matrix * matrix operation");
#endif // HMDF_SANITY_EXCEPTIONS

    Matrix<T, MO1, false>   result { lhs_rows, rhs_cols, 0 };

    // Floating point matrices of any real size take the packed register-tiled
    // kernel. It is typically two to three times faster than the loop nest
    // below. Everything else (and tiny products, where packing does not pay)
    // keeps the generic loops.
    //
    if constexpr (std::is_floating_point_v<T>)  {
        if (lhs_rows >= 8 && rhs_cols >= 4 && lhs_cols >= 16 &&
            lhs_rows * lhs_cols * rhs_cols >= HMDF_GEMM_MIN_WORK)  {
            const long  big_thr {
                ((lhs_rows * lhs_cols * rhs_cols) >= 10'000'000L)
                    ? ThreadGranularity::get_thread_level() : 0
            };
            auto        pbd =
                [lhs_rows, lhs_cols, &result,
                 &lhs = std::as_const(lhs), &rhs = std::as_const(rhs)]
                (auto begin, auto end) -> void  {
                    _gemm_packed_<T>(lhs, rhs, result,
                                     lhs_rows, lhs_cols,
                                     long(begin), long(end));
                };

            if (big_thr > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<T>(
                        0L, rhs_cols, std::move(pbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else
                pbd(0L, rhs_cols);

            return (result);
        }
    }

    const long  thread_level {
        (lhs_cols >= 600L || rhs_cols >= 600L)
            ? ThreadGranularity::get_thread_level() : 0
    };
    auto        col_lbd =
        [lhs_rows, lhs_cols, &result,
         &lhs = std::as_const(lhs), &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            for (long rc { begin }; rc < end; rc += HMDF_MAT_BLOCK) {
                for (long lc { 0 }; lc < lhs_cols; lc += HMDF_MAT_BLOCK) {
                    for (long r { 0 }; r < lhs_rows; r += HMDF_MAT_BLOCK) {
                        const long  r_max {
                            std::min(r + HMDF_MAT_BLOCK, lhs_rows)
                        };
                        const long  rc_max {
                            std::min(rc + HMDF_MAT_BLOCK, end)
                        };
                        const long  lc_max {
                            std::min(lc + HMDF_MAT_BLOCK, lhs_cols)
                        };

                        for (long rr { rc }; rr < rc_max; ++rr) {
                            for (long cc { lc }; cc < lc_max; ++cc) {
                                const T val { rhs(cc, rr) };

#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                                for (long i { r }; i < r_max; ++i)
                                    result(i, rr) += lhs(i, cc) * val;
                            }
                        }
                    }
                }
            }
        };
    auto        row_lbd =
        [lhs_cols, rhs_cols, &result,
         &lhs = std::as_const(lhs), &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            for (long r { begin }; r < end; r += HMDF_MAT_BLOCK) {
                for (long c { 0 }; c < rhs_cols; c += HMDF_MAT_BLOCK) {
                    for (long k { 0 }; k < lhs_cols; k += HMDF_MAT_BLOCK) {
                        const long  r_max { std::min(r + HMDF_MAT_BLOCK, end) };
                        const long  c_max {
                            std::min(c + HMDF_MAT_BLOCK, rhs_cols)
                        };
                        const long  k_max {
                            std::min(k + HMDF_MAT_BLOCK, lhs_cols)
                        };

                        for (long rr { r }; rr < r_max; ++rr) {
                            for (long kk { k }; kk < k_max; ++kk) {
                                const T val { lhs(rr, kk) };

#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                                for (long j { c }; j < c_max; ++j)
                                    result(rr, j) += val * rhs(kk, j);
                            }
                        }
                    }
                }
            }
        };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        if constexpr (MO1 == matrix_orient::column_major)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, rhs_cols, std::move(col_lbd));
        else  // matrix_orient::row_major
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, lhs_rows, std::move(row_lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        if constexpr (MO1 == matrix_orient::column_major)
            col_lbd(0L, rhs_cols);
        else  // matrix_orient::row_major
            row_lbd(0L, lhs_rows);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static Matrix<T, MO1, false>
hadamard(const Matrix<T, MO1, IS_SYM1> &lhs,
         const Matrix<T, MO2, IS_SYM2> &rhs)  {

    const long  rows { lhs.rows() };
    const long  cols { lhs.cols() };

#ifdef HMDF_SANITY_EXCEPTIONS
    if (cols != rhs.cols() || rows != rhs.rows())
        throw NotFeasible("Incompatible matrices for Hadamard multiplication");
#endif // HMDF_SANITY_EXCEPTIONS

    Matrix<T, MO1, false>   result { rows, cols, 0 };
    const long              thread_level {
        (cols >= 500L || rows >= 500L)
            ? ThreadGranularity::get_thread_level() : 0
    };

    auto    col_lbd =
        [rows, &result, &lhs = std::as_const(lhs), &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            for (long c { begin }; c < end; ++c)
                for (long r { 0 }; r < rows; ++r)
                    result(r, c) = lhs(r, c) * rhs(r, c);
        };
    auto    row_lbd =
        [cols, &result, &lhs = std::as_const(lhs), &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            for (long r { begin }; r < end; ++r)
                for (long c { 0 }; c < cols; ++c)
                    result(r, c) = lhs(r, c) * rhs(r, c);
        };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        if constexpr (MO1 == matrix_orient::column_major)
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, cols, std::move(col_lbd));
        else  // matrix_orient::row_major
            futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                          0L, rows, std::move(row_lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        if constexpr (MO1 == matrix_orient::column_major)
            col_lbd(0L, cols);
        else  // matrix_orient::row_major
            row_lbd(0L, rows);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator + (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    using result_t = std::vector<T, A1>;

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector + vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] += rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] += rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator - (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    using result_t = std::vector<T, A1>;

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector - vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] -= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] -= rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator * (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    using result_t = std::vector<T, A1>;

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector * vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] *= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] *= rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator / (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    using result_t = std::vector<T, A1>;

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector / vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] /= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] /= rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator + (const std::vector<T, A> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::vector<T, A>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  lhs_size { long(lhs.size()) };

    if (N != lhs_size)
        throw NotFeasible("Incompatible vector + array operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] += rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] += rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator - (const std::vector<T, A> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::vector<T, A>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  lhs_size { long(lhs.size()) };

    if (N != lhs_size)
        throw NotFeasible("Incompatible vector - array operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] -= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] -= rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator * (const std::vector<T, A> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::vector<T, A>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  lhs_size { long(lhs.size()) };

    if (N != lhs_size)
        throw NotFeasible("Incompatible vector * array operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] *= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] *= rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator / (const std::vector<T, A> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::vector<T, A>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  lhs_size { long(lhs.size()) };

    if (N != lhs_size)
        throw NotFeasible("Incompatible vector / array operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] /= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] /= rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator + (const std::array<T, N> &lhs, const std::vector<T, A> &rhs)  {

    using result_t = std::array<T, N>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (N != rhs_size)
        throw NotFeasible("Incompatible array + vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] += rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] += rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator - (const std::array<T, N> &lhs, const std::vector<T, A> &rhs)  {

    using result_t = std::array<T, N>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (N != rhs_size)
        throw NotFeasible("Incompatible array - vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] -= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] -= rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator * (const std::array<T, N> &lhs, const std::vector<T, A> &rhs)  {

    using result_t = std::array<T, N>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (N != rhs_size)
        throw NotFeasible("Incompatible array * vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] *= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] *= rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator / (const std::array<T, N> &lhs, const std::vector<T, A> &rhs)  {

    using result_t = std::array<T, N>;

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (N != rhs_size)
        throw NotFeasible("Incompatible array / vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] /= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] /= rhs[i];
        };
    const long      thread_level {
        N >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, long(N), std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, long(N));
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator += (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector += vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] += rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] += rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator -= (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector -= vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] -= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] -= rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator *= (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector *= vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] *= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] *= rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator /= (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs)  {

    const long  lhs_size { long(lhs.size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
    const long  rhs_size { long(rhs.size()) };

    if (lhs_size != rhs_size)
        throw NotFeasible("Incompatible vector /= vector operation");
#endif // HMDF_SANITY_EXCEPTIONS

    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] /= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] /= rhs[i];
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}


// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator + (const std::vector<T, A> &lhs, T rhs)  {

    using result_t = std::vector<T, A>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] += rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] += rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator - (const std::vector<T, A> &lhs, T rhs)  {

    using result_t = std::vector<T, A>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] -= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] -= rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator * (const std::vector<T, A> &lhs, T rhs)  {

    using result_t = std::vector<T, A>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] *= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] *= rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator / (const std::vector<T, A> &lhs, T rhs)  {

    using result_t = std::vector<T, A>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] /= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] /= rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator + (T lhs, const std::vector<T, A> &rhs)  { return (rhs + lhs); }

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator - (T lhs, const std::vector<T, A> &rhs)  {

    using result_t = std::vector<T, A>;

    const long      rhs_size { long(rhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { rhs };
    auto            lbd =
        [&result, lhs](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)  {
                    auto    &val { result[i + j] };

                    val = lhs - val;
                }
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)  {
                auto    &val { result[i] };

                val = lhs - val;
            }
        };
    const long      thread_level {
        rhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        auto    futures {
            ThreadGranularity::thr_pool_.parallel_loop<T>(
                  0L, rhs_size, std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, rhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator * (T lhs, const std::vector<T, A> &rhs)  { return (rhs * lhs); }

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A>
operator / (T lhs, const std::vector<T, A> &rhs)  {

    using result_t = std::vector<T, A>;

    const long      rhs_size { long(rhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { rhs };
    auto            lbd =
        [&result, lhs](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)  {
                    auto    &val { result[i + j] };

                    val = lhs / val;
                }
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)  {
                auto    &val { result[i] };

                val = lhs / val;
            }
        };
    const long      thread_level {
        rhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        auto    futures {
            ThreadGranularity::thr_pool_.parallel_loop<T>(
                  0L, rhs_size, std::move(lbd))
        };

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, rhs_size);
    }

    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A> &
operator += (std::vector<T, A> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] += rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] += rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A> &
operator -= (std::vector<T, A> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] -= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] -= rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A> &
operator *= (std::vector<T, A> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] *= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] *= rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, typename A>
static inline
std::vector<T, A> &
operator /= (std::vector<T, A> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] /= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] /= rhs;
        };
    const long      thread_level {
        lhs_size >= ThreadPool::MUL_THR_THHOLD
            ? ThreadGranularity::get_thread_level() : 0
    };

    if (thread_level > 2)  {
        std::vector<std::future<void>>  futures;

        futures = ThreadGranularity::thr_pool_.parallel_loop<T>(
                      0L, lhs_size, std::move(lbd));

        for (auto &fut : futures)  fut.get();
    }
    else  {
        lbd(0L, lhs_size);
    }

    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator + (const std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] += rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] += rhs[i];
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator - (const std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] -= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] -= rhs[i];
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator * (const std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] *= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] *= rhs[i];
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator / (const std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] /= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] /= rhs[i];
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator += (std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] += rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] += rhs[i];
        };

    lbd(0L, lhs_size);
    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator -= (std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] -= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] -= rhs[i];
        };

    lbd(0L, lhs_size);
    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator *= (std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] *= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] *= rhs[i];
        };

    lbd(0L, lhs_size);
    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator /= (std::array<T, N> &lhs, const std::array<T, N> &rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] /= rhs[i + j];
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] /= rhs[i];
        };

    lbd(0L, lhs_size);
    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator + (const std::array<T, N> &lhs, T rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] += rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] += rhs;
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator - (const std::array<T, N> &lhs, T rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] -= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] -= rhs;
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator * (const std::array<T, N> &lhs, T rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] *= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] *= rhs;
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator / (const std::array<T, N> &lhs, T rhs)  {

    using result_t = std::array<T, N>;

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { lhs };
    auto            lbd =
        [&result, &rhs = std::as_const(rhs)](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    result[i + j] /= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                result[i] /= rhs;
        };

    lbd(0L, lhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator + (T lhs, const std::array<T, N> &rhs)  { return (rhs + lhs); }

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator - (T lhs, const std::array<T, N> &rhs)  {

    using result_t = std::array<T, N>;

    const long      rhs_size { long(rhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { rhs };
    auto            lbd =
        [&result, lhs](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)  {
                    auto    &val { result[i + j] };

                    val = lhs - val;
                }
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)  {
                auto    &val { result[i] };

                val = lhs - val;
            }
        };

    lbd(0L, rhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator * (T lhs, const std::array<T, N> &rhs)  { return (rhs * lhs); }

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N>
operator / (T lhs, const std::array<T, N> &rhs)  {

    using result_t = std::array<T, N>;

    const long      rhs_size { long(rhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    result_t        result { rhs };
    auto            lbd =
        [&result, lhs](auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)  {
                    auto    &val { result[i + j] };

                    val = lhs / val;
                }
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)  {
                auto    &val { result[i] };

                val = lhs / val;
            }
        };

    lbd(0L, rhs_size);
    return (result);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator += (std::array<T, N> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] += rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] += rhs;
        };

    lbd(0L, lhs_size);
    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator -= (std::array<T, N> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] -= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] -= rhs;
        };

    lbd(0L, lhs_size);
    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator *= (std::array<T, N> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] *= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] *= rhs;
        };

    lbd(0L, lhs_size);
    return (lhs);
}

// ----------------------------------------------------------------------------

template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator /= (std::array<T, N> &lhs, T rhs)  {

    const long      lhs_size { long(lhs.size()) };
    constexpr long  block_s { HMDF_MAT_BLOCK / sizeof(T) };
    auto            lbd =
        [&lhs = lhs, &rhs = std::as_const(rhs)]
        (auto begin, auto end) -> void  {
            long    i { begin };

            for (; (i + block_s) < end; i += block_s)  {
#pragma GCC ivdep
#pragma clang loop vectorize(enable)
#pragma omp simd
                for (long j { 0 }; j < block_s; ++j)
                    lhs[i + j] /= rhs;
            }

            // Handle remaining elements
            //
            for (; i < end; ++i)
                lhs[i] /= rhs;
        };

    lbd(0L, lhs_size);
    return (lhs);
}

} // namespace hmdf

// ----------------------------------------------------------------------------

// Local Variables:
// mode:C++
// tab-width:4
// c-basic-offset:4
// End:
