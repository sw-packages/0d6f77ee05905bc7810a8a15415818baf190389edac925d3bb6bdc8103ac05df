// Hossein Moein
// November 7, 2024
/*
Copyright (c) 2019-2026, Hossein Moein
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
* Neither the name of Hossein Moein and/or the DataFrame nor the
  names of its contributors may be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Hossein Moein BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include <DataFrame/DataFrameTypes.h>
#include <DataFrame/Utils/Concepts.h>
#include <DataFrame/Utils/MetaProg.h>
#include <DataFrame/Utils/Threads/ThreadGranularity.h>

#include <functional>
#include <vector>

// ----------------------------------------------------------------------------

namespace hmdf
{

enum class  matrix_orient : unsigned char  {

    column_major = 1,
    row_major = 2,
};

// ----------------------------------------------------------------------------

template<typename T,
         matrix_orient MO = matrix_orient::column_major,
         bool IS_SYM = false>
class   Matrix  {

public:

    using size_type = long;
    using value_type = T;
    using reference = value_type &;
    using const_reference = const value_type &;
    using pointer = value_type *;
    using const_pointer = const value_type *;
    using self_t = Matrix<value_type, MO, IS_SYM>;

    // Is matrix data multidimensional
    //
    inline static constexpr bool    IS_MD { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! IS_MD,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    using scalar_ma_t = Matrix<data_t, MO, IS_SYM>;
    using non_sym_ma_t = Matrix<T, MO, false>;
    using trans_result_t =
        typename std::conditional<
            MO == matrix_orient::column_major,
            Matrix<T, matrix_orient::row_major, IS_SYM>,
            Matrix<T, matrix_orient::column_major, IS_SYM>>::type;

    Matrix() = default;
    Matrix(size_type rows, size_type cols, const_reference def_v = T());
    Matrix(const Matrix &) = default;
    Matrix(Matrix &&) = default;
    ~Matrix() = default;
    Matrix &operator =(const Matrix &) = default;
    Matrix &operator =(Matrix &&) = default;

    template<typename M2>
    Matrix &operator =(const M2 &lhs);

    void clear() noexcept;
    void swap(Matrix &rhs) noexcept;
    [[nodiscard]] bool empty() const noexcept;
    void reserve(size_type rows, size_type cols);

    [[nodiscard]] size_type rows() const noexcept;
    [[nodiscard]] size_type cols() const noexcept;

    static constexpr matrix_orient orientation();

public:

    void resize(size_type rows, size_type cols, const_reference def_v = T());

    [[nodiscard]] reference at(size_type r, size_type c);
    [[nodiscard]] const_reference at(size_type r, size_type c) const;
    [[nodiscard]] reference operator()(size_type r, size_type c);
    [[nodiscard]] const_reference operator()(size_type r, size_type c) const;

    [[nodiscard]] reference operator[](size_type r, size_type c);
    [[nodiscard]] const_reference operator[](size_type r, size_type c) const;

    // This returns another matrix with top n-rows and n-columns of self.
    // Rows starts at top (index 0) and columns start at left (index 0).
    //
    [[nodiscard]] Matrix corner(size_type nrows, size_type ncols) const;

    // Set the given column or row from the given iterator.
    // col_data/row_Data iterators must be valid for the length of
    // columns/rows.
    //
    template<typename I>
    void set_column(I col_data, size_type col);

    template<typename I>
    void set_row(I row_data, size_type row);

    // They return requested row or column in std::vector
    //
    [[nodiscard]]
    std::vector<value_type> get_column_vec(size_type col) const noexcept;
    [[nodiscard]]
    std::vector<value_type> get_row_vec(size_type row) const noexcept;

    // It returns requested column in a one-column matrix
    //
    [[nodiscard]]
    non_sym_ma_t get_column_mat(size_type col) const noexcept;

    // It returns requested row in a one-row matrix
    //
    [[nodiscard]]
    non_sym_ma_t get_row_mat(size_type row) const noexcept;

    [[nodiscard]] bool is_square() const noexcept;

    // A matrix is either structurally symmetric (IS_SYM is true) or the data
    // in the matrix is symmetric. In both cases this returns true.
    //
    [[nodiscard]] bool is_symmetric() const noexcept;

    [[nodiscard]] trans_result_t transpose() const noexcept;
    [[nodiscard]] Matrix transpose2() const noexcept;

    // Inverse(A) * A = A * Inverse(A) = I
    //
    // Also:
    //                       1
    //   Inverse(A) = ---------------- * Adjoint(A)
    //                 Determinant(A)
    //
    [[nodiscard]] Matrix inverse() const;

    // It multiplies all elements by factor
    //
    Matrix &self_scale(value_type factor) noexcept;
    [[nodiscard]] Matrix scale(value_type factor) const noexcept;

    // It applies the function to all elements. There is no particular or
    // guaranteed order to the function application.
    // This is a more general form of above scale().
    //
    Matrix &self_apply(std::function<value_type (const value_type &)> &&fn);
    [[nodiscard]]
    Matrix apply(std::function<value_type (const value_type &)> &&fn) const;

    // Row Reduced Echelon Form:
    // A matrix that has undergone Gaussian elimination is said to be in
    // row reduced echelon form.
    // Such a matrix has the following characteristics:
    // 1. All zero rows are at the bottom of the matrix
    // 2. The leading entry of each nonzero row occurs to the right of the
    //    leading entry of the previous row.
    // 3. The leading entry in any nonzero row is 1.
    // 4. All entries in the column above and below a leading 1 are zero.
    //
    // RREF is an important technique in solving simultaneous equations and
    // finding the rank of a matrix.
    //
    inline Matrix &rref(size_type &rank) noexcept;
    inline Matrix &rref(Matrix &that, size_type &rank) const noexcept;

    // Frobenius Norm:
    // The Frobenius norm of a matrix is the square root of the sum of
    // the squares of the values of the elements of the matrix.
    //
    [[nodiscard]] value_type norm() const noexcept;

    // Mean of the entire values in the matrix
    //
    [[nodiscard]] value_type mean() const noexcept;

    // Degree matrix is a square diagonal matrix where each diagonal value
    // represents the number of connections in a row of an adjacency matrix.
    //
    // Adjacency matrix (ADJ) is a square matrix that represents a connected
    // graph. A none zero value at i, j in an ADJ means there is an edge
    // between vertices i and j. ADJ may contain only 0s and 1s indicating
    // absence or presence of edges between vertices. Or it may contain real
    // numbers which are the weights of edges between vertices. A 0 weight
    // means there is no edge.
    //
    // degree_matrix() assumes self is an Adjacency matrix.
    //
    [[nodiscard]] Matrix degree_matrix() const;

    // A Laplacian matrix is a square matrix that represents a graph, where
    // each entry signifies the relationship between vertices based on their
    // connections, essentially showing how much a vertex differs from its
    // neighbors, and is calculated by subtracting the adjacency matrix from
    // the degree matrix of the graph; it's often used in graph theory and
    // related fields like machine learning to analyze graph properties and
    // structure based on its eigenvalues and eigenvectors.
    //
    // laplacian_matrix() assumes self is an Adjacency matrix.
    //
    [[nodiscard]] Matrix laplacian_matrix() const;

    // Variance/Covariance matrix.
    // The columns of the matrix are assumed to be observations of some
    // random variable. So the covariance matrix is a square matrix
    // containing the covariances of the above random variables.
    //
    // If it is unbiased the estimate is divided by n - 1, otherwise by n,
    // n being the number of rows.
    //
    // The reason for dividing by n - 1 is because we are dividing by
    // degrees of freedom (i.e. number of independent observations).
    // For example, if we have two observations, when calculating the mean
    // we have two independent observations; however, when calculating the
    // variance, we have only one independent observation, since the two
    // observations are equally distant from the mean.
    //
    // NOTE: This works with both scalar and multidimensional (MD),
    //       vectors and arrays, data.
    //
    // For a nXm scalar matrix, you will get a mXm covariance matrix.
    // For a nXm MD matrix you will get a m*dXm*d matrix, where d is the
    // dimensionality of data
    //
    [[nodiscard]] scalar_ma_t
    covariance(bool is_unbiased = true) const;

    // Let A be an nXn matrix. The number l is an eigenvalue of A if there
    // exists a non-zero vector v such that
    //     Av = lv
    // In this case, vector v is called an eigenvector of A corresponding
    // to l. For each eigenvalue l, the set of all vectors v satisfying
    // Av = lv is called the eigenspace of A corresponding to l.
    //
    // Putting it in more laymen's term:
    //
    // Place a coin on its side and set it spinning. Take some butter and
    // spread it over a slice of bread. Pick up an elastic band and stretch
    // it. In each of these cases we do something that affects the shape or
    // orientation of the object in question. The elastic band and butter
    // have been deformed and the coin has been rotated.
    // When we investigate transformations mathematically we find that there
    // are directions that remain the same after the deformation has
    // occurred. In the case of the stretching of the elastic band, if you
    // had drawn an arrow on the band before you stretched it, would it
    // point in the same direction afterwards? The answer depends on how
    // you drew the original arrow. The transformation preserves the
    // direction in which you stretch the band but some other arrows have
    // their direction changed. The preserved direction is called an
    // EIGENVECTOR of the transformation and the associated amount by which
    // it has been stretched is an EIGENVALUE.
    // Eigenvalues are multipliers. They are numbers that represent how much
    // stretching has taken place or, in other words, how much something has
    // been scaled up by. In the sentence 'I am 3.2 times taller than when
    // I was born' the number 3.2 is acting as an eigenvalue.
    // To make sense of an eigenvalue it must have an associated 'operation'
    // (the transformation that has occurred) and an associated 'direction'
    // (the eigenvector). It doesn't mean anything by itself to say that 3.2
    // is an eigenvalue. You need to know the operation 'enlarged' and the
    // direction 'up' to say that I am now 3.2 times bigger in the
    // up-direction!
    // If you rotate a coin by 360 degrees you preserve all directions and
    // so each direction is an eigenvector. Because no stretching has
    // occurred, all of these eigenvectors have eigenvalue 1. Rotating the
    // coin by 60 degrees destroys all directions and this transformation
    // has no eigenvectors or eigenvalues at all. Careful spreading of
    // butter on bread, by moving the knife in one direction only, is a
    // transformation with an eigenvector in the direction of spreading.
    // The associated eigenvalue depends on how far the butter is spread.
    // The elastic band has an eigenvector in the left-right direction
    // because that arrow still points in that direction after the
    // transformation. The band has been stretched by approximately the same
    // amount that I have grown since I was born - so the eigenvector has
    // eigenvalue 3.2!
    // The idea of eigenvalues and eigenvectors can be extended to any
    // operator H. (H might be 'rotate by 360 degrees' or 'stretch in
    // direction of y-axis' or operators in Quantum theory or elsewhere).
    // We write H(x) to mean 'the action of H on x'. (So x might be a
    // particular vector that we are rotating or stretching or it might be a
    // quantum state or some other object). If we can find an object x and a
    // number k so that the following equation is true:
    //     H(x) = k * x
    // Then we know that x has been preserved by H apart from a scalar
    // multiplier k. It is k times bigger than what it was before H acted
    // upon it. Therefore we call x an eigenvector of H with eigenvalue k.
    //
    //
    // This method finds all the eigenvalues and eigenvectors.
    // If matrix is symmetric:
    //     first tridiagonalize, then diagonalize.
    // else:
    //     reduce to Hessenberg form, then reduce to real Schur form.
    //
    // If sort_values is true, eigen values are sorted in ascending order
    //
    template<typename MA1, typename MA2>
    void eigen_space(MA1 &eigenvalues,
                     MA2 &eigenvectors,
                     bool sort_values) const;

    // In linear algebra, the Singular Value Decomposition (SVD) is an
    // important factorization of a rectangular real or complex matrix,
    // with several applications in signal processing and statistics.
    // Applications which employ the SVD include computing the
    // pseudoinverse, matrix approximation, and determining the rank,
    // range and null space of a matrix.
    //
    // Suppose M is an mXn matrix whose entries come from the field K,
    // which is either the field of real numbers or the field of complex
    // numbers. Then there exists a factorization of the form
    //     M = U*Σ*~V
    //
    // where U is an mXm unitary matrix over K, the matrix Σ is mXn
    // with nonnegative numbers on the diagonal (as defined for a
    // rectangular matrix) and zeros off the diagonal, and ~V denotes the
    // conjugate transpose of V (transpose of V in case of real matrices),
    // an nXn unitary matrix over K. Such a factorization is called a
    // Singular Value Decomposition of M.
    //
    //  -- The matrix V thus contains a set of orthonormal "input" or
    //     "analysing" basis vector directions for M
    //  -- The matrix U contains a set of orthonormal "output" basis vector
    //     directions for M
    //  -- The matrix Σ contains the singular values, which can be thought
    //     of as scalar "gain controls" by which each corresponding input
    //     is multiplied to give a corresponding output.
    //
    // A common convention is to order the values Σi,i in non-increasing
    // fashion. In this case, the diagonal matrix Σ is uniquely determined
    // by M (though the matrices U and V are not).
    //
    template<typename MA1, typename MA2, typename MA3>
    inline void svd(MA1 &U, MA2 &S, MA3 &V, bool full_size = true) const;

    // In linear algebra, the LU decomposition is a matrix decomposition
    // which writes a matrix as the product of a lower and upper triangular
    // amtrices. This decomposition is used in numerical analysis to solve
    // systems of linear equations or calculate the determinant.
    //
    // LU decomposition of a square matrix A is a decomposition of A as
    //     A = LU
    //
    // where L and U are lower and upper triangular matrices (of the same
    // size), respectively. This means that L has only zeros above the
    // diagonal and U has only zeros below the diagonal.
    //
    // The LU decomposition is twice as efficient as the QR decomposition.
    //
    // NOTE: The LU decompostion with pivoting always exists, even if the
    //       matrix is singular. The primary use of the LU decomposition is
    //       in the solution of square systems of simultaneous linear
    //       equations. This will fail if is_singular() returns false.
    //
    template<typename MA1, typename MA2>
    inline void lud(MA1 &L, MA2 &U) const;

    // LDLT factorization is a matrix decomposition that expresses a real
    // symmetric matrix S as the product of a lower unit triangular matrix
    // L, a diagonal matrix D, and the transpose of lower triangular matrix
    // L^T. This decomposition is computationally efficient and useful for
    // determining the definiteness of a matrix, as the signs of the diagonal
    // entries in D indicate whether the matrix is positive definite, negative
    // definite, or indefinite. It is often called the "square-root-free
    // Cholesky decomposition" because it achieves a similar result without
    // the square roots required in the standard Cholesky method.
    //
    // The LDLT factorization is particularly useful for solving linear
    // systems and for determining the definiteness of a symmetric matrix
    // without a full eigenspace calculation.
    //
    template<typename MA>
    inline void ldlt(std::vector<value_type> &D, MA &L) const;

    // Solve the simultaneous equation Ax = rhs by Gaussian elimination.
    // It returns the x vector.
    // MA can be either a matrix of one column or a std::vector.
    //
    template<typename MA>
    [[nodiscard]] inline non_sym_ma_t solve(const MA &rhs) const;
    [[nodiscard]] inline non_sym_ma_t solve() const; // rhs is the last column

    // In 2-D, when you talk about the point (2, 4), you can think of the
    // 2 and 4 as directions to get from the origin to the point
    // (move 2 units in the x direction and 4 in the y direction).  In
    // a 3-D system, the same idea holds - (1, 3, 7) means start at the
    // origin (0, 0, 0), go 1 unit in the x direction, 3 in the y direction,
    // and 7 in the z direction.
    // The determinant of a 1x1 matrix is the signed length of the line
    // from the origin to the point. It's positive if the point is in the
    // positive x direction, negative if in the other direction.
    // In 2-D, look at the matrix as two 2-dimensional points on the plane,
    // and complete the parallelogram that includes those two points and
    // the origin. The (signed) area of this parallelogram is the
    // determinant.  If you sweep clockwise from the first to the second,
    // the determinant is negative, otherwise, positive.
    // In 3-D, look at the matrix as 3 3-dimensional points in space.
    // Complete the parallepipe that includes these points and the origin,
    // and the determinant is the (signed) volume of the parallelepipe.
    // The same idea works in any number of dimensions.  The determinant
    // is just the (signed) volume of the n-dimensional parallelepipe.
    // Note that length, area, volume are the _volumes_ in 1, 2, and
    // 3-dimensional spaces.  A similar concept of volume exists for
    // Euclidean space of any dimensionality.
    //
    // [HM]: A matrix that has determinant equals zero is singular.
    //       It means it has at least 2 vectors that are linearly
    //       dependent, therefore they cannot enclose an area or a space.
    //
    // For how determinant of N X N matrices are calulated
    //     see: http://mathworld.wolfram.com/Determinant.html
    // For Laplace Expension
    //     see: http://en.wikipedia.org/wiki/Cofactor_expansion
    //
    // NOTE: This is a relatively _expensive_ calculation. Its complexity
    //       is O(n^3), where n is the number of rows or columns.
    //
    [[nodiscard]] inline value_type determinant() const;

    // Minor of a matrix is the same matrix with the specified row
    // and column taken out.
    //
    // NOTE: Linear algebrically speaking, a minor of a matrix is the
    //       _detereminant_ of some smaller square matrix, cut down from
    //       the original matrix.
    //
    template<typename MA>
    inline MA &
    get_minor(MA &mmatrix, size_type drow, size_type dcol) const noexcept;

    // A Cofactor of a matrix is the determinant of a minor of the matrix.
    // You can also say cofactor is the signed minor of the matrix.
    //
    [[nodiscard]]
    inline value_type cofactor(size_type row, size_type column) const;

    // The Adjoint of a matrix is formed by taking the transpose of the
    // cofactors matrix of the original matrix.
    //
    template<typename MA>
    inline MA &adjoint(MA &amatrix) const;

    // A "centered matrix" is a matrix where the mean of each column has been
    // adjusted to be zero, meaning that the data within each column is
    // centered around the value of zero
    //
    inline void center() noexcept;
    template<typename MA>
    inline void get_centered(MA &cmatrix) const noexcept;

    // The square root of a matrix, in the context of linear algebra, is
    // another matrix that, when multiplied by itself, results in the original
    // matrix. It's not simply element-wise square rooting. It's a more
    // involved process involving techniques like diagonalization or
    // Cholesky decomposition.
    // NOTE: Matrix must be symmetric positive semi-definite (PSD), otherwise
    //       you may have negatve Eigen values which results in NaN values.
    //       A good acceptable input is a convariance matrix.
    //
    Matrix &sqrt() noexcept;
    template<typename MA>
    inline MA &get_sqrt(MA &that) const noexcept;

    // Whitening a data matrix, also known as sphering, is a data preprocessing
    // technique that transforms the data so that its covariance matrix becomes
    // the identity matrix. This process effectively decorrelates the features
    // and ensures they have equal variance. In simpler terms, it changes the
    // input vector into a white noise vector, where all frequencies have the
    // same amplitude.
    // If center is false, it means self is already centered (mean is
    // subtracted).
    //
    Matrix &whiten(bool center = false) noexcept;
    template<typename MA>
    inline MA &get_whiten(MA &that, bool center = false) const noexcept;

    // The following methods apply the corresponding functions to all matrix
    // elements one by one. They return a reference to self.
    // ew = Element Wise
    //
    Matrix &ew_square() noexcept;
    Matrix &ew_cube() noexcept;
    Matrix &ew_sqrt() noexcept;
    Matrix &ew_tanh() noexcept;
    Matrix &ew_inverse() noexcept;  // 1/x
    Matrix &ew_add(value_type val) noexcept;
    Matrix &ew_minus(value_type val) noexcept;
    Matrix &ew_multiply(value_type val) noexcept;
    Matrix &ew_divide(value_type val) noexcept;

    // Return a scalar matrix where multidimensional data is flattened.
    // if col_wise is true the dimensions in the matrix data are flattened
    // into columns, otherwise they are flattened into rows.
	//
    [[nodiscard]]
    scalar_ma_t get_flatten(bool col_wise = true) const requires (IS_MD);

    // These return the inner (dot) product of the given rows/columns
    // NOTE: These work with both scalar and multidimensional
    //       (i.e. vectors and arrays) data.
    //
    [[nodiscard]]
    value_type row_inner_prod(size_type row1, size_type row2) const;
    [[nodiscard]]
    value_type col_inner_prod(size_type col1, size_type col2) const;

    // Get a matrix filled with real uniform random numbers. T can only be a
    // floating point type
    //
    [[nodiscard]]
    static Matrix
    get_random(size_type rows, size_type cols, T low, T high,
               unsigned int seed = static_cast<unsigned int>(-1))
        requires std::floating_point<T>;

    //
    // Friends
    //

    template<typename TT, matrix_orient MO1, matrix_orient MO2,
             bool IS_SYM1, bool IS_SYM2>
    friend typename std::conditional<IS_SYM1 && IS_SYM2,
                                     Matrix<TT, MO1, true>,
                                     Matrix<TT, MO1, false>>::type
    operator +(const Matrix<TT, MO1, IS_SYM1> &lhs,
               const Matrix<TT, MO2, IS_SYM2> &rhs);

    template<typename TT, matrix_orient MO1, matrix_orient MO2,
             bool IS_SYM1, bool IS_SYM2>
    friend typename std::conditional<IS_SYM1 && IS_SYM2,
                                     Matrix<TT, MO1, true>,
                                     Matrix<TT, MO1, false>>::type
    operator -(const Matrix<TT, MO1, IS_SYM1> &lhs,
               const Matrix<TT, MO2, IS_SYM2> &rhs);

private:

    inline static constexpr size_type   NOPOS_ { static_cast<size_type>(-9) };
    inline static constexpr bool        resizable_ { IS_MD && Resizable<T> };
    inline static constexpr double      EPSILON_ { double(2.220446e-16) };

    using storage_t = std::vector<value_type>;

    // Initializes the val to zero(s)
    //
    inline void
    zero_out_(value_type &val) const;

    // Partial pivoting for Gaussian elimination:
    //
    // Pivoting is a process performed on a matrix in order to improve
    // numerical stability. Partial pivoting of an nXn matrix is the
    // sorting of the rows of the matrix so that row r contains the maximum
    // absolute column value for column c, among all rows r ... n.
    //
    [[nodiscard]] inline size_type
    ppivot_(size_type pivot_row,
            size_type self_rows,
            size_type self_cols) noexcept;

    // Symmetric Householder reduction to tridiagonal form.
    //
    // This is derived from the Algol procedures tred2 by Bowdler, Martin,
    // Reinsch, and Wilkinson, Handbook for Auto. Comp., Vol.ii-Linear
    // Algebra, and the corresponding Fortran subroutine in EISPACK.
    //
    template<typename MA1, typename MA2, typename MA3>
    static inline void
    tridiagonalize_(MA1 &e_vecs, MA2 &e_vals, MA3 &imagi) noexcept;

    // Symmetric tridiagonal QL algorithm.
    //
    // This is derived from the Algol procedures tql2 by Bowdler, Martin,
    // Reinsch, and Wilkinson, Handbook for Auto. Comp., Vol.ii-Linear
    // Algebra, and the corresponding Fortran subroutine in EISPACK.
    //
    template<typename MA1, typename MA2, typename MA3>
    static inline void
    diagonalize_(MA1 &e_vecs, MA2 &e_vals, MA3 &imagi) noexcept;

    // Nonsymmetric reduction to Hessenberg form.
    //
    // This is derived from the Algol procedures orthes and ortran, by
    // Martin and Wilkinson, Handbook for Auto. Comp., Vol.ii-Linear
    // Algebra, and the corresponding Fortran subroutines in EISPACK.
    //
    template<typename MA1, typename MA2>
    static inline void
    red_to_hessenberg_(MA1 &e_vecs, MA2 &hess_form) noexcept;

    // Nonsymmetric reduction from Hessenberg to real Schur form.
    //
    // This is derived from the Algol procedure hqr2, by Martin and
    // Wilkinson, Handbook for Auto. Comp., Vol.ii-Linear Algebra, and the
    // corresponding Fortran subroutines in EISPACK.
    //
    template<typename MA1, typename MA2, typename MA3, typename MA4>
    static inline void
    hessenberg_to_schur_(MA1 &e_vecs,
                         MA2 &e_vals,
                         MA3 &imagi,
                         MA4 &hess_form) noexcept;

     // It returns the quotient of two complex numbers:
     // (a + ib) / (c + id)
     //
     // Admittedly this method doesn't belong here
     //
     static inline void
     cdiv_(value_type xr,
           value_type xi,
           value_type yr,
           value_type yi,
           value_type &cdivr,
           value_type &cdivi) noexcept;

    size_type   rows_ { 0 };
    size_type   cols_ { 0 };
    storage_t   matrix_ { };

private:  // Iterators

    // A random access iterator over every element of the matrix, either row
    // by row (BY_ROW: [0, 0], [0, 1], ... [0, cols - 1], [1, 0], ...) or
    // column by column. IS_CONST selects the const flavor.
    //
    // The position is kept as one linear index, pos_, in the iterator's own
    // traversal order, so ==, <, -, += and -= are O(1), exact, and work to
    // and from end() (which is pos_ == rows * cols). When the traversal order
    // is also the storage order (a row iterator over a row-major matrix, a
    // column iterator over a column-major matrix) dereference indexes the
    // storage directly. In every other case, including symmetric matrices
    // with their packed storage, the [row, column] pair is tracked as well
    // and advanced incrementally, so ++ and -- never divide.
    //
    template<bool IS_CONST, bool BY_ROW>
    class   iterator_impl_  {

    public:

        using iterator_category = std::random_access_iterator_tag;
        using iterator_concept = std::random_access_iterator_tag;
        using value_type = T;
        using size_type = long;
        using difference_type = std::ptrdiff_t;
        using pointer = std::conditional_t<IS_CONST, const T *, T *>;
        using const_pointer = const T *;
        using reference = std::conditional_t<IS_CONST, const T &, T &>;
        using const_reference = const T &;

    private:

        using matrix_ptr =
            std::conditional_t<IS_CONST, const self_t *, self_t *>;

        // Traversal order == storage order
        //
        static constexpr bool   DIRECT_ {
            ! IS_SYM && (BY_ROW == (MO == matrix_orient::row_major))
        };

        inline difference_type size_() const noexcept  {

            return (difference_type(mptr_->rows_ * mptr_->cols_));
        }

        // Recompute [row_, col_] from pos_. A position of size_() maps to
        // [rows, 0] when going by row and [0, cols] when going by column.
        //
        inline void sync_() noexcept  {

            const size_type len { BY_ROW ? mptr_->cols_ : mptr_->rows_ };

            if (len > 0)  {
                const size_type line { size_type(pos_) / len };
                const size_type in_line { size_type(pos_) % len };

                if constexpr (BY_ROW)  { row_ = line; col_ = in_line; }
                else  { col_ = line; row_ = in_line; }
            }
            else  { row_ = 0; col_ = 0; }
        }

    public:

        inline iterator_impl_() = default;

        // Any position outside the matrix, including [rows, cols], is end().
        //
        inline explicit
        iterator_impl_(matrix_ptr m, size_type row = 0, size_type col = 0)
            noexcept
            : mptr_(m)  {

            pos_ = (row < 0 || col < 0 || row >= m->rows_ || col >= m->cols_)
                       ? size_()
                       : (BY_ROW ? row * m->cols_ + col : col * m->rows_ + row);
            if constexpr (! DIRECT_)  sync_();
        }

        // iterator -> const_iterator
        //
        template<bool IS_CONST2>
        requires (IS_CONST && ! IS_CONST2)
        inline iterator_impl_(const iterator_impl_<IS_CONST2, BY_ROW> &rhs)
            noexcept
            : mptr_(rhs.mptr_), pos_(rhs.pos_), row_(rhs.row_), col_(rhs.col_)
        {   }

        inline bool operator ==(const iterator_impl_ &rhs) const noexcept  {

            return (mptr_ == rhs.mptr_ && pos_ == rhs.pos_);
        }
        inline std::strong_ordering
        operator <=>(const iterator_impl_ &rhs) const noexcept  {

            return (pos_ <=> rhs.pos_);
        }

        // Following STL style, this iterator appears as a pointer
        // to value_type.
        //
        inline reference operator *() const noexcept  {

            if constexpr (DIRECT_)  return (mptr_->matrix_[size_type(pos_)]);
            else  return (mptr_->at(row_, col_));
        }
        inline pointer operator ->() const noexcept  {

            return (std::addressof(**this));
        }
        inline reference operator [](difference_type n) const noexcept  {

            return (*(*this + n));
        }

        // Address of the current element, or nullptr for end().
        //
        inline explicit operator pointer() const noexcept  {

            return (pos_ >= 0 && pos_ < size_() ? std::addressof(**this)
                                                : nullptr);
        }

        inline iterator_impl_ &operator ++() noexcept  {    // ++Prefix

            pos_ += 1;
            if constexpr (! DIRECT_)  {
                if constexpr (BY_ROW)  {
                    if (++col_ == mptr_->cols_)  { col_ = 0; ++row_; }
                }
                else  {
                    if (++row_ == mptr_->rows_)  { row_ = 0; ++col_; }
                }
            }
            return (*this);
        }
        inline iterator_impl_ operator ++(int) noexcept  {  // Postfix++

            const iterator_impl_    save { *this };

            ++(*this);
            return (save);
        }

        inline iterator_impl_ &operator --() noexcept  {    // --Prefix

            pos_ -= 1;
            if constexpr (! DIRECT_)  {
                if constexpr (BY_ROW)  {
                    if (col_ == 0)  { col_ = mptr_->cols_ - 1; --row_; }
                    else  col_ -= 1;
                }
                else  {
                    if (row_ == 0)  { row_ = mptr_->rows_ - 1; --col_; }
                    else  row_ -= 1;
                }
            }
            return (*this);
        }
        inline iterator_impl_ operator --(int) noexcept  {  // Postfix--

            const iterator_impl_    save { *this };

            --(*this);
            return (save);
        }

        inline iterator_impl_ &operator +=(difference_type n) noexcept  {

            pos_ += n;
            if constexpr (! DIRECT_)  sync_();
            return (*this);
        }
        inline iterator_impl_ &operator -=(difference_type n) noexcept  {

            return (*this += -n);
        }

        inline iterator_impl_ operator +(difference_type n) const noexcept  {

            iterator_impl_  result { *this };

            result += n;
            return (result);
        }
        inline iterator_impl_ operator -(difference_type n) const noexcept  {

            iterator_impl_  result { *this };

            result += -n;
            return (result);
        }
        friend inline iterator_impl_
        operator +(difference_type n, const iterator_impl_ &it) noexcept  {

            return (it + n);
        }
        friend inline difference_type
        operator -(const iterator_impl_ &lhs,
                   const iterator_impl_ &rhs) noexcept  {

            return (lhs.pos_ - rhs.pos_);
        }

    private:

        template<bool, bool>
        friend class iterator_impl_;

        matrix_ptr      mptr_ { nullptr };
        difference_type pos_ { 0 };
        size_type       row_ { 0 };
        size_type       col_ { 0 };
    };

public:
	
    // It goes through the matrix row-by-row starting at [0, 0]
    //
    using row_iterator = iterator_impl_<false, true>;
    using row_const_iterator = iterator_impl_<true, true>;

    // It goes through the matrix column-by-column starting at [0, 0]
    //
    using col_iterator = iterator_impl_<false, false>;
    using col_const_iterator = iterator_impl_<true, false>;

    // Forwards
    //
    [[nodiscard]]
    inline row_iterator row_begin() noexcept  {

        return (row_iterator(this, 0, 0));
    }
    [[nodiscard]]
    inline row_const_iterator row_cbegin() const noexcept  {

        return (row_const_iterator(this, 0, 0));
    }
    [[nodiscard]]
    inline row_iterator row_end() noexcept  {

        return (row_iterator(this, rows(), cols()));
    }
    [[nodiscard]]
    inline row_const_iterator row_cend() const noexcept  {

        return (row_const_iterator(this, rows(), cols()));
    }

    [[nodiscard]]
    inline col_iterator col_begin() noexcept  {

        return (col_iterator(this, 0, 0));
    }
    [[nodiscard]]
    inline col_const_iterator col_cbegin() const noexcept  {

        return (col_const_iterator(this, 0, 0));
    }
    [[nodiscard]]
    inline col_iterator col_end() noexcept  {

        return (col_iterator(this, rows(), cols()));
    }
    [[nodiscard]]
    inline col_const_iterator col_cend() const noexcept  {

        return (col_const_iterator(this, rows(), cols()));
    }

    using reverse_row_iterator = std::reverse_iterator<row_iterator>;
    using reverse_row_const_iterator =
        std::reverse_iterator<row_const_iterator>;
    using reverse_col_iterator = std::reverse_iterator<col_iterator>;
    using reverse_col_const_iterator =
        std::reverse_iterator<col_const_iterator>;

    // Reverses
    //
    [[nodiscard]]
    inline reverse_row_iterator row_rbegin() noexcept  {

        return (std::make_reverse_iterator(row_end()));
    }
    [[nodiscard]]
    inline reverse_row_const_iterator row_crbegin() const noexcept  {

        return (std::make_reverse_iterator(row_cend()));
    }
    [[nodiscard]]
    inline reverse_row_iterator row_rend() noexcept  {

        return (std::make_reverse_iterator(row_begin()));
    }
    [[nodiscard]]
    inline reverse_row_const_iterator row_crend() const noexcept  {

        return (std::make_reverse_iterator(row_cbegin()));
    }

    [[nodiscard]]
    inline reverse_col_iterator col_rbegin() noexcept  {

        return (std::make_reverse_iterator(col_end()));
    }
    [[nodiscard]]
    inline reverse_col_const_iterator col_crbegin() const noexcept  {

        return (std::make_reverse_iterator(col_cend()));
    }
    [[nodiscard]]
    inline reverse_col_iterator col_rend() noexcept  {

        return (std::make_reverse_iterator(col_begin()));
    }
    [[nodiscard]]
    inline reverse_col_const_iterator col_crend() const noexcept  {

        return (std::make_reverse_iterator(col_cbegin()));
    }
};

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline bool
operator != (const Matrix<T, MO1, IS_SYM1> &lhs,
             const Matrix<T, MO2, IS_SYM2> &rhs);

// -------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline bool
operator == (const Matrix<T, MO1, IS_SYM1> &lhs,
             const Matrix<T, MO2, IS_SYM2> &rhs);

// ----------------------------------------------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline typename std::conditional<IS_SYM1 && IS_SYM2,
                                        Matrix<T, MO1, true>,
                                        Matrix<T, MO1, false>>::type
operator + (const Matrix<T, MO1, IS_SYM1> &lhs,
            const Matrix<T, MO2, IS_SYM2> &rhs);

// -------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static inline typename std::conditional<IS_SYM1 && IS_SYM2,
                                        Matrix<T, MO1, true>,
                                        Matrix<T, MO1, false>>::type
operator - (const Matrix<T, MO1, IS_SYM1> &lhs,
            const Matrix<T, MO2, IS_SYM2> &rhs);

// -------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
Matrix<T, MO1, IS_SYM1> &
operator += (Matrix<T, MO1, IS_SYM1> &lhs, const Matrix<T, MO2, IS_SYM2> &rhs);

// -------------------------------------

template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
Matrix<T, MO1, IS_SYM1> &
operator -= (Matrix<T, MO1, IS_SYM1> &lhs, const Matrix<T, MO2, IS_SYM2> &rhs);

// ----------------------------------------------------------------------------

// Vector * Matrix
//
template<typename T, matrix_orient MO, bool IS_SYM>
static Matrix<T, MO, false>
operator * (const std::vector<T> &lhs, const Matrix<T, MO, IS_SYM> &rhs);

// -------------------------------------

// Matrix * Vector
//
template<typename T, matrix_orient MO, bool IS_SYM>
static Matrix<T, MO, false>
operator * (const Matrix<T, MO, IS_SYM> &lhs, const std::vector<T> &rhs);

// -------------------------------------

// Matrix * Matrix
// Naïve but cache friendly and multi-threaded O(n^3) algorithm
//
template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static Matrix<T, MO1, false>
operator * (const Matrix<T, MO1, IS_SYM1> &lhs,
            const Matrix<T, MO2, IS_SYM2> &rhs);

// -------------------------------------

// Element-wise multiplication
//
template<typename T, matrix_orient MO1, matrix_orient MO2,
         bool IS_SYM1, bool IS_SYM2>
static Matrix<T, MO1, false>
hadamard(const Matrix<T, MO1, IS_SYM1> &lhs,
         const Matrix<T, MO2, IS_SYM2> &rhs);

// ----------------------------------------------------------------------------

// Vector + Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator + (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// -------------------------------------

// Vector - Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator - (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// -------------------------------------

// Vector * Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator * (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// -------------------------------------

// Vector / Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1>
operator / (const std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// -------------------------------------

// Vector += Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator += (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// -------------------------------------

// Vector -= Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator -= (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// -------------------------------------

// Vector *= Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator *= (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// -------------------------------------

// Vector /= Vector
//
template<typename T, typename A1, typename A2>
static inline
std::vector<T, A1> &
operator /= (std::vector<T, A1> &lhs, const std::vector<T, A2> &rhs);

// ----------------------------------------------------------------------------

// Vector + Array
//
template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator + (const std::vector<T, A> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Vector - Array
//
template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator - (const std::vector<T, A> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Vector * Array
//
template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator * (const std::vector<T, A> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Vector / Array
//
template<typename T, typename A, std::size_t N>
static inline
std::vector<T, A>
operator / (const std::vector<T, A> &lhs, const std::array<T, N> &rhs);

// ----------------------------------------------------------------------------

// Array + Vector
//
template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator + (const std::array<T, N> &lhs, const std::vector<T, A> &rhs);

// -------------------------------------

// Array - Vector
//
template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator - (const std::array<T, N> &lhs, const std::vector<T, A> &rhs);

// -------------------------------------

// Array * Vector
//
template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator * (const std::array<T, N> &lhs, const std::vector<T, A> &rhs);

// -------------------------------------

// Array / Vector
//
template<typename T, typename A, std::size_t N>
static inline
std::array<T, N>
operator / (const std::array<T, N> &lhs, const std::vector<T, A> &rhs);

// ----------------------------------------------------------------------------

// Vector + Value
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator + (const std::vector<T, A> &lhs, T rhs);

// -------------------------------------

// Vector - Value
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator - (const std::vector<T, A> &lhs, T rhs);

// -------------------------------------

// Vector * Value
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator * (const std::vector<T, A> &lhs, T rhs);

// -------------------------------------

// Vector / Value
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator / (const std::vector<T, A> &lhs, T rhs);

// ----------------------------------------------------------------------------

// Value + Vector
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator + (T lhs, const std::vector<T, A> &rhs);

// -------------------------------------

// Value - Vector
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator - (T lhs, const std::vector<T, A> &rhs);

// -------------------------------------

// Value * Vector
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator * (T lhs, const std::vector<T, A> &rhs);

// -------------------------------------

// Value / Vector
//
template<typename T, typename A>
static inline
std::vector<T, A>
operator / (T lhs, const std::vector<T, A> &rhs);

// ----------------------------------------------------------------------------

// Vector += Value
//
template<typename T, typename A>
static inline
std::vector<T, A> &
operator += (std::vector<T, A> &lhs, T rhs);

// -------------------------------------

// Vector -= Value
//
template<typename T, typename A>
static inline
std::vector<T, A> &
operator -= (std::vector<T, A> &lhs, T rhs);

// -------------------------------------

// Vector *= Value
//
template<typename T, typename A>
static inline
std::vector<T, A> &
operator *= (std::vector<T, A> &lhs, T rhs);

// -------------------------------------

// Vector /= Value
//
template<typename T, typename A>
static inline
std::vector<T, A> &
operator /= (std::vector<T, A> &lhs, T rhs);

// ----------------------------------------------------------------------------

// Array + Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator + (const std::array<T, N> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Array - Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator - (const std::array<T, N> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Array * Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator * (const std::array<T, N> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Array / Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator / (const std::array<T, N> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Array += Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator += (std::array<T, N> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Array -= Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator -= (std::array<T, N> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Array *= Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator *= (std::array<T, N> &lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Array /= Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator /= (std::array<T, N> &lhs, const std::array<T, N> &rhs);

// ----------------------------------------------------------------------------

// Array + Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator + (const std::array<T, N> &lhs, T rhs);

// -------------------------------------

// Array - Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator - (const std::array<T, N> &lhs, T rhs);

// -------------------------------------

// Array * Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator * (const std::array<T, N> &lhs, T rhs);

// -------------------------------------

// Array / Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator / (const std::array<T, N> &lhs, T rhs);

// -------------------------------------

// Array += Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator += (std::array<T, N> &lhs, T rhs);

// -------------------------------------

// Array -= Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator -= (std::array<T, N> &lhs, T rhs);

// -------------------------------------

// Array *= Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator *= (std::array<T, N> &lhs, T rhs);

// -------------------------------------

// Array /= Value
//
template<typename T, std::size_t N>
static inline
std::array<T, N> &
operator /= (std::array<T, N> &lhs, T rhs);

// ----------------------------------------------------------------------------

// Value + Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator + (T lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Value - Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator - (T lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Value * Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator * (T lhs, const std::array<T, N> &rhs);

// -------------------------------------

// Value / Array
//
template<typename T, std::size_t N>
static inline
std::array<T, N>
operator / (T lhs, const std::array<T, N> &rhs);

} // namespace hmdf

// ----------------------------------------------------------------------------

#ifndef HMDF_DO_NOT_INCLUDE_TCC_FILES
#  include <DataFrame/Utils/Matrix.tcc>
#endif // HMDF_DO_NOT_INCLUDE_TCC_FILES

// ----------------------------------------------------------------------------

// Local Variables:
// mode:C++
// tab-width:4
// c-basic-offset:4
// End:
