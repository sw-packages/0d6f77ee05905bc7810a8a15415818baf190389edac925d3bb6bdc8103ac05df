// Hossein Moein
// September 22, 2017
/*
Copyright (c) 2019-2026, Hossein Moein
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
* Neither the name of Hossein Moein and/or the DataFrame nor the
  names of its contributors may be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Hossein Moein BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include <DataFrame/DataFrameTypes.h>
#include <DataFrame/Internals/DataFrame_standalone.tcc>
#include <DataFrame/RandGen.h>
#include <DataFrame/Utils/AlignedAllocator.h>
#include <DataFrame/Utils/Concepts.h>
#include <DataFrame/Utils/FixedSizePriorityQueue.h>
#include <DataFrame/Utils/Matrix.h>
#include <DataFrame/Utils/Threads/ThreadGranularity.h>
#include <DataFrame/Utils/Utils.h>

#include <algorithm>
#include <array>
#include <cmath>

// e
//
#ifndef M_E
#  define M_E 2.71828182845904523536
#endif // M_E

// PI
//
#ifndef M_PI
#  define M_PI 3.14159265358979323846264338327950288
#endif // M_PI

// PI/2
//
#ifndef M_PI_2
#  define M_PI_2 1.57079632679489661923132169163975144
#endif // M_PI_2

// PI/4
//
#ifndef M_PI_4
#  define M_PI_4 0.785398163397448309615660845819875721
#endif // M_PI_4

// 2PI
//
#ifndef TAU
#  define TAU 6.28318530717958647692528676655900576
#endif // TAU

// sqrt(2)
//
#ifndef M_SQRT2
#  define M_SQRT2 1.41421356237309504880
#endif // m_SQRT2

// 1/sqrt(2)
//
#ifndef M_SQRT1_2
#  define M_SQRT1_2 0.707106781186547524400844362104849039
#endif // M_SQRT1_2

#include <cstddef>
#include <functional>
#include <future>
#include <iterator>
#include <limits>
#include <map>
#include <numbers>
#include <numeric>
#include <queue>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

// ----------------------------------------------------------------------------

namespace hmdf
{

#define DEFINE_VISIT_BASIC_TYPES \
    using value_type = T; \
    using index_type = I; \
    using size_type = std::size_t;

#define DEFINE_VISIT_BASIC_TYPES_2 \
    DEFINE_VISIT_BASIC_TYPES \
    using result_type = T;

#define DEFINE_VISIT_BASIC_TYPES_3 \
    DEFINE_VISIT_BASIC_TYPES \
    using result_type = std::vector<T, typename allocator_declare<T, A>::type>;

#define DEFINE_PRE_POST \
    inline void pre ()  { result_.clear(); } \
    inline void post ()  {  }

#define DEFINE_RESULT \
    inline const result_type &get_result () const  { return (result_); } \
    inline result_type &get_result ()  { return (result_); }

#define PASS_DATA_ONE_BY_ONE \
    template <typename K, typename H> \
    inline void \
    operator() (K idx_begin, K /*idx_end*/, H column_begin, H column_end)  { \
\
        while (column_begin < column_end) \
            (*this)(*idx_begin++, *column_begin++); \
    }

#define PASS_DATA_ONE_BY_ONE_2 \
    template <typename K, typename H> \
    inline void \
    operator() (K idx_begin, K /*idx_end*/, \
                H column_begin1, H column_end1, \
                H column_begin2, H column_end2)  { \
\
        while (column_begin1 < column_end1 && column_begin2 < column_end2) \
            (*this)(*idx_begin++, *column_begin1++, *column_begin2++); \
    }

#define DECL_CTOR(name) \
    explicit \
    name(bool skipnan = false) : skip_nan_(skipnan)  {   }

#define SKIP_NAN if (skip_nan_ && is_nan__(val))  { return; }
#define SKIP_NAN_BASE if (BaseClass::_skip_nan && is_nan__(val))  { return; }

#define GET_COL_SIZE \
    const std::size_t   col_s = \
        std::min(std::distance(idx_begin, idx_end), \
                 std::distance(column_begin, column_end));

#define GET_COL_SIZE2 \
    const std::size_t   col_s = std::distance(column_begin, column_end);

#define OBO_PORT_DECL \
    using val_vec = std::vector<T, typename allocator_declare<T, A>::type>; \
    using idx_vec = std::vector<I, typename allocator_declare<I, A>::type>; \
    val_vec     aux_val_vec_ {  }; \
    idx_vec     aux_idx_vec_ {  }; \
    bool        obo_data_ { false };  // one-by-one data passing

#define OBO_PORT_OPT \
    inline void \
    operator()(const index_type &, const value_type &val)  { \
        obo_data_ = true; \
        aux_val_vec_.push_back(val); \
    }

#define OBO_PORT_OPT2 \
    inline void \
    operator()(const index_type &idx, const value_type &val)  { \
        obo_data_ = true; \
        aux_val_vec_.push_back(val); \
        aux_idx_vec_.push_back(idx); \
    }

#define OBO_PORT_PRE \
    aux_val_vec_.clear(); \
    aux_idx_vec_.clear(); \
    obo_data_ = false;

#define OBO_PORT_POST \
    if (obo_data_) \
        (*this)(aux_idx_vec_.begin(), aux_idx_vec_.end(), \
                aux_val_vec_.begin(), aux_val_vec_.end());

// ----------------------------------------------------------------------------

template<typename V, typename S>
static inline auto _bc_pow_(const V &v, S exp) noexcept  {

    if constexpr (! std::is_arithmetic_v<S>)  {
        using data_t = typename S::value_type;

        std::vector<data_t> res(exp.size());

        if constexpr (std::is_arithmetic_v<V>)  {
            for (std::size_t i { 0 }; i < exp.size(); ++i)
                res[i] = std::pow(v, exp[i]);
        }
        else  {
            for (std::size_t i { 0 }; i < exp.size(); ++i)
                res[i] = std::pow(v[i], exp[i]);
        }
        return (res);
    }
    else if constexpr (std::is_arithmetic_v<V>)  {
        return (std::pow(v, exp));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::pow(res[i], exp);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_log_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::log(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::log(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_sqrt_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::sqrt(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::sqrt(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_tanh_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::tanh(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::tanh(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_atan_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::atan(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::atan(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_sinh_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::sinh(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::sinh(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_cosh_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::cosh(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::cosh(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_erf_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::erf(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::erf(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_log2_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::log2(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::log2(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_exp_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::exp(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::exp(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_fabs_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::fabs(v));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.begin(), v.end());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::fabs(res[i]);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _bc_signbit_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (std::signbit(v) ? V(-1) : V(1));
    }
    else  {
        using data_t = typename V::value_type;

        std::vector<data_t> res(v.size());

        for (std::size_t i { 0 }; i < v.size(); ++i)
            res[i] = std::signbit(v[i]) ? data_t(-1) : data_t(1);
        return (res);
    }
}

// -------------------------------------

template<typename V>
static inline auto _reduce_to_scalar_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (v);
    }
    else  {
        using data_t = typename V::value_type;

        data_t  sum { 0 };

        for (const auto &elem : v)
            sum += elem;
        return (sum);
    }
}

// -------------------------------------

template<typename V>
static inline auto _reduce_to_product_(const V &v) noexcept  {

    if constexpr (std::is_arithmetic_v<V>)  {
        return (v);
    }
    else  {
        using data_t = typename V::value_type;

        data_t  prod { 1 };

        for (const auto &elem : v)
            prod *= elem;
        return (prod);
    }
}

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  LastVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    inline void
    operator() (const index_type &, const value_type &val)  {

        if (! skip_nan_ || ! is_nan__(val)) [[likely]]  result_ = val;
    }
    template <typename K, typename H>
    inline void
    operator() (const K &/*idx_begin*/, const K &/*idx_end*/,
                const H &column_begin, const H &column_end) {

        for (auto citer = --column_end; citer >= column_begin; --citer)
            if (! skip_nan_ || ! is_nan__(*citer)) [[likely]]  {
                result_ = *citer;
                break;
            }
    }

    inline void pre ()  { result_ = result_type { }; }
    inline void post ()  {  }
    inline result_type get_result () const  { return (result_); }

    DECL_CTOR(LastVisitor)

private:

    result_type result_ {  };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  FirstVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    inline void
    operator() (const index_type &, const value_type &val)  {

        if (! started_)  {
            if (! skip_nan_ || ! is_nan__(val))  {
                result_ = val;
                started_ = true;
            }
        }
    }
    template <typename K, typename H>
    inline void
    operator() (const K &/*idx_begin*/, const K &/*idx_end*/,
                const H &column_begin, const H &column_end) {

        for (auto citer = column_begin; citer < column_end; ++citer)
            if (! skip_nan_ || ! is_nan__(*citer)) [[likely]]  {
                result_ = *citer;
                break;
            }
    }

    inline void pre ()  { result_ = result_type { }; started_ = false; }
    inline void post ()  {  }
    inline result_type get_result () const  { return (result_); }

    DECL_CTOR(FirstVisitor)

private:

    result_type result_ {  };
    bool        started_ { false };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  CountVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = std::size_t;

    inline void operator() (const index_type &, const value_type &val)  {

        if (! skip_nan_ || ! is_nan__(val)) [[likely]]  result_ += 1;
    }
    template <typename K, typename H>
    inline void
    operator() (const K &/*idx_begin*/, const K &/*idx_end*/,
                const H &column_begin, const H &column_end) {

        result_ = result_type(std::distance(column_begin, column_end));
    }

    inline void pre ()  { result_ = 0; }
    inline void post ()  {  }
    inline result_type get_result () const  { return (result_); }

    DECL_CTOR(CountVisitor)

private:

    result_type result_ { 0 };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  SumVisitor  {

private:

    using data_t =
        typename std::conditional_t<std::is_arithmetic_v<T> || StringOnly<T>,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T> || StringOnly<T>,
                                    T,
                                    std::vector<data_t>>;

    inline void operator()(const index_type &, const value_type &val)  {

        SKIP_NAN

        if constexpr (! std::is_arithmetic_v<T>  && ! StringOnly<T>)  {
            if (! started_)  {
                result_.resize(val.size(), 0);
                started_ = true;
            }
        }

        result_ += val;
    }
    template <typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin, const H &column_end) {

        if constexpr (is_std_vector_v<value_type> &&
                      ! StringOnly<value_type>)
            result_.resize(column_begin->size(), 0);

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        if constexpr (! std::is_arithmetic_v<value_type>)  {
#ifdef HMDF_SANITY_EXCEPTIONS
            const size_type dim { column_begin->size() };

            for (size_type i { 0 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "SumVisitor: Inconsistent data dimensions");
#endif // HMDF_SANITY_EXCEPTIONS
        }

        auto    lbd =
            [this] (const auto &begin, const auto &end) -> result_type  {
                result_type sum { };

                if constexpr (! std::is_arithmetic_v<value_type>)
                    sum.resize(begin->size(), 0);
                if constexpr (is_std_array_v<value_type>)  {
                    const size_type dim { begin->size() };

                    for (auto citer = begin; citer < end; ++citer)
                        for (size_type d { 0 }; d < dim; ++d)
                            sum[d] += (*citer)[d];
                }
                else  {
                    if (! skip_nan_)  {
                        for (auto citer = begin; citer < end; ++citer)
                            sum += *citer;
                    }
                    else  {
                        for (auto citer = begin; citer < end; ++citer)
                            if (! is_nan__(*citer))  sum += *citer;
                    }
                }

                return (sum);
            };

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    column_begin, column_end, std::move(lbd));

            for (auto &fut : futures)  result_ += fut.get();
        }
        else  {
            result_ = lbd(column_begin, column_end);
        }
    }

    inline void pre()  {

        started_ = false;
        if constexpr (std::is_arithmetic_v<value_type>)
            result_ = 0;
        else if constexpr (StringOnly<value_type>)
            result_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    DECL_CTOR(SumVisitor)

private:

    bool        started_ { false };
    result_type result_ { };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  MeanBase  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    using data_t = typename std::conditional_t<! is_md_,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;

    inline void pre ()  {

        _sum.pre();
        _cnt = 0;
        if constexpr (! is_md_)
            _mean = 0;
        else
            _mean.clear();
    }
    inline size_type get_count () const  { return (_cnt); }
    inline const result_type &get_sum () const  { return (_sum.get_result()); }
    inline result_type &get_sum ()  { return (_sum.get_result()); }
    inline const result_type &get_result () const  { return (_mean); }
    inline result_type &get_result ()  { return (_mean); }

    MeanBase(bool skipnan = false) : _skip_nan(skipnan)  {   }

protected:

    const bool          _skip_nan;
    result_type         _mean { };
    size_type           _cnt { 0 };
    SumVisitor<T, I>    _sum { _skip_nan };
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  MeanVisitor : public MeanBase<T, I>  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using BaseClass = MeanBase<T, I>;

    inline void operator() (const I &idx, const T &val)  {

        SKIP_NAN_BASE

        BaseClass::_cnt += 1;
        BaseClass::_sum(idx, val);
    }
    template<typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end) {

        BaseClass::_sum(idx_begin, idx_end, column_begin, column_end);
        if (! BaseClass::_skip_nan)  {
            BaseClass::_cnt = std::distance(column_begin, column_end);
        }
        else  {
            for (auto citer = column_begin; citer < column_end; ++citer)
                if (! is_nan__(*citer)) [[likely]]
                    BaseClass::_cnt += 1;
        }
    }

    inline void post ()  {

        BaseClass::_sum.post();
        BaseClass::_mean =
            BaseClass::_sum.get_result() / data_t(BaseClass::_cnt);
    }

    MeanVisitor(bool skipnan = false) : BaseClass(skipnan)  {   }
};

// ----------------------------------------------------------------------------

// Welford's algorithm for the running mean
//
template<arithmetic T, typename I = unsigned long>
struct  StableMeanVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    inline void operator() (const I &, const T &val)  {

        SKIP_NAN

        cnt_ += 1;
        mean_ += (val - mean_) / T(cnt_);
    }
    PASS_DATA_ONE_BY_ONE

    inline void pre ()  { mean_ = 0; cnt_ = 0; }
    inline size_type get_count () const  { return (cnt_); }
    inline result_type get_result () const  { return (mean_); }
    inline void post ()  {  }

    StableMeanVisitor(bool skipnan = false) : skip_nan_(skipnan)  {   }

private:

    const bool  skip_nan_;
    value_type  mean_ { 0 };
    size_type   cnt_ { 0 };
};

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long>
struct  WeightedMeanVisitor : public MeanBase<T, I>  {

    using BaseClass = MeanBase<T, I>;

    inline void operator() (const I &idx, const T &val)  {

        SKIP_NAN_BASE

        BaseClass::_cnt += 1;
        BaseClass::_sum(idx, val * T(BaseClass::_cnt));
    }
    PASS_DATA_ONE_BY_ONE

    inline void
    post()  {

        BaseClass::_sum.post();
        BaseClass::_mean =
            BaseClass::_sum.get_result() /
            (T((BaseClass::_cnt * (BaseClass::_cnt + 1))) / T(2));
    }

    WeightedMeanVisitor(bool skipnan = true) : BaseClass(skipnan)  {   }
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct GeometricMeanVisitor : public MeanBase<T, I>  {

    using BaseClass = MeanBase<T, I>;
    using size_type = std::size_t;

    inline void operator() (const I &idx, const T &val)  {

        SKIP_NAN_BASE

        if constexpr (std::is_arithmetic_v<T>)  {
            BaseClass::_sum(idx, std::log(val));
        }
        else  {
            if (BaseClass::_mean.empty()) [[unlikely]]
                BaseClass::_mean.resize(val.size(), 0 );
            for (size_type d { 0 }; const auto v : val)
                BaseClass::_mean[d++] += std::log(v);
        }
        BaseClass::_cnt += 1;
    }

    template <typename K, typename H>
    inline void
    operator() (K idx_begin, K /*idx_end*/, H column_begin, H column_end)  {

        if constexpr (std::is_arithmetic_v<T>)  {
            if (! BaseClass::_skip_nan)  {
                BaseClass::_cnt = std::distance(column_begin, column_end);
                for (auto citer = column_begin; citer < column_end; ++citer)
                    BaseClass::_sum(*idx_begin, std::log(*citer));
            }
            else  {
                for (auto citer = column_begin; citer < column_end; ++citer)  {
                    if (! is_nan__(*citer)) [[likely]]  {
                        BaseClass::_cnt += 1;
                        BaseClass::_sum(*idx_begin, std::log(*citer));
                    }
                }
            }
        }
        else  {
            using data_t = typename T::value_type;

            const size_type col_s {
                size_type(std::distance(column_begin, column_end))
            };
            const size_type dim { column_begin->size() };

#ifdef HMDF_SANITY_EXCEPTIONS
            for (size_type i { 0 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "GeometricMeanVisitor: Inconsistent data dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

            std::vector<data_t> sum (dim, 0);

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &val { *(column_begin + i) };

                for (size_type d { 0 }; d < dim; ++d)  {
                    sum[d] += std::log(val[d]);
                }
            }
            BaseClass::_mean = std::move(sum);
            BaseClass::_cnt = col_s;
        }
    }

    inline void post ()  {

        if constexpr (std::is_arithmetic_v<T>)  {
            BaseClass::_sum.post();
            BaseClass::_mean =
                std::exp(BaseClass::_sum.get_result() / T(BaseClass::_cnt));
        }
        else  {
            using data_t = typename T::value_type;

            const size_type dim { BaseClass::_mean.size() };

            for (size_type d { 0 }; d < dim; ++d)
                BaseClass::_mean[d] =
                    std::exp(BaseClass::_mean[d] / data_t(BaseClass::_cnt));
        }
    }

    GeometricMeanVisitor(bool skipnan = true) : BaseClass(skipnan)  {   }
};

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long>
struct  HarmonicMeanVisitor : public MeanBase<T, I>  {

    using BaseClass = MeanBase<T, I>;
    using size_type = std::size_t;

    inline void operator() (const I &idx, const T &val)  {

        SKIP_NAN_BASE

        BaseClass::_cnt += 1;
        BaseClass::_sum(idx, T(1) / val);
    }

    template <typename K, typename H>
    inline void
    operator() (K /*idx_begin*/, K /*idx_end*/,
                H column_begin, H column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };
        auto            lbd =
            [this] (const auto &begin, const auto &end) -> T  {
                T   sum { 0 };

                if (! BaseClass::_skip_nan)
                    for (auto citer { begin }; citer < end; ++citer)
                        sum += T(1) / *citer;
                else
                    for (auto citer { begin }; citer < end; ++citer)
                        if (! is_nan__(*citer))
                            sum += T(1) / *citer;
                return (sum);
            };
        T               sum_sq { 0 };

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<T>(
                    column_begin, column_end, std::move(lbd))
            };

            for (auto &fut : futures)  sum_sq += fut.get();
        }
        else
            sum_sq = lbd(column_begin, column_end);

        // _sum exposes T& via get_result()
        //
        BaseClass::_sum.get_result() = sum_sq;
        BaseClass::_cnt =
            BaseClass::_skip_nan
                ? std::count_if(column_begin, column_end,
                                [](const T &v) { return (! is_nan__(v)); })
                : col_s;
    }

    inline void post ()  {

        BaseClass::_sum.post();
        BaseClass::_mean = T(BaseClass::_cnt) / BaseClass::_sum.get_result();
    }

    HarmonicMeanVisitor(bool skipnan = true) : BaseClass(skipnan)  {   }
};

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long>
struct  QuadraticMeanVisitor : public MeanBase<T, I>  {

    using BaseClass = MeanBase<T, I>;
    using size_type = std::size_t;

    inline void operator() (const I &idx, const T &val)  {

        SKIP_NAN_BASE

        BaseClass::_cnt += 1;
        BaseClass::_sum(idx, val * val);
    }

    template <typename K, typename H>
    inline void
    operator() (K /*idx_begin*/, K /*idx_end*/,
                H column_begin, H column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };
        auto            lbd =
            [this] (const auto &begin, const auto &end) -> T  {
                T   sum { 0 };

                if (! BaseClass::_skip_nan)
                    for (auto citer { begin }; citer < end; ++citer)
                        sum += *citer * *citer;
                else
                    for (auto citer { begin }; citer < end; ++citer)
                        if (! is_nan__(*citer))
                            sum += *citer * *citer;
                return (sum);
            };
        T               sum_sq { 0 };

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<T>(
                    column_begin, column_end, std::move(lbd))
            };

            for (auto &fut : futures)  sum_sq += fut.get();
        }
        else
            sum_sq = lbd(column_begin, column_end);

        // _sum exposes T& via get_result()
        //
        BaseClass::_sum.get_result() = sum_sq;
        BaseClass::_cnt =
            BaseClass::_skip_nan
                ? std::count_if(column_begin, column_end,
                                [](const T &v) { return (! is_nan__(v)); })
                : col_s;
    }

    inline void post()  {

        BaseClass::_sum.post();
        euclidean_norm_ = std::sqrt(BaseClass::_sum.get_result());
        BaseClass::_mean = euclidean_norm_ / std::sqrt(T(BaseClass::_cnt));
    }

    BaseClass::value_type
    get_euclidean_norm() const  { return (euclidean_norm_); }

    QuadraticMeanVisitor(bool skipnan = true) : BaseClass(skipnan)  {   }

private:

    BaseClass::value_type   euclidean_norm_ { 0 };
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  ProdVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    inline void operator() (const index_type &, const value_type &val)  {

        SKIP_NAN

        if constexpr (! std::is_arithmetic_v<value_type> &&
                      ! Fillable<value_type>)  {
            if (! started_)  {
                result_.resize(val.size(), 1);
                started_ = true;
            }
        }

        result_ *= val;
    }
    template <typename K, typename H>
    inline void
    operator() (const K &/*idx_begin*/, const K &/*idx_end*/,
                const H &column_begin, const H &column_end) {

        if constexpr (! std::is_arithmetic_v<value_type> &&
                      ! Fillable<value_type>)
            result_.resize(column_begin->size(), 1);

        if (std::distance(column_begin, column_end) >=
                ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    lbd =
                [this] (const auto &begin, const auto &end) -> value_type  {
                    value_type  prod { 1 };

                    if (! this->skip_nan_)  {
                        for (auto citer = begin; citer < end; ++citer)
                            prod *= *citer;
                    }
                    else  {
                        for (auto citer = begin; citer < end; ++citer)
                            if (! is_nan__(*citer))
                                prod *= *citer;
                    }

                    return (prod);
                };
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    column_begin, column_end, std::move(lbd));

            for (auto &fut : futures)  result_ *= fut.get();
        }
        else  {
            if (! skip_nan_)  {
                for (auto citer = column_begin; citer < column_end; ++citer)
                    result_ *= *citer;
            }
            else  {
                for (auto citer = column_begin; citer < column_end; ++citer)
                    if (! is_nan__(*citer))
                        result_ *= *citer;
            }
        }
    }

    inline void pre ()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            result_ = 1;
        }
        else  {
            if constexpr (Fillable<value_type>)  // For a std::array
                result_.fill(1);
            else  started_ = false;  // For a std::vector
        }
    }
    inline void post ()  {  }
    inline result_type get_result () const  { return (result_); }

    DECL_CTOR(ProdVisitor)

private:

    bool        started_ { false };
    value_type  result_ { 1 };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, typename Cmp = std::less<T>>
struct  ExtremumVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    using compare_type = Cmp;

    inline void operator() (const index_type &idx, const value_type &val)  {

        counter_ += 1;
        if (is_nan__(val)) [[unlikely]]  {
            if (skip_nan_)  return;
            else  {
                extremum_ = std::numeric_limits<value_type>::quiet_NaN();
                is_first = false;
            }
        }

        if (cmp_(extremum_, val) || is_first)  {
            extremum_ = val;
            index_ = idx;
            pos_ = counter_;
            is_first = false;
        }
    }
    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end) {

#ifdef HMDF_SANITY_EXCEPTIONS
        if (std::distance(idx_begin, idx_end) <
                std::distance(column_begin, column_end))
            throw DataFrameError("ExtremumVisitor: column size must be <= "
                                 "index size");
#endif // HMDF_SANITY_EXCEPTIONS

        GET_COL_SIZE

        size_type    index { 0 };

        for (; index < col_s; ++index, ++counter_)  {
            const auto  &val { *(column_begin + index) };

            if (! skip_nan_ || ! is_nan__(val)) [[likely]]  {
                pos_ = counter_;
                index_ = *(idx_begin + index);
                extremum_ = val;
                index += 1;
                break;
            }
        }

        // NOTE: Currently in multi-threading mode, pos_ and index_ are not
        //       updated.
        if (std::distance(column_begin, column_end) >=
                ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    lbd =
                [this] (const auto &begin, const auto &end) -> value_type  {
                    value_type  extremum { value_type(*begin) };

                    if (! this->skip_nan_)  {
                        for (auto citer { begin + 1 }; citer < end; ++citer)  {
                            if (this->cmp_(extremum, *citer))
                                extremum = *citer;
                        }
                    }
                    else  {
                        for (auto citer { begin + 1 }; citer < end; ++citer)  {
                            if (this->cmp_(extremum, *citer) &&
                                ! is_nan__(*citer))
                                extremum = *citer;
                        }
                    }

                    return (extremum);
                };
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    column_begin + index, column_end, std::move(lbd))
            };

            if (! futures.empty())  {
                extremum_ = futures[0].get();
                for (size_type i { 1 }; i < futures.size(); ++i)  {
                    const auto  val { std::move(futures[i].get()) };

                    if (cmp_(extremum_, val))
                        extremum_ = val;
                }
            }
        }
        else  {
            if (! skip_nan_)  {
                for (; index < col_s; ++index, ++counter_)  {
                    const auto  &val { *(column_begin + index) };

                    if (cmp_(extremum_, val))  {
                        extremum_ = val;
                        index_ = *(idx_begin + index);
                        pos_ = counter_;
                    }
                }
            }
            else  {
                for (; index < col_s; ++index, ++counter_)  {
                    const auto  &val { *(column_begin + index) };

                    if (cmp_(extremum_, val) && ! is_nan__(val))  {
                        extremum_ = val;
                        index_ = *(idx_begin + index);
                        pos_ = counter_;
                    }
                }
            }
        }
    }

    inline void pre ()  {
        is_first = true;
        pos_ = 0;
        counter_ = 0;
        extremum_ = value_type { };
    }
    inline void post ()  {  }
    inline result_type get_result () const  { return (extremum_); }
    inline index_type get_index () const  { return (index_); }
    inline size_type get_position () const  { return (pos_); }

    DECL_CTOR(ExtremumVisitor)

private:

    value_type      extremum_ { };
    index_type      index_ { };
    bool            is_first { true };
    size_type       pos_ { 0 };
    size_type       counter_ { 0 };
    compare_type    cmp_ {  };
    const bool      skip_nan_;
};

template<typename T, typename I = unsigned long>
using MaxVisitor = ExtremumVisitor<T, I, std::less<T>>;
template<typename T, typename I = unsigned long>
using MinVisitor = ExtremumVisitor<T, I, std::greater<T>>;

// ----------------------------------------------------------------------------

// This visitor takes O(M * log(N)),
// where N is the number of largest values and M is the total number.
//
template<typename T, typename I, template<typename> typename C>
struct  NExtremumVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    struct  DataItem  {
        value_type  value { };
        index_type  index_val { };
        size_type   index_idx { };

        inline friend bool
        operator < (const DataItem &lhs, const DataItem &rhs)  {

            return (lhs.value < rhs.value);
        }
        inline friend bool
        operator > (const DataItem &lhs, const DataItem &rhs)  {

            return (lhs.value > rhs.value);
        }
        inline friend bool
        operator <= (const DataItem &lhs, const DataItem &rhs)  {

            return (lhs.value <= rhs.value);
        }
        inline friend bool
        operator >= (const DataItem &lhs, const DataItem &rhs)  {

            return (lhs.value >= rhs.value);
        }
    };

    using compare_type = C<DataItem>;
    using result_type = std::vector<DataItem>;

    inline void operator() (const index_type &idx, const value_type &val)  {

        const size_type c = counter_++;

        SKIP_NAN

        p_queue_.push( { val, idx, c } );
        if (p_queue_.size() > n_)  p_queue_.pop();
    }

    template <typename K, typename H>
    inline void
    operator() (K idx_begin, K /*idx_end*/, H column_begin, H column_end)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        if (size_type(std::distance(column_begin, column_end)) < n_)
            throw DataFrameError("NExtremumVisitor: column size must be >= N");
#endif // HMDF_SANITY_EXCEPTIONS

        while (column_begin < column_end)
            (*this)(*idx_begin++, *column_begin++);
    }

    inline void pre()  {

        counter_ = 0;
        result_.clear();
        for (; ! p_queue_.empty(); p_queue_.pop()) ;
    }
    inline void post()  {

        for (; ! p_queue_.empty(); p_queue_.pop())
            result_.push_back(p_queue_.top());
    }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    inline void sort_by_index_val()  {

        std::sort(result_.begin(), result_.end(),
                  [](const DataItem &lhs, const DataItem &rhs) -> bool  {
                      return (lhs.index_val < rhs.index_val);
                  });
    }
    inline void sort_by_index_idx()  {

        std::sort(result_.begin(), result_.end(),
                  [](const DataItem &lhs, const DataItem &rhs) -> bool  {
                      return (lhs.index_idx < rhs.index_idx);
                  });
    }
    inline void sort_by_value()  {

        std::sort(result_.begin(), result_.end(),
                  [](const DataItem &lhs, const DataItem &rhs) -> bool  {
                      return (lhs.value < rhs.value);
                  });
    }

    explicit
    NExtremumVisitor(size_type n, bool skipnan = false)
        : p_queue_(compare_type { }, result_type { n + 1 }),
          n_(n),
          skip_nan_(skipnan)  {

        result_.reserve(n_);
    }
    NExtremumVisitor() = delete;

private:

    using q_type =
        std::priority_queue<DataItem, std::vector<DataItem>, compare_type>;

    result_type     result_ { };
    size_type       counter_ { 0 };
    q_type          p_queue_;
    const size_type n_;
    const bool      skip_nan_;
};

template<typename T, typename I = unsigned long>
using NLargestVisitor = NExtremumVisitor<T, I, std::greater>;
template<typename T, typename I = unsigned long>
using NSmallestVisitor = NExtremumVisitor<T, I, std::less>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  CovVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    Matrix<data_t, matrix_orient::row_major>>;
    using var_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;
    using mean_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;

private:

    struct  InterResults  {
        data_t      total1 { 0 };
        data_t      total2 { 0 };
        data_t      dot_prod { 0 };
        data_t      dot_prod1 { 0 };
        data_t      dot_prod2 { 0 };
        size_type   cnt { 0 };

        inline void clear()  {
            total1 = total2 = dot_prod = dot_prod1 = dot_prod2 = 0;
            cnt = 0;
        }
    };

    // Kahan summation algorithm, also known as compensated summation
    // This is numerically stable for very large numbers
    //
    template <typename H>
    inline static InterResults
    get_kahan_sum_(const H &begin1, const H &end1, const H &begin2,
                   bool skip_nan)  {

        InterResults    result { };
        auto            iter2 = begin2;
        value_type      total1_c { 0 };
        value_type      total2_c { 0 };
        value_type      dot_prod_c { 0 };
        value_type      dot_prod1_c { 0 };
        value_type      dot_prod2_c { 0 };


        if (! skip_nan)  {
            for (auto iter1 = begin1; iter1 < end1; ++iter1, ++iter2) {
                const value_type    &val1 = *iter1;
                const value_type    total1_y = val1 - total1_c;
                const value_type    total1_t = result.total1 + total1_y;

                const value_type    &val2 = *iter2;
                const value_type    total2_y = val2 - total2_c;
                const value_type    total2_t = result.total2 + total2_y;

                const value_type    dot_prod_y = (val1 * val2) - dot_prod_c;
                const value_type    dot_prod_t = result.dot_prod + dot_prod_y;

                const value_type    dot_prod1_y = (val1 * val1) - dot_prod1_c;
                const value_type    dot_prod1_t =
                    result.dot_prod1 + dot_prod1_y;

                const value_type    dot_prod2_y = (val2 * val2) - dot_prod2_c;
                const value_type    dot_prod2_t =
                    result.dot_prod2 + dot_prod2_y;

                total1_c = (total1_t - result.total1) - total1_y;
                result.total1 = total1_t;

                total2_c = (total2_t - result.total2) - total2_y;
                result.total2 = total2_t;

                dot_prod_c = (dot_prod_t - result.dot_prod) - dot_prod_y;
                result.dot_prod = dot_prod_t;

                dot_prod1_c = (dot_prod1_t - result.dot_prod1) - dot_prod1_y;
                result.dot_prod1 = dot_prod1_t;

                dot_prod2_c = (dot_prod2_t - result.dot_prod2) - dot_prod2_y;
                result.dot_prod2 = dot_prod2_t;

                result.cnt += 1;
            }
        }
        else  {
            for (auto iter1 = begin1; iter1 < end1; ++iter1, ++iter2) {
                const value_type    &val1 = *iter1;
                const value_type    &val2 = *iter2;

                if (! is_nan__(val1) && ! is_nan__(val2)) [[likely]]  {
                    const value_type    total1_y = val1 - total1_c;
                    const value_type    total1_t = result.total1 + total1_y;

                    const value_type    total2_y = val2 - total2_c;
                    const value_type    total2_t = result.total2 + total2_y;

                    const value_type    dot_prod_y = (val1 * val2) - dot_prod_c;
                    const value_type    dot_prod_t =
                        result.dot_prod + dot_prod_y;

                    const value_type    dot_prod1_y =
                        (val1 * val1) - dot_prod1_c;
                    const value_type    dot_prod1_t =
                        result.dot_prod1 + dot_prod1_y;

                    const value_type    dot_prod2_y =
                        (val2 * val2) - dot_prod2_c;
                    const value_type    dot_prod2_t =
                        result.dot_prod2 + dot_prod2_y;

                    total1_c = (total1_t - result.total1) - total1_y;
                    result.total1 = total1_t;

                    total2_c = (total2_t - result.total2) - total2_y;
                    result.total2 = total2_t;

                    dot_prod_c = (dot_prod_t - result.dot_prod) - dot_prod_y;
                    result.dot_prod = dot_prod_t;

                    dot_prod1_c =
                        (dot_prod1_t - result.dot_prod1) - dot_prod1_y;
                    result.dot_prod1 = dot_prod1_t;

                    dot_prod2_c =
                        (dot_prod2_t - result.dot_prod2) - dot_prod2_y;
                    result.dot_prod2 = dot_prod2_t;

                    result.cnt += 1;
                }
            }
        }

        return (result);
    }

    template <typename H>
    inline static InterResults
    get_regular_sum_(const H &begin1, const H &end1, const H &begin2,
                     bool skip_nan)  {

        InterResults    result { };
        auto            iter2 = begin2;

        if (! skip_nan)  {
            for (auto iter1 = begin1; iter1 < end1; ++iter1, ++iter2) {
                const value_type    &val1 = *iter1;
                const value_type    &val2 = *iter2;

                result.total1 += val1;
                result.total2 += val2;
                result.dot_prod += (val1 * val2);
                result.dot_prod1 += (val1 * val1);
                result.dot_prod2 += (val2 * val2);
                result.cnt += 1;
            }
        }
        else  {
            for (auto iter1 = begin1; iter1 < end1; ++iter1, ++iter2) {
                const value_type    &val1 = *iter1;
                const value_type    &val2 = *iter2;

                if (! is_nan__(val1) && ! is_nan__(val2)) [[likely]]  {
                    result.total1 += val1;
                    result.total2 += val2;
                    result.dot_prod += (val1 * val2);
                    result.dot_prod1 += (val1 * val1);
                    result.dot_prod2 += (val2 * val2);
                    result.cnt += 1;
                }
            }
        }

        return (result);
    }

public:

    inline void operator()(const index_type &,
                           const value_type &val1, const value_type &val2)  {

        if (skip_nan_ && (is_nan__(val1) || is_nan__(val2))) [[unlikely]]
            return;

        inter_result_.total1 += val1;
        inter_result_.total2 += val2;
        inter_result_.dot_prod += (val1 * val2);
        inter_result_.dot_prod1 += (val1 * val1);
        inter_result_.dot_prod2 += (val2 * val2);
        inter_result_.cnt += 1;
    }
    template <typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin1, const H &column_end1,
               const H &column_begin2, const H &column_end2)  {

        const size_type col_s {
            size_type(std::distance(column_begin1, column_end1))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type col_s2 {
            size_type(std::distance(column_begin2, column_end2))
        };

        if (col_s != col_s2)
            throw DataFrameError("CovVisitor: The two columns must have the "
                                 "same length");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (std::is_arithmetic_v<value_type>)  {
            auto    lbd =
                [this]
                (const auto &begin1, const auto &end1,
                 const auto &begin2) -> InterResults  {
                    if (stable_algo_)
                        return(get_kahan_sum_(begin1, end1, begin2, skip_nan_));
                    return(get_regular_sum_(begin1, end1, begin2, skip_nan_));
                };

            if (std::distance(column_begin1, column_end1) >=
                    ThreadPool::MUL_THR_THHOLD &&
                ThreadGranularity::get_thread_level() > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop2<T>(
                        column_begin1,
                        column_end1,
                        column_begin2,
                        column_end2,
                        std::move(lbd))
                };

                for (auto &fut : futures)  {
                    const auto  &result = fut.get();

                    inter_result_.total1 += result.total1;
                    inter_result_.total2 += result.total2;
                    inter_result_.dot_prod += result.dot_prod;
                    inter_result_.dot_prod1 += result.dot_prod1;
                    inter_result_.dot_prod2 += result.dot_prod2;
                    inter_result_.cnt += result.cnt;
                }
            }
            else  {
                inter_result_ = lbd(column_begin1, column_end1, column_begin2);
            }
        }
        else  {  // Multidimensional input columns
            const long  dim1 { long(column_begin1->size()) };
            const long  dim2 { long(column_begin2->size()) };

            mean1_.assign(dim1, 0);
            mean2_.assign(dim2, 0);

            auto    mean_lbd =
                [dim1, dim2]
                (const auto &begin1, const auto &end1, const auto &begin2)
                    -> std::pair<std::vector<data_t>, std::vector<data_t>>  {
                    std::vector<data_t> m1(dim1, 0), m2(dim2, 0);

                    for (auto c1 { begin1 }, c2 { begin2 };
                         c1 < end1; ++c1, ++c2)  {
                        for (long i { 0 }; i < dim1; ++i)  m1[i] += (*c1)[i];
                        for (long i { 0 }; i < dim2; ++i)  m2[i] += (*c2)[i];
                    }
                    return { std::move(m1), std::move(m2) };
                };

            if (long(col_s) >= ThreadPool::MUL_THR_THHOLD &&
                ThreadGranularity::get_thread_level() > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop2<
                        std::pair<std::vector<data_t>, std::vector<data_t>>>(
                        column_begin1, column_end1,
                        column_begin2, column_end2, std::move(mean_lbd))
                };

                for (auto &fut : futures)  {
                    auto    [m1, m2] = fut.get();

                    for (long i { 0 }; i < dim1; ++i)  mean1_[i] += m1[i];
                    for (long i { 0 }; i < dim2; ++i)  mean2_[i] += m2[i];
                }
            }
            else  {
                auto    [m1, m2] =
                    mean_lbd(column_begin1, column_end1, column_begin2);

                mean1_ = std::move(m1);
                mean2_ = std::move(m2);
            }
            mean1_ /= static_cast<data_t>(col_s);
            mean2_ /= static_cast<data_t>(col_s);

            result_.resize(dim1, dim2, 0);

            auto    cov_lbd =
                [this, dim1, dim2]
                (const auto &begin1, const auto &end1, const auto &begin2)
                    -> Matrix<data_t, matrix_orient::row_major>  {
                    Matrix<data_t, matrix_orient::row_major>   partial {
                        dim1, dim2, 0
                    };

                    for (auto c1 { begin1 }, c2 { begin2 };
                         c1 < end1; ++c1, ++c2)  {
                        for (long i { 0 }; i < dim1; ++i)  {
                            const data_t    dx { (*c1)[i] - this->mean1_[i] };

                            for (long j { 0 }; j < dim2; ++j)
                                partial(i, j) +=
                                    dx * ((*c2)[j] - this->mean2_[j]);
                        }
                    }
                    return (partial);
                };

            if (long(col_s) >= ThreadPool::MUL_THR_THHOLD &&
                ThreadGranularity::get_thread_level() > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop2<
                        Matrix<data_t, matrix_orient::row_major>>(
                        column_begin1, column_end1,
                        column_begin2, column_end2, std::move(cov_lbd))
                };

                for (auto &fut : futures)  {
                    const auto  &partial { fut.get() };

                    for (long i { 0 }; i < dim1; ++i)
                        for (long j { 0 }; j < dim2; ++j)
                            result_(i, j) += partial(i, j);
                }
            }
            else
                result_ = cov_lbd(column_begin1, column_end1, column_begin2);

            const data_t    norm {
                data_t(1) / static_cast<data_t>(col_s - b_)
            };

            for (long i { 0 }; i < dim1; ++i)
                for (long j { 0 }; j < dim2; ++j)
                    result_(i, j) *= norm;
        }
    }

    inline void pre ()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            inter_result_.clear();
            result_ = 0;
        }
        else  {
            result_.clear();
            mean1_.clear();
            mean2_.clear();
        }
    }
    inline void post ()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            const data_t    d = data_t(inter_result_.cnt) - b_;

            if (d != 0) [[likely]]  {
                result_ = (inter_result_.dot_prod -
                           (inter_result_.total1 * inter_result_.total2) /
                           data_t(inter_result_.cnt)) /
                          d;
            }
            else  { result_ = std::numeric_limits<data_t>::quiet_NaN(); }
        }
    }

    inline const result_type &get_result () const  { return (result_); }
    inline result_type &get_result ()  { return (result_); }
    inline var_t get_var1 () const  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            const data_t    d = data_t(inter_result_.cnt) - b_;

            if (d != 0) [[likely]]  {
                return ((inter_result_.dot_prod1 -
                         (inter_result_.total1 * inter_result_.total1) /
                         data_t(inter_result_.cnt)) /
                        d);
            }
            else { return (std::numeric_limits<data_t>::quiet_NaN()); }
        }
        else  {
            var_t   var (result_.rows(),
                         std::numeric_limits<data_t>::quiet_NaN());

            return (var);
        }
    }
    inline var_t get_var2 () const  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            const data_t    d = data_t(inter_result_.cnt) - b_;

            if (d != 0) [[likely]]  {
                return ((inter_result_.dot_prod2 -
                         (inter_result_.total2 * inter_result_.total2) /
                         data_t(inter_result_.cnt)) /
                        d);
            }
            else { return (std::numeric_limits<data_t>::quiet_NaN()); }
        }
        else  {
            var_t   var (result_.cols(),
                         std::numeric_limits<data_t>::quiet_NaN());

            return (var);
        }
    }
    inline size_type get_count() const  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (inter_result_.cnt);
        else
            return (0);
    }

    inline const mean_t &get_mean1() const  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            if (inter_result_.cnt | 0x0) [[likely]]
                const_cast<CovVisitor *>(this)->mean1_ =
                    inter_result_.total1 / data_t(inter_result_.cnt);
            else
                const_cast<CovVisitor *>(this)->mean1_ =
                    std::numeric_limits<data_t>::quiet_NaN();
        }
        return (mean1_);
    }
    inline const mean_t &get_mean2() const  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            if (inter_result_.cnt | 0x0) [[likely]]
                const_cast<CovVisitor *>(this)->mean2_ =
                    inter_result_.total2 / data_t(inter_result_.cnt);
            else
                const_cast<CovVisitor *>(this)->mean2_ =
                    std::numeric_limits<data_t>::quiet_NaN();
        }
        return (mean2_);
    }

    data_t get_b() const  { return (b_); }

    explicit CovVisitor (bool biased = false,
                         bool skipnan = false,
                         bool stable_algo = false)
        : b_ (biased ? 0 : 1),
          skip_nan_(skipnan),
          stable_algo_(stable_algo)  {  }
    CovVisitor(const CovVisitor &) = default;
    CovVisitor(CovVisitor &&) = default;
    CovVisitor &operator =(const CovVisitor &) = default;
    CovVisitor &operator =(CovVisitor &&) = default;
    ~CovVisitor() = default;

private:

    InterResults    inter_result_ { };
    result_type     result_ { };
    data_t          b_;
    bool            skip_nan_;
    bool            stable_algo_;
    mean_t          mean1_ { };
    mean_t          mean2_ { };
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  VarVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    Matrix<data_t, matrix_orient::row_major>>;
    using mean_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;


    inline void operator() (const index_type &idx, const value_type &val)  {

        cov_(idx, val, val);
    }
    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end) {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            cov_(idx_begin, idx_end,
                 column_begin, column_end, column_begin, column_end);
        }
        else  {
            const long col_s { long(std::distance(column_begin, column_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
            if (col_s < 3)
                throw DataFrameError("VarVisitor: Need at least 3 "
                                     "observations");
#endif // HMDF_SANITY_EXCEPTIONS

            // Accumulated centered outer products
            //
            const long          dim { long(column_begin->size()) };
            result_type         m2 { dim, dim, 0 };
            std::vector<data_t> delta(dim);  // delta = x - mean
            std::vector<data_t> delta2(dim); // delta2 = x - new_mean

            // Running mean
            //
            mean_.resize(dim, 0);
            count_ = 0;
            for (long k { 0 }; k < col_s; ++k)  {
                const auto  &point = *(column_begin + k);

#ifdef HMDF_SANITY_EXCEPTIONS
                if (long(point.size()) != dim)
                    throw DataFrameError("VarVisitor: "
                                         "Inconsistent dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

                count_ += 1;

                for (long i { 0 }; i < dim; ++i)
                    delta[i] = point[i] - mean_[i];

                // Update mean
                //
                for (long i { 0 }; i < dim; ++i)
                    mean_[i] += delta[i] / data_t(count_);

                for (long i { 0 }; i < dim; ++i)
                    delta2[i] = point[i] - mean_[i];

                // Accumulate only lower triangle
                //
                for (long i { 0 }; i < dim; ++i)
                    for (long j { 0 }; j <= i; ++j)
                        m2(i, j) += delta[i] * delta2[j];
            }

            // Normalize and symmetrize
            //
            const data_t    inv { data_t(1) / (data_t(col_s) - cov_.get_b()) };

            result_.resize(dim, dim, 0);
            for (long i { 0 }; i < dim; ++i)  {
                for (long j { 0 }; j <= i; ++j) {
                    result_(i, j) = m2(i, j) * inv;
                    if (i != j)  result_(j, i) = result_(i, j);
                }
            }
        }
    }

    inline void pre ()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            cov_.pre();
        }
        else  {
            result_.clear();
            mean_.clear();
            count_ = 0;
        }
    }
    inline void post ()  {

        if constexpr (std::is_arithmetic_v<value_type>)
            cov_.post();
    }
    inline const result_type &get_result() const  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_result());
        else
            return (result_);
    }
    inline result_type &get_result()  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_result());
        else
            return (result_);
    }
    inline size_type get_count() const  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_count());
        else
            return (count_);
    }
    inline const mean_t &get_mean() const  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_mean1());
        else
            return (mean_);
    }
    data_t get_b() const  { return (cov_.get_b()); }

    explicit VarVisitor(bool biased = false, bool skip_nan = false,
                        bool stable_algo = false)
        : cov_(biased, skip_nan, stable_algo)  {   }
    VarVisitor(const VarVisitor &) = default;
    VarVisitor(VarVisitor &&) = default;
    VarVisitor &operator =(const VarVisitor &) = default;
    VarVisitor &operator =(VarVisitor &&) = default;
    ~VarVisitor() = default;

private:

    CovVisitor<value_type, index_type>  cov_;
    mean_t                              mean_ { };
    result_type                         result_ { };
    size_type                           count_ { 0 };
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  BetaVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    Matrix<data_t, matrix_orient::row_major>>;
    using mean_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;


    inline void operator()(const index_type &idx,
                           const value_type &val, const value_type &bmark)  {

        cov_(idx, val, bmark);
    }
    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &data_begin, const H &data_end,
               const H &benchmark_begin, const H &benchmark_end)  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            cov_(idx_begin, idx_end,
                 data_begin, data_end, benchmark_begin, benchmark_end);
        }
        else  {
#ifdef HMDF_SANITY_EXCEPTIONS
            const long  data_s { long(std::distance(data_begin, data_end)) };
            const long  bench_s {
                long(std::distance(benchmark_begin, benchmark_end))
            };

            if (data_s != bench_s)
                throw DataFrameError(
                    "BetaVisitor: Data and benchmark size " "mismatch");
            if (data_s < 3)
                throw DataFrameError(
                    "BetaVisitor: Need at least 3 " "observations");
#endif // HMDF_SANITY_EXCEPTIONS

            // Σ_XY (d1 × d2)
            //
            cov_.pre();
            cov_(idx_begin, idx_end,
                 data_begin, data_end, benchmark_begin, benchmark_end);
            cov_.post();

            const auto  sigma_xy { std::move(cov_.get_result()) };

            // Σ_Y (d2 × d2)
            //
            VarVisitor<value_type, index_type>  var_;

            var_.pre();
            var_(idx_begin, idx_end, benchmark_begin, benchmark_end);
            var_.post();

            const auto  sigma_y { std::move(var_.get_result()) };

            // Solve Σ_Y * B^T = Σ_XY^T
            //
            const auto  rhs { sigma_xy.transpose2() };

            // B^T = Σ_Y^{-1} * Σ_XY^T
            //
            const auto  bt { sigma_y.solve(rhs) };

            // B
            //
            result_ = bt.transpose2();
        }
    }

    inline void pre()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            cov_.pre();
            result_ = 0;
        }
        else  result_.clear();
    }
    inline void post()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            cov_.post();

            const value_type    v { cov_.get_var2() };

            result_ = v != 0.0
                          ? cov_.get_result() / v
                          : std::numeric_limits<value_type>::quiet_NaN();
        }
    }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline size_type get_count() const  { return (cov_.get_count()); }
    inline const mean_t &get_data_mean() const  { return (cov_.get_mean1()); }
    inline const mean_t &
    get_benchmark_mean() const  { return (cov_.get_mean2()); }

    explicit
    BetaVisitor(bool biased = false,
                bool skip_nan = false,
                bool stable_algo = false)
        : cov_(biased, skip_nan, stable_algo)  {   }

private:

    CovVisitor<value_type, index_type>  cov_;
    result_type                         result_ { };
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  StdVisitor   {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;
    using mean_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;

    inline void
    operator()(const index_type &idx, const value_type &val)  {

        var_(idx, val);
    }
    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end) {

        var_(idx_begin, idx_end, column_begin, column_end);
    }

    inline void pre()  {

        var_.pre();
        if constexpr (std::is_arithmetic_v<value_type>)
            result_ = 0;
        else
            result_.clear();
    }
    inline void post()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            var_.post();
            result_ = ::sqrt(var_.get_result());
        }
        else  {
            const auto  &var { var_.get_result() };

            result_.resize(var.rows());
            for (long i { 0 }; i < var.rows(); ++i)
                result_[i] = std::sqrt(var(i, i));
        }
    }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline size_type get_count() const  { return (var_.get_count()); }
    inline const mean_t &get_mean() const  { return (var_.get_mean()); }
    data_t get_b() const  { return (var_.get_b()); }

    explicit
    StdVisitor(bool biased = false,
               bool skip_nan = false,
               bool stable_algo = false)
        : var_ (biased, skip_nan, stable_algo)  {   }

private:

    VarVisitor<value_type, index_type>  var_;
    result_type                         result_ { };
};

// ----------------------------------------------------------------------------

// Standard Error of the Mean
//
template<typename T, typename I = unsigned long>
struct  SEMVisitor   {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    Matrix<data_t, matrix_orient::row_major>>;
    using mean_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;


    inline void operator()(const index_type &idx, const value_type &val)  {

        std_ (idx, val);
    }
    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end) {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            std_(idx_begin, idx_end, column_begin, column_end);
        }
        else  {
            const long                          col_s {
                long(std::distance(column_begin, column_end))
            };
            const long                          dim = column_begin->size();
            CovVisitor<value_type, index_type>  cov;

            // Calculate covariance of dimensions
            //
            mean_t  means (dim, 0);
            mean_t  delta (dim, 0);
            mean_t  delta2(dim, 0);

            result_.resize(dim, dim, 0);
            for (long j { 0 }; j < col_s; ++j)  {
                const auto  &point = *(column_begin + j);

                for (long i { 0 }; i < dim; ++i)
                    delta[i] = point[i] - means[i];

                const data_t    inv_n { data_t(1) / data_t(j + 1) };

                // Update mean
                //
                for (long i { 0 }; i < dim; ++i)
                    means[i] += delta[i] * inv_n;

                for (long i { 0 }; i < dim; ++i)
                    delta2[i] = point[i] - means[i];

                // Update result (outer product)
                //
                for (long i { 0 }; i < dim; ++i)
                    for (long k { 0 }; k < dim; ++k)
                        result_(i, k) += delta[i] * delta2[k];
            }

            const data_t    denom {
                data_t(1) / (data_t(col_s) - std_.get_b())
            };
            const data_t    inv_n { data_t(1) / data_t(col_s) };

            // Per-dimension standard error (diagonal only)
            //
            per_dim_SEM_.resize(dim, 0);
            for (long i { 0 }; i < dim; ++i)
                per_dim_SEM_[i] = std::sqrt(result_(i, i) * inv_n);

            // Full covariance of the SEM (dim x dim)
            //
            for (long i { 0 }; i < dim; ++i)
                for (long k { 0 }; k < dim; ++k)
                    result_(i, k) *= denom * inv_n;
        }
    }

    inline void pre()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            std_.pre();
            result_ = 0;
        }
        else  {
            result_.clear();
            per_dim_SEM_.clear();
        }
    }
    inline void post()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            std_.post();
            result_ = std_.get_result() / ::sqrt(get_count());
        }
    }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline size_type get_count() const  { return (std_.get_count()); }
    inline const mean_t &get_per_dim_SEM() const  { return (per_dim_SEM_); }
    inline mean_t &get_per_dim_SEM()  { return (per_dim_SEM_); }

    explicit SEMVisitor(bool biased = false) : std_ (biased)  {   }

private:

    StdVisitor<value_type, index_type>  std_;
    result_type                         result_ { };
    COND_DECL(! std::is_arithmetic_v<T>, mean_t, per_dim_SEM_);
};

template<typename T, typename I = unsigned long>
using sem_v = SEMVisitor<T, I>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  TrackingErrorVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;
    using mean_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;
    using matrix_t = Matrix<data_t, matrix_orient::row_major>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;

    inline void operator()(const index_type &idx,
                           const value_type &val1, const value_type &val2)  {

        std_(idx, val1 - val2);
    }
    template <typename K, typename H>
    inline void
    operator()(K idx_begin, K /*idx_end*/,
               H column_begin1, H column_end1,
               H column_begin2, H column_end2)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        const long  col_s1 { long(std::distance(column_begin1, column_end1)) };
        const long  col_s2 { long(std::distance(column_begin2, column_end2)) };

        if (col_s1 != col_s2)
            throw DataFrameError(
                "TrackingErrorVisitor: Both columns must have same size");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (std::is_arithmetic_v<value_type>)  {
            while (column_begin1 < column_end1 && column_begin2 < column_end2)
                (*this)(*idx_begin++, *column_begin1++, *column_begin2++);
        }
        else  {
            const long  col_s {
                long(std::distance(column_begin1, column_end1))
            };
            const long  dim = long(column_begin1->size());
            mean_t      mean_x(dim, 0);
            mean_t      mean_y(dim, 0);
            matrix_t    m2_x { dim, dim, 0 };
            matrix_t    m2_y { dim, dim, 0 };
            matrix_t    m2_xy { dim, dim, 0 };
            mean_t      dx2(dim, 0);
            mean_t      dy2(dim, 0);
            mean_t      dx(dim, 0);
            mean_t      dy(dim, 0);

            for (long j { 0 }; j < col_s; ++j)  {
                const auto  &val_x { *(column_begin1 + j) };
                const auto  &val_y { *(column_begin2 + j) };

                for (long i { 0 }; i < dim; ++i)  {
                    dx[i] = val_x[i] - mean_x[i];
                    dy[i] = val_y[i] - mean_y[i];
                }

                const data_t    inv_n { data_t(1) / data_t(j + 1) };

                mean_x += dx * inv_n;
                mean_y += dy * inv_n;

                for (long i { 0 }; i < dim; ++i)  {
                    dx2[i] = val_x[i] - mean_x[i];
                    dy2[i] = val_y[i] - mean_y[i];
                }

                for (long i { 0 }; i < dim; ++i)  {
                    for (long k { 0 }; k < dim; ++k)  {
                        m2_x(i, k) += dx[i] * dx2[k];
                        m2_y(i, k) += dy[i] * dy2[k];
                        m2_xy(i, k) += dx[i] * dy2[k];
                    }
                }
            }

            // Calculate covariance
            //
            matrix_t        cov { dim, dim, 0 };
            const data_t    denom {
                data_t(1) / (data_t(col_s) - std_.get_b())
            };

            for (long i { 0 }; i < dim; ++i)
                for (long j { 0 }; j < dim; ++j)
                    cov(i, j) = m2_x(i, j) * denom +
                                m2_y(i, j) * denom -
                                m2_xy(i, j) * denom -
                                m2_xy(j, i) * denom;

            // Tracking error vector
            //
            result_.resize(dim, 0);
            for (long i { 0 }; i < dim; ++i)
                result_[i] = std::sqrt(cov(i, i));
        }
    }


    inline void pre()  {

        if constexpr (std::is_arithmetic_v<value_type>)
            std_.pre();
        else  result_.clear();
    }
    inline void post()  {

        if constexpr (std::is_arithmetic_v<value_type>)
            std_.post();
    }
    inline const result_type &get_result() const  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (std_.get_result());
        else  return (result_);
    }
    inline result_type &get_result()  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (std_.get_result());
        else  return (result_);
    }

    explicit TrackingErrorVisitor (bool biased = false) : std_ (biased)  {  }

private:

    using stdev_type = StdVisitor<value_type, index_type>;

    stdev_type  std_;
    COND_DECL(! std::is_arithmetic_v<T>, result_type, result_);
};

template<typename T, typename I = unsigned long>
using te_v = TrackingErrorVisitor<T, I>;

// ----------------------------------------------------------------------------

// This ranks the values in the column based on rank policy starting from 0.
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  RankVisitor  {

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        std::vector<value_type,
                    typename allocator_declare<value_type, A>::type>;

    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        using vec_t =
            std::vector<size_type,
                        typename allocator_declare<size_type, A>::type>;

        vec_t   rank_vec(col_s);

        std::iota(rank_vec.begin(), rank_vec.end(), 0);
        std::stable_sort(
            rank_vec.begin(), rank_vec.end(),
            [&column_begin](size_type lhs, size_type rhs) -> bool  {
                return *(column_begin + lhs) < *(column_begin + rhs);
            });

        result_type         result(col_s);
        const value_type    *prev_value { &*(column_begin + rank_vec[0]) };

        for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
            value_type  avg_val { static_cast<value_type>(i) };
            value_type  first_val { static_cast<value_type>(i) };
            value_type  last_val { static_cast<value_type>(i) };
            size_type   j { i + 1 };

            for ( ; j < col_s && *prev_value == *(column_begin + rank_vec[j]);
                 ++j)  {
                last_val = static_cast<value_type>(j);
                avg_val += static_cast<value_type>(j);
            }
            avg_val /= value_type(j - i);

            switch(policy_)  {
            case rank_policy::average:
                for (; i < col_s && i < j; ++i)
                    result[rank_vec[i]] = avg_val;
                break;
            case rank_policy::first:
                for (; i < col_s && i < j; ++i)
                    result[rank_vec[i]] = first_val;
                break;
            case rank_policy::last:
                for (; i < col_s && i < j; ++i)
                    result[rank_vec[i]] = last_val;
                break;
            case rank_policy::actual:
                for (; i < col_s && i < j; ++i)
                    result[rank_vec[i]] = static_cast<value_type>(i);
                break;
            }
            if (i < col_s)
                prev_value = &*(column_begin + rank_vec[i]);
            i -= 1;  // Because the outer loop does ++i
        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    RankVisitor(rank_policy p = rank_policy::actual) : policy_(p)  {   }

private:

    // I had to make policy_ non-const, because in Windows compiler the
    // assignment operator is implicitly deleted. We need this visitor to be
    // assignable for multithreading
    //
    rank_policy policy_;
    result_type result_ { };
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  CorrVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;
    using mean_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    T,
                                    std::vector<data_t>>;


    inline void operator()(const index_type &idx,
                           const value_type &val1, const value_type &val2)  {

        cov_(idx, val1, val2);
    }

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin1, const H &column_end1,
               const H &column_begin2, const H &column_end2)  {

        if (type_ == correlation_type::pearson)  {
            if constexpr (std::is_arithmetic_v<value_type>)  {
                cov_ (idx_begin, idx_end,
                      column_begin1, column_end1, column_begin2, column_end2);
            }
            else  {
                cov_.pre();
                cov_(idx_begin, idx_end,
                     column_begin1, column_end1,
                     column_begin2, column_end2);
                cov_.post();

                var1_.pre();
                var1_(idx_begin, idx_end, column_begin1, column_end1);
                var1_.post();

                var2_.pre();
                var2_(idx_begin, idx_end, column_begin2, column_end2);
                var2_.post();

                const long  dim = long(column_begin1->size());

                result_.resize(dim, std::numeric_limits<data_t>::quiet_NaN());
                for (long i { 0 }; i < dim; ++i)  {
                    const auto  var_x = var1_.get_result()(i, i);
                    const auto  var_y = var2_.get_result()(i, i);

                    if (var_x > 0 && var_y > 0) [[likely]]
                        result_[i] =
                            cov_.get_result()(i, i) / std::sqrt(var_x * var_y);
                }
                mean1_ = std::move(var1_.get_mean());
                mean2_ = std::move(var2_.get_mean());
            }
        }
        else if constexpr (std::is_arithmetic_v<value_type>)  {
            const size_type col_s =
                std::min ({ std::distance(idx_begin, idx_end),
                            std::distance(column_begin1, column_end1),
                            std::distance(column_begin2, column_end2) });
            const auto      thread_level =
                (col_s < ThreadPool::MUL_THR_THHOLD)
                    ? 0L : ThreadGranularity::get_thread_level();

            if (type_ == correlation_type::spearman) {
                auto    calc_lbd =
                    [col_s, this]
                    (const auto &rank1, const auto &rank2) -> void  {
                        value_type  diff_sum { 0 };

                        for (size_type i = 0; i < col_s; ++i)  {
                            const value_type diff = rank1[i] - rank2[i];

                            diff_sum += diff * diff;
                        }

                        this->result_ =
                            value_type(1) -
                            ((value_type(6) * diff_sum) /
                             (value_type(col_s * (col_s * col_s - 1))));
                    };

                if (thread_level > 2)  {
                    auto    lbd =
                        [](const K &ib, const K &ie,
                           const H &cb, const H &ce) -> RankVisitor<T, I>  {
                            RankVisitor<T, I>   rank;

                            rank.pre();
                            rank(ib, ie, cb, ce);
                            rank.post();
                            return (rank);
                        };
                    auto    fut1 =
                        ThreadGranularity::thr_pool_.dispatch(
                              false,
                              lbd,
                                  std::cref(idx_begin),
                                  std::cref(idx_end),
                                  std::cref(column_begin1),
                                  std::cref(column_end1));
                    auto    fut2 =
                        ThreadGranularity::thr_pool_.dispatch(
                              false,
                              lbd,
                                  std::cref(idx_begin),
                                  std::cref(idx_end),
                                  std::cref(column_begin2),
                                  std::cref(column_end2));

                    calc_lbd(fut1.get().get_result(), fut2.get().get_result());
                }
                else  {
                    RankVisitor<T, I>   rank1;

                    rank1.pre();
                    rank1(idx_begin, idx_end, column_begin1, column_end1);
                    rank1.post();

                    const auto  rank2 = rank1.get_result();

                    rank1.pre();
                    rank1(idx_begin, idx_end, column_begin2, column_end2);
                    rank1.post();

                    calc_lbd(rank2, rank1.get_result());
                }
            }
            else if (type_ == correlation_type::kendall_tau)  {
                auto        lbd =
                    [&column_begin1 = std::as_const(column_begin1),
                     &column_begin2 = std::as_const(column_begin2)]
                    (auto begin, auto end) -> value_type  {
                        // concordant pairs - discordant pairs
                        //
                        value_type  diff { 0 };

                        for (size_type i { begin }; i < (end - 1); ++i)  {
                            for (size_type j { i + 1 }; j < end; ++j)  {
                                diff +=
                                    std::copysign(T(1),
                                                  (*(column_begin1 + i) -
                                                   *(column_begin1 + j)) *
                                                  (*(column_begin2 + i) -
                                                   *(column_begin2 + j)));
                            }
                        }

                        return (diff);
                    };
                // concordant - discordant
                //
                value_type  concordant_diff { 0 };

                if (thread_level > 2)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                            size_type(0), col_s, std::move(lbd));

                    for (auto &fut : futures)  concordant_diff += fut.get();
                }
                else  {
                    concordant_diff = lbd(size_type(0), col_s);
                }

                result_ = concordant_diff / ((col_s * (col_s - 1)) / T(2));
            }
        }
    }

    inline void pre()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            cov_.pre();
            result_ = 0;
        }
        else  result_.clear();
    }
    inline void post()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            if (type_ == correlation_type::pearson)  {
                cov_.post();
                result_ = cov_.get_result() /
                          (::sqrt(cov_.get_var1()) * ::sqrt(cov_.get_var2()));
            }
        }
    }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline const mean_t &get_data_mean1() const {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_mean1());
        else  return (mean1_);
    }
    inline mean_t &get_data_mean1()  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_mean1());
        else  return (mean1_);
    }
    inline const mean_t &get_data_mean2() const {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_mean2());
        else  return (mean2_);
    }
    inline mean_t &get_data_mean2()  {

        if constexpr (std::is_arithmetic_v<value_type>)
            return (cov_.get_mean2());
        else  return (mean2_);
    }

    explicit
    CorrVisitor(correlation_type t = correlation_type::pearson,
                bool biased = false,
                bool skip_nan = false,
                bool stable_algo = false)
        : cov_(biased, skip_nan, stable_algo), type_(t)  {

        if constexpr (! std::is_arithmetic_v<value_type>)  {
            var1_ = var_t{ biased, skip_nan, stable_algo };
            var2_ = var_t{ biased, skip_nan, stable_algo };
        }
    }

private:

    using var_t = VarVisitor<T, I>;

    CovVisitor<value_type, index_type>  cov_;
    result_type                         result_ { };
    const correlation_type              type_;
    COND_DECL(! std::is_arithmetic_v<T>, var_t, var1_);
    COND_DECL(! std::is_arithmetic_v<T>, var_t, var2_);
    COND_DECL(! std::is_arithmetic_v<T>, mean_t, mean1_);
    COND_DECL(! std::is_arithmetic_v<T>, mean_t, mean2_);
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  CrossCorrVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin1, const H &column_end1,
                const H &column_begin2, const H &column_end2)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        {
        const long  col_s1 = long(std::distance(column_begin1, column_end1));
        const long  col_s2 = long(std::distance(column_begin2, column_end2));

        if (std::abs(min_lag_) >= (col_s1 - 3) ||
            std::abs(max_lag_) >= (col_s2 - 3))
            throw DataFrameError("CrossCorrVisitor: Timeseries are too short");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        result_.reserve(max_lag_ - min_lag_);
        for (long i = min_lag_; i < max_lag_; ++i)  {
            corr_.pre();
            if (i < 0)
                corr_(idx_begin, idx_end,
                      column_begin1 + std::abs(i), column_end1,
                      column_begin2, column_end2 + i);
            else
                corr_(idx_begin, idx_end,
                      column_begin1, column_end1 - i,
                      column_begin2 + i, column_end2);
            corr_.post();
            result_.push_back(corr_.get_result());
        }
    }

    CrossCorrVisitor (long min_lag, long max_lag,
                      correlation_type t = correlation_type::pearson,
                      bool biased = false,
                      bool skip_nan = false,
                      bool stable_algo = false)
        : corr_ (t, biased, skip_nan, stable_algo),
          min_lag_(min_lag),
          max_lag_(max_lag)  {  }

    inline void pre()  { result_.clear(); }
    inline void post ()  {  }

    inline const result_type &get_result () const  { return (result_); }
    inline result_type &get_result ()  { return (result_); }

private:

    CorrVisitor<value_type, index_type> corr_;
    result_type                         result_ { };
    const long                          min_lag_;
    const long                          max_lag_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  DotProdVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    using data_t = typename std::conditional_t<! is_md_,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = data_t;
    using comp_result_t = std::vector<data_t>;
    using mag_t =
        typename std::conditional_t<! is_md_,
                                    T,
                                    std::vector<data_t>>;

    inline void operator()(const index_type &,
                           const value_type &val1, const value_type &val2)  {

        result_ += val1 * val2;
        mag1_ += val1 * val1;
        mag2_ += val2 * val2;

        const value_type    diff { val1 - val2 };

        euc_dist_ += diff * diff;
        man_dist_ += std::fabs(diff);
    }

    template <typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin1, const H &column_end1,
               const H &column_begin2, const H &column_end2)  {

        const size_type  col_s {
            size_type(std::distance(column_begin1, column_end1))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type  col_s2 {
            size_type(std::distance(column_begin2, column_end2))
        };

        if (col_s != col_s2)
            throw DataFrameError(
                "DotProdVisitor: Two columns must have the same length");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (std::is_arithmetic_v<value_type>)  {
            auto    lbd =
                [](const auto &begin1, const auto &end1,
                   const auto &begin2) -> std::tuple<result_type,
                                                     result_type,
                                                     result_type,
                                                     result_type,
                                                     result_type>  {
                    value_type  result { 0 };
                    value_type  mag1 { 0 };
                    value_type  mag2 { 0 };
                    value_type  euc_dist { 0 };
                    value_type  man_dist { 0 };
                    auto        iter2 { begin2 };

                    for (auto iter1 { begin1 };
                         iter1 < end1; ++iter1, ++iter2) {
                        const auto  val1 { *iter1 };
                        const auto  val2 { *iter2 };

                        result += val1 * val2;
                        mag1 += val1 * val1;
                        mag2 += val2 * val2;

                        const value_type    diff { val1 - val2 };

                        euc_dist += diff * diff;
                        man_dist += std::fabs(diff);
                    }
                    return (std::make_tuple(result,
                                            mag1,
                                            mag2,
                                            euc_dist,
                                            man_dist));
                };

            if (col_s >= ThreadPool::MUL_THR_THHOLD &&
                ThreadGranularity::get_thread_level() > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop2<T>(
                        column_begin1,
                        column_end1,
                        column_begin2,
                        column_end2,
                        std::move(lbd))
                };

                for (auto &fut : futures)  {
                    const auto  ret { fut.get() };

                    result_ += std::get<0>(ret);
                    mag1_ += std::get<1>(ret);
                    mag2_ += std::get<2>(ret);
                    euc_dist_ += std::get<3>(ret);
                    man_dist_ += std::get<4>(ret);
                }
            }
            else  {
                const auto  ret {
                    lbd(column_begin1, column_end1, column_begin2)
                };

                result_ = std::get<0>(ret);
                mag1_ = std::get<1>(ret);
                mag2_ = std::get<2>(ret);
                euc_dist_ = std::get<3>(ret);
                man_dist_ = std::get<4>(ret);
            }
        }
        else  {  // Multidimensional path
            const size_type dim { column_begin1->size() };

#ifdef HMDF_SANITY_EXCEPTIONS
            for (size_type i { 0 }; i < col_s; ++i)
                if ((column_begin1 + i)->size() != dim ||
                    (column_begin2 + i)->size() != dim)
                    throw DataFrameError(
                        "DotProdVisitor: Inconsistent data dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

            // Component-wise dot product, magnitudes, and distances
            // euc_dist_ and man_dist_ accumulate per-row then are summed;
            // sqrt is taken per-row here so post() must not apply it again.
            //
            comp_result_.resize(dim, 0);
            mag1_.resize(col_s);
            mag2_.resize(col_s);
            for (size_type n { 0 }; n < col_s; ++n)  {
                data_t      mag1    { 0 };
                data_t      mag2    { 0 };
                data_t      euc     { 0 };
                data_t      man     { 0 };
                const auto  &ary1   { *(column_begin1 + n) };
                const auto  &ary2   { *(column_begin2 + n) };

                for (size_type d { 0 }; d < dim; ++d)  {
                    const auto  val1 { ary1[d] };
                    const auto  val2 { ary2[d] };

                    comp_result_[d] += val1 * val2;
                    mag1 += val1 * val1;
                    mag2 += val2 * val2;

                    const data_t    diff { val1 - val2 };

                    euc += diff * diff;
                    man += std::abs(diff);
                }
                mag1_[n] = std::sqrt(mag1);
                mag2_[n] = std::sqrt(mag2);
                euc_dist_ += std::sqrt(euc);
                man_dist_ += man;
            }
            result_ = std::accumulate(comp_result_.begin(),
                                      comp_result_.end(),
                                      data_t(0));

        }
    }

    inline void pre()  {

        result_ = euc_dist_ = man_dist_ = 0;
        if constexpr (std::is_arithmetic_v<value_type>)  {
            mag1_ = mag2_ = 0;
        }
        else  {
            comp_result_.clear();
            mag1_.clear();
            mag2_.clear();
        }
    }
    inline void post()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            mag1_ = std::sqrt(mag1_);
            mag2_ = std::sqrt(mag2_);
            euc_dist_ = std::sqrt(euc_dist_);
        }
    }
    inline result_type get_result() const  { return (result_); }
    inline const mag_t &get_magnitude1() const  { return (mag1_); }
    inline mag_t &get_magnitude1()  { return (mag1_); }
    inline const mag_t &get_magnitude2() const  { return (mag2_); }
    inline mag_t &get_magnitude2() { return (mag2_); }

    inline const comp_result_t &get_comp_dp() const  { return (comp_result_); }
    inline comp_result_t &get_comp_dp() { return (comp_result_); }

    inline result_type get_euclidean_dist() const  { return (euc_dist_); }
    inline result_type get_manhattan_dist() const  { return (man_dist_); }

private:

    result_type     result_ { 0 };    // Dot product of two vectors
    mag_t           mag1_ { };        // Magnitude of first vector
    mag_t           mag2_ { };        // Magnitude of second vector
    result_type     euc_dist_ { 0 };  // Euclidean distance of two vectors
    result_type     man_dist_ { 0 };  // Manhattan distance of two vectors
    comp_result_t   comp_result_ { }; // Component-wise dot product
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, typename C = std::less<T>>
struct  ExtremumSubArrayVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    using compare_type = C;

    inline void operator() (const index_type &, const value_type &val)  {

        if (val >= min_to_consider_ && val <= max_to_consider_)  {
            const value_type    current_plus_val = current_sum_ + val;

            if (cmp_(current_plus_val, val))  {
                // Start a new sequence at the current element
                current_begin_idx_ = current_end_idx_;
                current_sum_ = val;
            }
            else // Extend the existing sequence with the current element
                current_sum_ = current_plus_val;

            if (cmp_(best_sum_, current_sum_))  {
                best_sum_ = current_sum_;
                best_begin_idx_ = current_begin_idx_;
                best_end_idx_ = current_end_idx_ + 1; // Make end_idx exclusive
            }
        }
        current_end_idx_ += 1;
    }
    PASS_DATA_ONE_BY_ONE

    inline void pre ()  {

        best_sum_ = cmp_(-std::numeric_limits<value_type>::max(),
                         std::numeric_limits<value_type>::max())
                             ? -std::numeric_limits<value_type>::max()
                             : std::numeric_limits<value_type>::max();
        best_begin_idx_ = 0;
        best_end_idx_ = 0;
        current_begin_idx_ = 0;
        current_end_idx_ = 0;
        current_sum_ = cmp_(-std::numeric_limits<value_type>::max(),
                            std::numeric_limits<value_type>::max())
                                ? -std::numeric_limits<value_type>::max()
                                : std::numeric_limits<value_type>::max();
    }
    inline void post ()  {  }
    inline result_type get_result () const  { return (best_sum_); }
    inline size_type get_begin_idx () const  { return (best_begin_idx_); }
    inline size_type get_end_idx () const  { return (best_end_idx_); }

    explicit ExtremumSubArrayVisitor(
        value_type min_to_consider = -std::numeric_limits<value_type>::max(),
        value_type max_to_consider = std::numeric_limits<value_type>::max())
        : min_to_consider_(min_to_consider),
          max_to_consider_(max_to_consider)  {   }

private:

    const value_type    min_to_consider_;
    const value_type    max_to_consider_;
    compare_type        cmp_ {  };
    result_type         best_sum_ {
        cmp_(-std::numeric_limits<value_type>::max(),
             std::numeric_limits<value_type>::max())
                 ? -std::numeric_limits<value_type>::max()
                 : std::numeric_limits<value_type>::max()
    };
    size_type           best_begin_idx_ { 0 };
    size_type           best_end_idx_ { 0 };
    size_type           current_begin_idx_ { 0 };
    size_type           current_end_idx_ { 0 };
    result_type         current_sum_ {
        cmp_(-std::numeric_limits<value_type>::max(),
             std::numeric_limits<value_type>::max())
                 ? -std::numeric_limits<value_type>::max()
                 : std::numeric_limits<value_type>::max()
    };
};

template<typename T, typename I = unsigned long>
using MaxSubArrayVisitor = ExtremumSubArrayVisitor<T, I, std::less<T>>;
template<typename T, typename I = unsigned long>
using MinSubArrayVisitor = ExtremumSubArrayVisitor<T, I, std::greater<T>>;

// ----------------------------------------------------------------------------

template<std::size_t N, typename T,
         typename I = unsigned long,
         typename C = std::less<T>,
         std::size_t A = 0>
struct  NExtremumSubArrayVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    struct  SubArrayInfo  {

        value_type  sum { };
        size_type   begin_index { 0 };
        size_type   end_index { 0 };

        friend inline bool
        operator < (const SubArrayInfo &lhs, const SubArrayInfo &rhs)  {

            return (lhs.sum < rhs.sum);
        }
        friend inline bool
        operator > (const SubArrayInfo &lhs, const SubArrayInfo &rhs)  {

            return (lhs.sum > rhs.sum);
        }
    };

    using result_type =
        std::vector<SubArrayInfo,
                    typename allocator_declare<SubArrayInfo, A>::type>;
    using compare_type = C;

    // NOTE: kept for interface completeness / any one-element-at-a-time
    // caller. The real algorithm needs random access to the whole column
    // (see compute_top_n_() below), so it only buffers here -- the actual
    // computation runs once in post().
    //
    inline void operator()(const index_type &, const value_type &val)  {

        buffer_.push_back(val);
    }

    template <typename K, typename H>
    inline void
    operator()(K /*idx_begin*/, K /*idx_end*/, H column_begin, H column_end)  {

        compute_top_n_(column_begin, column_end);
    }

    inline void pre()  {

        buffer_.clear();
        result_.clear();
    }
    inline void post()  {

        if (! buffer_.empty())
            compute_top_n_(buffer_.begin(), buffer_.end());
    }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    explicit NExtremumSubArrayVisitor(
        value_type min_to_consider = -std::numeric_limits<value_type>::max(),
        value_type max_to_consider = std::numeric_limits<value_type>::max())
        : extremum_sub_array_(min_to_consider, max_to_consider)  {   }

private:

    ExtremumSubArrayVisitor<T, I, C>   extremum_sub_array_;
    std::vector<value_type>            buffer_ {  };
    result_type                        result_ {  };
    compare_type                       cmp_ {  };

    // Finds the true top (at most) N disjoint sub-arrays by repeatedly
    // taking the single best remaining sub-array (via the Kadane's scan
    // in ExtremumSubArrayVisitor above) and recursing into the two
    // sub-ranges left after excluding it. This guarantees every returned
    // sub-array is genuinely non-dominated and none overlap -- unlike a
    // single Kadane's pass, which can only report the sequence of
    // running-best records it happened to set, silently missing real
    // candidates that simply never beat an earlier, unrelated record.
    // Complexity: O(n) for the first scan, plus up to two rescans (each
    // O(remaining range)) and one O(log N) heap operation per result
    // produced -- i.e. O(n + kN log N) with k bounded by the remaining
    // range size at each step.
    //
    template <typename Iter>
    inline void compute_top_n_(Iter col_begin, Iter col_end)  {

        const size_type n {
            static_cast<size_type>(std::distance(col_begin, col_end))
        };

        result_.clear();
        if (n == 0 || N == 0)  return;

        struct  Candidate  {
            SubArrayInfo    info {  };
            size_type       search_lo { 0 };
            size_type       search_hi { 0 };
        };
        struct  CandComp  {
            compare_type    sum_cmp_ {  };

            inline bool
            operator()(const Candidate &lhs, const Candidate &rhs) const  {

                return (sum_cmp_(lhs.info.sum, rhs.info.sum));
            }
        };

        // Best sub-array within [lo, hi) of the column, via the same
        // Kadane's scan and value filter as ExtremumSubArrayVisitor.
        // Returns false if nothing in [lo, hi) passes the filter.
        //
        auto    find_best =
            [this, col_begin]
            (size_type lo, size_type hi, Candidate &out) -> bool  {
                extremum_sub_array_.pre();
                for (size_type i { lo }; i < hi; ++i)
                    extremum_sub_array_(index_type { }, *(col_begin + i));

                const size_type rel_end { extremum_sub_array_.get_end_idx() };

                if (rel_end == 0)  return (false);

                out.info.sum = extremum_sub_array_.get_result();
                out.info.begin_index =
                    lo + extremum_sub_array_.get_begin_idx();
                out.info.end_index = lo + rel_end;
                out.search_lo = lo;
                out.search_hi = hi;
                return (true);
            };

        std::priority_queue<Candidate,
                            std::vector<Candidate>,
                            CandComp>   heap;
        Candidate                       first;

        if (find_best(0, n, first))
            heap.push(std::move(first));

        while (! heap.empty() && result_.size() < N)  {
            const Candidate top { heap.top() };

            heap.pop();
            result_.push_back(top.info);

            Candidate   left {  };
            Candidate   right {  };

            if (top.info.begin_index > top.search_lo &&
                find_best(top.search_lo, top.info.begin_index, left))
                heap.push(std::move(left));
            if (top.info.end_index < top.search_hi &&
                find_best(top.info.end_index, top.search_hi, right))
                heap.push(std::move(right));
        }

        std::sort(result_.begin(), result_.end(),
                  [this]
                  (const SubArrayInfo &lhs, const SubArrayInfo &rhs) -> bool {
                      return (cmp_(lhs.sum, rhs.sum));
                  });
    }
};

template<std::size_t N, typename T, typename I = unsigned long,
         std::size_t A = 0>
using NMaxSubArrayVisitor = NExtremumSubArrayVisitor<N, T, I, std::less<T>, A>;
template<std::size_t N, typename T, typename I = unsigned long,
         std::size_t A = 0>
using NMinSubArrayVisitor =
    NExtremumSubArrayVisitor<N, T, I, std::greater<T>, A>;

// ----------------------------------------------------------------------------

// Simple rolling adoptor for visitors
//
template<typename F, typename T, typename I = unsigned long, std::size_t A = 0>
struct  SimpleRollAdopter  {

private:

    using visitor_type = F;
    using f_result_type = typename visitor_type::result_type;

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        std::vector<f_result_type,
                    typename allocator_declare<f_result_type, A>::type>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (roll_count_ == 0 || roll_count_ > col_s)
            throw DataFrameError("SimpleRollAdopter: roll count must be <= "
                                 "column size");
#endif // HMDF_SANITY_EXCEPTIONS

        if (roll_count_ == 0)  return;

        result_.reserve(col_s);
        for (size_type i { 0 }; i < roll_count_ - 1 && i < col_s; ++i)
            result_.push_back(std::numeric_limits<f_result_type>::quiet_NaN());
        for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
            if (i + roll_count_ <= col_s)  {
                visitor_.pre();
                visitor_(idx_begin + i, idx_begin + (i + roll_count_),
                         column_begin + i, column_begin + (i + roll_count_));
                visitor_.post();
                result_.push_back(visitor_.get_result());
            }
            else  break;
        }
    }

    inline void pre()  { visitor_.pre(); result_.clear(); }
    inline void post()  { visitor_.post(); }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    SimpleRollAdopter(F &&functor, size_type r_count)
        : visitor_(std::move(functor)), roll_count_(r_count)  {   }

private:

    visitor_type    visitor_ { };
    const size_type roll_count_ { 0 };
    result_type     result_ { };
};

// ----------------------------------------------------------------------------

// This can only work with visitors that accept one data item at a time
//
template<typename F, typename T, typename I = unsigned long>
struct  StepRollAdopter  {

private:

    using visitor_type = F;

    visitor_type        visitor_ {  };
    const std::size_t   period_;

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type = typename visitor_type::result_type;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (period_ == 0 || period_ >= col_s)
            throw DataFrameError("StepRollAdopter: period must be < "
                                 "column size");
#endif // HMDF_SANITY_EXCEPTIONS

        if (period_ == 0)  return;

        for (size_type i { 0 }; i < col_s; i += period_) [[likely]]
            visitor_(idx_begin[i], column_begin[i]);
    }

    inline void pre()  { visitor_.pre(); }
    inline void post()  { visitor_.post(); }
    inline const result_type &
    get_result() const  { return (visitor_.get_result()); }
    inline result_type get_result()  { return (visitor_.get_result()); }

    StepRollAdopter(F &&functor, size_type period)
        : visitor_(std::move(functor)), period_(period)  {   }
};

// ----------------------------------------------------------------------------

// Expanding rolling adoptor for visitors
//
template<typename F, typename T, typename I = unsigned long, std::size_t A = 0>
struct  ExpandingRollAdopter  {

private:

    using visitor_type = F;
    using f_result_type = typename visitor_type::result_type;

    visitor_type        visitor_ { };
    const std::size_t   init_roll_count_ { 0 };
    const std::size_t   increment_count_ { 0 };

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        std::vector<f_result_type,
                    typename allocator_declare<f_result_type, A>::type>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (init_roll_count_ == 0 || init_roll_count_ >= col_s)
            throw DataFrameError("ExpandingRollAdopter: roll count must be < "
                                 "column size");
#endif // HMDF_SANITY_EXCEPTIONS

        if (init_roll_count_ == 0)  return;

        result_.reserve(col_s);

        std::size_t rc = init_roll_count_;

        for (std::size_t i { 0 }; i < rc - 1 && i < col_s; ++i) [[likely]]
            result_.push_back(std::numeric_limits<f_result_type>::quiet_NaN());
        for (std::size_t i { 0 }; i < col_s;
             ++i, rc += increment_count_) [[likely]]  {
            std::size_t r { 0 };

            visitor_.pre();
            for (std::size_t j { i }; r < rc && j < col_s; ++j, ++r) [[likely]]
                visitor_(*(idx_begin + j), *(column_begin + j));
            visitor_.post();
            if (r == rc)
                result_.push_back(visitor_.get_result());
            else  break;
        }
    }

    inline void pre()  { visitor_.pre(); result_.clear(); }
    inline void post()  { visitor_.post(); }
    DEFINE_RESULT

    ExpandingRollAdopter(F &&functor,
                         std::size_t r_count,
                         std::size_t i_count = 1)
        : visitor_(std::move(functor)),
          init_roll_count_(r_count),
          increment_count_(i_count)  {   }

private:

    result_type result_ { };
};

// ----------------------------------------------------------------------------

// One-pass stats calculation.
//
template<arithmetic T, typename I = unsigned long>
struct  StatsVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    inline void operator()(const index_type &, const value_type &val)  {

        SKIP_NAN
        update_one_(val, n_, m1_, m2_, m3_, m4_);
    }

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            // Each chunk accumulates its own independent (n, m1, m2, m3,
            // m4) via the exact same recurrence as the single-element
            // operator() above (update_one_()), then the partial results
            // are combined via the Pébay (2008) parallel-combination
            // formula in merge_moments_() -- this gives identical
            // results to a strictly serial single pass (verified against
            // both a brute-force reference and this serial recurrence,
            // across many uneven chunk splits, before being wired in
            // here) while letting the scan itself run across threads.
            //
            auto    lbd =
                [this]
                (auto begin, auto end) ->
                    std::tuple<size_type, value_type,
                               value_type, value_type, value_type>  {

                    size_type   n { 0 };
                    value_type  m1 { 0 }, m2 { 0 }, m3 { 0 }, m4 { 0 };

                    for (auto citer { begin }; citer != end; ++citer)  {
                        const value_type    val { *citer };

                        if (skip_nan_ && is_nan__(val))  continue;
                        update_one_(val, n, m1, m2, m3, m4);
                    }
                    return (std::make_tuple(n, m1, m2, m3, m4));
                };
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    column_begin, column_end, lbd)
            };

            for (auto &fut : futures)  {
                auto    [n, m1, m2, m3, m4] = fut.get();

                merge_moments_(n_, m1_, m2_, m3_, m4_, n, m1, m2, m3, m4);
            }
        }
        else  {
            auto    idx_iter { idx_begin };
            auto    col_iter { column_begin };

            while (col_iter < column_end)
                (*this)(*idx_iter++, *col_iter++);
        }
    }

    inline void pre ()  {

        n_ = 0;
        m1_ = m2_ = m3_ = m4_ = 0;
    }
    inline void post()  {  }

    inline size_type get_count() const  { return (n_); }
    inline result_type get_mean() const  { return (m1_); }
    inline result_type get_variance() const  {

        return (result_type(m2_ / (value_type(n_) - 1.0)));
    }
    inline result_type get_std() const  {

        return (result_type(::sqrt(get_variance())));
    }
    inline result_type get_skew() const  {

        return (result_type(::sqrt(n_) * m3_ / ::pow(m2_, 1.5)));
    }
    inline result_type get_kurtosis() const  {

        return (result_type(value_type(n_) * m4_ / (m2_ * m2_) - 3.0));
    }

    DECL_CTOR(StatsVisitor)

private:

    // Single-element Pébay (2008) one-pass update -- shared by both the
    // per-element operator() above (updating member state directly) and
    // each parallel chunk's local accumulation below (updating locals,
    // merged afterward via merge_moments_()). Kept as one function so
    // the formula only ever needs fixing in one place.
    //
    static inline void
    update_one_(value_type val, size_type &n, value_type &m1,
               value_type &m2, value_type &m3, value_type &m4)  {

        const size_type n1 { n };

        n += 1;

        const value_type    delta { val - m1 };
        const value_type    delta_n { delta / value_type(n) };
        const value_type    delta_n2 { delta_n * delta_n };
        const value_type    term1 { delta * delta_n * value_type(n1) };

        m1 += delta_n;
        m4 += term1 * delta_n2 * value_type(n * n - 3 * n + 3) +
              6.0 * delta_n2 * m2 - 4.0 * delta_n * m3;
        m3 += term1 * delta_n * value_type(n - 2) - 3.0 * delta_n * m2;
        m2 += term1;
    }

    // Pébay (2008) parallel combination: merges the moments of two
    // disjoint partitions A and B into the moments of their union,
    // without re-scanning the underlying data. Verified against a
    // brute-force two-pass reference and against the single-pass
    // recurrence above, across many uneven chunk splits, before being
    // used here.
    //
    static inline void
    merge_moments_(size_type &n_a,
                   value_type &m1_a,
                   value_type &m2_a,
                   value_type &m3_a,
                   value_type &m4_a,
                   size_type n_b,
                   value_type m1_b,
                   value_type m2_b,
                   value_type m3_b,
                   value_type m4_b)  {

        if (n_b == 0)  return;
        if (n_a == 0)  {
            n_a = n_b; m1_a = m1_b; m2_a = m2_b; m3_a = m3_b; m4_a = m4_b;
            return;
        }

        const value_type    na { value_type(n_a) };
        const value_type    nb { value_type(n_b) };
        const value_type    n  { na + nb };
        const value_type    delta { m1_b - m1_a };
        const value_type    delta2 { delta * delta };
        const value_type    delta3 { delta2 * delta };
        const value_type    delta4 { delta2 * delta2 };

        const value_type    new_m1 { m1_a + delta * nb / n };
        const value_type    new_m2 { m2_a + m2_b + delta2 * na * nb / n };
        const value_type    new_m3 {
            m3_a + m3_b +
            delta3 * na * nb * (na - nb) / (n * n) +
            3.0 * delta * (na * m2_b - nb * m2_a) / n
        };
        const value_type    new_m4 {
            m4_a + m4_b +
            delta4 * na * nb * (na * na - na * nb + nb * nb) / (n * n * n) +
            6.0 * delta2 * (na * na * m2_b + nb * nb * m2_a) / (n * n) +
            4.0 * delta * (na * m3_b - nb * m3_a) / n
        };

        n_a = size_type(n);
        m1_a = new_m1;
        m2_a = new_m2;
        m3_a = new_m3;
        m4_a = new_m4;
    }

    size_type   n_ { 0 };
    value_type  m1_ { 0 };
    value_type  m2_ { 0 };
    value_type  m3_ { 0 };
    value_type  m4_ { 0 };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long>
struct  SkewVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    inline void operator()(const index_type &idx, const value_type &val)  {

        stats_(idx, val);
    }
    PASS_DATA_ONE_BY_ONE

    inline void pre()  { stats_.pre(); }
    inline void post()  { stats_.post();  }
    inline result_type get_result() const  { return (stats_.get_skew()); }

    explicit
    SkewVisitor(bool skipnan = false) : stats_(skipnan)  {   }

private:

    StatsVisitor<T, I>  stats_;
};

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long>
struct  KurtosisVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    inline void operator()(const index_type &idx, const value_type &val)  {

        stats_(idx, val);
    }
    PASS_DATA_ONE_BY_ONE

    inline void pre()  { stats_.pre(); }
    inline void post()  { stats_.post();  }
    inline result_type get_result() const  { return (stats_.get_kurtosis()); }

    explicit
    KurtosisVisitor(bool skipnan = false) : stats_(skipnan)  {   }

private:

    StatsVisitor<T, I>  stats_;
};

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long>
struct  TTestVisitor  {

public:

    DEFINE_VISIT_BASIC_TYPES_2

    inline void operator()(const index_type &idx,
                           const value_type &x, const value_type &y)  {

        if (skip_nan_ && (is_nan__(x) || is_nan__(y)))  return;

        if (! related_ts_)  {
            v_x_(idx, x);
            v_y_(idx, y);

            // deg_freedom_ for this branch is computed fresh in post()
            // from v_x_.get_count()/v_y_.get_count() (Welch-Satterthwaite
            // needs both counts individually, not just their sum), so no
            // running tally is kept here.
            //
            // deg_freedom_ += 2;
        }
        else  {
            v_x_(idx, x - y);
            deg_freedom_ += 1;
        }
    }
    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &x_begin, const H &x_end,
               const H &y_begin, const H &y_end)  {

        const size_type col_s {
            size_Type(std::min ({ std::distance(idx_begin, idx_end),
                                  std::distance(x_begin, x_end),
                                  std::distance(y_begin, y_end) }))
        };

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            std::vector<std::future<void>>  futures;

            if (! related_ts_)  {
                auto    lbd =
                    [](auto &vis,
                       const auto &begin, const auto &end,
                       const auto &idx_begin) -> void  {

                        vis(idx_begin, idx_begin, begin, end);
                    };

                const auto  x_end_it { x_begin + col_s };
                const auto  y_end_it { y_begin + col_s };

                futures.reserve(2);
                futures.emplace_back(
                    ThreadGranularity::thr_pool_.dispatch(
                        false,
                        lbd,
                            std::ref(v_x_),
                            std::cref(x_begin),
                            std::cref(x_end_it),
                            std::cref(idx_begin)));
                futures.emplace_back(
                    ThreadGranularity::thr_pool_.dispatch(
                        false,
                        lbd,
                            std::ref(v_y_),
                            std::cref(y_begin),
                            std::cref(y_end_it),
                            std::cref(idx_begin)));
            }
            else  {
                auto    lbd =
                    [col_s](auto &vis,
                            const auto &x_begin, const auto &y_begin,
                            const auto &idx_begin) -> void  {

                        for (size_type i = 0; i < col_s; ++i)  {
                            const value_type    val =
                                *(x_begin + i) - *(y_begin + i);

                            vis(*idx_begin, val);
                        }
                    };

                futures.reserve(1);
                futures.emplace_back(
                    ThreadGranularity::thr_pool_.dispatch(
                        false,
                        lbd,
                            std::ref(v_x_),
                            std::cref(x_begin),
                            std::cref(y_begin),
                            std::cref(idx_begin)));
            }

            for (auto &fut : futures)  fut.get();
        }
        else  {
            if (! related_ts_)  {
                v_x_(idx_begin, idx_end, x_begin, x_begin + col_s);
                v_y_(idx_begin, idx_end, y_begin, y_begin + col_s);
            }
            else  {
                for (size_type i = 0; i < col_s; ++i)  {
                    v_x_(*idx_begin, *(x_begin + i) - *(y_begin + i));
                }
            }
        }
        if (related_ts_)
            deg_freedom_ = col_s;
    }

    inline void pre()  {

        v_x_.pre();
        v_y_.pre();
        result_ = 0;
        deg_freedom_ = 0;
    }
    inline void post()  {

        v_x_.post();
        v_y_.post();
        if (! related_ts_)  {
            const value_type    a {
                v_x_.get_result() / value_type(v_x_.get_count())
            };
            const value_type    b {
                v_y_.get_result() / value_type(v_y_.get_count())
            };

            result_ = (v_x_.get_mean() - v_y_.get_mean()) / std::sqrt(a + b);

            // Welch-Satterthwaite equation: the correct degrees of
            // freedom for a Welch (unequal-variance) t-statistic, which
            // is what result_ above computes. Previously this used
            // n_x + n_y - 2 (Student's/pooled df, via deg_freedom_ -= 2),
            // which only equals the Welch-Satterthwaite value when the
            // two variances happen to be equal -- otherwise it
            // overstates the degrees of freedom (understating the true
            // p-value) precisely when the variances differ, which is
            // the situation Welch's test exists to handle correctly.
            // Rounded to the nearest integer since deg_freedom_ is a
            // size_type; the underlying quantity is a continuous
            // approximation, not naturally an integer.
            //
            deg_freedom_ =
                size_type(std::round(
                    (a + b) * (a + b) /
                    (a * a / value_type(v_x_.get_count() - 1) +
                     b * b / value_type(v_y_.get_count() - 1))));
        }
        else  {
            result_ =
                v_x_.get_mean() /
                (std::sqrt(v_x_.get_result()) /
                 std::sqrt(value_type(v_x_.get_count())));
            deg_freedom_ -= 1;
        }
    }

    inline result_type get_result() const  { return (result_); }
    inline size_type get_deg_freedom() const  { return (deg_freedom_); }

    explicit TTestVisitor(bool is_related_ts, bool skipnan = false)
        : v_x_(false, skipnan),
          v_y_(false, skipnan),
          related_ts_(is_related_ts),
          skip_nan_(skipnan)  {  }

private:

    VarVisitor<T, I>    v_x_;
    VarVisitor<T, I>    v_y_;
    result_type         result_ { 0 };
    size_type           deg_freedom_ { 0 };
    const bool          related_ts_;
    const bool          skip_nan_;
};

// ----------------------------------------------------------------------------

//
// Single Action Visitors
//

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  CumSumVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end)  {

        value_type      running_sum = 0;
        GET_COL_SIZE

        result_type result;

        result.reserve(col_s);
        if (! skip_nan_)  {
            for (size_type i = 0; i < col_s; ++i) [[likely]]  {
                running_sum += *(column_begin + i);
                result.push_back(running_sum);
            }
        }
        else  {
            for (size_type i = 0; i < col_s; ++i) [[likely]]  {
                const value_type    &value = *(column_begin + i);

                if (! is_nan__(value)) [[likely]]  {
                    running_sum += value;
                    result.push_back(running_sum);
                }
                else
                    result.push_back(value);
            }
        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    DECL_CTOR(CumSumVisitor)

private:

    result_type result_ {  };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  CumCountVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    using result_type =
        std::vector<size_type, typename allocator_declare<T, A>::type>;


    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        size_type   running_cnt { 0 };
        result_type result;

        result.reserve(col_s);
        for (size_type i = 0; i < col_s; ++i) [[likely]]  {
            if (! is_nan__(*(column_begin + i))) [[likely]]
                running_cnt += 1;
            result.push_back(running_cnt);
        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

private:

    result_type result_ {  };
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  CumProdVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end)  {

        value_type      running_prod = 1;
        GET_COL_SIZE

        result_type result;

        result.reserve(col_s);
        if (! skip_nan_)  {
            for (size_type i = 0; i < col_s; ++i) [[likely]]  {
                running_prod *= *(column_begin + i);
                result.push_back(running_prod);
            }
        }
        else  {
            for (size_type i = 0; i < col_s; ++i) [[likely]]  {
                const value_type    &value = *(column_begin + i);

                if (! is_nan__(value)) [[likely]]  {
                    running_prod *= value;
                    result.push_back(running_prod);
                }
                else
                    result.push_back(value);
            }
        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    DECL_CTOR(CumProdVisitor)

private:

    result_type result_ {  };
    const bool  skip_nan_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long,
         typename C = std::less<T>, std::size_t A = 0>
struct  CumExtremumVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    using compare_type = C;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        if (col_s == 0)  return;

        value_type  running_extremum;
        size_type   i { 0 };
        result_type result;


        result.reserve(col_s);
        if (! skip_nan_)  {
            for (size_type i { 0 }; i < col_s; ++i)  {
                const value_type    &value { *(column_begin + i) };

                if (! is_nan__(value)) [[likely]]  {
                    running_extremum = value;
                    break;
                }
                else  result.push_back(value);
            }
        }
        else  running_extremum = *column_begin;

        if (! skip_nan_)  {
            for (; i < col_s; ++i) [[likely]]  {
                const value_type    &value { *(column_begin + i) };

                if (cmp_(running_extremum, value))
                    running_extremum = value;
                result.push_back(running_extremum);
            }
        }
        else  {
            for (; i < col_s; ++i) [[likely]]  {
                const value_type    &value { *(column_begin + i) };

                if (! is_nan__(value)) [[likely]]  {
                    if (cmp_(running_extremum, value))
                        running_extremum = value;
                    result.push_back(running_extremum);
                }
                else  result.push_back(value);
            }
        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    DECL_CTOR(CumExtremumVisitor)

private:

    result_type     result_ {  };  // Extremum
    compare_type    cmp_ {  };
    const bool      skip_nan_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using CumMaxVisitor = CumExtremumVisitor<T, I, std::less<T>, A>;
template<typename T, typename I = unsigned long, std::size_t A = 0>
using CumMinVisitor = CumExtremumVisitor<T, I, std::greater<T>, A>;

// ----------------------------------------------------------------------------

// This categorizes the values in the column with integer values starting
// from 0
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  CategoryVisitor  {

private:

    struct t_less_  {
        inline bool
        operator() (const T *lhs, const T *rhs) const { return (*lhs < *rhs); }
    };

public:

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        std::vector<size_type, typename allocator_declare<size_type, A>::type>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        result_type result;

        result.reserve(col_s);

        size_type   cat = nan_ != 0 ? 0 : 1;

        for (size_type i = 0; i < col_s; ++i) [[likely]]  {
            const value_type    &value = *(column_begin + i);

            if (is_nan__(value))  {
                result.push_back(nan_);
                continue;
            }

            const typename map_type::const_iterator citer =
                cat_map_.find(&value);

            if (citer == cat_map_.end())  {
                cat_map_.insert({ &value, cat });
                result.push_back(cat);
                cat += 1;
                if (cat == nan_)  cat += 1;
            }
            else
                result.push_back(citer->second);
        }
        result_.swap(result);
    }

    inline void pre()  { result_.clear(); cat_map_.clear(); }
    inline void post()  {  }
    DEFINE_RESULT

    explicit
    CategoryVisitor(size_type nan_val = size_type(-1)) : nan_(nan_val)  {   }

private:

    using map_type = std::map<
        const T *, size_type,
        t_less_,
        typename allocator_declare<
            std::pair<const T *const, size_type>, A>::type>;

    map_type        cat_map_ { };
    result_type     result_ { };
    const size_type nan_;
};

// ----------------------------------------------------------------------------

// It factorizes the given column into a vector of Booleans (actual char type)
// based on the result of the given function.
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  FactorizeVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type =
        std::vector<char, typename allocator_declare<char, A>::type>;
    using factor_func = std::function<char(const value_type &val)>;

    template <typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &column_begin, const H &column_end)  {

        const size_type col_s = std::distance(column_begin, column_end);
        result_type     result;

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            result.resize(col_s);

            auto    lbd =
                [&result, &column_begin, this]
                (auto begin, auto end) mutable -> void  {
                    for (; begin < end; ++begin)
                        result[begin] = this->ffunc_(*(column_begin + begin));
                };
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<char>(
                    size_type(0), col_s, std::move(lbd));

            for (auto &fut : futures)  fut.get();
        }
        else  {
            result.reserve(col_s);
            std::for_each(column_begin, column_end,
                          [&result, this](const auto &val) -> void  {
                              result.push_back(this->ffunc_(val));
                          });
        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit FactorizeVisitor(factor_func f) : ffunc_(f)  {   }

private:

    result_type result_ { };
    factor_func ffunc_;
};

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  AutoCorrVisitor  {

    template<typename U>
    using vec_type = std::vector<U, typename allocator_declare<U, A>::type>;

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    vec_type<data_t>,
                                    vec_type<std::vector<data_t>>>;

    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 5 || col_s < (max_lag_ + 4))
            throw DataFrameError("AutoCorrVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (! std::is_arithmetic_v<value_type>)  {
#ifdef HMDF_SANITY_EXCEPTIONS
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "AutoCorrVisitor: Inconsistent data dimensions");
#endif // HMDF_SANITY_EXCEPTIONS
        }

        result_type tmp_result(max_lag_);
        size_type   lag { 1 };

        if constexpr (std::is_arithmetic_v<value_type>)
            tmp_result[0] = 1.0;
        else
            lag = 0;

        if ((col_s >= (ThreadPool::MUL_THR_THHOLD / 3)) &&
            (ThreadGranularity::get_thread_level() > 2))  {
            vec_type<std::future<corr_res_t>>   futures;

            futures.reserve((max_lag_) - lag);
            while (lag < max_lag_)  {
                futures.emplace_back(
                    ThreadGranularity::thr_pool_.dispatch(
                        false,
                        &AutoCorrVisitor::get_auto_corr_<K, H>,
                            std::cref(idx_begin),
                            std::cref(idx_end),
                            col_s,
                            lag,
                            std::cref(column_begin)));
                lag += 1;
            }
            for (auto &fut : futures)  {
                const auto  &result = fut.get();

                tmp_result[result.first] = result.second;
            }
        }
        else  {
            while (lag < max_lag_)  {
                const auto  result =
                    get_auto_corr_(idx_begin, idx_end,
                                   col_s, lag, column_begin);

                tmp_result[result.first] = std::move(result.second);
                lag += 1;
            }
        }
        result_.swap(tmp_result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    AutoCorrVisitor(size_type max_lag) : max_lag_(max_lag)  {   }

private:

    result_type     result_ {  };
    const size_type max_lag_;

    using corr_res_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    std::pair<size_type, data_t>,
                                    std::pair<size_type, std::vector<data_t>>>;

    template<typename K, typename H>
    inline static corr_res_t
    get_auto_corr_(const K &idx_begin, const K &idx_end,
                   size_type col_s, size_type lag, const H &column_begin)  {

        CorrVisitor<value_type, index_type> corr {  };

        corr.pre();
        corr (idx_begin, idx_end,
              column_begin, column_begin + (col_s - lag),
              column_begin + lag, column_begin + col_s);
        corr.post();

        return (corr_res_t(lag, std::move(corr.get_result())));
    }
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using acf_v = AutoCorrVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  PartialAutoCorrVisitor  {

    template<typename U>
    using vec_type = std::vector<U, typename allocator_declare<U, A>::type>;

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;
    using matrix_t = Matrix<data_t, matrix_orient::row_major>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    vec_type<data_t>,
                                    vec_type<matrix_t>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 5 || col_s < (max_lag_ + 2))
            throw DataFrameError(
                "PartialAutoCorrVisitor: Time-series is too short");
        if (max_lag_ > 375)
            throw DataFrameError("PartialAutoCorrVisitor: Maximum lag is 375");
#endif // HMDF_SANITY_EXCEPTIONS

#ifdef HMDF_SANITY_EXCEPTIONS
        if constexpr (! std::is_arithmetic_v<value_type>)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError("PartialAutoCorrVisitor: "
                                         "Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        result_type         result(max_lag_);
        matrix_t            x;
        matrix_t            y;
        data_t              mean { 0 };
        std::vector<data_t> dim_mean;

        // The regression below must operate on the demeaned series -- a
        // regression with no intercept term implicitly assumes a
        // zero-mean process, which real data essentially never
        // satisfies. Without this, PACF is not invariant to adding a
        // constant to the whole series, which it must be by definition.
        //
        if constexpr (std::is_arithmetic_v<value_type>)  {
            result[0] = 1;
            for (size_type i { 0 }; i < col_s; ++i)
                mean += data_t(*(column_begin + i));
            mean /= data_t(col_s);
        }
        else  {
            const size_type dim { column_begin->size() };
            matrix_t        identity { long(dim), long(dim), 0 };

            for (long i { 0 }; i < identity.rows(); ++i)
                identity(i, i) = 1;
            result[0] = std::move(identity);

            dim_mean.resize(dim, data_t(0));
            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &obs { *(column_begin + i) };

                for (size_type d { 0 }; d < dim; ++d)
                    dim_mean[d] += data_t(obs[d]);
            }
            for (size_type d { 0 }; d < dim; ++d)
                dim_mean[d] /= data_t(col_s);
        }
        for (size_type k { 1 }; k < max_lag_; ++k)  {
            x.clear();
            y.clear();

            const size_type rows { col_s - k };

            if constexpr (std::is_arithmetic_v<value_type>)  {
                x.resize(rows, k);
                y.resize(rows, 1);
                for (size_type i { 0 }; i < rows; ++i)  {
                    y(i, 0) = data_t(*(column_begin + (i + k))) - mean;
                    for (size_type j { 0 }; j < k; ++j)
                        x(i, j) = *(column_begin + (i + j)) - mean;
                }
            }
            else  {
                const size_type dim { column_begin->size() };

                x.resize(col_s - k, k * dim, 0);
                y.resize(col_s - k, dim, 0);

                // y row i: the dim components of observation (i + k),
                //          demeaned per dimension
                //
                for (size_type i { 0 }; i < rows; ++i)  {
                    const auto  &obs_y { *(column_begin + (i + k)) };

                    for (size_type d { 0 }; d < dim; ++d)
                        y(i, d) = data_t(obs_y[d]) - dim_mean[d];

                    // x row i: lagged observations, demeaned per dimension
                    // block j: columns [j * dim ... j * dim + dim - 1]
                    //
                    for (size_type j { 0 }; j < k; ++j)  {
                        const auto  &obs_x { *(column_begin + (i + j)) };

                        for (size_type d { 0 }; d < dim; ++d)
                            x(i, j * dim + d) = obs_x[d] - dim_mean[d];
                    }
                }
            }

            const auto  x_trans = x.transpose();
            const auto  phi = (x_trans * x).inverse() * x_trans * y;

            if constexpr (std::is_arithmetic_v<value_type>)  {
                result[k] = phi(k - 1, 0);
            }
            else  {
                const size_type dim { column_begin->size() };

                // The partial autocorrelation matrix at lag k is the last
                // dimXdim block of phi: rows [(k - 1) * dim ... k * dim - 1],
                // all dim columns
                //
                matrix_t    res { long(dim), long(dim), 0 };

                for (size_type r { 0 }; r < dim; ++r)
                    for (size_type c { 0 }; c < dim; ++c)
                        res(r, c) = phi((k - 1) * dim + r, c);
                result[k] = std::move(res);
            }
        }

        result_.swap(result);
    }

    DEFINE_PRE_POST

    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    explicit
    PartialAutoCorrVisitor(size_type max_lag) : max_lag_(max_lag)  {   }

private:

    result_type     result_ {  };
    const size_type max_lag_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using pacf_v = PartialAutoCorrVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  FixedAutoCorrVisitor  {

    template<typename U>
    using vec_type = std::vector<U, typename allocator_declare<U, A>::type>;

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    vec_type<data_t>,
                                    vec_type<std::vector<data_t>>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s <= lag_)
            throw DataFrameError(
                "FixedAutoCorrVisitor: column size must be > lag");

        if constexpr (! std::is_arithmetic_v<value_type>)  {
            const size_type dim { column_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "AutoCorrVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        CorrVisitor<value_type, index_type> corr {  };
        result_type                         result;

        if (policy_ == roll_policy::blocks)  {
            const size_type calc_size { col_s / lag_ };

            result.reserve(calc_size);
            for (size_type i { 0 }; i < calc_size; ++i)  {
                auto    far_end { i * lag_ + 2 * lag_ };
                auto    near_end { i * lag_ + lag_ };
                auto    begin { i * lag_ };

                if (far_end >= col_s)
                    far_end -= far_end % col_s;
                if (near_end >= col_s)
                    near_end -= near_end % col_s;
                if ((near_end - begin) > (far_end - near_end))
                    begin += ((near_end - begin) - (far_end - near_end));

                try  {  // The last block might be too small to calculate var
                    corr.pre();
                    corr (idx_begin, idx_end,  // This doesn't matter
                          column_begin + begin,
                          column_begin + near_end,
                          column_begin + near_end,
                          column_begin + far_end);
                    corr.post();
                }
                catch (const DataFrameError &)  { break; }


                result.push_back(std::move(corr.get_result()));
            }
        }
        else  {  // roll_policy::continuous
            const size_type calc_size { col_s - lag_ };

            result.reserve(calc_size);
            for (size_type i { 0 }; i < calc_size; ++i)  {
                auto    far_end { i + 2 * lag_ };
                auto    near_end { i + lag_ };
                auto    begin { i };

                if (far_end > col_s)
                    far_end -= far_end % col_s;
                if (near_end >= col_s)
                    near_end -= near_end % col_s;
                if ((near_end - begin) > (far_end - near_end))
                    begin += ((near_end - begin) - (far_end - near_end));
                try  {  // The last block might be too small to calculate var
                    corr.pre();
                    corr (idx_begin, idx_end,  // This doesn't matter
                          column_begin + begin,
                          column_begin + near_end,
                          column_begin + near_end,
                          column_begin + far_end);
                    corr.post();
                }
                catch (const DataFrameError &)  { break; }

                result.push_back(std::move(corr.get_result()));
            }

        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    FixedAutoCorrVisitor(size_type lag_period, roll_policy rp)
        : lag_(lag_period), policy_(rp)  {   }

private:

    const size_type     lag_;
    const roll_policy   policy_;
    result_type         result_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using facf_v = FixedAutoCorrVisitor<T, I, A>;

// ----------------------------------------------------------------------------

// Exponential rolling adoptor for visitors
// decay * Xt + (1 − decay) * Xt-1
// or
//    Xt + (1 - decay)Xt-1 + (1 - decay)^2 Xt-2 + ... + (1 - decay)^t X0
// ------------------------------------------------------------------------
//          1 + (1 - decay) + (1 - decay)^2 + ... + (1 - decay)^t
//
template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  ExponentiallyWeightedMeanVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s <= 3)
            throw DataFrameError("ExponentiallyWeightedMeanVisitor: "
                                 "column size must be > 3");
#endif // HMDF_SANITY_EXCEPTIONS

        result_type         result(col_s, 0);
        const value_type    decay_comp { T(1) - decay_ };
        size_type           starting { 0 };

        for (; starting < col_s; ++starting)  {
            const value_type    val { *(column_begin + starting) };

            if (! is_nan__(val))  {
                result[starting] = val;
                break;
            }
        }

        if (! finite_adjust_)  {
            for (size_type i { starting + 1 }; i < col_s; ++i) [[likely]]
                result[i] = decay_ * *(column_begin + i) +
                            decay_comp * result[i - 1];
        }
        else  {  // Adjust for the fact that this is not an infinite data set
            value_type  denominator { 1 };
            value_type  decay_comp_prod { 1 };
            value_type  numerator { result[starting] };

            std::transform(column_begin + (starting + 1), column_end,
                           result.begin() + (starting + 1),
                           [&decay_comp_prod,
                            decay_comp,
                            &denominator,
                            &numerator]
                           (const auto &val) mutable -> value_type  {
                                decay_comp_prod *= decay_comp;
                                denominator += decay_comp_prod;
                                numerator = numerator * decay_comp + val;
                                return (numerator / denominator);
                           });
        }

        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    ExponentiallyWeightedMeanVisitor(exponential_decay_spec eds,
                                     value_type value,
                                     bool finite_adjust = false)
        : decay_(eds == exponential_decay_spec::center_of_gravity
                 ? T(1) / (T(1) + value)
                     : eds == exponential_decay_spec::span
                         ? T(2) / (T(1) + value)
                         : eds == exponential_decay_spec::halflife
                             ? T(1) - std::exp(std::log(T(0.5)) / value)
                             : value),
          finite_adjust_(finite_adjust)  {   }

private:

    const value_type    decay_;
    const bool          finite_adjust_;
    result_type         result_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using ewm_v = ExponentiallyWeightedMeanVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  ExponentiallyWeightedVarVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s <= 3)
            throw DataFrameError("ExponentiallyWeightedVarVisitor: "
                                 "column size must be > 3");
#endif // HMDF_SANITY_EXCEPTIONS

        result_type         ewmvar;
        result_type         ewmstd;
        const value_type    decay_comp { T(1) - decay_ };

        ewmvar.resize(col_s);
        ewmstd.resize(col_s);

        // sum_1/sum_2/sum_x/sum_xx are the running (sum of weights, sum
        // of squared weights, weighted sum of inputs, weighted sum of
        // squared inputs), each updated in O(1) per step instead of an
        // O(i) inner loop.
        //
        value_type  sum_1 { 0 };
        value_type  sum_2 { 0 };
        value_type  sum_x { 0 };
        value_type  sum_xx { 0 };

        for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
            const value_type    x { *(column_begin + i) };

            sum_1 = value_type(1) + decay_comp * sum_1;
            sum_2 = value_type(1) + decay_comp * decay_comp * sum_2;
            sum_x = x + decay_comp * sum_x;
            sum_xx = x * x + decay_comp * sum_xx;

            const value_type    ewma { sum_x / sum_1 };
            const value_type    factor_sum { sum_xx - ewma * ewma * sum_1 };
            const value_type    sum_1_sq { sum_1 * sum_1 };
            const value_type    bias { sum_1_sq / (sum_1_sq - sum_2) };
            const value_type    var { bias * factor_sum / sum_1 };

            ewmvar[i] = var;
            ewmstd[i] = std::sqrt(var);
        }

        ewmvar_.swap(ewmvar);
        ewmstd_.swap(ewmstd);
    }

    inline const result_type &get_result() const  { return (ewmvar_); }
    inline result_type &get_result()  { return (ewmvar_); }
    inline const result_type &get_std() const  { return (ewmstd_); }
    inline result_type &get_std()  { return (ewmstd_); }

    inline void pre()  { ewmvar_.clear(); ewmstd_.clear(); }
    inline void post()  {  }

    ExponentiallyWeightedVarVisitor(exponential_decay_spec eds, value_type val)
        : decay_(eds == exponential_decay_spec::center_of_gravity
                 ? T(1) / (T(1) + val)
                     : eds == exponential_decay_spec::span
                         ? T(2) / (T(1) + val)
                         : eds == exponential_decay_spec::halflife
                             ? T(1) - std::exp(std::log(T(0.5)) / val)
                             : val)  {   }

private:

    const value_type    decay_;
    result_type         ewmvar_ {  };
    result_type         ewmstd_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using ewm_var_v = ExponentiallyWeightedVarVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  ExponentiallyWeightedCovVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &x_begin, const H &x_end,
               const H &y_begin, const H &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)) || col_s <= 3)
            throw DataFrameError("ExponentiallyWeightedCovVisitor: "
                                 "column sizes must be equal and > 3");
#endif // HMDF_SANITY_EXCEPTIONS

        result_type         ewmcov;
        const value_type    decay_comp { T(1) - decay_ };

        ewmcov.reserve(col_s);

        // ExponentiallyWeightedVarVisitor, generalized to two series.
        // sum_1/sum_2/sum_x/sum_y/sum_xy are the running (sum of weights,
        // sum of squared weights, weighted sum of x, weighted sum of y,
        // weighted sum of x*y), each updated in O(1) per step instead
        // of an O(i) inner loop. Expanding Sum(w^j*(x-ewmax)*(y-ewmay))
        // algebraically gives sum_xy - sum_x*sum_y/sum_1, the same trick
        // (avoiding needing the means before summing cross deviations) as the
        // variance case's sum_xx - ewma^2*sum_1.
        //
        value_type  sum_1 { 0 };
        value_type  sum_2 { 0 };
        value_type  sum_x { 0 };
        value_type  sum_y { 0 };
        value_type  sum_xy { 0 };

        for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
            const value_type    x { *(x_begin + i) };
            const value_type    y { *(y_begin + i) };

            sum_1 = value_type(1) + decay_comp * sum_1;
            sum_2 = value_type(1) + decay_comp * decay_comp * sum_2;
            sum_x = x + decay_comp * sum_x;
            sum_y = y + decay_comp * sum_y;
            sum_xy = x * y + decay_comp * sum_xy;

            const value_type    factor_sum { sum_xy - (sum_x * sum_y) / sum_1 };
            const value_type    sum_1_sq { sum_1 * sum_1 };
            const value_type    bias { sum_1_sq / (sum_1_sq - sum_2) };
            const value_type    cov { bias * factor_sum / sum_1 };

            ewmcov.push_back(cov);
        }

        ewmcov_.swap(ewmcov);
    }

    inline const result_type &get_result() const  { return (ewmcov_); }
    inline result_type &get_result()  { return (ewmcov_); }

    inline void pre()  { ewmcov_.clear(); }
    inline void post()  {  }

    ExponentiallyWeightedCovVisitor(exponential_decay_spec eds,
                                    value_type value)
        : decay_(eds == exponential_decay_spec::center_of_gravity
                 ? T(1) / (T(1) + value)
                     : eds == exponential_decay_spec::span
                         ? T(2) / (T(1) + value)
                         : eds == exponential_decay_spec::halflife
                             ? T(1) - std::exp(std::log(T(0.5)) / value)
                             : value)  {   }

private:

    const value_type    decay_;
    result_type         ewmcov_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using ewm_cov_v = ExponentiallyWeightedCovVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  ExponentiallyWeightedCorrVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <bidirectional_iterator K, bidirectional_iterator H>
    inline void
    operator()(const K &, const K &,
               const H &x_begin, const H &x_end,
               const H &y_begin, const H &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)) || col_s <= 3)
            throw DataFrameError("ExponentiallyWeightedCorrVisitor: "
                                 "column sizes must be equal and > 3");
#endif // HMDF_SANITY_EXCEPTIONS

        result_type         ewmcorr;
        const value_type    decay_comp { T(1) - decay_ };
        size_type           starting { 0 };

        ewmcorr.reserve(col_s);
        for (; starting < col_s; ++starting)
            if (is_nan__(*(x_begin + starting)) ||
                is_nan__(*(y_begin + starting)))
                ewmcorr.push_back(std::numeric_limits<T>::quiet_NaN());
            else  break;

        // Guard against an all-invalid column: without this, the
        // unconditional push below would make the result one longer
        // than col_s.
        //
        if (starting < col_s)
            ewmcorr.push_back(std::numeric_limits<T>::quiet_NaN());

        // Same O(1)-per-step recurrence as ExponentiallyWeightedCovVisitor
        // (see the derivation comment there), generalized to also track
        // each series' own running variance so the correlation can be
        // formed directly. sum_1/sum_2/sum_x/sum_y/sum_xy/sum_xx/sum_yy are
        // updated in O(1) per step instead of re-summing the full history
        // back to index 0 on every step.
        //
        if (starting < col_s)  {
            value_type  sum_1 { 1 };
            value_type  sum_2 { 1 };
            value_type  sum_x { *(x_begin + starting) };
            value_type  sum_y { *(y_begin + starting) };
            value_type  sum_xy { sum_x * sum_y };
            value_type  sum_xx { sum_x * sum_x };
            value_type  sum_yy { sum_y * sum_y };

            for (size_type i { starting + 1 }; i < col_s; ++i) [[likely]]  {
                const value_type    x { *(x_begin + i) };
                const value_type    y { *(y_begin + i) };

                sum_1 = value_type(1) + decay_comp * sum_1;
                sum_2 = value_type(1) + decay_comp * decay_comp * sum_2;
                sum_x = x + decay_comp * sum_x;
                sum_y = y + decay_comp * sum_y;
                sum_xy = x * y + decay_comp * sum_xy;
                sum_xx = x * x + decay_comp * sum_xx;
                sum_yy = y * y + decay_comp * sum_yy;

                const value_type    factor_sum {
                    sum_xy - (sum_x * sum_y) / sum_1
                };
                const value_type    factor_sumx {
                    sum_xx - (sum_x * sum_x) / sum_1
                };
                const value_type    factor_sumy {
                    sum_yy - (sum_y * sum_y) / sum_1
                };
                const value_type    sum_1_sq { sum_1 * sum_1 };
                const value_type    bias { sum_1_sq / (sum_1_sq - sum_2) };
                const value_type    cov { bias * factor_sum / sum_1 };
                const value_type    varx { bias * factor_sumx / sum_1 };
                const value_type    vary { bias * factor_sumy / sum_1 };

                ewmcorr.push_back(cov / std::sqrt(varx * vary));
            }
        }

        ewmcorr_.swap(ewmcorr);
    }
    inline const result_type &get_result() const  { return (ewmcorr_); }
    inline result_type &get_result()  { return (ewmcorr_); }

    inline void pre()  { ewmcorr_.clear(); }
    inline void post()  {  }

    ExponentiallyWeightedCorrVisitor(exponential_decay_spec eds,
                                     value_type value)
        : decay_(eds == exponential_decay_spec::center_of_gravity
                 ? T(1) / (T(1) + value)
                     : eds == exponential_decay_spec::span
                         ? T(2) / (T(1) + value)
                         : eds == exponential_decay_spec::halflife
                             ? T(1) - std::exp(std::log(T(0.5)) / value)
                             : value)  {   }

private:

    const value_type    decay_;
    result_type         ewmcorr_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using ewm_corr_v = ExponentiallyWeightedCorrVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  ZeroLagMovingMeanVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s <= 3 || roll_period_ >= (col_s - 1))
            throw DataFrameError("ZeroLagMovingMeanVisitor: column > 3 and "
                                 "roll period < column size - 1");
#endif // HMDF_SANITY_EXCEPTIONS

        result_.resize(col_s, std::numeric_limits<T>::quiet_NaN());

        size_type   starting { 0 };

        for (; starting < col_s; ++starting)
            if (! is_nan__(*(column_begin + starting)))
                break;

        const size_type lag { size_type (0.5 * double(roll_period_ - 1)) };

        if (starting + lag < col_s)  {
            if (col_s >= ThreadPool::MUL_THR_THHOLD &&
                ThreadGranularity::get_thread_level() > 2)  {
                auto    lbd =
                    [lag, &column_begin, this]
                    (auto begin, auto end) mutable -> void  {
                        for (size_type i = begin; i < end; ++i) [[likely]]
                            result_[i] = T(2) * *(column_begin + i) -
                                         *(column_begin + (i - lag));
                    };
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        starting + lag, col_s, std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                for (size_type i { starting + lag }; i < col_s; ++i) [[likely]]
                    result_[i] = T(2) * *(column_begin + i) -
                                 *(column_begin + (i - lag));
            }

            ewm_v<T, I, A>  ewm {
                exponential_decay_spec::span, value_type(roll_period_), true
            };

            ewm.pre();
            ewm (idx_begin, idx_end,
                 result_.begin() + (starting + lag), result_.end());
            ewm.post();

            std::copy(ewm.get_result().begin(), ewm.get_result().end(),
                      result_.begin() + (starting + lag));
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    ZeroLagMovingMeanVisitor(size_type roll_period)
        : roll_period_(roll_period)  {   }

private:

    const size_type roll_period_;
    result_type     result_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using zlmm_v = ZeroLagMovingMeanVisitor<T, I, A>;

// ----------------------------------------------------------------------------

// Linear Regression moving mean
//
template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  LinregMovingMeanVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s <= 3 || roll_period_ >= (col_s - 1))
            throw DataFrameError("LinregMovingMeanVisitor: column > 3 and "
                                 "roll period < column size - 1");
#endif // HMDF_SANITY_EXCEPTIONS

        const value_type    sum_x {
            0.5 * T(roll_period_) * T(roll_period_ + 1)
        };
        const value_type    sum_x2 {
            sum_x * (2.0 * T(roll_period_) + 1.0) / 3.0
        };
        const value_type    divisor {
            T(roll_period_) * sum_x2 - sum_x * sum_x
        };
        result_type         result(col_s, std::numeric_limits<T>::quiet_NaN());
        const auto          thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };
        bool                any_nan { false };

        for (size_type i { 0 }; (i < col_s) && (! any_nan); ++i)
            if (is_nan__(*(column_begin + i)))  any_nan = true;

        if (! any_nan)  {
            auto    fill_range =
                [&column_begin = std::as_const(column_begin),
                 &result, sum_x, sum_x2, divisor, this]
                (size_type begin, size_type end) mutable -> void  {
                    if (begin >= end)  return;

                    value_type  sum_y { 0 };
                    value_type  sum_xy { 0 };

                    for (size_type j { 0 }; j < roll_period_; ++j) [[likely]]  {
                        const value_type    v {
                            *(column_begin + (begin - roll_period_ + j))
                        };

                        sum_y += v;
                        sum_xy += v * T(j + 1);
                    }
                    result[begin] =
                        linreg_from_sums_(sum_y, sum_xy, sum_x, sum_x2,
                                          divisor, type_, T(roll_period_));

                    for (size_type i { begin + 1 }; i < end; ++i) [[likely]]  {
                        const value_type    leaving  {
                            *(column_begin + (i - roll_period_ - 1))
                        };
                        const value_type    entering {
                            *(column_begin + (i - 1))
                        };

                        sum_xy = sum_xy - sum_y + T(roll_period_) * entering;
                        sum_y  = sum_y - leaving + entering;

                         result[i] =
                            linreg_from_sums_(sum_y, sum_xy, sum_x, sum_x2,
                                              divisor, type_, T(roll_period_));
                    }
                 };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        roll_period_, col_s, fill_range)
                };

                for (auto &fut : futures)  fut.get();
            }
            else
                fill_range(roll_period_, col_s);
         }
         else  {
            if (thread_level > 2)  {
                auto    lbd =
                    [&column_begin = std::as_const(column_begin),
                     &result, sum_x, sum_x2, divisor, this]
                    (auto begin, auto end) mutable -> void  {
                        for (size_type i { begin }; i < end; ++i) [[likely]]
                            result[i] =
                                linreg_(column_begin + (i - roll_period_),
                                        column_begin + i,
                                        sum_x, sum_x2, divisor,
                                        type_, roll_period_);
                    };
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        roll_period_, col_s, std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                for (size_type i { roll_period_ }; i < col_s; ++i) [[likely]]
                    result[i] = linreg_(column_begin + (i - roll_period_),
                                        column_begin + i,
                                        sum_x, sum_x2, divisor,
                                        type_, roll_period_);
            }
         }
         result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    LinregMovingMeanVisitor(size_type roll_period = 14,
                            linreg_moving_mean_type ltype =
                                linreg_moving_mean_type::linreg)
        : roll_period_(roll_period), type_(ltype)  {   }

private:

    // Shared tail logic: turns (sum_y, sum_xy) for a roll_period_-wide
    // window into whichever quantity `lmm_type` asks for. Used by both the
    // O(1) incremental path and linreg_() below, so the two paths can never
    // silently diverge on this part of the math.
    //
    inline static value_type
    linreg_from_sums_(value_type sum_y, value_type sum_xy,
                      value_type sum_x, value_type sum_x2,
                      value_type divisor,
                      linreg_moving_mean_type lmm_type,
                      value_type roll_period) {

        const value_type    slope {
            (roll_period * sum_xy - sum_x * sum_y) / divisor
        };

        if (lmm_type == linreg_moving_mean_type::slope)  return (slope);

        if (lmm_type == linreg_moving_mean_type::theta ||
            lmm_type == linreg_moving_mean_type::degree)  {
            const value_type    theta { std::atan(slope) };

            return (lmm_type == linreg_moving_mean_type::theta
                        ? theta : theta * (180.0 / std::numbers::pi));
        }

        const value_type    intercept {
            (sum_y * sum_x2 - sum_x * sum_xy) / divisor
        };

        if (lmm_type == linreg_moving_mean_type::intercept)
            return (intercept);

        return (lmm_type == linreg_moving_mean_type::forecast
                    ? slope * roll_period + intercept
                    : slope * (roll_period - T(1)) + intercept);
    }

    template <typename H>
    inline static value_type
    linreg_(const H &column_begin, const H &column_end,
            value_type sum_x, value_type sum_x2,
            value_type divisor,
            linreg_moving_mean_type lmm_type,
            value_type roll_period)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };
        value_type      sum_y { 0 };
        value_type      sum_xy { 0 };

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    lbd =
                [&column_begin]
                (auto begin, auto end) mutable -> std::pair<T, T>  {
                    value_type  sum_y { 0 };
                    value_type  sum_xy { 0 };

                    for (size_type i { begin }; i < end; ++i) [[likely]]  {
                        const value_type    val { *(column_begin + i) };

                        sum_y += val;
                        sum_xy += val * T(i + 1);
                    }
                    return (std::make_pair(sum_y, sum_xy));
                };
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0), col_s, std::move(lbd))
            };

            for (auto &fut : futures)  {
                const auto  &val { fut.get() };

                sum_y += val.first;
                sum_xy += val.second;
            }
        }
        else  {
            for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
                const value_type    val { *(column_begin + i) };

                sum_y += val;
                sum_xy += val * T(i + 1);
            }
        }

        return (linreg_from_sums_(sum_y, sum_xy, sum_x, sum_x2, divisor,
                                  lmm_type, roll_period));
    }

    const size_type                 roll_period_;
    const linreg_moving_mean_type   type_;
    result_type                     result_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using linregmm_v = LinregMovingMeanVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  SymmTriangleMovingMeanVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (roll_period_ == 0 || roll_period_ >= col_s)
            throw DataFrameError("SymmTriangleMovingMeanVisitor: "
                                 "roll period must be > 0 and < column size");
#endif // HMDF_SANITY_EXCEPTIONS

        size_type   starting { 0 };

        for (; starting < col_s; ++starting)
            if (! is_nan__(*(column_begin + starting)))
                break;

        result_type result(col_s, std::numeric_limits<T>::quiet_NaN());

        // Not enough valid data past the lead-in to fill even one window --
        // leave `result` as all-NaN rather than let either path below index
        // past `column_end`.
        //
        if (starting + roll_period_ >= col_s)  {
            result_.swap(result);
            return;
        }

        // A NaN anywhere, under an O(1) sliding-window update, would stay
        // inside the running sums forever once it enters them (same reason
        // as LinregMovingMeanVisitor's fast path) -- so that path below only
        // runs when the column is entirely NaN-free from `starting` on;
        // otherwise this falls back to the original per-window recompute
        // against the triangle weights directly, keeping the NaN
        // contamination radius identical to before.
        //
        bool    any_nan { false };

        for (size_type i = starting; i < col_s && ! any_nan; ++i)
            if (is_nan__(*(column_begin + i)))  any_nan = true;

        if (any_nan)  {
            const auto  triangle {
                gen_sym_triangle<value_type>(roll_period_, 1, true)
            };

            for (size_type i { starting + roll_period_ }; i < col_s; ++i)  {
                value_type  sum { 0 };
                size_type   tri_idx { 0 };

                for (size_type j = { i - roll_period_ }; j < i; ++j, ++tri_idx)
                    sum += *(column_begin + j) * triangle[tri_idx];
                result[i] = sum;
            }
        }
        else  {
            // The symmetric triangular kernel of width p is the
            // convolution of two rectangular (box) kernels of widths a and
            // b, with a + b - 1 == p (a == b when p is odd, b == a + 1
            // when p is even) -- gen_sym_triangle's own ramp-up-then-mirror
            // construction is exactly that. That means the
            // triangle-weighted moving sum is just a size-b moving sum OF
            // a size-a moving sum -- both plain box sums, each O(1) per
            // step -- instead of recomputing the full triangle-weighted
            // window from scratch at every position. `ring` holds the last
            // b box-sum values so the outer sum knows which one is leaving
            // as it slides.
            //
            const size_type    a { (roll_period_ + 1) / 2 };
            const size_type    b { roll_period_ + 1 - a };
            const value_type   norm { T(a) * T(b) };
            const size_type    i0 { starting + roll_period_ };
            size_type          t { i0 - roll_period_ };
            value_type         box_a { 0 };

            for (size_type k { 0 }; k < a; ++k)
                box_a += *(column_begin + (t + k));

            std::vector<value_type> ring(b);
            size_type               ring_pos { 0 };
            value_type              tri_sum { 0 };

            ring[ring_pos++ % b] = box_a;
            tri_sum += box_a;
            for (size_type step { 1 }; step < b; ++step)  {
                box_a = box_a - *(column_begin + t) + *(column_begin + (t + a));
                t += 1;
                ring[ring_pos % b] = box_a;
                ring_pos += 1;
                tri_sum += box_a;
            }
            result[i0] = tri_sum / norm;

            for (size_type i { i0 + 1 }; i < col_s; ++i) [[likely]]  {
                box_a = box_a - *(column_begin + t) + *(column_begin + (t + a));
                t += 1;

                const value_type    oldest { ring[ring_pos % b] };

                ring[ring_pos % b] = box_a;
                ring_pos += 1;
                tri_sum = tri_sum - oldest + box_a;
                result[i] = tri_sum / norm;
            }
        }
        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    SymmTriangleMovingMeanVisitor(size_type roll_period)
        : roll_period_(roll_period)  {   }

private:

    const size_type roll_period_;
    result_type     result_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using symtmm_v = SymmTriangleMovingMeanVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  KthValueVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    using vec_type = std::vector<T, typename allocator_declare<T, A>::type>;

    template <typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &values_begin, const H &values_end)  {

        vec_type        aux;
        const size_type col_s {
            size_type(std::distance(values_begin, values_end))
        };

        if (skip_nan_)  {
            aux.reserve(col_s);
            std::copy_if(values_begin, values_end,
                         std::back_inserter(aux),
                         [](T x) -> bool { return (! is_nan__(x)); });
        }
        else
            aux.insert(aux.begin(), values_begin, values_end);
        compute_size_ = aux.size();

        if (compute_size_ != 0) {
            const size_type kth {
                std::clamp(
                    size_type(std::round(double(kth_element_ * compute_size_) /
                                         double(col_s))),
                    size_type(1), compute_size_)
            };
            const auto      nth {
                aux.begin() + static_cast<std::ptrdiff_t>(kth - 1)
            };

            std::nth_element(aux.begin(), nth, aux.end());
            result_ = *nth;
        }
    }

    inline void pre()  { result_ = value_type(); }
    inline void post()  {   }
    inline result_type get_result() const  { return (result_); }
    inline size_type get_compute_size() const  { return (compute_size_); }

    explicit KthValueVisitor(size_type ke, bool skipnan = false)
        : kth_element_(ke), skip_nan_(skipnan)  {   }

private:

    result_type     result_ {  };
    size_type       compute_size_ { 0 };
    const size_type kth_element_;
    const bool      skip_nan_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using kthv_v = KthValueVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  NKthValueVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    using vec_type = std::vector<T, typename allocator_declare<T, A>::type>;

    template <typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &values_begin, const H &values_end)  {

        vec_type        aux;
        const size_type col_s {
            size_type(std::distance(values_begin, values_end))
        };

        if (skip_nan_)  {
            aux.reserve(col_s);
            std::copy_if(values_begin, values_end,
                         std::back_inserter(aux),
                         [](T x) -> bool { return (! is_nan__(x)); });
        }
        else
            aux.insert(aux.begin(), values_begin, values_end);
        compute_size_ = aux.size();

#ifdef HMDF_SANITY_EXCEPTIONS
        for (const size_type kth : kth_elements_)
            if (kth > compute_size_)
                throw DataFrameError("NKthValueVisitor: One of the kth values "
                                     "is greater than input column length");
#endif // HMDF_SANITY_EXCEPTIONS

        if (compute_size_ != 0) {
            const bool  sort_it {
                kth_elements_.size() >=
                    size_type(std::round(
                        std::log2(double(compute_size_)) *
                        double(compute_size_)))
            };

            result_.resize(kth_elements_.size());
            if (sort_it)  {
                std::sort(aux.begin(), aux.end());
                for (size_type i { 0 }; const size_type k : kth_elements_)  {
                    const size_type kth {
                        std::clamp(
                            size_type(std::round(
                                double(k * compute_size_) / double(col_s))),
                            size_type(1), compute_size_)
                    };

                    result_[i++] = aux[kth - 1];
                }
            }
            else  {
                for (size_type i { 0 }; const size_type k : kth_elements_)  {
                    const size_type kth {
                        std::clamp(
                            size_type(std::round(
                                double(k * compute_size_) / double(col_s))),
                            size_type(1), compute_size_)
                    };
                    const auto      nth {
                        aux.begin() + static_cast<std::ptrdiff_t>(kth - 1)
                    };

                    std::nth_element(aux.begin(), nth, aux.end());
                    result_[i++] = *nth;
                }
            }
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {   }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline size_type get_compute_size() const  { return (compute_size_); }

    explicit NKthValueVisitor(std::vector<size_type> &&ke,
                              bool skipnan = false)
        : kth_elements_(ke), skip_nan_(skipnan)  {   }

private:

    result_type                     result_ {  };
    size_type                       compute_size_ { 0 };
    const std::vector<size_type>    kth_elements_;
    const bool                      skip_nan_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using nkthv_v = NKthValueVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  MedianVisitor  {

private:

    using vec_type = std::vector<T, typename allocator_declare<T, A>::type>;

public:

    DEFINE_VISIT_BASIC_TYPES_2

    template <typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };
        vec_type        aux;

        if (skip_nan_)  {
            aux.reserve(col_s);
            std::copy_if(column_begin, column_end,
                         std::back_inserter(aux),
                         [](const value_type &v) -> bool  {
                             return (! is_nan__(v));
                         });
        }
        else  {
            aux.insert(aux.end(), column_begin, column_end);
        }

        const size_type cs { aux.size() };

        if (cs == 0)
            return;

        const size_type half { col_s >> 1 };
        const size_type kth1 {
            size_type(std::round(double((half + 1) * cs) / double(col_s)))
        };
        auto            nth1 {
            aux.begin() + static_cast<std::ptrdiff_t>(kth1 - 1)
        };

        // Odd
        //
        if (cs & 0x01)  {
            std::nth_element(aux.begin(), nth1, aux.end());
            result_ = *nth1;
            return;
        }

        // Even
        //
        const size_type kth2 {
            size_type(std::round(
                double((cs < col_s ? half + 2 : half) * cs) / double(col_s)))
        };
        auto            nth2 {
            aux.begin() + static_cast<std::ptrdiff_t>(kth2 - 1)
        };

        if (kth1 == kth2)  {
            std::nth_element(aux.begin(), nth1, aux.end());
            result_ = *nth1;
        }
        else  {
            // Select the larger order statistic first.
            //
            const auto  nth_high { (kth1 > kth2) ? nth1 : nth2 };
            const auto  nth_low { (kth1 > kth2) ? nth2 : nth1 };

            std::nth_element(aux.begin(), nth_high, aux.end());

            // The lower order statistic is entirely in the
            // partition preceding nth_high.
            //
            std::nth_element(aux.begin(), nth_low, nth_high);

            const value_type    low { *nth_low };
            const value_type    high { *nth_high };

            result_ = (low + high) / value_type(2);
        }
    }

    OBO_PORT_OPT

    inline void pre()  {

        OBO_PORT_PRE
        result_ = value_type();
    }
    inline void post()  { OBO_PORT_POST }
    inline result_type get_result() const  { return (result_); }

    explicit
    MedianVisitor(bool skipnan = false) : skip_nan_(skipnan)  {  }

private:

    OBO_PORT_DECL

    result_type result_ {  };
    const bool  skip_nan_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using med_v = MedianVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  QuantileVisitor  {

private:

    using vec_type = std::vector<T, typename allocator_declare<T, A>::type>;

public:

    DEFINE_VISIT_BASIC_TYPES_2

    template <typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (qt_ < 0.0 || qt_ > 1.0 || col_s == 0)
            throw DataFrameError("QuantileVisitor: qt must >= 0 and <= 1 and "
                                 "column size > 0");
#endif // HMDF_SANITY_EXCEPTIONS

        vec_type    aux;

        if (skip_nan_)  {
            aux.reserve(col_s);
            std::copy_if(column_begin, column_end,
                         std::back_inserter(aux),
                         [](const value_type &v) -> bool {
                             return (! is_nan__(v));
                         });
        }
        else
            aux.insert(aux.end(), column_begin, column_end);

        const size_type compute_size { aux.size() };

        if (compute_size == 0)  return;

        const double    vec_len_frac { qt_ * col_s };

        // int_idx must be floor(vec_len_frac), not round(vec_len_frac):
        // int_idx and int_idx+1 are later used as the two ranks bracketing
        // the true (fractional) target rank, which only holds if int_idx is
        // the floor. Rounding instead of flooring made int_idx jump to the
        // ceiling whenever the fractional part was >= 0.5, so int_idx and
        // int_idx+1 no longer bracketed vec_len_frac at all.
        //
        // need_two must reflect whether vec_len_frac has a genuine
        // fractional remainder -- not col_s's parity, which was only ever
        // coincidentally right for the classic "average the two middle
        // values" median-of-even-n case and wrong for every other
        // quantile. The epsilon absorbs floating-point noise from qt_*col_s
        // (e.g. 0.1 * 10 not landing on exactly 1.0).
        //
        constexpr double    epsilon { 1e-9 };
        const size_type     int_idx {
            static_cast<size_type>(std::floor(vec_len_frac + epsilon))
        };
        const double        frac_part {
            std::max(0.0, vec_len_frac - double(int_idx))
        };
        const bool          need_two { frac_part > epsilon };

        const auto  rescaled_kth =
            [compute_size, col_s](size_type raw_idx) -> size_type  {
                return (std::clamp(
                    size_type(std::round(
                        double(raw_idx * compute_size) / double(col_s))),
                    size_type(1), compute_size));
            };

        if (qt_ == 0.0)  {
            result_= std::ranges::min(aux);
        }
        else if (qt_ == 1.0)  {
            result_ = std::ranges::max(aux);
        }
        else if (policy_ == quantile_policy::mid_point ||
                 policy_ == quantile_policy::linear)  {
            const size_type kth1 { rescaled_kth(int_idx) };
            const auto      nth1 {
                aux.begin() + static_cast<std::ptrdiff_t>(kth1 - 1)
            };

            if (need_two && int_idx + 1 <= col_s)  {
                const size_type kth2 { rescaled_kth(int_idx + 1) };

                if (kth2 == kth1)  {
                    std::nth_element(aux.begin(), nth1, aux.end());
                    result_ = *nth1;
                }
                else  {
                    const auto  nth2 {
                        aux.begin() + static_cast<std::ptrdiff_t>(kth2 - 1)
                    };
                    const auto  nth_high { (kth1 > kth2) ? nth1 : nth2 };
                    const auto  nth_low  { (kth1 > kth2) ? nth2 : nth1 };

                    std::nth_element(aux.begin(), nth_high, aux.end());
                    std::nth_element(aux.begin(), nth_low, nth_high);

                    const value_type    v1 { *nth1 };
                    const value_type    v2 { *nth2 };

                    result_ = (policy_ == quantile_policy::mid_point)
                                  ? (v1 + v2) / value_type(2)
                                  : v1 + (v2 - v1) * value_type(frac_part);
                }
            }
            else  {
                std::nth_element(aux.begin(), nth1, aux.end());
                result_ = *nth1;
            }
        }
        else if (policy_ == quantile_policy::lower_value ||
                 policy_ == quantile_policy::higher_value)  {
            const size_type raw_idx {
                policy_ == quantile_policy::lower_value
                    ? int_idx
                    : (int_idx + 1 <= col_s && need_two ? int_idx + 1 : int_idx)
            };
            const size_type kth { rescaled_kth(raw_idx) };
            const auto      nth {
                aux.begin() + static_cast<std::ptrdiff_t>(kth - 1)
            };

            std::nth_element(aux.begin(), nth, aux.end());
            result_ = *nth;
        }
    }

    OBO_PORT_OPT

    inline void pre()  {

        OBO_PORT_PRE
        result_ = value_type();
    }
    inline void post()  { OBO_PORT_POST }
    inline result_type get_result() const  { return (result_); }

    explicit
    QuantileVisitor(double quantile = 0.5,
                    quantile_policy q_policy = quantile_policy::mid_point,
                    bool skip_nan = false)
        : qt_(quantile), policy_(q_policy), skip_nan_(skip_nan)  {   }

private:

    OBO_PORT_DECL

    result_type             result_ {  };
    const double            qt_;
    const quantile_policy   policy_;
    const bool              skip_nan_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using qt_v = QuantileVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  NQuantileVisitor  {

private:

    using vec_type = std::vector<T, typename allocator_declare<T, A>::type>;

public:

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s == 0)
            throw DataFrameError("NQuantileVisitor: Column size > 0");
        for (const auto qt : qts_)
            if (qt < 0.0 || qt > 1.0)
                throw DataFrameError("NQuantileVisitor: 1 >= quantiles >= 0");
#endif // HMDF_SANITY_EXCEPTIONS

        vec_type    aux;

        if (skip_nan_)  {
            aux.reserve(col_s);
            std::copy_if(column_begin, column_end,
                         std::back_inserter(aux),
                         [](const value_type &v) -> bool {
                             return (! is_nan__(v));
                         });
        }
        else
            aux.assign(column_begin, column_end);

        const size_type compute_size { aux.size() };

        if (compute_size == 0)  return;

        const auto  rescaled_kth =
            [compute_size, col_s](size_type raw_idx) -> size_type  {
                return (std::clamp(
                    size_type(std::round(
                        double(raw_idx * compute_size) / double(col_s))),
                    size_type(1), compute_size));
            };

        result_.resize(qts_.size());
        for (size_type i { 0 }; const double qt : qts_)  {
            const double        vec_len_frac { qt * col_s };
            // See QuantileVisitor for why this must be floor (not round)
            // and why need_two must test the fractional remainder directly
            // (not col_s's parity).
            //
            constexpr double    epsilon { 1e-9 };
            const size_type     int_idx {
                static_cast<size_type>(std::floor(vec_len_frac + epsilon))
            };
            const double        frac_part {
                std::max(0.0, vec_len_frac - double(int_idx))
            };
            const bool          need_two { frac_part > epsilon };

            if (qt == 0.0 || qt == 1.0)  {
                const size_type kth { rescaled_kth((qt == 0.0) ? 1 : col_s) };
                const auto      nth {
                    aux.begin() + static_cast<std::ptrdiff_t>(kth - 1)
                };

                std::nth_element(aux.begin(), nth, aux.end());
                result_[i++] = *nth;
            }
            else if (policy_ == quantile_policy::mid_point ||
                     policy_ == quantile_policy::linear)  {
                const size_type kth1 { rescaled_kth(int_idx) };
                const auto      nth1 {
                    aux.begin() + static_cast<std::ptrdiff_t>(kth1 - 1)
                };

                if (need_two && int_idx + 1 <= col_s)  {
                    const size_type kth2 { rescaled_kth(int_idx + 1) };

                    if (kth2 == kth1)  {
                        std::nth_element(aux.begin(), nth1, aux.end());
                        result_[i++] = *nth1;
                    }
                    else  {
                        const auto  nth2 {
                            aux.begin() + static_cast<std::ptrdiff_t>(kth2 - 1)
                        };
                        const auto  nth_high { (kth1 > kth2) ? nth1 : nth2 };
                        const auto  nth_low  { (kth1 > kth2) ? nth2 : nth1 };

                        std::nth_element(aux.begin(), nth_high, aux.end());
                        std::nth_element(aux.begin(), nth_low, nth_high);

                        const value_type    v1 { *nth1 };
                        const value_type    v2 { *nth2 };

                        result_[i++] =
                            (policy_ == quantile_policy::mid_point)
                                 ? (v1 + v2) / value_type(2)
                                 : v1 + (v2 - v1) * value_type(frac_part);
                    }
                }
                else  {
                    std::nth_element(aux.begin(), nth1, aux.end());
                    result_[i++] = *nth1;
                }
            }
            else if (policy_ == quantile_policy::lower_value ||
                     policy_ == quantile_policy::higher_value)  {
                const size_type raw_idx {
                    (policy_ == quantile_policy::lower_value)
                         ? int_idx
                         : ((((int_idx + 1) <= col_s) && need_two)
                                 ? int_idx + 1 : int_idx)
                };
                const size_type kth { rescaled_kth(raw_idx) };
                const auto      nth {
                    aux.begin() + static_cast<std::ptrdiff_t>(kth - 1)
                };

                std::nth_element(aux.begin(), nth, aux.end());
                result_[i++] = *nth;
            }
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    explicit
    NQuantileVisitor(std::vector<double> &&quantiles,
                     quantile_policy q_policy = quantile_policy::mid_point,
                     bool skip_nan = false)
        : qts_(quantiles), policy_(q_policy), skip_nan_(skip_nan)  {   }

private:

    result_type                 result_ {  };
    const std::vector<double>   qts_;
    const quantile_policy       policy_;
    const bool                  skip_nan_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using nqt_v = NQuantileVisitor<T, I, A>;

// ----------------------------------------------------------------------------

// Mode of a vector is a value that appears most often in the vector.
// This visitor extracts the top N repeated values in the column with the
// associated indices.
// The T type must be hashable
// Because of the information this has to return, it is not a cheap operation
//
template<std::size_t N,
         hashable_equal T, typename I = unsigned long, std::size_t A = 0>
struct  ModeVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_type = std::vector<U, typename allocator_declare<U, A>::type>;

    struct  DataItem  {
        // Value of the column item
        //
        const value_type                   *value { nullptr };
        // List of indices where value occurred
        //
        VectorConstPtrView<index_type, A>  indices { };

        // Number of times value occurred
        //
        inline size_type repeat_count() const  { return (indices.size()); }

        // List of column indices where value occurred
        //
        vec_type<size_type> value_indices_in_col {  };

        DataItem() = default;
        inline DataItem(const value_type &v) : value(&v)  {
            indices.reserve(4);
            value_indices_in_col.reserve(4);
        }

        const value_type &get_value() const noexcept  { return (*value); }
    };

private:

    struct my_hash_  {
        using argument_type = const value_type *;
        using result_type = std::size_t;

        inline result_type operator()(const argument_type &a) const noexcept {

            return (std::hash<value_type>()(*a));
        }
    };

    struct my_equal_to_  {
        using first_argument_type = const value_type *;
        using second_argument_type = const value_type *;
        using result_type = bool;

        inline result_type
        operator()(const first_argument_type &f,
                   const second_argument_type &s) const noexcept  {

            return (std::equal_to<value_type>()(*f, *s));
        }
    };

    using map_type = std::unordered_map<
        const T *,
        DataItem,
        my_hash_,
        my_equal_to_,
        typename allocator_declare<
            std::pair<const T *const, DataItem>, A>::type>;

public:

    using result_type = std::array<DataItem, N>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

        if constexpr (N == 0)
            return;

        DataItem    nan_item;
        map_type    val_map;

        val_map.reserve(col_s);
        for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
            if (is_nan__(*(column_begin + i))) [[unlikely]]  {
                nan_item.value = &*(column_begin + i);
                nan_item.indices.push_back(&*(idx_begin + i));
                nan_item.value_indices_in_col.push_back(i);
            }
            else [[likely]]  {
                auto    ret {
                    val_map.try_emplace(&*(column_begin + i),
                                        *(column_begin + i))
                };

                ret.first->second.indices.push_back(&*(idx_begin + i));
                ret.first->second.value_indices_in_col.push_back(i);
            }
        }

        vec_type<DataItem>  val_vec;

        val_vec.reserve(val_map.size() + 1);
        if (nan_item.value != nullptr)
            val_vec.push_back(nan_item);

        std::for_each(val_map.begin(),
                      val_map.end(),
                      [&val_vec](const auto &map_pair) -> void {
                          if (map_pair.second.value) [[likely]]
                              val_vec.push_back(map_pair.second);
                      });

        const auto  comp =
            [](const DataItem &lhs, const DataItem &rhs) -> bool {
                return (lhs.repeat_count() > rhs.repeat_count());
            };

        if (N < val_vec.size())  {
            const auto  nth {
                val_vec.begin() + static_cast<std::ptrdiff_t>(N)
            };

            std::nth_element(val_vec.begin(), nth, val_vec.end(), comp);
            std::sort(val_vec.begin(), nth, comp);
        }
        else  {
            std::sort(val_vec.begin(), val_vec.end(), comp);
        }

        for (size_type i { 0 }; i < N && i < val_vec.size(); ++i)
            result_[i] = val_vec[i];
    }

    OBO_PORT_OPT2

    inline void pre()  {

        result_type x;

        result_.swap(x);
        OBO_PORT_PRE
    }
    inline void post()  { OBO_PORT_POST }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    inline void sort_by_repeat_count()  {

        if (result_.size() >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)
            ThreadGranularity::thr_pool_.parallel_sort(
                result_.begin(), result_.end(),
                [](const DataItem &lhs, const DataItem &rhs) -> bool  {
                    return (lhs.repeat_count() < rhs.repeat_count());
                });
        else
            std::sort(result_.begin(), result_.end(),
                      [](const DataItem &lhs, const DataItem &rhs) -> bool  {
                          return (lhs.repeat_count() < rhs.repeat_count());
                      });
    }
    inline void sort_by_value()  {

        if (result_.size() >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)
            ThreadGranularity::thr_pool_.parallel_sort(
                result_.begin(), result_.end(),
                [](const DataItem &lhs, const DataItem &rhs) -> bool  {
                    return (*(lhs.value) < *(rhs.value));
                });
        else
            std::sort(result_.begin(), result_.end(),
                      [](const DataItem &lhs, const DataItem &rhs) -> bool  {
                          return (*(lhs.value) < *(rhs.value));
                      });
    }

private:

    OBO_PORT_DECL

    result_type result_ { };
};

template<std::size_t N,
         typename T, typename I = unsigned long, std::size_t A = 0>
using mode_v = ModeVisitor<N, T, I, A>;

// ----------------------------------------------------------------------------

// This calculates 4 different form of Mean Absolute Deviation based on the
// requested type input. Please see mad_type enum type
//
template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  MADVisitor  {

private:

    const mad_type  mad_type_;
    const bool      skip_nan_;

    template <typename K, typename H>
    inline void
    calc_mean_abs_dev_around_mean_(const K &idx_begin,
                                   const K &idx_end,
                                   const H &column_begin,
                                   const H &column_end)  {

        GET_COL_SIZE2

        if (col_s == 0)  return;

        MeanVisitor<T, I>   mean_visitor { skip_nan_ };

        mean_visitor.pre();
        mean_visitor(idx_begin, idx_end, column_begin, column_end);
        mean_visitor.post();

        MeanVisitor<T, I>   mean_mean_visitor { skip_nan_ };
        const value_type    mean { mean_visitor.get_result() };
        const index_type    idx { index_type { } };

        mean_mean_visitor.pre();
        if (! skip_nan_)  {
            for (std::size_t i { 0 }; i < col_s; ++i) [[likely]]  {
                const value_type    &value { *(column_begin + i) };

                mean_mean_visitor(idx, std::fabs(value - mean));
            }
        }
        else  {
            for (std::size_t i { 0 }; i < col_s; ++i) [[likely]]  {
                const value_type    &value { *(column_begin + i) };

                if (! is_nan__(value)) [[likely]]
                    mean_mean_visitor(idx, std::fabs(value - mean));
            }
        }
        mean_mean_visitor.post();

        result_ = mean_mean_visitor.get_result();
    }

    template <typename K, typename H>
    inline void
    calc_mean_abs_dev_around_median_(const K &idx_begin,
                                     const K &idx_end,
                                     const H &column_begin,
                                     const H &column_end)  {

        MedianVisitor<T, I, A> median_visitor { skip_nan_ };

        median_visitor.pre();
        median_visitor(idx_begin, idx_end, column_begin, column_end);
        median_visitor.post();

        GET_COL_SIZE2

        MeanVisitor<T, I>   mean_median_visitor { skip_nan_ };
        const index_type    idx { index_type { } };

        mean_median_visitor.pre();
        if (! skip_nan_)  {
            for (std::size_t i { 0 }; i < col_s; ++i) [[likely]]
                mean_median_visitor(
                    idx,
                    std::fabs(*(column_begin + i) -
                              median_visitor.get_result()));
        }
        else  {
            for (std::size_t i { 0 }; i < col_s; ++i) [[likely]]  {
                const value_type    value { *(column_begin + i) };

                if (! is_nan__(value)) [[likely]]
                    mean_median_visitor(
                        idx,
                        std::fabs(value - median_visitor.get_result()));
            }
        }
        mean_median_visitor.post();

        result_ = mean_median_visitor.get_result();
    }

    template <typename K, typename H>
    inline void
    calc_median_abs_dev_around_mean_(const K &idx_begin,
                                     const K &idx_end,
                                     const H &column_begin,
                                     const H &column_end)  {

        using vec_t = std::vector<T, typename allocator_declare<T, A>::type>;

        GET_COL_SIZE2

        MeanVisitor<T, I>   mean_visitor { skip_nan_ };

        mean_visitor.pre();
        mean_visitor(idx_begin, idx_end, column_begin, column_end);
        mean_visitor.post();

        MedianVisitor<T, I, A>  median_mean_visitor;
        vec_t                   mean_dists;

        mean_dists.resize(col_s);
        for (std::size_t i { 0 }; i < col_s; ++i) [[likely]]
            mean_dists[i] =
                std::fabs(*(column_begin + i) - mean_visitor.get_result());
        median_mean_visitor.pre();
        median_mean_visitor(idx_begin, idx_end,
                            mean_dists.begin(), mean_dists.end());
        median_mean_visitor.post();

        result_ = median_mean_visitor.get_result();
    }

    template <typename K, typename H>
    inline void
    calc_median_abs_dev_around_median_(const K &idx_begin,
                                       const K &idx_end,
                                       const H &column_begin,
                                       const H &column_end)  {

        using vec_t = std::vector<T, typename allocator_declare<T, A>::type>;

        MedianVisitor<T, I, A> median_visitor { skip_nan_ };

        median_visitor.pre();
        median_visitor(idx_begin, idx_end, column_begin, column_end);
        median_visitor.post();

        GET_COL_SIZE2

        MedianVisitor<T, I, A>  median_median_visitor;
        vec_t                   median_dists;

        median_dists.reserve(col_s);
        for (std::size_t i { 0 }; i < col_s; ++i) [[likely]]  {
            const value_type    value { *(column_begin + i) };

            if (! skip_nan_ || ! is_nan__(value)) [[likely]]
                median_dists.push_back(
                    std::fabs(value - median_visitor.get_result()));
        }
        median_median_visitor.pre();
        median_median_visitor(idx_begin, idx_end,
                              median_dists.begin(), median_dists.end());
        median_median_visitor.post();

        result_ = median_median_visitor.get_result();
    }

public:

    DEFINE_VISIT_BASIC_TYPES_2

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        switch (mad_type_)  {
            case mad_type::mean_abs_dev_around_mean:
                calc_mean_abs_dev_around_mean_(idx_begin, idx_end,
                                               column_begin, column_end);
                break;
            case mad_type::mean_abs_dev_around_median:
                calc_mean_abs_dev_around_median_(idx_begin, idx_end,
                                                 column_begin, column_end);
                break;
            case mad_type::median_abs_dev_around_mean:
                calc_median_abs_dev_around_mean_(idx_begin, idx_end,
                                                 column_begin, column_end);
                break;
            case mad_type::median_abs_dev_around_median:
                calc_median_abs_dev_around_median_(idx_begin, idx_end,
                                                   column_begin, column_end);
                break;
            default:
                break;
        }
    }

    OBO_PORT_OPT

    MADVisitor(mad_type mt, bool skip_nan = false)
        : mad_type_(mt), skip_nan_(skip_nan)  {   }

    inline void pre()  {

        OBO_PORT_PRE
        result_ = value_type();
    }
    inline void post()  { OBO_PORT_POST }
    inline result_type get_result() const  { return (result_); }

private:

    OBO_PORT_DECL

    result_type result_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using mad_v = MADVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  DiffVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <bidirectional_iterator K, bidirectional_iterator H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s == 0 || size_type(std::abs(periods_)) >= (col_s - 1))
            throw DataFrameError("DiffVisitor: column size must be >  0 and "
                                 "periods < column size");
#endif // HMDF_SANITY_EXCEPTIONS

        bool            there_is_zero { false };
        result_type     result;
        const bool      abs_val { abs_val_ };
        auto            diff_func =
            [abs_val](bool local_skip_nan_,
                    bool &there_is_zero,
                    const auto &i,
                    const auto &j,
                    auto &result) -> void  {
                if (local_skip_nan_ && (is_nan__(*i) || is_nan__(*j)))
                [[unlikely]]
                    return;

                const value_type    diff { *i - *j };
                const value_type    val { abs_val ? std::fabs(diff) : diff };

                result.push_back(val);
                there_is_zero = there_is_zero || (val == 0);
            };

        result.reserve(col_s);
        if (periods_ >= 0) [[likely]]  {
            if (! skip_nan_)  {
                for (long i = 0;
                     i < periods_ && static_cast<size_type>(i) < col_s;
                     ++i) [[likely]]
                    result.push_back(
                        std::numeric_limits<value_type>::quiet_NaN());
            }

            auto    i { column_begin + periods_ };

            for (auto j { column_begin }; i < column_end; ++i, ++j) [[likely]]
                diff_func(skip_nan_, there_is_zero, i, j, result);
        }
        else  {
            H   i { column_end - (1 + std::abs(periods_)) };
            H   j { column_end - 1 };

            for ( ; i > column_begin; --i, --j)
                diff_func(skip_nan_, there_is_zero, i, j, result);

            if (i == column_begin)
                diff_func(skip_nan_, there_is_zero, i, j, result);

            std::reverse(result.begin(), result.end());

            if (! skip_nan_)
                for (size_type local_i { 0 };
                     local_i < static_cast<size_type>(std::abs(periods_)) &&
                     local_i < col_s;
                     ++local_i)
                    result.push_back(
                        std::numeric_limits<value_type>::quiet_NaN());
        }

        if (non_zero_ && there_is_zero)
            std::for_each(result.begin(), result.end(),
                          [](value_type &v)  {
                              v += std::numeric_limits<value_type>::epsilon();
                          });

        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    DiffVisitor(long periods = 1,
                bool skipnan = true,
                bool non_zero = false,
                bool abs_val = false)
        : periods_(periods),
          skip_nan_(skipnan),
          non_zero_(non_zero),
          abs_val_(abs_val)  {  }

private:

    result_type result_ { };
    const long  periods_;
    const bool  skip_nan_;
    const bool  non_zero_;
    const bool  abs_val_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using diff_v = DiffVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  ZScoreVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

public:

    DEFINE_VISIT_BASIC_TYPES

    template<typename U>
    using vec_type = std::vector<U, typename allocator_declare<U, A>::type>;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    vec_type<T>,
                                    vec_type<std::vector<data_t>>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE2

        StdVisitor<T, I>    svisit { false, skip_nan_ };

        svisit.pre();
        svisit(idx_begin, idx_end, column_begin, column_end);
        svisit.post();

        const auto  m { svisit.get_mean() };
        const auto  s { svisit.get_result() };
        result_type result(col_s);
        const auto  thread_level { (col_s < ThreadPool::MUL_THR_THHOLD)
            ? 0L : ThreadGranularity::get_thread_level()
        };

        auto    lbd =
            [m, s, &result, &column_begin]
            (auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)  {
                    const auto  &val { *(column_begin + i) };

                    if constexpr (! std::is_arithmetic_v<T> &&
                                  ! is_std_vector_v<T>)  {
                        const std::vector<data_t>   vec(val.begin(), val.end());

                        result[i] = (vec - m) / s;
                    }
                    else  result[i] = (val - m) / s;
                }
            };

        if (thread_level > 2)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    std::move(lbd));

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(size_type(0), col_s);
        }

        result_.swap(result);
    }

    OBO_PORT_OPT

    inline void pre()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            OBO_PORT_PRE
        }
        result_.clear();
    }
    inline void post()  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            OBO_PORT_POST
        }
    }
    DEFINE_RESULT

    DECL_CTOR(ZScoreVisitor)

private:

    OBO_PORT_DECL

    result_type result_ {  };  // Z Score
    const bool  skip_nan_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using zs_v = ZScoreVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long>
struct  SampleZScoreVisitor  {

    DEFINE_VISIT_BASIC_TYPES_2

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &population_begin, const H &population_end,
               const H &sample_begin, const H &sample_end)  {

        const size_type s_col_s = std::distance(sample_begin, sample_end);

        StdVisitor<T, I>    p_svisit { false, skip_nan_ };
        MeanVisitor<T, I>   s_mvisit { skip_nan_ };

        p_svisit.pre();
        s_mvisit.pre();
        if (s_col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 3)  {
            auto    fut1 {
                ThreadGranularity::thr_pool_.dispatch(
                      false,
                      [&p_svisit,
                       &idx_begin, &idx_end,
                       &population_begin, &population_end]() -> void  {
                          p_svisit(idx_begin, idx_end,
                                   population_begin, population_end);
                      })
            };
            auto    fut2 {
                ThreadGranularity::thr_pool_.dispatch(
                      false,
                      [&s_mvisit,
                       &idx_begin, &idx_end,
                       &sample_begin, &sample_end]() -> void  {
                          s_mvisit(idx_begin, idx_end,
                                   sample_begin, sample_end);
                      })
            };

            fut1.get();
            fut2.get();
        }
        else  {
            p_svisit(idx_begin, idx_end, population_begin, population_end);
            s_mvisit(idx_begin, idx_end, sample_begin, sample_end);
        }
        p_svisit.post();
        s_mvisit.post();

        result_ = (s_mvisit.get_result() - p_svisit.get_mean()) /
                  (p_svisit.get_result() / ::sqrt(s_col_s));
    }

    inline void pre()  { result_ = 0; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }

    DECL_CTOR(SampleZScoreVisitor)

private:

    value_type  result_ {  };  // Z Score
    const bool  skip_nan_;
};

template<typename T, typename I = unsigned long>
using szs_v = SampleZScoreVisitor<T, I>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  BoxCoxVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;
    using anal_res_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                                   data_t,
                                                   std::vector<data_t>>;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    vec_t<data_t>,
                                    vec_t<std::vector<data_t>>>;

private:

    template<typename V, typename S>
    static inline auto bc_shift_add_(const V &v, S shift) noexcept  {

        if constexpr (std::is_arithmetic_v<V>)  {
            return (v + shift);
        }
        else  {
            anal_res_t  res(v.size());

            for (size_type i { 0 }; i < v.size(); ++i)
                res[i] = v[i] + shift;
            return (res);
        }
    }

    template<typename H>
    inline void modulus_(const H &column_begin, size_type col_s,
                         size_type thread_level)  {

        result_.resize(col_s);
        if (lambda_ != 0)  {
            auto   lbd =
                [this, &column_begin] (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        const auto          &val { *(column_begin + i) };
                        const anal_res_t    sign { _bc_signbit_(val) };
                        const anal_res_t    &v {
                            (_bc_pow_(_bc_fabs_(val) + one_, lambda_) -
                             one_) / lambda_
                        };

                        result_[i] = sign * v;
                    }
                };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0), col_s, std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
        else  {
            auto    lbd =
                [this, &column_begin] (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        const auto          &val { *(column_begin + i) };
                        const anal_res_t    sign { _bc_signbit_(val) };

                        result_[i] = sign * _bc_log_(_bc_fabs_(val) + one_);
                    }
                };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0), col_s, std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
    }

    template<typename H>
    inline void exponential_(const H &column_begin,
                             size_type col_s, size_type thread_level)  {

        result_.resize(col_s);
        if (lambda_ != 0)  {
            auto    lbd =
                [this, &column_begin] (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        const auto  &val { *(column_begin + i) };

                        result_[i] =
                            (_bc_exp_(lambda_ * val) - one_) / lambda_;
                    }
               };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
        else  {
            auto    lbd =
                [this, &column_begin] (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        if constexpr (! std::is_arithmetic_v<T>)  {
                            const auto  &val { *(column_begin + i) };

                            result_[i].assign(std::begin(val), std::end(val));
                        }
                        else
                            result_[i] = *(column_begin + i);
                    }
               };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
    }

    template<typename H>
    inline void original_(const H &column_begin,
                          data_t shift,
                          size_type col_s,
                          size_type thread_level)  {

        result_.resize(col_s);
        if (lambda_ != 0)  {
            auto    lbd =
                [this, shift, &column_begin] (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        const auto  &val { *(column_begin + i) };

                        result_[i] =
                            (_bc_pow_(val + shift, lambda_) - one_) / lambda_;
                    }
               };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
        else  {
            auto    lbd =
                [this, shift, &column_begin] (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        const auto  &val { *(column_begin + i) };

                        result_[i] = _bc_log_(val + shift);
                    }
               };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
    }

    template<typename K, typename H>
    inline void geometric_mean_(const K &dummy,
                                const H &column_begin,
                                const H &column_end,
                                data_t shift,
                                size_type col_s, size_type thread_level)  {

        H                           citer { column_begin };
        GeometricMeanVisitor<T, I>  gm;

        result_.resize(col_s);
        gm.pre();
        while (citer < column_end) [[likely]]
            gm(dummy, *citer++ + shift);
        gm.post();

        if (lambda_ != 0)  {
            auto    lbd =
                [this, shift,
                 &gm = std::as_const(gm.get_result()), &column_begin]
                (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        const auto  &val { *(column_begin + i) };
                        const auto  &raw_v { val + shift };

                        result_[i] =
                            (_bc_pow_(raw_v, lambda_) - one_) /
                            (lambda_ * _bc_pow_(gm, lambda_ - one_));

                    }
               };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
        else  {
            auto    lbd =
                [this, shift, gm = gm.get_result(), &column_begin]
                (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        const auto  &val { *(column_begin + i) };

                        if constexpr (is_std_array_v<T>)  {
                            const auto  &res { _bc_log_(val + shift) * gm };

                            result_[i].assign(std::begin(res), std::end(res));
                        }
                        else
                            result_[i] = _bc_log_(val + shift) * gm;
                    }
               };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s);
            }
        }
    }

public:

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };
        data_t          shift { 0 };

        if (! is_all_positive_ &&
            (box_cox_type_ == box_cox_type::original ||
             box_cox_type_ == box_cox_type::geometric_mean))  {
            if constexpr (std::is_arithmetic_v<value_type>)  {
                MinVisitor<T, I>    mv;

                mv.pre();
                mv(idx_begin, idx_end, column_begin, column_end);
                mv.post();
                shift = _bc_fabs_(mv.get_result()) + data_t(0.0000001);
            }
            else  {
                auto    min_val { (*column_begin)[0] };

                for (size_type i { 0 }; i < col_s; ++i)  {
                    const auto  &md_val { *(column_begin + i) };

                    for (const auto val : md_val)
                        min_val = std::min(min_val, val);
                }
                shift = _bc_fabs_(min_val) + data_t(0.0000001);
            }
        }

        const auto      thread_level { (col_s < ThreadPool::MUL_THR_THHOLD)
            ? 0L : ThreadGranularity::get_thread_level()
        };

        if (box_cox_type_ == box_cox_type::original)
            original_(column_begin, shift, col_s, thread_level);
        else if (box_cox_type_ == box_cox_type::geometric_mean)
            geometric_mean_(*idx_begin, column_begin, column_end,
                            shift, col_s, thread_level);
        else if (box_cox_type_ == box_cox_type::modulus)
            modulus_(column_begin, col_s, thread_level);
        else if (box_cox_type_ == box_cox_type::exponential)
            exponential_(column_begin, col_s, thread_level);
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    BoxCoxVisitor(box_cox_type bct, data_t l, bool is_all_pos)
        : box_cox_type_(bct),
          lambda_(l),
          is_all_positive_(is_all_pos)  {   }

private:

    result_type             result_ {  }; // Transformed
    const box_cox_type      box_cox_type_;
    const data_t            lambda_;
    const bool              is_all_positive_;
    static constexpr data_t one_ { 1 };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using bcox_v = BoxCoxVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  ProbabilityDistVisitor  {

    template<typename U>
    using vec_type = std::vector<U, typename allocator_declare<U, A>::type>;

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

    using sum_t =
        typename std::conditional_t<std::is_arithmetic_v<T>,
                                    data_t,
                                    std::vector<data_t>>;
public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<
            std::is_arithmetic_v<T>,
            vec_type<data_t>,
            Matrix<data_t, matrix_orient::column_major>>;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

        if constexpr (std::is_arithmetic_v<value_type>)  {
            result_.resize(col_s);
        }
        else  {
            const size_type dim = column_begin->size();

#ifdef HMDF_SANITY_EXCEPTIONS
            for (size_type i { 0 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "ProbabilityDistVisitor: "
                        "Inconsistent data dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

            result_.resize(long(col_s), long(dim));
        }

        sum_t       sum { 0 };
        const bool  threading {
            col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2
        };

        if (pdtype_ == prob_dist_type::arithmetic)  {
            auto    sum_lbd =
                [](const auto &begin, const auto &end) -> sum_t  {
                    sum_t   sum;

                    if constexpr (std::is_arithmetic_v<T>)
                        sum = 0;
                    else
                        sum.resize(begin->size(), 0);
                    for (auto citer { begin }; citer < end; ++citer)
                        sum = sum + *citer;
                    return (sum);
                };
            auto    lbd =
                [this, &column_begin, &sum = std::as_const(sum)]
                (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        if constexpr (std::is_arithmetic_v<T>)  {
                            result_[i] = *(column_begin + i) / sum;
                        }
                        else  {
                            const auto  &val { *(column_begin + i) / sum };

                            result_.set_row(val.begin(), long(i));
                        }
                    }
                };

            if (threading)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        column_begin,
                        column_end,
                        std::move(sum_lbd))
                };

                for (auto &fut : futures)  sum += fut.get();

                auto    futures2 {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures2)  fut.get();
            }
            else  {
                sum = sum_lbd(column_begin, column_end);
                lbd(size_type(0), col_s);
            }
        }
        else if (pdtype_ == prob_dist_type::log)  {
            auto    sum_lbd =
                [](const auto &begin, const auto &end) -> sum_t  {
                    sum_t   sum;

                    if constexpr (std::is_arithmetic_v<T>)
                        sum = 0;
                    else
                        sum.resize(begin->size(), 0);
                    for (auto citer = begin; citer < end; ++citer)
                        sum = sum + _bc_log_(*citer);
                    return (sum);
                };
            auto    lbd =
                [this, &column_begin, &sum = std::as_const(sum)]
                (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        if constexpr (std::is_arithmetic_v<T>)  {
                            result_[i] = _bc_log_(*(column_begin + i)) / sum;
                        }
                        else  {
                            const auto  &val {
                                _bc_log_(*(column_begin + i)) / sum
                            };

                            result_.set_row(val.begin(), long(i));
                        }
                    }
                };

            if (threading)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        column_begin,
                        column_end,
                        std::move(sum_lbd))
                };

                for (auto &fut : futures)  sum += fut.get();

                auto    futures2 {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures2)  fut.get();
            }
            else  {
                sum = sum_lbd(column_begin, column_end);
                lbd(size_type(0), col_s);
            }
        }
        else if (pdtype_ == prob_dist_type::softmax)  {
            // exp() of the raw values overflows well before any realistic
            // sum/ratio would -- e.g. exp(710) alone is already +inf in a
            // double, at which point inf/inf gives NaN for every entry,
            // not just the one that overflowed (confirmed empirically on
            // input no larger than {700,710,720,705}). Subtracting the
            // column's own max before exponentiating is the standard
            // softmax stabilization: base^(val-max) = base^val / base^max,
            // and that common base^max factor cancels exactly between the
            // numerator and every term of the denominator sum, so the
            // ratio is unchanged -- this only trades a real overflow risk
            // for none, it isn't an approximation.
            //
            sum_t   max_val;

            if constexpr (std::is_arithmetic_v<T>)
                max_val = *column_begin;
            else
                max_val.assign(column_begin->begin(), column_begin->end());
            for (auto citer { column_begin }; citer < column_end; ++citer)  {
                if constexpr (std::is_arithmetic_v<T>)
                    max_val = std::max(max_val, *citer);
                else
                    for (size_type d { 0 }; d < max_val.size(); ++d)
                        max_val[d] = std::max(max_val[d], (*citer)[d]);
            }

            auto    sum_lbd =
                [&max_val](const auto &begin, const auto &end) -> sum_t  {
                    sum_t   sum;

                    if constexpr (std::is_arithmetic_v<T>)
                        sum = 0;
                    else
                        sum.resize(begin->size(), 0);
                    for (auto citer { begin }; citer < end; ++citer)
                        sum = sum + _bc_exp_(*citer - max_val);
                    return (sum);
                };
            auto    lbd =
                [this, &column_begin, &sum = std::as_const(sum), &max_val]
                (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        if constexpr (std::is_arithmetic_v<T>)  {
                            result_[i] =
                                _bc_exp_(*(column_begin + i) - max_val) / sum;
                        }
                        else  {
                            const auto  &val {
                                _bc_exp_(*(column_begin + i) - max_val) / sum
                            };

                            result_.set_row(val.begin(), long(i));
                        }
                    }
                };

            if (threading)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        column_begin,
                        column_end,
                        std::move(sum_lbd))
                };

                for (auto &fut : futures)  sum += fut.get();

                auto    futures2 {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures2)  fut.get();
            }
            else  {
                sum = sum_lbd(column_begin, column_end);
                lbd(size_type(0), col_s);
            }
        }
        else if (pdtype_ == prob_dist_type::pow2)  {
            // Same overflow risk and same fix as softmax just above --
            // 2^val overflows a double around val=1024, confirmed
            // empirically (2^1050 among the inputs reproduces the same
            // all-NaN failure). Subtracting the column's max before
            // exponentiating cancels out exactly in the final ratio.
            //
            sum_t   max_val;

            if constexpr (std::is_arithmetic_v<T>)
                max_val = *column_begin;
            else
                max_val.assign(column_begin->begin(), column_begin->end());
            for (auto citer { column_begin }; citer < column_end; ++citer)  {
                if constexpr (std::is_arithmetic_v<T>)
                    max_val = std::max(max_val, *citer);
                else
                    for (size_type d { 0 }; d < max_val.size(); ++d)
                        max_val[d] = std::max(max_val[d], (*citer)[d]);
            }

            auto    sum_lbd =
                [&max_val](const auto &begin, const auto &end) -> sum_t  {
                    sum_t   sum;

                    if constexpr (std::is_arithmetic_v<T>)
                        sum = 0;
                    else
                        sum.resize(begin->size(), 0);
                    for (auto citer { begin }; citer < end; ++citer)
                        sum = sum + _bc_pow_(data_t(2), *citer - max_val);
                    return (sum);
                };
            auto    lbd =
                [this, &column_begin, &sum = std::as_const(sum), &max_val]
                (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        if constexpr (std::is_arithmetic_v<T>)  {
                            result_[i] =
                                _bc_pow_(data_t(2),
                                         *(column_begin + i) - max_val) / sum;
                        }
                        else  {
                            const auto  &val {
                                _bc_pow_(data_t(2),
                                         *(column_begin + i) - max_val) / sum
                            };

                            result_.set_row(val.begin(), long(i));
                        }
                    }
                };

            if (threading)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        column_begin,
                        column_end,
                        std::move(sum_lbd))
                };

                for (auto &fut : futures)  sum += fut.get();

                auto    futures2 {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures2)  fut.get();
            }
            else  {
                sum = sum_lbd(column_begin, column_end);
                lbd(size_type(0), col_s);
            }
        }
        else if (pdtype_ == prob_dist_type::pow10)  {
            // Same overflow risk and same fix as softmax/pow2 above --
            // 10^val overflows a double around val=308, confirmed
            // empirically ({300,310,320,305} reproduces the same all-NaN
            // failure). Subtracting the column's max before exponentiating
            // cancels out exactly in the final ratio.
            //
            sum_t   max_val;

            if constexpr (std::is_arithmetic_v<T>)
                max_val = *column_begin;
            else
                max_val.assign(column_begin->begin(), column_begin->end());
            for (auto citer { column_begin }; citer < column_end; ++citer)  {
                if constexpr (std::is_arithmetic_v<T>)
                    max_val = std::max(max_val, *citer);
                else
                    for (size_type d { 0 }; d < max_val.size(); ++d)
                        max_val[d] = std::max(max_val[d], (*citer)[d]);
            }

            auto    sum_lbd =
                [&max_val](const auto &begin, const auto &end) -> sum_t  {
                    sum_t   sum;

                    if constexpr (std::is_arithmetic_v<T>)
                        sum = 0;
                    else
                        sum.resize(begin->size(), 0);
                    for (auto citer { begin }; citer < end; ++citer)
                        sum = sum + _bc_pow_(data_t(10), *citer - max_val);
                    return (sum);
                };
            auto    lbd =
                [this, &column_begin, &sum = std::as_const(sum), &max_val]
                (auto begin, auto end) -> void  {
                    for (auto i { begin }; i < end; ++i)  {
                        if constexpr (std::is_arithmetic_v<T>)  {
                            result_[i] =
                                _bc_pow_(data_t(10),
                                         *(column_begin + i) - max_val) /
                                sum;
                        }
                        else  {
                            const auto  &val {
                                _bc_pow_(data_t(10),
                                         *(column_begin + i) - max_val) / sum
                            };

                            result_.set_row(val.begin(), long(i));
                        }
                    }
                };

            if (threading)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        column_begin,
                        column_end,
                        std::move(sum_lbd))
                };

                for (auto &fut : futures)  sum += fut.get();

                auto    futures2 {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd))
                };

                for (auto &fut : futures2)  fut.get();
            }
            else  {
                sum = sum_lbd(column_begin, column_end);
                lbd(size_type(0), col_s);
            }
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    ProbabilityDistVisitor(prob_dist_type pdtype) : pdtype_(pdtype)  {   }

private:

    result_type             result_ {  };
    const prob_dist_type    pdtype_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using pd_v = ProbabilityDistVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  NormalizeVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        if constexpr (std::is_arithmetic_v<value_type>)  {
            if (type_ == normalization_type::min_max)
                min_max_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::simple)
                simple_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::euclidean)
                euclidean_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::maxi)
                maxi_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::z_score)
                z_score_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::decimal_scaling)
                decimal_scaling_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::log_transform)
                log_transform_(column_begin, column_end);
            else if (type_ == normalization_type::root_transform)
                root_transform_(column_begin, column_end);
        }
        else if constexpr (container<T>)  {
            if (type_ == normalization_type::min_max)
                min_max_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::z_score)
                z_score_(idx_begin, idx_end, column_begin, column_end);
            else if (type_ == normalization_type::unit_length)
                unit_length_(column_begin, column_end);
            else if (type_ == normalization_type::flat_vector)
                flat_vector_(column_begin, column_end);
        }

        if (! done_)
            throw DataFrameError("NormalizeVisitor: Cannot do normalization; "
                                 "unknown norm type or mismatched data type");
    }

    inline void pre()  { result_.clear(); done_ = false; }
    inline void post()  {  }

    DEFINE_RESULT

    explicit
    NormalizeVisitor(normalization_type t = normalization_type::min_max)
        : type_(t)  {   }

private:

    template<typename H>
    inline void
    unit_length_(const H &column_begin, const H &column_end)  {

        if constexpr (container<T>)  {
            using data_t = typename T::value_type;

            const size_type col_s {
                size_type(std::distance(column_begin, column_end))
            };
            const size_type num_dim { column_begin->size() };
            auto            calc_norm =
                [](const value_type &point) -> data_t  {
                    data_t  sum { 0 };

                    for (const data_t val : point)
                        sum += val * val;
                    return (std::sqrt(sum));
                };

            result_.resize(col_s);
            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &point { *(column_begin + i) };
                const auto  norm { calc_norm(point) };
                value_type  norm_point;

                if constexpr (Resizable<value_type>)
                    norm_point.resize(num_dim, 0);
                if (norm != 0)  {
                    for (size_type j { 0 }; j < num_dim; ++j)
                        norm_point[j] = point[j] / norm;
                }
                result_[i] = std::move(norm_point);
            }
            done_ = true;
        }
    }
    template<typename H>
    inline void
    flat_vector_(const H &column_begin, const H &column_end)  {

        if constexpr (container<T>)  {
            using data_t = typename T::value_type;

            const size_type col_s {
                size_type(std::distance(column_begin, column_end))
            };
            const size_type num_dim { column_begin->size() };

            // Compute norm of all values combined
            //
            data_t total_norm { 0 };

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &point { *(column_begin + i) };

                for (const data_t val : point)
                    total_norm += val * val;
            }
            total_norm = std::sqrt(total_norm);

            // Normalize all values
            //
            result_.resize(col_s);
            if (total_norm != 0)  {
                for (size_type i { 0 }; i < col_s; ++i)  {
                    const auto  &point { *(column_begin + i) };
                    value_type  norm_point;

                    if constexpr (Resizable<value_type>)
                        norm_point.resize(num_dim, 0);
                    for (size_type j { 0 }; j < num_dim; ++j)
                        norm_point[j] = point[j] / total_norm;
                    result_[i] = std::move(norm_point);
                }
            }
            done_ = true;
        }
    }
    template<typename K, typename H>
    inline void
    min_max_(const K &idx_begin, const K &idx_end,
             const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        if constexpr (std::is_arithmetic_v<value_type>)  {
            MinVisitor<T, I>    minv;
            MaxVisitor<T, I>    maxv;

            minv.pre();
            maxv.pre();
            minv(idx_begin, idx_end, column_begin, column_end);
            maxv(idx_begin, idx_end, column_begin, column_end);
            minv.post();
            maxv.post();

            const value_type    diff { maxv.get_result() - minv.get_result() };

            result_.resize(col_s);
            if (col_s >= ThreadPool::MUL_THR_THHOLD &&
                ThreadGranularity::get_thread_level() > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [minv = minv.get_result(), &column_begin, diff, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)
                                this->result_[i] =
                                    (*(column_begin + i) - minv) / diff;
                        })
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                std::transform(column_begin, column_end,
                               result_.begin(),
                               [minv = minv.get_result(), diff]
                               (const auto &val) -> value_type  {
                                   return ((val - minv) / diff);
                               });
            }
            done_ = true;
        }
        else if constexpr (container<T>)  {
            using data_t = typename T::value_type;

            const size_type     num_dim { column_begin->size() };
            std::vector<data_t> min_vals(
                num_dim, std::numeric_limits<data_t>::max());
            std::vector<data_t> max_vals(
                num_dim, std::numeric_limits<data_t>::lowest());

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &point { *(column_begin + i) };

                for (size_type j { 0 }; j < num_dim; ++j)  {
                    min_vals[j] = std::min(min_vals[j], point[j]);
                    max_vals[j] = std::max(max_vals[j], point[j]);
                }
            }

            // Normalize
            //
            result_.resize(col_s);
            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &point { *(column_begin + i) };
                value_type  norm_point;

                if constexpr (Resizable<value_type>)
                    norm_point.resize(num_dim, 0);
                for (size_type j { 0 }; j < num_dim; ++j)  {
                    const data_t    range { max_vals[j] - min_vals[j] };

                    if (range != 0) [[likely]]
                        norm_point[j] = (point[j] - min_vals[j]) / range;
                }
                result_[i] = std::move(norm_point);
            }
            done_ = true;
        }
    }
    template<typename K, typename H>
    inline void
    simple_(const K &idx_begin, const K &idx_end,
            const H &column_begin, const H &column_end)  {

        SumVisitor<T, I>    sumv;

        sumv.pre();
        sumv(idx_begin, idx_end, column_begin, column_end);
        sumv.post();

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        result_.resize(col_s);
        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [sumv = sumv.get_result(), &column_begin, this]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i)
                            this->result_[i] = *(column_begin + i) / sumv;
                    })
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column_begin, column_end,
                           result_.begin(),
                           [sumv = sumv.get_result()]
                           (const auto &val) -> value_type  {
                               return (val / sumv);
                           });
        }
        done_ = true;
    }
    template<typename K, typename H>
    inline void
    euclidean_(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        QuadraticMeanVisitor<T, I>  eucliv;

        eucliv.pre();
        eucliv(idx_begin, idx_end, column_begin, column_end);
        eucliv.post();

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        result_.resize(col_s);
        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [eucli = eucliv.get_euclidean_norm(), &column_begin, this]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i)
                            this->result_[i] = *(column_begin + i) / eucli;
                    })
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column_begin, column_end,
                           result_.begin(),
                           [eucli = eucliv.get_euclidean_norm()]
                           (const auto &val) -> value_type  {
                               return (val / eucli);
                           });
        }
        done_ = true;
    }
    template<typename K, typename H>
    inline void
    maxi_(const K &idx_begin, const K &idx_end,
          const H &column_begin, const H &column_end)  {

        MaxVisitor<T, I>    maxv;

        maxv.pre();
        maxv(idx_begin, idx_end, column_begin, column_end);
        maxv.post();

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        result_.resize(col_s);
        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [maxv = maxv.get_result(), &column_begin, this]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i)
                            this->result_[i] = *(column_begin + i) / maxv;
                    })
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column_begin, column_end,
                           result_.begin(),
                           [maxv = maxv.get_result()]
                           (const auto &val) -> value_type  {
                               return (val / maxv);
                           });
        }
        done_ = true;
    }
    template<typename K, typename H>
    inline void
    z_score_(const K &idx_begin, const K &idx_end,
             const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        if constexpr (std::is_arithmetic_v<value_type>)  {
            StdVisitor<T, I>    stdv;

            stdv.pre();
            stdv(idx_begin, idx_end, column_begin, column_end);
            stdv.post();

            result_.resize(col_s);
            if (col_s >= ThreadPool::MUL_THR_THHOLD &&
                ThreadGranularity::get_thread_level() > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [meanv = stdv.get_mean(), stdv = stdv.get_result(),
                         &column_begin, this]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)
                                this->result_[i] =
                                    (*(column_begin + i) - meanv) / stdv;
                        })
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                std::transform(column_begin, column_end,
                           result_.begin(),
                               [meanv = stdv.get_mean(),
                                stdv = stdv.get_result()]
                               (const auto &val) -> value_type  {
                                   return ((val - meanv) / stdv);
                               });
            }
            done_ = true;
        }
        else if constexpr (container<T>)  {
            using data_t = typename T::value_type;

            const size_type num_dim { column_begin->size() };

            // Compute mean for each dimension
            //
            std::vector<data_t> means(num_dim, 0);

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &point { *(column_begin + i) };

                for (size_type j { 0 }; j < num_dim; ++j)
                    means[j] += point[j];
            }
            for (data_t &mean : means)
                mean /= data_t(col_s);

            // Compute standard deviation for each dimension
            //
            std::vector<data_t> std_devs(num_dim, 0);

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &point { *(column_begin + i) };

                for (size_type j { 0 }; j < num_dim; ++j)  {
                    const data_t    diff { point[j] - means[j] };

                    std_devs[j] += diff * diff;
                }
            }
            for (data_t &std_dev : std_devs)
                std_dev = std::sqrt(std_dev / data_t(col_s));

            // Normalize
            //
            result_.resize(col_s);
            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &point { *(column_begin + i) };
                value_type  norm_point;

                if constexpr (Resizable<value_type>)
                    norm_point.resize(num_dim, 0);
                for (size_type j { 0 }; j < num_dim; ++j)  {
                    if (std_devs[j] != 0)
                        norm_point[j] = (point[j] - means[j]) / std_devs[j];
                }
                result_[i] = std::move(norm_point);
            }
            done_ = true;
        }
    }
    template<typename K, typename H>
    inline void
    decimal_scaling_(const K &/*idx_begin*/, const K &/*idx_end*/,
                     const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        // Decimal scaling's own definition uses the maximum absolute
        // value, not the signed maximum.
        //
        value_type    max_abs { std::abs(*column_begin) };

        for (size_type i { 1 }; i < col_s; ++i)  {
            const auto  val { std::abs(*(column_begin + i)) };

            if (val > max_abs)  max_abs = val;
        }

        // Without floor(), 10^(log10(max)+1) simplifies algebraically to
        // just max*10 for any max -- confirmed numerically (the ratio is
        // exactly 10 regardless of digit count) and against the standard
        // definition from multiple independent sources, e.g. a max of 986
        // (3 digits) should scale by 10^3=1000, not 986*10=9860.
        //
        const value_type    scale {
            value_type(std::pow(10, std::floor(std::log10(max_abs)) + 1))
        };

        result_.resize(col_s);
        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [scale, &column_begin, this]
                    (auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i)
                            this->result_[i] = *(column_begin + i) / scale;
                    })
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column_begin, column_end,
                           result_.begin(),
                           [scale](const auto &val) -> value_type  {
                               return (val / scale);
                           });
        }
        done_ = true;
    }
    template<typename H>
    inline void
    log_transform_(const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        result_.resize(col_s);
        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&column_begin, this](auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i)
                            this->result_[i] = std::log(*(column_begin + i));
                    })
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column_begin, column_end,
                           result_.begin(),
                           [](const auto &val) -> value_type  {
                               return (std::log(val));
                           });
        }
        done_ = true;
    }
    template<typename H>
    inline void
    root_transform_(const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        result_.resize(col_s);
        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&column_begin, this](auto begin, auto end) -> void  {
                        for (size_type i { begin }; i < end; ++i)
                            this->result_[i] = std::sqrt(*(column_begin + i));
                    })
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            std::transform(column_begin, column_end,
                           result_.begin(),
                           [](const auto &val) -> value_type  {
                               return (std::sqrt(val));
                           });
        }
        done_ = true;
    }

    result_type                 result_ {  };  // Normalized
    const normalization_type    type_;
    bool                        done_ { false };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using norm_v = NormalizeVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  StandardizeVisitor  {

private:

    using data_t = typename std::conditional_t<std::is_arithmetic_v<T>,
                                               lazy_type<T>,
                                               value_type_of<T>>::type;

    template<typename U>
    using vec_type = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<
            std::is_arithmetic_v<T>,
            vec_type<data_t>,
            Matrix<data_t, matrix_orient::column_major>>;

    template<typename K, typename H>
    inline void
    operator() (const K &idx_begin, const K &idx_end,
                const H &column_begin, const H &column_end)  {

        StdVisitor<T, I>    sv;

        sv.pre();
        sv(idx_begin, idx_end, column_begin, column_end);
        sv.post();

        const size_type col_s = std::distance(column_begin, column_end);
        auto            lbd =
            [&mv = std::as_const(sv.get_mean()),
             &sv = std::as_const(sv.get_result()),
             &column_begin = std::as_const(column_begin), this]
            (auto begin, auto end) -> void  {
                for (size_type i = begin; i < end; ++i)
                    if constexpr (std::is_arithmetic_v<T>)  {
                        result_[i] = (*(column_begin + i) - mv) / sv;
                    }
                    else  {
                        const auto  &val { (*(column_begin + i) - mv) / sv };

                        result_.set_row(val.begin(), long(i));
                    }
            };

        if constexpr (std::is_arithmetic_v<value_type>)  {
            result_.resize(col_s);
        }
        else  {
            const size_type dim = column_begin->size();

#ifdef HMDF_SANITY_EXCEPTIONS
            for (size_type i { 0 }; i < col_s; ++i)
                if ((column_begin + i)->size() != dim)
                    throw DataFrameError(
                        "StandardizeVisitor: Inconsistent data dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

            result_.resize(long(col_s), long(dim));
        }

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    lbd);

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(size_type(0), col_s);
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

private:

    result_type result_ {  }; // Standardized
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using stand_v = StandardizeVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  PolyFitVisitor  {

private:

    // True when T is a container (multidimensional x input)
    //
    static constexpr bool   is_md_ = random_acc_cont<T>;

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using anal_res_t =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    using matrix_t = Matrix<data_t, matrix_orient::row_major>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = long;
    using result_type = vec_t<data_t>;
    using weight_func =
        std::function<data_t(const index_type &idx, size_type val_index)>;

    template<typename K, typename Hx, typename Hy>
    inline void
    operator()(const K &idx_begin, const K &,
               const Hx &x_begin, const Hx &x_end,
               const Hy &y_begin, const Hy &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };
        const auto      thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)))
            throw DataFrameError("PolyFitVisitor: two columns must be of "
                                 "equal sizes");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (is_md_)  {  // Multidimensional input
            // Multivariate polynomial least-squares fit.
            //
            // For dim dimensions and polynomial degree d, the basis consists
            // of all monomials of total degree <= d:
            //   { x[0]^e0 * x[1]^e1 * ... : e0 + e1 + ... <= d }
            //
            // The number of basis terms is C(dim+d, d).
            //
            // We form the normal equations directly:
            //   (Phi^T * W^2 * Phi) * c = Phi^T * W^2 * y
            //
            // where Phi[i][k] is the k-th monomial evaluated at x[i], and W
            // is the diagonal weight matrix.  The system is then handed off to
            // matrix_t::solve() which avoids duplicating elimination logic.

            const size_type dim { size_type(x_begin->size()) };
            const std::vector<std::vector<size_type>>   monomials {
                md_monomials_(dim, degree_)
            };
            const size_type n_terms { size_type(monomials.size()) };

            // Normal matrix (Phi^T * W^2 * Phi) and RHS (Phi^T * W^2 * y),
            // kept separate to match matrix_t::solve(rhs) signature.
            //
            matrix_t            normal { n_terms, n_terms, data_t(0) };
            std::vector<data_t> rhs (n_terms, data_t(0));

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto      &xi { *(x_begin + i) };
                const data_t    yi { data_t(*(y_begin + i)) };
                const data_t    wi { weights_(*(idx_begin + i), i) };
                const data_t    wi2 { wi * wi };

                // Evaluate all basis monomials at xi once and cache them
                //
                std::vector<data_t> phi(n_terms);

                for (size_type k { 0 }; k < n_terms; ++k)
                    phi[k] = eval_monomial_(xi, monomials[k]);

                // Accumulate outer product into normal matrix and dot into RHS
                //
                for (size_type r { 0 }; r < n_terms; ++r)  {
                    for (size_type c { 0 }; c < n_terms; ++c)
                        normal(r, c) += phi[r] * phi[c] * wi2;
                    rhs[r] += phi[r] * yi * wi2;
                }
            }

            /* solve() throws "matrix is singular" for our test example
            // Solve the normal equations: normal * coeffs = rhs
            //
            const auto  sol { normal.solve(rhs) };

            // sol is a single-column matrix; unpack into coeffs_
            //
            coeffs_.resize(n_terms);
            for (size_type k { 0 }; k < n_terms; ++k)
                coeffs_[k] = sol(k, 0);
            */

            matrix_t    U, S, V;

            normal.svd(U, S, V, false);

            // Compute pseudoinverse: for each singular value, use 1/s if above
            // threshold, 0 otherwise (handles rank-deficiency gracefully)
            //
            const data_t    threshold {
                S(0, 0) * n_terms * std::numeric_limits<data_t>::epsilon()
            };
            matrix_t        s_pinv { n_terms, n_terms, 0 };

            for (size_type k { 0 }; k < n_terms; ++k)  {
                const auto  s_val { S(k, 0) };

                if (std::fabs(s_val) > threshold)
                    s_pinv(k, k) = data_t(1) / s_val;
            }

            matrix_t    rhs_mat { n_terms, 1, 0 };

            rhs_mat.set_column(rhs.begin(), 0);

            // c = V * S⁺ * Ut * rhs
            //
            const auto  sol { V * s_pinv * U.transpose() * rhs_mat };

            coeffs_.resize(n_terms);
            for (size_type k { 0 }; k < n_terms; ++k)
                coeffs_[k] = sol(k, 0);

            // Evaluate fitted values and accumulate residual
            //
            y_fits_.resize(col_s, 0);
            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  &xi  { *(x_begin + i) };
                data_t      pred { 0 };

                for (size_type k { 0 }; k < n_terms; ++k)
                    pred += coeffs_[k] * eval_monomial_(xi, monomials[k]);
                y_fits_[i] = pred;

                const data_t    w   { weights_(*(idx_begin + i), i) };
                const data_t    val { (data_t(*(y_begin + i)) - pred) * w };

                residual_ += val * val;
            }
        }
        else  {  // Scalar input
            // Degree needs to change to contain the slope (0-degree)
            //
            size_type       deg { degree_ };
            const size_type nrows { deg + 1 };  // number of coefficients

            // Array that will store the values of
            // sigma(xi), sigma(xi^2), sigma(xi^3) ... sigma(xi^2n)
            //
            vec_t<data_t>   sigma_x(2 * nrows, data_t(0));
            auto            x_lbd =
                [&x_begin, &idx_begin, this]
                (auto begin, auto end, auto i) -> data_t  {
                    data_t  sum { 0 };

                    for (auto j { begin }; j < end; ++j)  {
                        const data_t    w { weights_(*(idx_begin + j), j) };

                        sum += _bc_pow_(*(x_begin + j), data_t(i)) * w;
                    }
                    return (sum);
               };

            for (size_type i { 0 }; i < size_type(sigma_x.size()); ++i)  {
                if (thread_level > 2)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                            size_type(0),
                            col_s,
                            std::move(x_lbd),
                            i);

                    for (auto &fut : futures)  sigma_x[i] += fut.get();
                }
                else  {
                    sigma_x[i] += x_lbd(size_type(0), col_s, i);
                }
            }

            // eq_mat is the Normal matrix (augmented) that will store the
            // equations. The extra column is the y column.
            //
            matrix_t    eq_mat { nrows, deg + 2, data_t(0) };

            for (size_type i { 0 }; i <= deg; ++i)
                for (size_type j { 0 }; j <= deg; ++j)
                    eq_mat(i, j) = sigma_x[i + j];

            // Array to store the values of
            // sigma(yi), sigma(xi*yi), sigma(xi^2*yi) ... sigma(xi^n*yi)
            //
            vec_t<data_t>   sigma_y(nrows, data_t(0));
            auto            y_lbd =
                [&x_begin, &y_begin, &idx_begin, this]
                (auto begin, auto end, auto i) -> data_t  {
                    data_t  sum { 0 };

                    for (auto j { begin }; j < end; ++j)  {
                        const data_t    w { weights_(*(idx_begin + j), j) };

                        sum += _bc_pow_(*(x_begin + j), data_t(i)) *
                               data_t(*(y_begin + j)) * w;
                    }
                    return (sum);
               };

            for (size_type i { 0 }; i < size_type(sigma_y.size()); ++i)  {
                if (thread_level > 2)  {
                    auto    futures =
                        ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                            size_type(0),
                            col_s,
                            std::move(y_lbd),
                            i);

                    for (auto &fut : futures)  sigma_y[i] += fut.get();
                }
                else  {
                    sigma_y[i] += y_lbd(size_type(0), col_s, i);
                }
            }

            // Load the values of sigma_y as the last column of eq_mat
            // (Normal Matrix but augmented)
            //
            for (size_type i { 0 }; i <= deg; ++i)
                eq_mat(i, nrows) = sigma_y[i];

            // deg is made deg + 1 because the Gaussian elimination part
            // below was for deg equations, but here deg is the deg of
            // polynomial and for deg we get deg + 1 equations
            //
            deg += 1;

            // From now Gaussian elimination starts (can be ignored) to solve
            // the set of linear equations (Pivotisation)
            //
            for (size_type i { 0 }; i < deg; ++i)  {
                for (size_type k { i + 1 }; k < deg; ++k)
                    if (eq_mat(i, i) < eq_mat(k, i))
                        for (size_type j { 0 }; j <= deg; ++j)
                            std::swap(eq_mat(i, j), eq_mat(k, j));
            }

            // Loop to perform the Gauss elimination
            //
            for (size_type i { 0 }; i < deg - 1; ++i)  {
                for (size_type k { i + 1 }; k < deg; ++k)  {
                    const data_t    t { eq_mat(k, i) / eq_mat(i, i) };

                    // Make the elements below the pivot elements equal to zero
                    // or elimnate the variables
                    //
                    for (size_type j { 0 }; j <= deg; ++j)
                        eq_mat(k, j) = eq_mat(k, j) - eq_mat(i, j) * t;
                }
            }

            // Back-substitution
            // coeffs_ is a vector whose values correspond to the values
            // of x, y, z ...
            //
            coeffs_.resize(deg, data_t(0));
            for (size_type i { deg - 1 }; i >= 0; --i)  {
                // Make the variable to be calculated equal to the rhs of the
                // last equation
                //
                coeffs_[i] = eq_mat(i, deg);
                for (size_type j { 0 }; j < deg; ++j)  {
                    // Then subtract all the lhs values except the coefficient
                    // of the variable whose value is being calculated
                    //
                    if (j != i)
                        coeffs_[i] =
                            coeffs_[i] - eq_mat(i, j) * coeffs_[j];
                }

                // Now finally divide the rhs by the coefficient of the
                // variable to be calculated
                //
                coeffs_[i] = coeffs_[i] / eq_mat(i, i);
            }

            y_fits_.resize(col_s, data_t(0));
            for (size_type i { 0 }; i < col_s; ++i)  {
                data_t  pred { 0 };

                for (size_type j { 0 }; j < deg; ++j)
                    pred += coeffs_[j] *
                            _bc_pow_(*(x_begin + i), data_t(j));
                y_fits_[i] = pred;

                const auto  w { weights_(*(idx_begin + i), i) };

                // y fits at given x points
                //
                const auto  val { (*(y_begin + i) - pred) * w };

                residual_ += val * val;
            }
        }
    }

    inline void pre()  { coeffs_.clear(); y_fits_.clear(); residual_ = 0; }
    inline void post()  {  }

    inline const result_type &get_result() const  { return (coeffs_); }
    inline result_type &get_result()  { return (coeffs_); }
    inline data_t get_slope() const  {

        return (coeffs_.size() > 1 ? coeffs_[1] : data_t(0));
    }
    inline data_t get_residual() const  { return (residual_); }
    inline const result_type &get_y_fits() const  { return (y_fits_); }
    inline result_type &get_y_fits()  { return (y_fits_); }

    explicit
    PolyFitVisitor(size_type d,
                   weight_func w_func =
                       [](const I &, std::size_t) -> data_t  { return (1); })
        : degree_(d), weights_(w_func)  {   }

private:

    // Generate all monomials of total degree <= max_degree over 'dim
    // variables. Each monomial is a vector of per-dimension exponents.
    //
    // For dim=2, max_degree=2 the result is (in total-degree order):
    //   {0,0}, {1,0}, {0,1}, {2,0}, {1,1}, {0,2}
    // giving 6 basis terms = C(dim+degree, degree) = C(4,2) = 6.
    //
    static inline std::vector<std::vector<size_type>>
    md_monomials_(size_type dim, size_type max_degree) noexcept  {

        std::vector<std::vector<size_type>>  result;
        std::vector<size_type>               current;

        std::function<void(size_type, size_type, std::vector<size_type> &)>
            gen =
            [&]
            (size_type d, size_type rem,
             std::vector<size_type> &current) -> void  {
                if (d == dim)  {
                    result.push_back(current);
                    return;
                }
                for (size_type e { rem }; e >= 0; --e)  {
                    current.push_back(e);
                    gen(d + 1, rem - e, current);
                    current.pop_back();
                }
            };

        gen(0, max_degree, current);
        std::sort(result.begin(), result.end(),
            [](const std::vector<size_type> &a,
               const std::vector<size_type> &b)  {
                const size_type sum_a {
                    std::accumulate(a.begin(), a.end(), 0)
                };
                const size_type sum_b {
                    std::accumulate(b.begin(), b.end(), 0)
                };

                if (sum_a != sum_b)  return (sum_a < sum_b);
                return (a < b);  // lexicographic within same total degree
            });
        return (result);
    }

    // Evaluate a single monomial (product of x[d]^exp[d] for all d) at
    // point x.
    //
    template<typename Vec>
    static inline typename Vec::value_type
    eval_monomial_(const Vec &x,
                   const std::vector<size_type> &exponents) noexcept  {

        using data_t = typename Vec::value_type;

        data_t  val { 1 };

        for (std::size_t d { 0 }; d < exponents.size(); ++d)
            val *= std::pow(x[d], data_t(exponents[d]));
        return (val);
    }

    result_type     y_fits_ {  };
    result_type     coeffs_ {  };
    data_t          residual_ { 0 };
    const size_type degree_;
    weight_func     weights_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using pfit_v = PolyFitVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  LogFitVisitor  {

private:

    // True when T is a container (multidimensional x input)
    //
    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using anal_res_t =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = long;
    using result_type = vec_t<data_t>;
    using weight_func =
        std::function<data_t(const index_type &idx, size_type val_index)>;

    template<typename K, typename Hx, typename Hy>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const Hx &x_begin, const Hx &x_end,
               const Hy &y_begin, const Hy &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };
        const auto      thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

        vec_t<anal_res_t>   logx(col_s);
        auto                log_lbd =
            [&logx, &x_begin](auto begin, auto end) -> void  {
                for (auto i { begin }; i < end; ++i)
                    logx[i] = _bc_log_(*(x_begin + i));
            };

        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    std::move(log_lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            log_lbd(size_type(0), col_s);
        }

        poly_fit_(idx_begin, idx_end,
                  logx.begin(), logx.end(),
                  y_begin, y_end);

        y_fits_.resize(col_s);
        if constexpr (is_md_)  {
            // PolyFitVisitor already computed the correct residual and y_fits
            // in log-x space for the multidimensional case. Just copy them.
            //
            residual_ = poly_fit_.get_residual();

            const auto  &pf_fits { poly_fit_.get_y_fits() };

            for (size_type i { 0 }; i < col_s; ++i)
                y_fits_[i] = pf_fits[i];
        }
        else  {
            // Scalar path: reconstruct prediction from slope/intercept
            // as before
            //
            const auto  &poly_res { poly_fit_.get_result() };
            auto        res_lbd =
                [&x_begin, &y_begin, &idx_begin,
                 &poly_res = std::as_const(poly_res), this]
                (auto begin, auto end) -> data_t  {
                    data_t  residual { 0 };

                    for (auto i { begin }; i < end; ++i)  {
                        const auto  pred  {
                            _bc_log_(*(x_begin + i)) * poly_res[1] + poly_res[0]
                        };

                        y_fits_[i] = pred;

                        const auto  w { weights_(*(idx_begin + i), i) };
                        const auto  val { (*(y_begin + i) - pred) * w };

                        residual += val * val;
                    }
                    return (residual);
                };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0), col_s, std::move(res_lbd))
                };

                for (auto &fut : futures)  residual_ += fut.get();
            }
            else  {
                residual_ = res_lbd(size_type(0), col_s);
            }
        }
    }

    inline void pre()  { poly_fit_.pre(); y_fits_.clear(); residual_ = 0; }
    inline void post()  { poly_fit_.post(); }
    inline const result_type &
    get_result() const  { return (poly_fit_.get_result()); }
    inline result_type &get_result()  { return (poly_fit_.get_result()); }
    inline data_t get_slope() const  { return (poly_fit_.get_slope()); }
    inline data_t get_residual() const  { return (residual_); }
    inline const result_type &get_y_fits() const  { return (y_fits_); }
    inline result_type &get_y_fits()  { return (y_fits_); }

    explicit
    LogFitVisitor(weight_func w_func =
                      [](const I &, std::size_t) -> data_t  { return (1); },
                  size_type deg = 1)
        : poly_fit_(deg, w_func), weights_(w_func)  {   }

private:

    result_type             y_fits_ {  };
    PolyFitVisitor<T, I, A> poly_fit_ {  };
    weight_func             weights_;
    data_t                  residual_ { 0 };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using lfit_v = LogFitVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  ExponentialFitVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template<typename K, typename H>
    inline void
    operator()(const K &, const K &,
               const H &x_begin, const H &x_end,
               const H &y_begin, const H &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };
        const auto      thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)))
            throw DataFrameError("ExponentialFitVisitor: two columns must be "
                                 "of equal sizes");
#endif // HMDF_SANITY_EXCEPTIONS

        value_type  sum_x { 0 };   // Sum of all observed x
        value_type  sum_y { 0 };   // Sum of all observed y
        value_type  sum_x2 { 0 };  // Sum of all observed x squared
        value_type  sum_xy { 0 };  // Sum of all x times sum of all observed y

        if (thread_level > 2)  {
            using sum_t =
                std::tuple<value_type, value_type, value_type, value_type>;

            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&x_begin, &y_begin](auto begin, auto end) -> sum_t  {
                        value_type  sum_x { 0 };
                        value_type  sum_y { 0 };
                        value_type  sum_x2 { 0 };
                        value_type  sum_xy { 0 };

                        for (auto i { begin }; i < end; ++i)  {
                            const value_type    x { *(x_begin + i) };
                            const value_type    log_y {
                                std::log(*(y_begin + i))
                            };

                            sum_x += x;
                            sum_y += log_y;
                            sum_xy += x * log_y;
                            sum_x2 += x * x;
                        }
                        return (std::make_tuple(sum_x, sum_y, sum_xy, sum_x2));
                    })
            };

            for (auto &fut : futures)  {
                const auto  &sums { fut.get() };

                sum_x += std::get<0>(sums);
                sum_y += std::get<1>(sums);
                sum_xy += std::get<2>(sums);
                sum_x2 += std::get<3>(sums);
            }
        }
        else  {
            for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
                const value_type    x { *(x_begin + i) };
                const value_type    log_y { std::log(*(y_begin + i)) };

                sum_x += x;
                sum_y += log_y;
                sum_xy += x * log_y;
                sum_x2 += x * x;
            }
        }

        // The slope (the the power of exp) of best fit line
        //
        slope_ = (col_s * sum_xy - sum_x * sum_y) /
                 (col_s * sum_x2 - sum_x * sum_x);

        // The intercept of best fit line
        //
        intercept_ = (sum_y - slope_ * sum_x) / col_s;

        const value_type    prefactor { std::exp(intercept_) };

        y_fits_.resize(col_s);
        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&x_begin, &y_begin, prefactor, this]
                    (auto begin, auto end) -> value_type  {
                        value_type  residual { 0 };

                        for (auto i { begin }; i < end; ++i)  {
                            const value_type    x { *(x_begin + i) };
                            const value_type    pred {
                                prefactor * std::exp(x * slope_)
                            };

                            // y fits at given x points
                            //
                            y_fits_[i] = pred;

                            const value_type    r { *(y_begin + i) - pred };

                            residual += r * r;
                        }
                        return (residual);
                   })
            };

            for (auto &fut : futures)  residual_ += fut.get();
        }
        else  {
            for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
                const value_type    x { *(x_begin + i) };
                const value_type    pred { prefactor * std::exp(x * slope_) };

                // y fits at given x points
                //
                y_fits_[i] = pred;

                const value_type    r { *(y_begin + i) - pred };

                residual_ += r * r;
            }
        }
    }

    inline void pre()  {

        y_fits_.clear();
        residual_ = 0;
        slope_ = 0;
        intercept_ = 0;
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (y_fits_); }
    inline result_type &get_result()  { return (y_fits_); }
    inline value_type get_residual() const  { return (residual_); }
    inline value_type get_slope() const  { return (slope_); }
    inline value_type get_intercept() const  { return (intercept_); }

    ExponentialFitVisitor()  {   }

private:

    result_type y_fits_ {  };
    value_type  residual_ { 0 };
    value_type  slope_ { 0 };
    value_type  intercept_ { 0 };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using efit_v = ExponentialFitVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  PowerFitVisitor  {

private:

    // True when T is a container (multidimensional x input)
    //
    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using anal_res_t =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    using matrix_t = Matrix<data_t, matrix_orient::row_major>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = vec_t<data_t>;

    template<typename K, typename H1, typename H2>
    inline void
    operator()(const K &, const K &,
               const H1 &x_begin, const H1 &x_end,
               const H2 &y_begin, const H2 &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };
        const auto      thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)))
            throw DataFrameError("PowerFitVisitor: X and Y columns must be "
                                 "of equal sizes");
        if constexpr (is_md_)  {
            const size_type dim { x_begin->size() };

            for (size_type i { 1 }; i < col_s; ++i)
                if ((x_begin + i)->size() != dim)
                    throw DataFrameError(
                        "PowerFitVisitor: Inconsistent data dimensions");
        }
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (! is_md_)  {
            using sum_t = std::tuple<data_t, data_t, data_t, data_t>;

            data_t  sum_x { };   // Sum of all observed x
            data_t  sum_y { 0 }; // Sum of all observed y
            data_t  sum_x2 { };  // Sum of all observed x squared
            data_t  sum_xy { };  // Sum of all x times sum of all observed y

            if constexpr (is_md_)  {
                const auto  dim { x_begin->size() };

                sum_x.resize(dim, 0);
                sum_x2.resize(dim, 0);
                sum_xy.resize(dim, 0);
            }
            else  {
                sum_x = 0;
                sum_x2 = 0;
                sum_xy = 0;
            }
            auto    lbd_1 =
                [&x_begin, &y_begin](auto begin, auto end) -> sum_t  {
                    data_t  sum_x { };
                    data_t  sum_y { 0 };
                    data_t  sum_x2 { };
                    data_t  sum_xy { };

                    if constexpr (is_md_)  {
                        const auto  dim { x_begin->size() };

                        sum_x.resize(dim, 0);
                        sum_x2.resize(dim, 0);
                        sum_xy.resize(dim, 0);
                    }
                    else  {
                        sum_x = 0;
                        sum_x2 = 0;
                        sum_xy = 0;
                    }
                    for (auto i { begin }; i < end; ++i)  {
                        const data_t    log_x { _bc_log_(*(x_begin + i)) };
                        const data_t    log_y {_bc_log_(*(y_begin + i)) };

                        sum_x += log_x;
                        sum_y += log_y;
                        sum_xy += log_x * log_y;
                        sum_x2 += log_x * log_x;
                    }
                    return (std::make_tuple(sum_x, sum_y, sum_xy, sum_x2));
                };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd_1))
                };

                for (auto &fut : futures)  {
                    const auto  &sums { fut.get() };

                    sum_x += std::get<0>(sums);
                    sum_y += std::get<1>(sums);
                    sum_xy += std::get<2>(sums);
                    sum_x2 += std::get<3>(sums);
                }
            }
            else  {
                const auto  &sums { lbd_1(size_type(0), col_s) };

                sum_x += std::get<0>(sums);
                sum_y += std::get<1>(sums);
                sum_xy += std::get<2>(sums);
                sum_x2 += std::get<3>(sums);
            }

            // The slope (the the power of exp) of best fit line
            //
            slope_ = (data_t(col_s) * sum_xy - sum_x * sum_y) /
                     (data_t(col_s) * sum_x2 - sum_x * sum_x);

            // The intercept of best fit line
            //
            intercept_ = (sum_y - slope_ * sum_x) / data_t(col_s);
        }
        else  {  // Multidimensional path
            const size_type dim { static_cast<size_type>(x_begin->size()) };
            const size_type mat_s { dim + 1 };

            // XtX is (dim+1 x dim+1), Xty is (dim+1)
            // Row/col 0 is the intercept (constant 1) term
            //
            matrix_t        XtX { long(mat_s), long(mat_s), 0 };
            vec_t<data_t>   Xty(mat_s, 0);

            // Accumulate XtX and Xty in log-space
            // X row = [1, ln(x_0), ln(x_1), ..., ln(x_{dim-1})]
            //
            for (auto i { size_type(0) }; i < col_s; ++i)  {
                const auto      &xi { *(x_begin + i) };
                const auto      log_y { _bc_log_(*(y_begin + i)) };

                // Build log_row = [1, ln(x_0), ..., ln(x_{dim-1})]
                //
                vec_t<data_t>   log_row(mat_s);

                log_row[0] = 1;
                for (size_type j { 0 }; j < dim; ++j)
                    log_row[j + 1] = std::log(xi[j]);

                // XtX += log_row * log_rowᵀ
                //
                for (long r { 0 }; r < long(mat_s); ++r)
                    for (long c { 0 }; c < long(mat_s); ++c)
                        XtX(r, c) += log_row[r] * log_row[c];

                // Xty += log_row * log_y
                //
                for (size_type r { 0 }; r < mat_s; ++r)
                    Xty[r] += log_row[r] * log_y;
            }

            // Solve (XtX) * beta = Xty
            // beta = [ln(a), b_0, b_1, ..., b_{dim-1}]
            //
            const matrix_t  beta { XtX.solve(Xty) };

            intercept_ = beta(0, 0);   // ln(a)
            slope_.resize(dim);
            for (size_type j { 0 }; j < dim; ++j)
                slope_[j] = beta(j + 1, 0);
        }

        const data_t    prefactor { _bc_exp_(intercept_) };
        auto            lbd_2 =
            [&x_begin, &y_begin, prefactor, this]
            (auto begin, auto end) -> data_t  {
                data_t  residual { 0 };

                for (auto i { begin }; i < end; ++i)  {
                    const auto    pred {
                        prefactor *
                        _reduce_to_product_(_bc_pow_(*(x_begin + i), slope_))
                    };

                    // y fits at given x points
                    //
                    y_fits_[i] = pred;

                    const auto  r { *(y_begin + i) - pred };

                    residual += r * r;
                }
                return (residual);
           };


        y_fits_.resize(col_s);
        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    std::move(lbd_2))
            };

             for (auto &fut : futures)  residual_ += fut.get();
        }
        else  {
            residual_ = lbd_2(size_type(0), col_s);
        }
    }

    inline void pre()  {

        y_fits_.clear();
        residual_ = 0;
        if constexpr (is_md_)
            slope_.clear();
        else
            slope_ = 0;
        intercept_ = 0;
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (y_fits_); }
    inline result_type &get_result()  { return (y_fits_); }
    inline data_t get_residual() const  { return (residual_); }
    inline const anal_res_t &get_slope() const  { return (slope_); }
    inline data_t get_intercept() const  { return (intercept_); }

    PowerFitVisitor()  {   }

private:

    result_type y_fits_ { };
    data_t      residual_ { 0 };
    anal_res_t  slope_ { };
    data_t      intercept_ { 0 };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using powfit_v = PowerFitVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  QuadraticFitVisitor  {

private:

    // True when T is a container (multidimensional x input)
    //
    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // Delegate for the MD path — degree fixed at 2, no weights
    //
    using poly_visitor_t = PolyFitVisitor<T, I, A>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type = vec_t<data_t>;

    template<typename K, typename Hx, typename Hy>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const Hx &x_begin, const Hx &x_end,
               const Hy &y_begin, const Hy &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)))
            throw DataFrameError("QuadraticFitVisitor: two columns must be "
                                 "of equal sizes");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (! is_md_)  {  // Scalar input
            const auto      thread_level {
                (col_s < ThreadPool::MUL_THR_THHOLD)
                    ? 0L : ThreadGranularity::get_thread_level()
            };

            using sum_t =
                std::tuple<value_type,  // sum_x
                           value_type,  // sum_y
                           value_type,  // sum_x2
                           value_type,  // sum_x3
                           value_type,  // sum_x4
                           value_type,  // sum_xy
                           value_type>; // sum_yx2

            value_type  sum_x { 0 };   // Sum of observed x
            value_type  sum_y { 0 };   // Sum of observed y
            value_type  sum_x2 { 0 };  // Sum of observed x squared
            value_type  sum_x3 { 0 };  // Sum of observed x cubed
            value_type  sum_x4 { 0 };  // Sum of bserved x quadrupled
            value_type  sum_xy { 0 };  // Sum of y times sum of x squared
            value_type  sum_yx2 { 0 }; // Sum of x times sum of observed y
            auto        lbd_1 =
                [&x_begin, &y_begin](auto begin, auto end) -> sum_t  {
                    value_type  sum_x { 0 };
                    value_type  sum_y { 0 };
                    value_type  sum_x2 { 0 };
                    value_type  sum_x3 { 0 };
                    value_type  sum_x4 { 0 };
                    value_type  sum_xy { 0 };
                    value_type  sum_yx2 { 0 };

                    for (auto i { begin }; i < end; ++i)  {
                        const value_type    x { *(x_begin + i) };
                        const value_type    y { *(y_begin + i) };

                        sum_x += x;
                        sum_y += y;
                        sum_x2 += x * x;
                        sum_x3 += x * x * x;
                        sum_x4 += x * x * x * x;
                        sum_xy += x * y;
                        sum_yx2 += y * x * x;
                    }
                    return (std::make_tuple(sum_x,
                                            sum_y,
                                            sum_x2,
                                            sum_x3,
                                            sum_x4,
                                            sum_xy,
                                            sum_yx2));
                };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd_1))
                };

                for (auto &fut : futures)  {
                    const auto  &sums { fut.get() };

                    sum_x += std::get<0>(sums);
                    sum_y += std::get<1>(sums);
                    sum_x2 += std::get<2>(sums);
                    sum_x3 += std::get<3>(sums);
                    sum_x4 += std::get<4>(sums);
                    sum_xy += std::get<5>(sums);
                    sum_yx2 += std::get<6>(sums);
                }
            }
            else  {
                const auto  &sums { lbd_1(size_type(0), col_s) };

                sum_x += std::get<0>(sums);
                sum_y += std::get<1>(sums);
                sum_x2 += std::get<2>(sums);
                sum_x3 += std::get<3>(sums);
                sum_x4 += std::get<4>(sums);
                sum_xy += std::get<5>(sums);
                sum_yx2 += std::get<6>(sums);
            }

            // Variables needed for calculation of coefficients
            //
            const value_type    c_xx { sum_x2 - sum_x * sum_x / col_s };
            const value_type    c_xy { sum_xy - sum_x * sum_y / col_s };
            const value_type    c_xx2 { sum_x3 - sum_x * sum_x2 / col_s };
            const value_type    c_x2y { sum_yx2 - sum_x2 * sum_y / col_s };
            const value_type    c_x2x2 { sum_x4 - sum_x2 * sum_x2 / col_s };

            // Best fit curve is given by yc = c + bx + ax²

            // The quadratic coefficient
            //
            slope_ = (c_x2y * c_xx - c_xy * c_xx2) /
                     (c_xx * c_x2x2 - c_xx2 * c_xx2);

            // The linear coefficient
            //
            intercept_ = (c_xy * c_x2x2 - c_x2y * c_xx2) /
                         (c_xx * c_x2x2 - c_xx2 * c_xx2);

            // Constant term
            //
            constant_ = (sum_y / data_t(col_s)) -
                        (intercept_ * sum_x / data_t(col_s)) -
                        (slope_ * sum_x2 / data_t(col_s));

            auto    lbd_2 =
                [&x_begin, &y_begin, this]
                (auto begin, auto end) -> value_type  {
                    value_type  residual { 0 };

                    for (auto i { begin }; i < end; ++i)  {
                        const value_type    x { *(x_begin + i) };
                        const value_type    pred {
                            constant_ + intercept_ * x + slope_ * x * x
                        };

                        // y fits at given x points
                        //
                        y_fits_[i] = pred;

                        const value_type    r { *(y_begin + i) - pred };

                        residual += r * r;
                    }
                    return (residual);
               };

            y_fits_.resize(col_s);
            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd_2))
                };

                 for (auto &fut : futures)  residual_ += fut.get();
            }
            else  {
                residual_ = lbd_2(size_type(0), col_s);
            }
        }
        else  {  // Multidimensional input
            // Multivariate path: delegate entirely to PolyFitVisitor(degree=2).
            //
            // PolyFitVisitor already handles:
            //   - monomial basis generation  C(dim+2, 2) terms
            //   - normal-equation assembly   (Phi^T * W^2 * Phi)
            //   - SVD-based solve            (rank-deficiency safe)
            //   - y_fits_ and residual_ accumulation
            //
            // We just forward all iterators unchanged and harvest its results.

            poly_visitor_.pre();
            poly_visitor_(idx_begin, idx_end, x_begin, x_end, y_begin, y_end);
            poly_visitor_.post();

            y_fits_ = std::move(poly_visitor_.get_y_fits());
            residual_ = poly_visitor_.get_residual();

            // coeffs_ mirrors PolyFitVisitor layout:
            //   [1, x0, x1, ..., x0^2, x0*x1, ..., x_{d-1}^2]
            //
            coeffs_ = std::move(poly_visitor_.get_result());
        }
    }

    inline void pre()  {

        y_fits_.clear();
        coeffs_.clear();
        residual_ = slope_ = intercept_ = constant_ = 0;
    }
    inline void post()  {  }

    inline const result_type &get_result() const { return (y_fits_); }
    inline result_type &get_result()  { return (y_fits_); }
    inline data_t get_residual() const { return (residual_); }

    // Scalar-path accessors — meaningful only when T is arithmetic.
    // MD callers should use get_coeffs() instead.
    //
    inline data_t get_slope() const  {
        static_assert(! is_md_,
            "get_slope() is not available for multidimensional input; "
            "use get_coeffs() to inspect the full quadratic coefficient "
            "vector");
        return (slope_);
    }
    inline data_t get_intercept() const  {
        static_assert(! is_md_,
            "get_intercept() is not available for multidimensional input; "
            "use get_coeffs() to inspect the full quadratic coefficient "
            "vector");
        return (intercept_);
    }
    inline data_t get_constant() const  {
        static_assert(! is_md_,
            "get_constant() is not available for multidimensional input; "
            "use get_coeffs() to inspect the full quadratic coefficient "
            "vector");
        return (constant_);
    }

    // MD-path accessor — coefficients in PolyFitVisitor monomial order:
    //   [1,  x0, x1, …,  x0², x0·x1, …,  x_{d-1}²]
    // Returns an empty vector for the scalar path (use get_slope etc.).
    //
    inline const result_type &get_coeffs() const  { return (coeffs_); }
    inline result_type  &get_coeffs()  { return (coeffs_); }

    QuadraticFitVisitor() = default;

private:

    result_type y_fits_ { };
    result_type coeffs_ { };       // populated on MD path only
    data_t      residual_ { 0 };
    data_t      slope_ { 0 };      // populated on scalar path only
    data_t      intercept_ { 0 };  // populated on scalar path only
    data_t      constant_ { 0 };   // populated on scalar path only

    // Reusable delegate for the MD path (degree fixed at 2)
    //
    poly_visitor_t  poly_visitor_ { 2 };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using qfit_v = QuadraticFitVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  LinearFitVisitor  {

private:

    // True when T is a container (multidimensional x input)
    //
    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using anal_res_t =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    using matrix_t = Matrix<data_t, matrix_orient::row_major>;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;

    // Slope_ is a vector of coefficients in the MD case,
    // a single-element pseudo-container in the scalar case
    //
    using slope_type  =
        typename std::conditional_t<! is_md_, data_t, vec_t<data_t>>;
    using result_type = vec_t<data_t>;

    template<typename K, typename H1, typename H2>
    inline void
    operator()(const K &, const K &,
               const H1 &x_begin, const H1 &x_end,
               const H2 &y_begin, const H2 &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)))
            throw DataFrameError("LinearFitVisitor: two columns must be "
                                 "of equal sizes");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (! is_md_)  {  // Scalar input
            const auto  thread_level {
                (col_s < ThreadPool::MUL_THR_THHOLD)
                    ? 0L : ThreadGranularity::get_thread_level()
            };

            using sum_t = std::tuple<data_t, data_t, data_t, data_t>;

            data_t  sum_x { 0 };   // Sum of observed x
            data_t  sum_y { 0 };   // Sum of observed y
            data_t  sum_x2 { 0 };  // Sum of observed x squared
            data_t  sum_xy { 0 };  // Sum of x times sum of observed y
            auto        lbd_1 =
                [&x_begin, &y_begin](auto begin, auto end) -> sum_t  {
                    data_t  sum_x { 0 };
                    data_t  sum_y { 0 };
                    data_t  sum_x2 { 0 };
                    data_t  sum_xy { 0 };

                    for (auto i { begin }; i < end; ++i)  {
                        const data_t    x { *(x_begin + i) };
                        const data_t    y { *(y_begin + i) };

                        sum_x += x;
                        sum_y += y;
                        sum_xy += x * y;
                        sum_x2 += x * x;
                    }
                    return (std::make_tuple(sum_x, sum_y, sum_xy, sum_x2));
                };

            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd_1))
                };

                for (auto &fut : futures)  {
                    const auto  &sums { fut.get() };

                    sum_x += std::get<0>(sums);
                    sum_y += std::get<1>(sums);
                    sum_xy += std::get<2>(sums);
                    sum_x2 += std::get<3>(sums);
                }
            }
            else  {
                const auto  &sums { lbd_1(size_type(0), col_s) };

                sum_x += std::get<0>(sums);
                sum_y += std::get<1>(sums);
                sum_xy += std::get<2>(sums);
                sum_x2 += std::get<3>(sums);
            }

            const data_t    divisor { sum_x2 * col_s - sum_x * sum_x };

            // The slope (the the power of exp) of best fit line
            //
            slope_ = (col_s * sum_xy - sum_x * sum_y) / divisor;

            // The intercept of best fit line
            //
            intercept_ = (sum_x2 * sum_y - sum_x * sum_xy) / divisor;

            auto    lbd_2 =
                [&x_begin, &y_begin, this]
                (auto begin, auto end) -> data_t  {
                    data_t  residual { 0 };

                    for (auto i { begin }; i < end; ++i)  {
                        const data_t    x { *(x_begin + i) };
                        const data_t    y { *(y_begin + i) };
                        const data_t    pred { slope_ * x + intercept_ };
                        const data_t    r { y - pred };

                        // y fits at given x points
                        //
                        y_fits_[i] = pred;
                        residual += r * r;
                    }
                    return (residual);
               };

            y_fits_.resize(col_s);
            if (thread_level > 2)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        std::move(lbd_2))
                };

                for (auto &fut : futures)  residual_ += fut.get();
            }
            else  {
                residual_ = lbd_2(size_type(0), col_s);
            }
        }
        else  {  // Multidimensional input
            if (do_solve_)
                do_md_by_solve_(x_begin, y_begin, col_s);
            else
                do_md_by_svd_(x_begin, y_begin, col_s);
        }
    }

    inline void pre()  {

        y_fits_.clear();
        residual_ = 0;
        intercept_ = 0;
        if constexpr (! is_md_)
            slope_ = data_t(0);
        else
            slope_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (y_fits_); }
    inline result_type &get_result()  { return (y_fits_); }
    inline data_t get_residual() const  { return (residual_); }
    inline const slope_type &get_slope() const  { return (slope_); }
    inline slope_type &get_slope()  { return (slope_); }
    inline data_t get_intercept() const  { return (intercept_); }

    explicit
    LinearFitVisitor(bool do_solve = true) : do_solve_(do_solve)  {   }

private:

    template<typename H1, typename H2>
    inline void
    do_md_by_svd_(const H1 &x_begin, const H2 &y_begin, size_type col_s)  {

        const size_type dim { x_begin->size() }; // # of features
        const size_type dim_p_one { dim + 1 };   // # coeff incl. intercept

        // Build design matrix X (col_s × dim_p_one) and response
        // y_mat (col_s × 1)
        //
        matrix_t    X { long(col_s), long(dim_p_one), 0 };
        matrix_t    y_mat { long(col_s), 1L, 0 };

        for (size_type i { 0 }; i < col_s; ++i)  {
            X(i, 0) = data_t(1);

            const auto  &xi { *(x_begin + i) };

            for (size_type j { 0 }; j < xi.size(); ++j)
                X(i, j + 1) = data_t(xi[j]);
            y_mat(i, 0) = data_t(*(y_begin + i));
        }

        // SVD decomposition: X = U * S * Vt
        // U is (col_s × col_s) or (col_s × dim_p_one) with full_size=false
        // S is (col_s × dim_p_one) diagonal
        // V is (dim_p_one × dim_p_one)
        //
        matrix_t    U, S, V;

        X.svd(U, S, V, false);

        // S is returned as a column vector (sv_count × 1), not a diagonal
        // matrix. U is (col_s × sv_count), V is (sv_count × sv_count)
        //
        const size_type sv_count { size_type(S.rows()) };
        data_t          max_sv { 0 };

        for (size_type i { 0 }; i < sv_count; ++i)
            if (S(i, 0) > max_sv)   max_sv = S(i, 0);

        const data_t    threshold {
            max_sv * data_t(std::max(col_s, dim_p_one)) *
            std::numeric_limits<data_t>::epsilon()
        };

        // Compute Σ + Ut y  (sv_count × 1)
        //
        matrix_t    splus_uty { long(sv_count), 1L, data_t(0) };

        for (size_type i { 0 }; i < sv_count; ++i)  {
            const data_t    sv { S(i, 0) };

            if (sv <= threshold)  continue;

            data_t  dot { 0 };

            for (size_type k { 0 }; k < col_s; ++k)
                dot += U(k, i) * y_mat(k, 0);

            splus_uty(i, 0) = dot / sv;
        }

        // β = V * (Σ + Ut y)
        //
        const matrix_t  beta { V * splus_uty };  // (dim_p_one × 1)

        // Extract intercept and slope vector
        //
        intercept_ = beta(0, 0);
        slope_.resize(dim);
        for (size_type j { 0 }; j < dim; ++j)
            slope_[j] = beta(j + 1, 0);

        // Compute fitted values and residual sum of squares
        //
        y_fits_.resize(col_s);
        for (size_type i { 0 }; i < col_s; ++i)  {
            data_t      pred { intercept_ };
            const auto  &xi { *(x_begin + i) };

            for (size_type j { 0 }; j < dim; ++j)
                pred += slope_[j] * xi[j];
            y_fits_[i]  = pred;

            const data_t    r { *(y_begin + i) - pred };

            residual_  += r * r;
        }
    }

    template<typename H1, typename H2>
    inline void
    do_md_by_solve_(const H1 &x_begin, const H2 &y_begin, size_type col_s)  {

        const size_type dim { x_begin->size() };  // # of features

        // Build design matrix X  (n × dim+1)  and response vector y_mat
        //
        matrix_t    X { long(col_s), long(dim + 1), 0 };
        matrix_t    y_mat { long(col_s), 1L, 0 };

        for (size_type i { 0 }; i < col_s; ++i)  {
            X(i, 0) = data_t(1);  // intercept column

            const auto  &xi { *(x_begin + i) };

            for (size_type j { 0 }; j < xi.size(); ++j)
                X(i, j + 1) = data_t(xi[j]);
            y_mat(i, 0) = data_t(*(y_begin + i));
        }

        // Normal equations:  β = (XᵀX)⁻¹ Xᵀy
        // Use Matrix::solve() which does Gaussian elimination on [A|b]
        //
        const matrix_t  Xt { X.transpose2() };
        const matrix_t  XtX { Xt * X };          // (dim+1 × dim+1)
        const matrix_t  Xty { Xt * y_mat };      // (dim+1 × 1)
        const matrix_t  beta { XtX.solve(Xty) }; // (dim+1 × 1)

        // Extract intercept and slope vector
        //
        intercept_ = beta(0, 0);
        slope_.resize(dim);
        for (size_type j { 0 }; j < dim; ++j)
            slope_[j] = beta(j + 1, 0);

        // Compute fitted values and residual sum of squares
        //
        y_fits_.resize(col_s);
        for (size_type i { 0 }; i < col_s; ++i)  {
            data_t       pred { intercept_ };
            const auto  &xi { *(x_begin + i) };

            for (size_type j { 0 }; j < dim; ++j)
                pred += slope_[j] * data_t(xi[j]);
            y_fits_[i] = pred;

            const data_t    r { data_t(*(y_begin + i)) - pred };

            residual_ += r * r;
        }
    }

    result_type y_fits_ {  };
    data_t      residual_{ 0 };
    data_t      intercept_ { 0 };
    slope_type  slope_ {  };   // data_t (scalar) or vector<data_t> (MD)
    const bool  do_solve_;
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using linfit_v = LinearFitVisitor<T, I, A>;

// ----------------------------------------------------------------------------

// https://en.wikipedia.org/w/index.php?title=Spline_%28mathematics%29&oldid=288288033#Algorithm_for_computing_natural_cubic_splines
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  CubicSplineFitVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };
    static constexpr bool   is_ary_ { is_std_array_v<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    using inner_data_t =
        typename std::conditional_t<! is_md_, T, vec_t<data_t>>;

public:

    using value_type = T;
    using index_type = I;
    using size_type  = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<data_t>,
                                    vec_t<vec_t<data_t>>>;

    // Yi(X) = Ai + Bi(X - Xi) + Ci(X - Xi)^2 + Di(X - Xi)^3
    // A is just Y input
    //
    template<typename K, typename Hx, typename Hy>
    inline void
    operator()(const K &, const K &,
               const Hx &x_begin, const Hx &x_end,
               const Hy &y_begin, const Hy &y_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };
        size_type       dims  { 1 };
        const auto      thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

        if constexpr (is_md_)  dims = y_begin->size();

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s != size_type(std::distance(y_begin, y_end)) || col_s <= 3)
            throw DataFrameError(
                "CubicSplineFitVisitor: two columns must be "
                "of equal sizes and > 3");

        // The tridiagonal derivation below divides by h[i] = X[i+1] - X[i]
        // and assumes h[i] > 0. A duplicate X divides by zero and NaN-
        // poisons the whole result; a merely out-of-order X (no duplicate)
        // divides by a negative, finite h[i] and silently produces a
        // finite-looking but mathematically meaningless spline. Neither is
        // detectable from the output alone, so it must be checked here.
        //
        for (size_type i { 1 }; i < col_s; ++i)
            if (*(x_begin + i) <= *(x_begin + (i - 1)))
                throw DataFrameError(
                    "CubicSplineFitVisitor: X column must be strictly "
                    "increasing");
#endif // HMDF_SANITY_EXCEPTIONS

        vec_t<data_t>   h(col_s, 0);
        auto            lbd =
            [&x_begin, &h](auto begin, auto end) -> void  {
                for (auto i { begin }; i < end; ++i)
                     h[i] = *(x_begin + (i + 1)) - *(x_begin + i);
            };

        if (thread_level > 2)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s - 1,
                    std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(size_type(0), col_s - 1);
        }

        vec_t<data_t>       mu(col_s, 0);
        result_type         z(col_s);
        constexpr data_t    two { 2 };
        constexpr data_t    three { 3 };

        if constexpr (is_md_)
            z[0] = vec_t<data_t>(dims, 0);
        else
            z[0] = 0;
        for(size_type i { 1 }; i < (col_s - 1); ++i) [[likely]]  {
            const auto  &yi { *(y_begin + i) };
            const auto  &yip1 { *(y_begin + (i + 1)) };
            const auto  &yim1 { *(y_begin + (i - 1)) };
            const auto  alpha {
                (yip1 - yi) * (three / h[i]) -
                (yi - yim1) * (three / h[i - 1])
            };
            const auto  l {
                two * (*(x_begin + (i + 1)) - *(x_begin + (i - 1))) -
                h[i - 1] * mu[i - 1]
            };

            mu[i] = h[i] / l;
            if constexpr (is_ary_)  {
                const auto  &val { (alpha - h[i - 1] * z[i - 1]) / l };

                z[i].assign(val.begin(), val.end());
            }
            else
                z[i] = (alpha - h[i - 1] * z[i - 1]) / l;
        }

        vec_t<inner_data_t> b(col_s - 1);
        vec_t<inner_data_t> c(col_s);
        vec_t<inner_data_t> d(col_s - 1);

        if constexpr (is_md_)
            c[col_s - 1] = vec_t<data_t>(dims, 0);
        else
            c[col_s - 1] = 0;
        for(long i { long(col_s - 2) }; i >= 0; --i) [[likely]]  {
            const auto  &yi { *(y_begin + i) };
            const auto  &yip1 { *(y_begin + (i + 1)) };

            c[i] = z[i] - c[i + 1] * mu[i];
            if constexpr (is_ary_)  {
                const auto  &val {
                    (yip1 - yi) / h[i] -
                    (c[i + 1] + c[i] * two) * (h[i] / three)
                };

                b[i].assign(val.begin(), val.end());
            }
            else
                b[i] = (yip1 - yi) / h[i] -
                       (c[i + 1] + c[i] * two) * (h[i] / three);
            d[i] = (c[i + 1] - c[i]) / (h[i] * three);
        }

        if constexpr (! is_md_)  {
            b_vec_.swap(b);
            c_vec_.swap(c);
            d_vec_.swap(d);
        }
        else  {
            b_vec_ = to_md_result_(b, dims);
            c_vec_ = to_md_result_(c, dims);
            d_vec_ = to_md_result_(d, dims);
        }
    }

    inline void pre()  {  }
    inline void post()  {  }

    inline const result_type &get_result() const  { return (b_vec_); }
    inline result_type &get_result()  { return (b_vec_); }
    inline const result_type &get_c_vec() const  { return (c_vec_); }
    inline result_type &get_c_vec()  { return (c_vec_); }
    inline const result_type &get_d_vec() const  { return (d_vec_); }
    inline result_type &get_d_vec()  { return (d_vec_); }

    CubicSplineFitVisitor() = default;

private:

    // MD only: transpose the result_type vector
    // outer = dimension, inner = segment
    //
    static inline result_type
    to_md_result_(result_type &src, size_type dims)  {

        const size_type n { src.size() };
        result_type     result(dims, vec_t<data_t>(n));

        for (size_type i { 0 }; i < n; ++i)
            for (size_type d { 0 }; d < dims; ++d)
                result[d][i] = src[i][d];
        return (result);
    }

    result_type b_vec_ {  };
    result_type c_vec_ {  };
    result_type d_vec_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using csfit_v = CubicSplineFitVisitor<T, I, A>;

// ----------------------------------------------------------------------------

// LOcally WEighted Scatterplot Smoothing
// A LOWESS function outputs smoothed estimates of dependent var (y) at the
// given independent var (x) values.
//
// This lowess function implements the algorithm given in the reference below
// using local linear estimates.
// Suppose the input data has N points. The algorithm works by estimating the
// `smooth` y_i by taking the frac * N the closest points to (x_i, y_i) based
// on their x values and estimating y_i using a weighted linear regression.
// The weight for (x_j, y_j) is tricube function applied to |x_i - x_j|.
// If n_loop > 1, then further weighted local linear regressions are performed,
// where the weights are the same as above times the _lowess_bisquare function
// of the residuals. Each iteration takes approximately the same amount of time
// as the original fit, so these iterations are expensive. They are most useful
// when the noise has extremely heavy tails, such as Cauchy noise. Noise with
// less heavy-tails, such as t-distributions with df > 2, are less problematic.
// The weights downgrade the influence of points with large residuals. In the
// extreme case, points whose residuals are larger than 6 times the median
// absolute residual are given weight 0. Delta can be used to save
// computations. For each x_i, regressions are skipped for points closer than
// delta. The next regression is fit for the farthest point within delta of
// x_i and all points in between are estimated by linearly interpolating
// between the two regression fits. Judicious choice of delta can cut
// computation time considerably for large data (N > 5000). A good choice is
// delta = 0.01 * range(independ_var). Some experimentation is likely required
// to find a good choice of frac and iter for a particular dataset.
// References
// ----------
// Cleveland, W.S. (1979) "Robust Locally Weighted Regression
// and Smoothing Scatterplots". Journal of the American Statistical
// Association 74 (368): 829-836.
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  LowessVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };
    static constexpr bool   is_ary_ { is_std_array_v<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // Always-scalar vector type — used for scratch buffers and resid_weights_
    // regardless of whether T is scalar or multidimensional.
    //
    using scalar_vec_t = vec_t<data_t>;

public:

    using value_type = T;
    using index_type = I;
    using size_type  = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<data_t>,
                                    vec_t<vec_t<data_t>>>;

private:

    // The bi-square function (1 - x^2)^2. Used to weight the residuals in the
    // robustifying iterations. Called by the calculate_residual_weights
    // function.
    //
    template<typename X>
    inline static
    void bi_square_(X x_begin, X x_end, long thread_level)  {

        auto    lbd =
            [](const auto &begin, const auto &end) -> void  {
                for (auto citer { begin }; citer < end; ++citer)  {
                    data_t        &x { *citer };
                    const data_t  val { data_t(1) - x * x };

                    x = val * val;
                }
            };

        if (thread_level > 2 &&
            std::distance(x_begin, x_end) >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    x_begin,
                    x_end,
                    std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(x_begin, x_end);
        }
    }

    // The tri-cubic function (1 - x^3)^3. Used to weight neighboring points
    // along the x-axis based on their distance to the current point.
    //
    template<typename X>
    inline static
    void tri_cube_(X x_begin, X x_end, long thread_level)  {

        auto    lbd =
            [](const auto &begin, const auto &end) -> void  {
                for (auto citer { begin }; citer < end; ++citer)  {
                    data_t        &x { *citer };
                    const data_t  val { data_t(1) - x * x * x };

                    x = val * val * val;
                }
            };

        if (thread_level > 2 &&
            std::distance(x_begin, x_end) >= ThreadPool::MUL_THR_THHOLD)  {
            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    x_begin,
                    x_end,
                    std::move(lbd))
            };

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(x_begin, x_end);
        }
    }

    // Calculate residual weights for the next robustifying iteration.
    //
    template<typename IDX, typename Y, typename K>
    inline void
    calc_residual_weights_(const IDX &idx_begin, const IDX &idx_end,
                           const Y &y_begin, const Y &y_end,
                           const K &y_fits_begin, const K &y_fits_end)  {

        // Even in the MD case, this is also called from the scalar path
        //
        using y_type = std::remove_cvref_t<decltype(*y_begin)>;

        const size_type col_s { size_type(std::distance(y_begin, y_end)) };

        if constexpr (container<y_type>)  {
            // Y is const vec_t<scalar_vec_t> &
            // Y_FITS is const vec_t<scalar_vec_t> &

            const size_type n_rows { resid_weights_.size() };

            // Per-row Euclidean norm of column-wise absolute residuals
            //
            std::fill(resid_weights_.begin(), resid_weights_.end(), 0);
            for (size_type c { 0 }; c < col_s; ++c)  {
                for (size_type i { 0 }; i < n_rows; ++i) [[likely]]  {
                    const auto      &y_fits { *(y_fits_begin + c) };
                    const auto      &ys { *(y_begin + c) };
                    const data_t    r { std::fabs(ys[i] - y_fits[i]) };

                    resid_weights_[i] += r * r;
                }
            }
            for (size_type i { 0 }; i < n_rows; ++i) [[likely]]
                resid_weights_[i] = std::sqrt(resid_weights_[i]);
        }
        else  {  // Scalar path
            auto    lbd =
                [&y_begin, &y_fits_begin, this]
                (auto begin, auto end, auto) -> void  {
                    for (size_type i { begin }; i < end; ++i) [[likely]]
                        resid_weights_[i] =
                            std::fabs(*(y_begin + i) - *(y_fits_begin + i));
                };

            if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop2<T>(
                        size_type(0),
                        col_s,
                        size_type(0),
                        size_type(std::distance(y_fits_begin, y_fits_end)),
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(size_type(0), col_s, size_type(0));
            }
        }

        MedianVisitor<data_t, I, A> median_v;

        median_v.pre();
        median_v(idx_begin, idx_end,
                 resid_weights_.begin(), resid_weights_.end());
        median_v.post();

        if (median_v.get_result() == 0)  {
            std::replace_if(resid_weights_.begin(), resid_weights_.end(),
                            std::bind(std::greater<data_t>(),
                                      std::placeholders::_1, 0),
                            data_t(1));
        }
        else  {
            const data_t    val { data_t(6) * median_v.get_result() };
            auto            lbd =
                [val](const auto &begin, const auto &end) -> void  {
                    for (auto citer { begin }; citer < end; ++citer)
                        *citer /= val;
                };

            if (thread_level_ > 2 && col_s >= ThreadPool::MUL_THR_THHOLD)  {
                auto    futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        resid_weights_.begin(),
                        resid_weights_.end(),
                        std::move(lbd))
                };

                for (auto &fut : futures)  fut.get();
            }
            else  {
                lbd(resid_weights_.begin(), resid_weights_.end());
            }
        }

        // Some trimming of outlier residuals.
        //
        std::replace_if(resid_weights_.begin(), resid_weights_.end(),
                        std::bind(std::greater<data_t>(),
                                  std::placeholders::_1, data_t(1)),
                        data_t(1));

        bi_square_(resid_weights_.begin(), resid_weights_.end(),
                   thread_level_);
    }

    // Update the counters of the local regression.
    // For most points within delta of the current point, we skip the weighted
    // linear regression (which save much computation of weights and fitted
    // points). Instead, we'll jump to the last point within delta, fit the
    // weighted regression at that point, and linearly interpolate in between.
    //
    template<typename X, typename K>
    inline static void
    update_indices_(const X &x_begin, const X & /*x_end*/,
                    const K &y_fits_begin, const K & /*y_fits_end*/,
                    data_t delta,
                    long &curr_idx, long &last_fit_idx,
                    size_type col_s)  {

        last_fit_idx = curr_idx;

        // This loop increments until we fall just outside of delta distance,
        // copying the results for any repeated x's along the way.
        //
        const data_t    cutoff { *(x_begin + last_fit_idx) + delta };
        long            k { last_fit_idx + 1 };
        bool            looped { false };
        bool            broke { false };

        for ( ; size_type(k) < col_s; ++k) [[likely]]  {
            looped = true;

            const data_t    xvalue { data_t(*(x_begin + k)) };

            if (xvalue > cutoff)  { broke = true; break; }
            if (xvalue == *(x_begin + last_fit_idx))  {
                // if tied with previous x-value, just use the already fitted
                // y, and update the last-fit counter.
                //
                *(y_fits_begin + k) = *(y_fits_begin + last_fit_idx);
                last_fit_idx = k;
            }
        }

        // If the scan above ran off the end of the data without ever
        // exceeding the cutoff (every remaining point was within delta),
        // this loop's increment leaves k one past the last valid index.
        // Pull it back so k lands on the last index actually visited,
        // matching the case where the loop broke early (and matching what
        // a range-based scan that simply stops at the last index would
        // leave k at) -- otherwise the very last delta-window of the data
        // computes one index too far right.
        //
        if (looped && ! broke)  k -= 1;

        // curr_idx, which indicates the next point to fit the regression at,
        // is either one prior to k (since k should be the first point outside
        // of delta) or is just incremented + 1 if k = curr_idx + 1.
        // This insures we always step forward.
        //
        curr_idx = std::max(k - (looped ? 1 : 2), last_fit_idx + 1);
    }

    // Calculate smoothed/fitted y by linear interpolation between the current
    // and previous y fitted by weighted regression.
    // Called only if delta > 0.
    //
    template<typename X, typename K>
    inline void
    interpolate_skipped_fits_(const X x_begin, const X /*x_end*/,
                              K y_fits_begin, K /*y_fits_end*/,
                              long curr_idx, long last_fit_idx)  {

        auxiliary_vec_.clear();
        auxiliary_vec_.reserve(curr_idx - last_fit_idx);

        const data_t    last_fit_xval { data_t(*(x_begin + last_fit_idx)) };

        std::transform(x_begin + (last_fit_idx + 1), x_begin + curr_idx,
                       std::back_inserter(auxiliary_vec_),
                       [last_fit_xval](const auto &x) -> data_t  {
                           return (x - last_fit_xval);
                       });

        const data_t    x_diff {
            data_t(*(x_begin + curr_idx) - last_fit_xval)
        };

        for (auto &val : auxiliary_vec_) [[likely]]  val /= x_diff;

        const data_t    last_fit_yval { *(y_fits_begin + last_fit_idx) };
        const data_t    curr_idx_yval { *(y_fits_begin + curr_idx) };

        // auxiliary_vec_[j] holds the interpolation fraction for absolute
        // index (last_fit_idx + 1 + j); j is 0-based (it came from
        // back_inserter starting at an empty vector), but i below is the
        // absolute fit index, so the two must not be used interchangeably.
        //
        for (long i { last_fit_idx + 1 }; i < curr_idx; ++i) [[likely]]  {
            const data_t    avalue { auxiliary_vec_[i - (last_fit_idx + 1)] };

            *(y_fits_begin + i) =
                avalue * curr_idx_yval + (data_t(1) - avalue) * last_fit_yval;
        }
    }

    // Calculate smoothed/fitted y-value by weighted regression.
    // No regression function (e.g. lstsq) is called. Instead "projection
    // vector" p_idx_j is calculated,
    // and y_fit[i] = sum(p_idx_j * y[j]) = y_fit[i]
    // for j s.t. x[j] is in the neighborhood of xval. p_idx_j is a function of
    // the weights, xval, and its neighbors.
    //
    template<typename X, typename K,
             typename Y, typename W>
    inline static void
    calculate_y_fits_(const X x_begin, const X /*x_end*/,
                      const K y_begin, const K /*y_end*/,
                      const W w_begin, const W /*w_end*/,
                      Y y_fits_begin, Y /*y_fits_end*/,
                      long curr_idx, data_t xval,
                      size_type left_end, size_type right_end,
                      bool reg_ok, bool fill_with_nans)  {

        if (! reg_ok)  {
            // Fill a bad regression (weights all zeros) with nans
            // or
            // Fill a bad regression with the original value only possible
            // when not using xvals distinct from x
            //
            *(y_fits_begin + curr_idx) =
                fill_with_nans
                    ? std::numeric_limits<data_t>::quiet_NaN()
                    : *(y_begin + curr_idx);
        }
        else  {
            data_t  sum_weighted_x { 0 };

            for (size_type j { left_end }; j < right_end; ++j) [[likely]]
                sum_weighted_x += *(w_begin + j) * *(x_begin + j);

            data_t  weighted_sqdev_x { 0 };

            for (size_type j { left_end }; j < right_end; ++j) [[likely]]  {
                const data_t    val { *(x_begin + j) - sum_weighted_x };

                weighted_sqdev_x += *(w_begin + j) * val * val;
            }

            for (size_type j { left_end }; j < right_end; ++j) [[likely]]  {
                const data_t    p_idx_j {
                    *(w_begin + j) *
                    (data_t(1) + (xval - sum_weighted_x) *
                     (*(x_begin + j) - sum_weighted_x) / weighted_sqdev_x)
                };

                *(y_fits_begin + curr_idx) += p_idx_j * *(y_begin + j);
            }
        }
    }

    // If it returns True, at least some points have positive weight, and the
    // regression will be run. If False, the regression is skipped and
    // y_fit[i] is set to equal y[i].
    //
    template<typename X, typename K>
    inline bool
    calculate_weights_(const X &x_begin, const X &/*x_end*/,
                       // Regression weights
                       const K &w_begin, const K &/*w_end*/,
                       // The x-value of the point currently being fit
                       //
                       data_t xval,
                       size_type left_end, size_type right_end,
                       // The radius of the current neighborhood. The larger
                       // of distances between x[i] and its left-most or
                       // right-most neighbor.
                       //
                       data_t radius)  {

        x_j_.clear();
        dist_i_j_.clear();
        x_j_.reserve(right_end - left_end);
        dist_i_j_.reserve(right_end - left_end);
        for (size_type j { left_end }; j < right_end; ++j) [[likely]]  {
            x_j_.push_back(*(x_begin + j));
            dist_i_j_.push_back(std::fabs(*(x_begin + j) - xval) / radius);

            // Assign the distance measure to the weights, then apply the
            // tricube function to change in-place.
            //
            *(w_begin + j) = dist_i_j_.back();
        }

        tri_cube_(w_begin + left_end, w_begin + right_end, thread_level_);
        for (size_type j { left_end }; j < right_end; ++j) [[likely]]
            *(w_begin + j) *= resid_weights_[j];

        data_t      sum_weights { 0 };
        size_type   non_zero_cnt { 0 };

        std::for_each(w_begin + left_end, w_begin + right_end,
                      [&sum_weights, &non_zero_cnt](auto w) -> void  {
                          if (w != 0)  {
                              sum_weights += w;
                              non_zero_cnt += 1;
                          }
                      });

        bool    reg_ok { true };

        // 2nd condition checks if only 1 local weight is non-zero, which
        // will give a divisor of zero in calculate_y_fit
        //
        if (sum_weights <= 0 || non_zero_cnt == 1)
            reg_ok = false;
        else
            for (size_type j { left_end }; j < right_end; ++j)
                *(w_begin + j) /= sum_weights;

        return (reg_ok);
    }

    // Find the indices bounding the k-nearest-neighbors of the current point.
    // It returns the radius of the current neighborhood. The larger of
    // distances between xval and its left-most or right-most neighbor.
    //
    template<typename X>
    inline static data_t
    update_neighborhood_(const X &x_begin, const X &/*x_end*/,
                         data_t xval,
                         size_type curr_idx,
                         size_type &left_end, size_type &right_end)  {

        // A subtle loop. Start from the current neighborhood range:
        // [left_end, right_end). Shift both ends rightwards by one (so that
        // the neighborhood still contains k points), until the current point
        // is in the center (or just to the left of the center) of the
        // neighborhood. This neighborhood will contain the k-nearest
        // neighbors of xval.
        //
        // Once the right end hits the end of the data, hold the neighborhood
        // the same for the remaining xvals.
        //
        while (true)  {
            if (right_end < curr_idx)  {
                if (xval > ((*(x_begin + left_end) +
                             *(x_begin + right_end)) / data_t(2)))  {
                    left_end += 1;
                    right_end += 1;
                }
                else  break;
            }
            else  break;
        }

        return (std::max(xval - *(x_begin + left_end),
                         *(x_begin + (right_end - 1)) - xval));
    }

    template<typename K, typename Y, typename X>
    inline void
    lowess_scalar_(const K &idx_begin, const K &idx_end,
                   const Y &y_begin, const Y &y_end,  // dependent variable
                   const X &x_begin, const X &x_end,  // independent variable
                   scalar_vec_t &y_fits_col,          // output per-column fits
                   bool update_resid = true)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };

        // The number of neighbors in each regression. round up if close
        // to integer
        //
        size_type   k { size_type (frac_ * data_t(col_s) + data_t(1e-10)) };

        // frac_ should be set, so that 2 <= k <= n. Conform them instead of
        // throwing error.
        //
        if (k < 2)  k = 2;
        if (k > col_s)  k = col_s;

        scalar_vec_t    weights (col_s, 0);

        y_fits_col.resize(col_s, 0);
        for (size_type l { 0 }; l < loop_n_; ++l) [[likely]]  {
            long        curr_idx { 0 };
            long        last_fit_idx { -1 };
            size_type   left_end { 0 };
            size_type   right_end { k };

            // Fit y[i]'s until the end of the regression
            //
            std::fill(y_fits_col.begin(), y_fits_col.end(), 0);
            while (true)  {
                // The x value at which we will fit this time
                //
                const data_t    xval { data_t(*(x_begin + curr_idx)) };
                // Describe the neighborhood around the current xval.
                //
                const data_t    radius {
                    update_neighborhood_(x_begin, x_end,
                                         xval, col_s,
                                         left_end, right_end)
                };

                // Re-initialize the weights for each point xval.
                //
                std::fill(weights.begin(), weights.end(), 0);

                // Calculate the weights for the regression in this
                // neighborhood. Determine if at least some weights are
                // positive, so a regression is ok.
                //
                const bool  reg_ok {
                    calculate_weights_(x_begin, x_end,
                                       weights.begin(), weights.end(),
                                       xval,
                                       left_end, right_end,
                                       radius)
                };

                // If ok, run the regression
                //
                calculate_y_fits_(x_begin, x_end,
                                  y_begin, y_end,
                                  weights.begin(), weights.end(),
                                  y_fits_col.begin(), y_fits_col.end(),
                                  curr_idx, xval,
                                  left_end, right_end,
                                  reg_ok, false);

                // If we skipped some points, because of how delta_ was set,
                // go back and fit them by linear interpolation.
                //
                if (last_fit_idx < (curr_idx - 1))
                    interpolate_skipped_fits_(
                        x_begin, x_end,
                        y_fits_col.begin(), y_fits_col.end(),
                        curr_idx, last_fit_idx);

                // Update the last fit counter to indicate we've now fit this
                // point. Find the next i for which we'll run a regression.
                //
                update_indices_(x_begin, x_end,
                                y_fits_col.begin(), y_fits_col.end(),
                                delta_,
                                curr_idx, last_fit_idx,
                                col_s);

                if (last_fit_idx >= (long(col_s) - 1L))  break;
            }

            // In the MD path resid_weights_ is updated by the caller
            // (lowess_md_) after all columns are done.
            //
            if (update_resid)
                calc_residual_weights_(idx_begin, idx_end,
                                       y_begin, y_end,
                                       y_fits_col.begin(), y_fits_col.end());
        }
    }

    template<typename IDX, typename YS, typename XS>
    inline void
    lowess_(const IDX &idx_begin, const IDX &idx_end,
            const YS  &y_begin, const YS  &y_end,
            const XS  &x_begin, const XS  &x_end)  {

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };


        // y_fits_ IS the scalar_vec_t in the scalar case
        //
        resid_weights_.resize(col_s, 1);
        lowess_scalar_(idx_begin, idx_end,
                       y_begin, y_end,
                       x_begin, x_end,
                       y_fits_,
                       true);   // update_resid = true
    }

    // MD entry point.
    // Y iterators dereference to T (e.g. std::vector<double> or
    // std::array<double,N>).  X iterators dereference to data_t (scalar).
    //
    // Layout of y_fits_ in MD mode: y_fits_[col][row]
    //
    // For each robustifying iteration:
    //   1. Run lowess_scalar_ on each column (update_resid=false).
    //   2. After all columns: update resid_weights_ via the MD norm method.
    //
    template<typename IDX, typename YMD, typename XS>
    inline void
    lowess_md_(const IDX &idx_begin, const IDX &idx_end,
               const YMD &y_begin, const YMD &y_end,
               const XS &x_begin, const XS &x_end)  {

        const size_type n_rows { size_type(std::distance(y_begin, y_end)) };

        if (n_rows == 0)  return;

        const size_type col_s {
            [n_rows, &y_begin]() -> size_type  {
                if constexpr (is_ary_)
                    return (std::tuple_size<T>::value);
                else
                    return ((n_rows > 0) ? y_begin->size() : size_type(0));
            }()
        };

        if (col_s == 0)  return;

        resid_weights_.resize(n_rows, 1);

        // Allocate result storage: y_fits_[col][row]
        //
        y_fits_.resize(col_s, scalar_vec_t(n_rows, 0));

        // Build column-major views of y so we can pass flat iterators
        // to lowess_scalar_.  We rebuild these each outer iteration
        // since resid_weights_ changes.
        //
        // y_cols[c][r] = y_begin[r][c]
        //
        vec_t<scalar_vec_t> y_cols(col_s, scalar_vec_t(n_rows));

        for (size_type r { 0 }; r < n_rows; ++r)  {
            const auto  &row { *(y_begin + r) };

            for (size_type c { 0 }; c < col_s; ++c)
                y_cols[c][r] = row[c];
        }

        // Outer robustifying loop
        //
        for (size_type l { 0 }; l < loop_n_; ++l) [[likely]]  {
            // Fit each column independently using the shared resid_weights_
            //
            for (size_type c { 0 }; c < col_s; ++c)  {
                lowess_scalar_(idx_begin, idx_end,
                               y_cols[c].begin(), y_cols[c].end(),
                               x_begin, x_end,
                               y_fits_[c],
                               false); // update_resid = false; we do it below
            }

            // Update resid_weights_ using the Euclidean norm across columns
            //
            calc_residual_weights_(idx_begin, idx_end,
                                   y_cols.begin(), y_cols.end(),
                                   y_fits_.begin(), y_fits_.end());
        }
    }

public:

    template<typename K, typename Y, typename X>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const Y &y_begin, const Y &y_end,     // dependent variable
               const X &x_begin, const X &x_end)  {  // independent variable

        using bool_vec_t =
            std::vector<bool, typename allocator_declare<bool, A>::type>;

#ifdef HMDF_SANITY_EXCEPTIONS
        if (frac_ < 0 || frac_ > 1)
            throw DataFrameError("LowessVisitor: 0 <= frac <= 1");
#endif // HMDF_SANITY_EXCEPTIONS

        const size_type col_s { size_type(std::distance(x_begin, x_end)) };

        if constexpr (is_md_)  {
            if (sorted_)  {
                lowess_md_(idx_begin, idx_end, y_begin, y_end, x_begin, x_end);
            }
            else  {
                scalar_vec_t            xvals(x_begin, x_end);
                std::vector<size_type>  sorting_idxs(col_s);

                std::iota(sorting_idxs.begin(), sorting_idxs.end(), 0);
                if (col_s >= ThreadPool::MUL_THR_THHOLD &&
                    ThreadGranularity::get_thread_level() > 2)  {
                    ThreadGranularity::thr_pool_.parallel_sort(
                        sorting_idxs.begin(), sorting_idxs.end(),
                        [&xvals](auto lhs, auto rhs) -> bool  {
                            return (xvals[lhs] < xvals[rhs]);
                        });
                    ThreadGranularity::thr_pool_.parallel_sort(
                        xvals.begin(), xvals.end(),
                        [](auto lhs, auto rhs) -> bool {
                            return (lhs < rhs);
                        });
                }
                else  {
                    std::sort(sorting_idxs.begin(), sorting_idxs.end(),
                              [&xvals](auto lhs, auto rhs) -> bool  {
                                  return (xvals[lhs] < xvals[rhs]);
                              });
                    std::sort(xvals.begin(), xvals.end(),
                              [](auto lhs, auto rhs) -> bool {
                                  return (lhs < rhs);
                              });
                }

                // Reorder rows of y according to sorted x order
                //
                vec_t<T>    yvals(y_begin, y_end);
                bool_vec_t  done_vec(col_s, false);

                _sort_by_sorted_index_(yvals, sorting_idxs, done_vec, col_s);
                lowess_md_(idx_begin, idx_end,
                           yvals.begin(), yvals.end(),
                           xvals.begin(), xvals.end());
            }
        }
        else  {  // Scalar path
            if (sorted_)
                lowess_(idx_begin, idx_end, y_begin, y_end, x_begin, x_end);
            else  {  // Sort x and y in ascending order of x
                scalar_vec_t            xvals(x_begin, x_end);
                scalar_vec_t            yvals(y_begin, y_end);
                std::vector<size_type>  sorting_idxs(col_s);

                std::iota(sorting_idxs.begin(), sorting_idxs.end(), 0);
                if (col_s >= ThreadPool::MUL_THR_THHOLD &&
                    ThreadGranularity::get_thread_level() > 2)  {
                    ThreadGranularity::thr_pool_.parallel_sort(
                        sorting_idxs.begin(), sorting_idxs.end(),
                        [&xvals] (auto lhs, auto rhs) -> bool  {
                            return (xvals[lhs] < xvals[rhs]);
                        });
                    ThreadGranularity::thr_pool_.parallel_sort(
                        xvals.begin(), xvals.end(),
                        [] (auto lhs, auto rhs) -> bool  {
                            return (lhs < rhs);
                        });
                }
                else  {
                    std::sort(sorting_idxs.begin(), sorting_idxs.end(),
                              [&xvals] (auto lhs, auto rhs) -> bool  {
                                  return (xvals[lhs] < xvals[rhs]);
                              });
                    std::sort(xvals.begin(), xvals.end(),
                              [] (auto lhs, auto rhs) -> bool  {
                                  return (lhs < rhs);
                              });
                }

                bool_vec_t  done_vec (col_s, false);

                _sort_by_sorted_index_(yvals, sorting_idxs, done_vec, col_s);
                lowess_(idx_begin, idx_end,
                        yvals.begin(), yvals.end(),
                        xvals.begin(), xvals.end());
            }
        }
    }

    inline void pre()  {

        y_fits_.clear();
        resid_weights_.clear();
        auxiliary_vec_.clear();
        x_j_.clear();
        dist_i_j_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (y_fits_); }
    inline result_type &get_result()  { return (y_fits_); }
    inline const scalar_vec_t &
    get_residual_weights() const  { return (resid_weights_); }
    inline scalar_vec_t &get_residual_weights()  { return (resid_weights_); }

    explicit
    LowessVisitor(size_type loop_n = 3,
                  data_t frac = data_t(2) / data_t(3),
                  data_t delta = 0,
                  bool sorted = false)
        : frac_(frac),
          loop_n_(loop_n + 1),
          delta_(delta),
          sorted_(sorted),
          thread_level_(ThreadGranularity::get_thread_level())  {   }

private:

    // Between 0 and 1. The fraction of the data used when estimating
    // each y-value.
    //
    const data_t    frac_;
    // The number of residual-based reweightings to perform.
    //
    const size_type loop_n_;
    // Distance within which to use linear-interpolation instead of weighted
    // regression.
    //
    const data_t    delta_;
    // Are x and y vectors sorted in the ascending order of values in x vector
    //
    const bool      sorted_;

    const long      thread_level_;

    result_type     y_fits_ {  };
    // Always scalar — one weight per row regardless of T
    //
    scalar_vec_t    resid_weights_ {  };

    // Always scalar scratch buffers — never vector-of-vectors
    //
    scalar_vec_t    auxiliary_vec_ {  };
    scalar_vec_t    x_j_ {  };
    scalar_vec_t    dist_i_j_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using lowess_v = LowessVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  DecomposeVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };
    static constexpr bool   is_ary_ { is_std_array_v<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using value_type = T;
    using index_type = I;
    using size_type  = std::size_t;
    using result_type = typename std::conditional_t<
        ! is_md_,
        vec_t<data_t>,          // indexed [time]
        vec_t<vec_t<data_t>>>;  // indexed [time][dim]

private:

    template<typename K, typename H>
    inline void
    do_trend_(const K &idx_begin, const K &idx_end,
              const H &y_begin, const H &y_end,
              size_type col_s,
              vec_t<data_t> &xvals)  {

        std::iota(xvals.begin(), xvals.end(), data_t(0));

        LowessVisitor<T, I, A> l_v {
            3, frac_, delta_ * data_t(col_s), true
        };

        // Calculate trend
        //
        l_v.pre();
        l_v (idx_begin, idx_end, y_begin, y_end, xvals.begin(), xvals.end());
        l_v.post();
        if constexpr (! is_md_)  {
            // Scalar: get_result() is vec_t<double> indexed [time].
            // Direct move.
            //
            trend_ = std::move(l_v.get_result());
        }
        else  {
            // MD: LOWESS get_result() is vec_t<vec_t<data_t>>
            // indexed [dim][time].
            // Transpose to [time][dim] so it matches the input layout and all
            // downstream ops (detrending, seasonal, residual) index uniformly.
            //
            const auto      &lowess_res { l_v.get_result() }; // [dim][time]
            const size_type dim { lowess_res.size() };

            trend_.resize(col_s);
            for (size_type t { 0 }; t < col_s; ++t)  {
                trend_[t].resize(dim);
                for (size_type d { 0 }; d < dim; ++d)
                    trend_[t][d] = lowess_res[d][t];
            }
        }
    }

    template<typename MEAN, typename K>
    inline void
    do_seasonal_(size_type col_s, const K &idx_begin, const K &idx_end,
                 const result_type &detrended)  {

        using dtrend_t = typename result_type::value_type;

        StepRollAdopter<MEAN, dtrend_t, I>  sr_mean { MEAN(), s_period_ };

        // Calculate one-period seasonality
        //
        seasonal_.resize(col_s);
        for (size_type i { 0 }; i < s_period_; ++i) [[likely]]  {
            sr_mean.pre();
            sr_mean (idx_begin + i, idx_end,
                     detrended.begin() + i, detrended.end());
            sr_mean.post();
            seasonal_[i] = std::move(sr_mean.get_result());
        }

        // [01]-center the period means depending on the type
        //
        MEAN    m_v;

        m_v.pre();
        m_v (idx_begin, idx_begin + s_period_,
             seasonal_.begin(), seasonal_.begin() + s_period_);
        m_v.post();

        const auto  &result { m_v.get_result() };

        if (type_ == decompose_type::additive)  {
            for (size_type i { 0 }; i < s_period_; ++i)
                seasonal_[i] -= result;
        }
        else  {
            for (size_type i { 0 }; i < s_period_; ++i)
                seasonal_[i] /= result;
        }

        // Tile the one-time seasone over the seasonal_ vector
        //
        for (size_type i { s_period_ }; i < col_s; ++i)
            seasonal_[i] = seasonal_[i % s_period_];
    }

    inline void
    do_residual_(const result_type &detrended)  {

        // What is left is residual
        //
        if (type_ == decompose_type::additive)
            residual_ = detrended - seasonal_;
        else
            residual_ = detrended / seasonal_;
    }

public:

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &y_begin, const H &y_end)  {

        const size_type col_s { size_type(std::distance(y_begin, y_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (s_period_ > col_s / 2)
            throw DataFrameError("DecomposeVisitor: short period must be <= "
                                 "half of column size");
#endif // HMDF_SANITY_EXCEPTIONS

        vec_t<data_t>   xvals(col_s);

        do_trend_(idx_begin, idx_end, y_begin, y_end, col_s, xvals);

        // We want to reuse the vector, so just rename it.
        // This way nobody gets confused
        //
        result_type detrended(col_s);
        size_type   dim { 0 };

        if constexpr (is_ary_)  dim = y_begin->size();

        // Remove trend from observations in y
        //
        auto    add_lbd =
            [dim, this, &detrended, &y_begin]
            (auto begin, auto end, auto) -> void {
                for (size_type i { begin }; i < end; ++i) [[likely]]  {
                    if constexpr (is_ary_)  {
                        const auto  &val { *(y_begin + i) - trend_[i] };
                        size_type   j { 0 };

                        detrended[i].resize(dim);
                        for (auto b { val.begin() }; b < val.end(); ++b)
                            detrended[i][j++] = *b;
                    }
                    else  {
                        detrended[i] = *(y_begin + i) - trend_[i];
                    }
                }
            };
        auto    mul_lbd =
            [dim, this, &detrended, &y_begin]
            (auto begin, auto end, auto) -> void {
                for (size_type i { begin }; i < end; ++i) [[likely]]  {
                    if constexpr (is_ary_)  {
                        const auto  &val { *(y_begin + i) / trend_[i] };
                        size_type   j { 0 };

                        detrended[i].resize(dim);
                        for (auto b { val.begin() }; b < val.end(); ++b)
                            detrended[i][j++] = *b;
                    }
                    else  {
                        detrended[i] = *(y_begin + i) / trend_[i];
                    }
                }
            };

        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            std::vector<std::future<void>>  futures;

            if (type_ == decompose_type::additive)
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop2<T>(
                        size_type(0),
                        col_s,
                        size_type(0),
                        trend_.size(),
                        std::move(add_lbd));
            else
                futures =
                    ThreadGranularity::thr_pool_.parallel_loop2<T>(
                        size_type(0),
                        col_s,
                        size_type(0),
                        trend_.size(),
                        std::move(mul_lbd));

            for (auto &fut : futures)  fut.get();
        }
        else  {
            if (type_ == decompose_type::additive)
                add_lbd(size_type(0), col_s, size_type(0));
            else
                mul_lbd(size_type(0), col_s, size_type(0));
        }

        using dtrend_t = typename result_type::value_type;

        if (type_ == decompose_type::additive)
            do_seasonal_<MeanVisitor<dtrend_t, I>>
                (col_s, idx_begin, idx_end, detrended);
        else
            do_seasonal_<GeometricMeanVisitor<dtrend_t, I>>
                (col_s, idx_begin, idx_end, detrended);

        do_residual_(detrended);
    }

    inline void pre()  {

        trend_.clear();
        seasonal_.clear();
        residual_.clear();
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (trend_); }
    inline result_type &get_result()  { return (trend_); }
    inline const result_type &get_trend() const  { return (trend_); }
    inline result_type &get_trend()  { return (trend_); }
    inline const result_type &get_seasonal() const  { return (seasonal_); }
    inline result_type &get_seasonal()  { return (seasonal_); }
    inline const result_type &get_residual () const  { return (residual_); }
    inline result_type &get_residual()  { return (residual_); }

    DecomposeVisitor(size_type s_period,
                     data_t frac,
                     data_t delta,
                     decompose_type t = decompose_type::additive)
        : frac_(frac),
          s_period_(s_period),
          delta_(delta),
          type_(t)  {   }

private:

    // Between 0 and 1. The fraction of the data used when estimating
    // each y-value.
    //
    const data_t            frac_;
    // Seasonal period in unit of one observation. There must be at least
    // two seasons in the data
    //
    const size_type         s_period_;
    // Distance within which to use linear-interpolation instead of weighted
    // regression. 0 or small values cause longer/more accurate processing
    //
    const data_t            delta_;
    const decompose_type    type_;

    result_type             trend_ {  };
    result_type             seasonal_ {  };
    result_type             residual_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using decom_v = DecomposeVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<container V>
inline bool
is_normal(const V &column, double epsl, bool check_for_standard)  {

    using value_type = typename V::value_type;

    const int                       dummy_idx { int() };
    StatsVisitor<value_type, int>   svisit;

    svisit.pre();
    for (auto citer : column)
        svisit(dummy_idx, citer);
    svisit.post();

    const value_type    mean = static_cast<value_type>(svisit.get_mean());
    const value_type    stdev = static_cast<value_type>(svisit.get_std());
    const value_type    high_band_1 = static_cast<value_type>(mean + stdev);
    const value_type    low_band_1 = static_cast<value_type>(mean - stdev);
    double              count_1 = 0.0;
    const value_type    high_band_2 =
        static_cast<value_type>(mean + stdev * 2.0);
    const value_type    low_band_2 =
        static_cast<value_type>(mean - stdev * 2.0);
    double              count_2 = 0.0;
    const value_type    high_band_3 =
        static_cast<value_type>(mean + stdev * 3.0);
    const value_type    low_band_3 =
        static_cast<value_type>(mean - stdev * 3.0);
    double              count_3 = 0.0;

    for (const auto &val : column) [[likely]]  {
        if (val >= low_band_1 && val < high_band_1)  {
            count_3 += 1;
            count_2 += 1;
            count_1 += 1;
        }
        else if (val >= low_band_2 && val < high_band_2)  {
            count_3 += 1;
            count_2 += 1;
        }
        else if (val >= low_band_3 && val < high_band_3)  {
            count_3 += 1;
        }
    }

    const double    col_s = static_cast<double>(column.size());

    if (std::fabs((count_1 / col_s) - 0.68) <= epsl &&
        std::fabs((count_2 / col_s) - 0.95) <= epsl &&
        std::fabs((count_3 / col_s) - 0.997) <= epsl)  {
        if (check_for_standard)
            return (std::fabs(mean - 0) <= epsl &&
                    std::fabs(stdev - 1.0) <= epsl);
        return (true);
    }
    return (false);
}

// ----------------------------------------------------------------------------

template<container V>
inline bool
is_lognormal(const V &column, double epsl)  {

    using value_type = typename V::value_type;

    const int                       dummy_idx { int() };
    StatsVisitor<value_type, int>   svisit;
    StatsVisitor<value_type, int>   log_visit;

    svisit.pre();
    for (auto val : column) [[likely]]  {
        svisit(dummy_idx, static_cast<value_type>(std::log(val)));
        log_visit(dummy_idx, val);
    }
    svisit.post();

    const value_type    mean = static_cast<value_type>(svisit.get_mean());
    const value_type    stdev = static_cast<value_type>(svisit.get_std());
    const value_type    high_band_1 = static_cast<value_type>(mean + stdev);
    const value_type    low_band_1 = static_cast<value_type>(mean - stdev);
    double              count_1 = 0.0;
    const value_type    high_band_2 =
        static_cast<value_type>(mean + stdev * 2.0);
    const value_type    low_band_2 =
        static_cast<value_type>(mean - stdev * 2.0);
    double              count_2 = 0.0;
    const value_type    high_band_3 =
        static_cast<value_type>(mean + stdev * 3.0);
    const value_type    low_band_3 =
        static_cast<value_type>(mean - stdev * 3.0);
    double              count_3 = 0.0;

    for (const auto &val : column) [[likely]]  {
        const auto  log_val = std::log(val);

        if (log_val >= low_band_1 && log_val < high_band_1)  {
            count_3 += 1;
            count_2 += 1;
            count_1 += 1;
        }
        else if (log_val >= low_band_2 && log_val < high_band_2)  {
            count_3 += 1;
            count_2 += 1;
        }
        else if (log_val >= low_band_3 && log_val < high_band_3)  {
            count_3 += 1;
        }
    }

    const double    col_s = static_cast<double>(column.size());

    if (std::fabs((count_1 / col_s) - 0.68) <= epsl &&
        std::fabs((count_2 / col_s) - 0.95) <= epsl &&
        std::fabs((count_3 / col_s) - 0.997) <= epsl &&
        log_visit.get_skew() > 10.0 * svisit.get_skew() &&
        log_visit.get_kurtosis() > 10.0 * svisit.get_kurtosis())
        return (true);
    return (false);
}

// ----------------------------------------------------------------------------

template<typename AV, typename T,
         typename I = unsigned long, std::size_t A = 0>
struct  BiasVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;
    static constexpr bool   is_ary_ = is_std_array_v<T>;

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;
    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using avg_type = AV;
    using value_type = T;
    using index_type = I;
    using size_type  = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_,
                                    vec_t<data_t>,
                                    vec_t<vec_t<data_t>>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (roll_period_ == 0 || roll_period_ >= col_s)
            throw DataFrameError("BiasVisitor: roll period must > 0 and "
                                 "< column size");
#endif // HMDF_SANITY_EXCEPTIONS

        SimpleRollAdopter<avg_type, T, I, A>   avger {
            std::move(avg_v_), roll_period_
        };

        avger.pre();
        avger (idx_begin, idx_end, column_begin, column_end);
        avger.post();

        auto    lbd =
            [this, &column_begin] (auto begin, auto end, auto) -> void  {
                for (size_type i { begin }; i < end; ++i) [[likely]]  {
                    auto    &re { result_[i] };

                    if constexpr (is_ary_)  {
                        const auto  &val { *(column_begin + i) };

                        re.resize(val.size());
                        for (size_type j { 0 }; const auto v : val)  {
                            re[j] = v / re[j] - data_t(1);;
                            j += 1;
                        }
                    }
                    else  {
                        re = *(column_begin + i) / re - data_t(1);
                    }
                }
            };

        result_ = std::move(avger.get_result());
        if (col_s >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop2<T>(
                    roll_period_ - 1,
                    col_s,
                    roll_period_ - 1,
                    col_s,
                    std::move(lbd));

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd(roll_period_ - 1, col_s, roll_period_ - 1);
        }
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    explicit
    BiasVisitor(avg_type avg, size_type roll_period = 26)
        : roll_period_(roll_period), avg_v_(avg)  {   }

private:

    const size_type roll_period_;
    avg_type        avg_v_;
    result_type     result_ { };
};

template<typename AV, typename T, typename I = unsigned long,
         std::size_t A = 0>
using bias_v = BiasVisitor<AV, T, I, A>;

// ----------------------------------------------------------------------------

template<arithmetic T, typename I = unsigned long, std::size_t A = 0>
struct  NonZeroRangeVisitor  {

    DEFINE_VISIT_BASIC_TYPES_3

    template <typename K, typename H1, typename H2>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H1 &column1_begin, const H1 &column1_end,
               const H2 &column2_begin, const H2 &column2_end)  {

        const size_type        col_s {
            size_type(std::min({ std::distance(idx_begin, idx_end),
                                 std::distance(column1_begin, column1_end),
                                 std::distance(column2_begin, column2_end) }))
        };
        bool                   there_is_zero { false };
        result_type            result;
        constexpr value_type   nudge {
            std::is_floating_point_v<value_type>
                ? value_type(std::numeric_limits<value_type>::epsilon())
                : value_type(1)
        };

        if (long(col_s) >= ThreadPool::MUL_THR_THHOLD &&
            ThreadGranularity::get_thread_level() > 2)  {
            result.resize(col_s);

            auto    futures {
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0),
                    col_s,
                    [&result, &column1_begin, &column2_begin]
                    (auto begin, auto end) -> bool  {
                        bool    there_is_zero { false };

                        for (size_type i { begin }; i < end; ++i)  {
                            const value_type    v {
                                *(column1_begin + i) - *(column2_begin + i)
                            };

                            result[i] = v;
                            if (v == 0)  there_is_zero = true;
                        }
                        return (there_is_zero);
                    })
            };

            for (auto &fut : futures)  there_is_zero |= fut.get();
            if (there_is_zero)  {
                auto    local_futures {
                    ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                        size_type(0),
                        col_s,
                        [&result]
                        (auto begin, auto end) -> void  {
                            for (size_type i { begin }; i < end; ++i)
                                result[i] += nudge;
                        })
                };

                for (auto &fut : local_futures)  fut.get();
            }
        }
        else  {
            result.resize(col_s);
            for (size_type i { 0 }; i < col_s; ++i) [[likely]]  {
                const value_type    v {
                    *(column1_begin + i) - *(column2_begin + i)
                };

                result[i] = v;
                if (v == 0)  there_is_zero = true;
            }
            if (there_is_zero)
                std::for_each(result.begin(), result.end(),
                              [nudge](value_type &v) -> void  { v += nudge; });
        }

        result_.swap(result);
    }

    DEFINE_PRE_POST
    DEFINE_RESULT

    NonZeroRangeVisitor() = default;

private:

    result_type result_ {  };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using nzr_v = NonZeroRangeVisitor<T, I, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  StationaryCheckVisitor  {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };
    static constexpr bool   is_ary_ { is_std_array_v<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 5)
            throw DataFrameError(
                "StationaryCheckVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        if (method_ == stationary_test::kpss)
            do_kpss_(idx_begin, idx_end, column_begin, column_end, col_s);
        else
            do_adf_(column_begin, col_s);
    }

    inline void pre()  {

        if constexpr (is_md_)  {
            kpss_val_.clear();
            kpss_stat_.clear();
            adf_stat_.clear();
        }
        else  {
            kpss_val_ = 0;
            kpss_stat_ = -1;
            adf_stat_ = 0;
        }
    }
    inline void post()  {  }
    inline result_type get_kpss_value() const  { return (kpss_val_); }
    inline result_type get_kpss_statistic() const  { return (kpss_stat_); }
    inline result_type get_adf_statistic() const  { return (adf_stat_); }

    explicit
    StationaryCheckVisitor(stationary_test method,
                           const StationaryTestParams params = { })
        : method_(method), params_(params)  {   }

private:

    using matrix_t = Matrix<data_t, matrix_orient::row_major>;

    // Helper: map a scalar KPSS value to its significance level
    //
    inline data_t
    classify_kpss_(data_t val) const  {
        if (val < params_.critical_values[0])  return (data_t(0.1));
        if (val < params_.critical_values[1])  return (data_t(0.05));
        if (val < params_.critical_values[2])  return (data_t(0.025));
        if (val < params_.critical_values[3])  return (data_t(0.01));
        return (data_t(0));
    }

    template<typename K, typename H>
    inline void
    do_kpss_(const K &idx_begin, const K &idx_end,
             const H &column_begin, const H &column_end,
             size_type col_s)  {

        std::vector<data_t> times(col_s);

        std::iota(times.begin(), times.end(), data_t(1));

        // Calculate residuals from a linear trend fit
        //
        std::vector<value_type> residuals(col_s);

        if constexpr (! is_md_)  {
            linfit_v<T, I>  linfit;

            linfit.pre();
            linfit(idx_begin, idx_end,
                   times.begin(), times.end(), column_begin, column_end);
            linfit.post();
            for (size_type i { 0 }; i < col_s; ++i)
                residuals[i] = *(column_begin + i) - linfit.get_result()[i];
        }
        else  {
            // LinearFitVisitor's MD mode fits MULTIPLE X predictors
            // against a single SCALAR Y (genuine multivariate regression)
            // -- it does not provide "shared scalar X, independent fit
            // per Y dimension", which is what a per-dimension trend
            // detrend needs. Feeding it column_begin (the actual MD data)
            // as X and times as Y, as before, asked it to predict the
            // time index from the data -- producing a fit on the scale of
            // the time index, not a per-dimension detrended prediction.
            // Fit each dimension's own scalar column against times
            // separately with the plain (non-MD) LinearFitVisitor instead.
            //
            const size_type      ndim { column_begin->size() };
            std::vector<data_t>  dim_col(col_s);

            if constexpr (! is_ary_)
                for (auto &r : residuals)  r.resize(ndim);

            for (size_type d { 0 }; d < ndim; ++d)  {
                for (size_type i { 0 }; i < col_s; ++i)
                    dim_col[i] = (*(column_begin + i))[d];

                LinearFitVisitor<data_t, I>  dim_linfit;

                dim_linfit.pre();
                dim_linfit(idx_begin, idx_end,
                           times.begin(), times.end(),
                           dim_col.begin(), dim_col.end());
                dim_linfit.post();
                for (size_type i { 0 }; i < col_s; ++i)
                    residuals[i][d] = dim_col[i] - dim_linfit.get_result()[i];
            }
        }

        // Calculate cumulative sum of residuals
        //
        std::vector<value_type> cum_sum(col_s);

        cum_sum[0] = residuals[0];
        for (size_type i { 1 }; i < col_s; ++i)
            cum_sum[i] = cum_sum[i - 1] + residuals[i];

        // Calculate variance of residuals
        //
        VarVisitor<T, I>    var { true };

        var.pre();
        var(idx_begin, idx_end, residuals.begin(), residuals.end());
        var.post();

        const auto  &var_res { var.get_result() };

        if constexpr (! is_md_)  {
            data_t  norm_sq { 0 };

            for (size_type i { 0 }; i < col_s; ++i)
                norm_sq += cum_sum[i] * cum_sum[i];

            kpss_val_ = norm_sq / (data_t(col_s) * data_t(col_s) * var_res);
            kpss_stat_ = classify_kpss_(kpss_val_);
        }
        else  {
            const size_type ndim { column_begin->size() };

            std::vector<data_t> norm_sq(ndim, 0);

            for (size_type i { 0 }; i < col_s; ++i)
                for (size_type d { 0 }; d < ndim; ++d)
                    norm_sq[d] += cum_sum[i][d] * cum_sum[i][d];

            const data_t    denom_scale { data_t(col_s * col_s) };

            kpss_val_.resize(ndim);
            kpss_stat_.resize(ndim);
            for (size_type d { 0 }; d < ndim; ++d)  {
                kpss_val_[d]  = norm_sq[d] / (denom_scale * var_res(d, d));
                kpss_stat_[d] = classify_kpss_(kpss_val_[d]);
            }
        }
    }

    // Runs the ADF regression  Δy_t = α + β·y_(t-1) + Σ γ_j·Δy_(t-j)
    // [+ δ·t]  on a single scalar series, returning the t-statistic on β
    // (the actual ADF statistic). y_begin/y_end must be a scalar (data_t)
    // range of length n; with_trend adds the linear-trend column.
    //
    inline data_t
    do_adf_scalar_(const std::vector<data_t> &y,
                   size_type lag,
                   bool with_trend) const  {

        const size_type     col_s { y.size() };
        std::vector<data_t> dy(col_s - 1);

        for (size_type j { 0 }; j < col_s - 1; ++j)
            dy[j] = y[j + 1] - y[j];

        const size_type n_obs { col_s - 1 - lag };
        const size_type ylag_col { 1 };
        const size_type n_cols { 2 + lag + (with_trend ? 1 : 0) };

        matrix_t    X { long(n_obs), long(n_cols), 0 };
        matrix_t    y_mat { long(n_obs), 1L, 0 };

        for (size_type r { 0 }; r < n_obs; ++r)  {
            const size_type    t { r + lag + 1 };

            X(r, 0) = data_t(1);        // intercept
            X(r, ylag_col) = y[t - 1];  // y_(t-1), the coefficient of interest
            for (size_type j { 1 }; j <= lag; ++j)
                X(r, 1 + j) = dy[t - j - 1];   // Δy_(t-j), j = 1..lag
            if (with_trend)
                X(r, n_cols - 1) = data_t(t);  // linear trend
            y_mat(r, 0) = dy[t - 1];           // Δy_t (response)
        }

        const matrix_t  Xt { X.transpose2() };
        const matrix_t  XtX { Xt * X };
        const matrix_t  beta { XtX.solve(Xt * y_mat) };
        data_t          rss { 0 };

        for (size_type r { 0 }; r < n_obs; ++r)  {
            data_t  pred { 0 };

            for (size_type c { 0 }; c < n_cols; ++c)
                pred += X(r, c) * beta(c, 0);

            const data_t    e { y_mat(r, 0) - pred };

            rss += e * e;
        }

        const data_t    sigma2 { rss / data_t(n_obs - n_cols) };

        // Var(β) = σ^2 · diag((XtX)^-1)[ylag_col]. Get just that one
        // diagonal entry by solving (XtX)·v = e_ylag for v (the ylag_col
        // column of (XtX)^-1) instead of inverting the whole matrix; since
        // (XtX)^-1 is symmetric, v's ylag_col-th entry is exactly the
        // diagonal entry needed.
        //
        matrix_t    e_ylag { long(n_cols), 1L, 0 };

        e_ylag(ylag_col, 0) = data_t(1);

        const matrix_t  inv_col { XtX.solve(e_ylag) };
        const data_t    se { std::sqrt(sigma2 * inv_col(ylag_col, 0)) };

        return (beta(ylag_col, 0) / se);
    }

    template<typename H>
    inline void
    do_adf_(const H &column_begin, size_type col_s)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s <= (params_.adf_lag + 2))
            throw DataFrameError(
                "StationaryCheckVisitor(ADF): Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        if constexpr (! is_md_)  {
            std::vector<data_t> y(col_s);

            for (size_type i { 0 }; i < col_s; ++i)
                y[i] = data_t(*(column_begin + i));
            adf_stat_ =
                do_adf_scalar_(y, params_.adf_lag, params_.adf_with_trend);
        }
        else  {
            // Same reasoning as do_kpss_'s MD path: the ADF regression
            // above is inherently single-series, so run it once per
            // dimension on that dimension's own extracted scalar column.
            //
            const size_type      ndim { column_begin->size() };
            std::vector<data_t>  dim_col(col_s);

            adf_stat_.resize(ndim);
            for (size_type d { 0 }; d < ndim; ++d)  {
                for (size_type i { 0 }; i < col_s; ++i)
                    dim_col[i] = data_t((*(column_begin + i))[d]);
                adf_stat_[d] =
                    do_adf_scalar_(dim_col, params_.adf_lag,
                                   params_.adf_with_trend);
            }
        }
    }

    const stationary_test       method_;
    const StationaryTestParams  params_;

    // In a KPSS test, a higher test statistic value (meaning a larger
    // calculated KPSS statistic) indicates a greater likelihood that the time
    // series is not stationary around a deterministic trend, while a lower
    // value suggests stationarity; essentially, you want a low KPSS test value
    // to conclude stationarity.
    //
    result_type                 kpss_val_ { };
    result_type                 kpss_stat_ { };

    // To interpret an ADF test statistic, compare its value to the critical
    // value at a chosen significance level (usually 0.05): if the test
    // statistic is less than the critical value, you reject the null
    // hypothesis and conclude that the time series is stationary; if it's
    // greater than the critical value, you fail to reject the null hypothesis,
    // indicating non-stationarity; a more negative ADF statistic signifies
    // stronger evidence against the null hypothesis (i.e., more likely
    // stationary).
    //
    result_type                 adf_stat_ { };
};

template<typename T, typename I = unsigned long>
using stac_v = StationaryCheckVisitor<T, I>;

// ----------------------------------------------------------------------------

// Two-sample Kolmogorov–Smirnov test
//
template<arithmetic T, typename I = unsigned long>
struct  KolmoSmirnovTestVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = double;

    template<typename K, typename H>
    inline void
    operator()(const K & /*idx_begin*/, const K & /*idx_end*/,
               const H &column1_begin, const H &column1_end,
               const H &column2_begin, const H &column2_end)  {

        const size_type col1_s {
            size_type(std::distance(column1_begin, column1_end))
        };
        const size_type col2_s {
            size_type(std::distance(column2_begin, column2_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col1_s < 4 || col2_s < 4)
            throw DataFrameError("KolmoSmirnovTestVisitor: "
                                 "Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        const auto      thread_level { ThreadGranularity::get_thread_level() };
        std::vector<T>  data1(column1_begin, column1_end);
        std::vector<T>  data2(column2_begin, column2_end);

        if (col1_s > ThreadPool::MUL_THR_THHOLD && thread_level > 2)
            ThreadGranularity::thr_pool_.parallel_sort(
                data1.begin(), data1.end());
        else
            std::sort(data1.begin(), data1.end());

        if (col2_s > ThreadPool::MUL_THR_THHOLD && thread_level > 2)
            ThreadGranularity::thr_pool_.parallel_sort(
                data2.begin(), data2.end());
        else
            std::sort(data2.begin(), data2.end());

        size_type   i { 0 }, j { 0 };
        result_type cdf1 { 0 }, cdf2 { 0 };
        result_type max_diff { 0 };

        while (i < col1_s && j < col2_s) [[likely]]  {
            const auto  &val1 { data1[i] };
            const auto  &val2 { data2[j] };

            if (val1 < val2)  {
                i += 1;
                cdf1 = result_type(i) / result_type(col1_s);
            }
            else if (val1 > val2)  {
                j += 1;
                cdf2 = result_type(j) / result_type(col2_s);
            }
            else [[unlikely]]  {
                i += 1;
                while (i < col1_s && data1[i] == val1) [[unlikely]]  i += 1;
                cdf1 = result_type(i) / result_type(col1_s);

                j += 1;
                while (j < col2_s && data2[j] == val2) [[unlikely]]  j += 1;
                cdf2 = result_type(j) / result_type(col2_s);
            }
            max_diff = std::max(max_diff, std::fabs(cdf1 - cdf2));
        }

        result_ = max_diff;

        // Now calculate p-value
        //
        const result_type    n {
            result_type(col1_s * col2_s) / result_type(col1_s + col2_s)
        };

        // The plain sqrt(n)*D lambda is a large-sample approximation that
        // is noticeably off for finite samples; the standard correction
        // (Stephens 1970 -- also what scipy.stats.ks_2samp and R's ks.test
        // use) adds a small sample-size-dependent term before squaring.
        // Confirmed against scipy: without this term, the p-value differs
        // from the correct asymptotic value by ~34% on a 50-vs-65-sample
        // test (0.0081 vs 0.0063).
        //
        const result_type    lambda {
            (std::sqrt(n) + result_type(0.12) +
             result_type(0.11) / std::sqrt(n)) * result_
        };
        const result_type    value { 2.0 * std::exp(-2.0 * lambda * lambda) };

        p_value_ = (value > 1.0) ? 1.0 : value;
    }

    inline void pre()  { result_ = -1; p_value_= -1; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }
    inline result_type get_p_value() const  { return (p_value_); }

    KolmoSmirnovTestVisitor()  {   }

private:

    result_type result_ { -1 };  // D-value
    result_type p_value_ { -1 }; // P-value
};

template<typename T, typename I = unsigned long>
using ks_test_v = KolmoSmirnovTestVisitor<T, I>;

// ----------------------------------------------------------------------------

// Mann-Whitney U test
//
template<arithmetic T, typename I = unsigned long>
struct  MannWhitneyUTestVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = double;

    template<typename K, typename H>
    inline void
    operator()(const K & /*idx_begin*/, const K & /*idx_end*/,
               const H &column1_begin, const H &column1_end,
               const H &column2_begin, const H &column2_end)  {

        const size_type col1_s {
            size_type(std::distance(column1_begin, column1_end))
        };
        const size_type col2_s {
            size_type(std::distance(column2_begin, column2_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col1_s < 4 || col2_s < 4)
            throw DataFrameError("MannWhitneyUTestVisitor: "
                                 "Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        using pvec_t = std::vector<std::pair<value_type, char>>;

        const auto      thread_level { ThreadGranularity::get_thread_level() };
        pvec_t          combined;
        const size_type com_s { col1_s + col2_s };

        combined.reserve(com_s);
        for (auto citer = column1_begin; citer < column1_end; ++citer)
            combined.push_back({ *citer, char(0) });
        for (auto citer = column2_begin; citer < column2_end; ++citer)
            combined.push_back({ *citer, char(1) });

        if ((col1_s + col2_s) > ThreadPool::MUL_THR_THHOLD && thread_level > 2)
            ThreadGranularity::thr_pool_.parallel_sort(
                combined.begin(), combined.end(),
                [] (auto lhs, auto rhs) -> bool  {
                    return (lhs.first < rhs.first);
                });
        else
            std::sort(combined.begin(), combined.end(),
                      [] (auto lhs, auto rhs) -> bool  {
                          return (lhs.first < rhs.first);
                      });

        // Calculate the rank
        //
        std::vector<result_type>    ranks(com_s, 0);

        {
            size_type   i { 0 };

            while (i < com_s) {
                size_type   j { i };

                while ((j + 1) < com_s &&
                       combined[j + 1].first == combined[i].first)
                    j += 1;

                // ranks are 1-based
                //
                const result_type   avg_rank { result_type(i + j + 2) / 2.0 };

                for (size_type k { i }; k <= j; ++k)
                    ranks[k] = avg_rank;
                i = j + 1;
            }
        }

        // Calculate rank sum for group 1
        //
        result_type  r1 { 0 };

        for (size_type i { 0 }; i < com_s; ++i) {
            if (combined[i].second == char(0))
                r1 += ranks[i];
        }

        // U statistics
        //
        u1_ = r1 - result_type(col1_s * (col1_s + 1)) / 2.0;
        u2_ = result_type(col1_s * col2_s) - u1_;
        result_ = std::min(u1_, u2_); // U

        // Mean and stdev of U
        //
        // The division by 12.0 in the formula for stdev comes from the
        // variance of the ranks used in the Mann-Whitney U test.
        //
        const result_type    mu_u { result_type(col1_s * col2_s) / 2.0 };
        const result_type    sigma_u {
            std::sqrt(result_type(col1_s * col2_s * (col1_s + col2_s + 1)) /
                      result_type(12))
        };

        zscore_ = (u1_ - mu_u) / sigma_u;
        p_val_ =
            2.0 *
            (1.0 - 0.5 * std::erfc(-std::fabs(zscore_) / std::numbers::sqrt2));

    }

    inline void pre()  { result_ = u1_ = u2_ = zscore_ = -1; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }
    inline result_type get_u1() const  { return (u1_); }
    inline result_type get_u2() const  { return (u2_); }
    inline result_type get_zscore() const  { return (zscore_); }
    inline result_type get_pvalue() const  { return (p_val_); }

    MannWhitneyUTestVisitor()  {   }

private:

    result_type result_ { -1 };  // U statistics
    result_type u1_ { -1 };      // U1 statistics
    result_type u2_ { -1 };      // U2 statistics
    result_type zscore_ { -1 };  // Z-score
    result_type p_val_ { -1 };   // Two-tailed p-value
};

template<typename T, typename I = unsigned long>
using mwu_test_v = MannWhitneyUTestVisitor<T, I>;

// ----------------------------------------------------------------------------

// Anderson Darling Test
//
template<arithmetic T, typename I = unsigned long>
struct  AndersonDarlingTestVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = double;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        const size_type col_s = std::distance(column_begin, column_end);

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 20)
            throw DataFrameError("AndersonDarlingTestVisitor: "
                                 "Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        // Test statistic explicitly depends on order statistics.
        //
        std::vector<value_type> sorted(column_begin, column_end);
        const auto              thread_level =
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level();

        if (thread_level > 2)
            ThreadGranularity::thr_pool_.parallel_sort(sorted.begin(),
                                                       sorted.end());
        else
            std::sort(sorted.begin(), sorted.end());

        ZScoreVisitor<T, I> zscore;

        zscore.pre();
        zscore(idx_begin, idx_end, sorted.begin(), sorted.end());
        zscore.post();

        std::vector<value_type> phi(col_s);
        auto                    lbd1 =
            [&phi, &z = std::as_const(zscore.get_result())]
            (auto begin, auto end) -> void  {
                for (size_type i { begin }; i < end; ++i)
                    phi[i] = normal_cdf_(z[i]);
            };

        if (thread_level > 2)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0), col_s, std::move(lbd1));

            for (auto &fut : futures)  fut.get();
        }
        else  {
            lbd1(size_type(0), col_s);
        }

        result_type a2 { 0 };
        auto        lbd2 =
            [&phi = std::as_const(phi), col_s]
            (auto begin, auto end) -> result_type  {
                result_type res { 0 };

                for (size_type i { begin }; i < end; ++i)
                    res += result_type(2 * i + 1) *
                           (std::log(phi[i]) +
                            std::log(1.0 - phi[col_s - 1 - i]));
                return (res);
            };

        if (thread_level > 2)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0), col_s, std::move(lbd2));

            for (auto &fut : futures)  a2 += fut.get();
        }
        else  {
            a2 = lbd2(size_type(0), col_s);
        }
        a2 = -result_type(col_s) - a2 / result_type(col_s);

        // These constants 4.0 and 25.0 come from a finite-sample correction
        // proposed by D.A. Stephens in his 1974 paper:
        //
        // "EDF Statistics for Goodness of Fit and Some Comparisons"
        // Journal of the American Statistical Association, Vol. 69, No. 347,
        // pp. 730–737.
        //
        result_ =
            a2 *
            result_type(1.0 + 4.0 /
                        result_type(col_s) - 25.0 / result_type(col_s * col_s));
        p_value_ = get_p_value_(result_);
    }

    inline void pre()  { result_ = p_value_ = 0; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }
    inline result_type get_p_value() const  { return (p_value_); }

    AndersonDarlingTestVisitor()  {   };

private:

    // Standard normal CDF using the error function
    //
    static inline value_type normal_cdf_(value_type x)  {

        return (T(0.5) * std::erfc(-x / T(std::numbers::sqrt2)));
    }

    static inline result_type get_p_value_(result_type a2)  {

        if (a2 < 0.2)
            return (1.0 - std::exp(-13.436 + 101.14 * a2 - 223.73 * a2 * a2));
        else if (a2 < 0.34)
            return (1.0 - std::exp(-8.318 + 42.796 * a2 - 59.938 * a2 * a2));
        else if (a2 < 0.6)
            return (std::exp(0.9177 - 4.279 * a2 - 1.38 * a2 * a2));
        else
            return (std::exp(1.2937 - 5.709 * a2 + 0.0186 * a2 * a2));
    }

    result_type result_ { 0 };  // A2*
    result_type p_value_ { 0 };
};

template<typename T, typename I = unsigned long>
using adar_test_v = AndersonDarlingTestVisitor<T, I>;

// ----------------------------------------------------------------------------

// Shapiro Wilk Test
//
template<arithmetic T, typename I = unsigned long>
struct  ShapiroWilkTestVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = double;

    template<typename K, typename H>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const H &column_begin, const H &column_end)  {

        const long  col_s { long(std::distance(column_begin, column_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 3)
            throw DataFrameError(
                "ShapiroWilkTestVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        // Test statistic explicitly depends on order statistics.
        //
        std::vector<value_type> sorted(column_begin, column_end);
        const auto              thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };

        if (thread_level > 2)
            ThreadGranularity::thr_pool_.parallel_sort(
                sorted.begin(), sorted.end());
        else
            std::sort(sorted.begin(), sorted.end());

        //
        // Algorithm AS R94, Journal of the Royal Statistical Society Series C
        // (Applied Statistics) vol. 44, no. 4, pp. 547-551 (1995).
        //

        result_ = p_value_ = 1;  // Stop the behaviour change 'feature'

        // Polynomial coefficients
        //
        constexpr result_type   c1[6] =
            { 0, 0.221157, -0.147981, -2.07119, 4.434685, -2.706056 };
        constexpr result_type   c2[6] =
            { 0, 0.042981, -0.293762, -1.752461, 5.682633, -3.582633 };

        std::vector<result_type>    a(col_s, 0);

        const long          n1 { col_s };
        result_type         w1 { 0 };
        const result_type   an { result_type(col_s) };

        // Calculate coefficients a[] for the test
        //
        if (col_s == 3)  {
            a[0] = M_SQRT1_2;
        }
        else  {
            const result_type   an25 { an + 0.25 };
            result_type         summ2 { 0 };

            for (long i { 1 }; i <= col_s; ++i) {
                auto    &val { a[i - 1] };

                val = ppnd7_((i - 0.375) / an25);
                summ2 += val * val;
            }
            summ2 *= 2.0;

            const result_type   ssumm2 { std::sqrt(summ2) };
            const result_type   rsn { 1.0 / std::sqrt(an) };
            const result_type   a1 { poly_(c1, 6, rsn) - a[0] / ssumm2 };
            result_type         fac { 0 };
            long                i1 { 0 };

            // Normalize a[]
            //
            if (col_s > 5)  {
                i1 = 3;

                const result_type   a2 { -a[1] / ssumm2 + poly_(c2, 6, rsn) };

                fac = std::sqrt((summ2 - 2.0 * a[0] * a[0] -
                                 2.0 * a[1] * a[1]) /
                                (1.0 - 2.0 * a1 * a1 - 2.0 * a2 * a2));
                a[1] = a2;
            }
            else  {
                i1 = 2;
                fac = std::sqrt((summ2 - 2.0 * a[0] * a[0]) /
                                (1.0  - 2.0 * a1 * a1));
            }
            a[0] = a1;
            for (long i { i1 }; i <= (col_s / 2); ++i)
                a[i - 1] /= -fac;
        }

        const long          ncens { col_s - n1 };
        const result_type   delta { ncens / an };

        // If W input as negative, calculate significance level of -W
        //
        if (result_ < 0)  {
            w1 = 1.0 + result_;
            return (l70_(w1, col_s, an, ncens, delta));

        }

        // Check for zero range
        //
        const result_type   range { sorted[n1 - 1] - sorted[0] };

        // Check for correct sort order on range - scaled X
        //
        result_type xx { sorted[0] / range };
        result_type sx { xx };
        result_type sa { -a[0] };
        long        j { col_s - 1 };

        for (long i { 2 }; i <= n1; ++i)  {
            const result_type   xi { sorted[i - 1] / range };

            sx += xi;
            if (i != j)  sa += sign_(1, i - j) * a[std::min(i, j) - 1];
            xx = xi;
            j -= 1;
        }

        // Calculate W statistic as squared correlation between data and
        // coefficients
        //
        sa /= n1;
        sx /= n1;

        result_type ssa { 0 };
        result_type sax { 0 };
        result_type ssx { 0 };

        j = col_s;
        for (long i { 1 }; i <= n1; ++i, --j)  {
            const result_type   asa {
                (i != j) ? sign_(1, i - j) * a[std::min(i, j) - 1] - sa : -sa
            };
            const result_type   xsx { sorted[i - 1] / range - sx };

            ssa += asa * asa;
            ssx += xsx * xsx;
            sax += asa * xsx;
        }

        // W1 equals (1-W) claculated to avoid excessive rounding error
        // for W very near 1 (a potential problem in very large samples)
        //
        const result_type   ssassx { std::sqrt(ssa * ssx) };

        w1 = (ssassx - sax) * (ssassx + sax) / (ssa * ssx);

        l70_(w1, col_s, an, ncens, delta);
    }

    inline void pre()  { result_ = p_value_ = 0; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }
    inline result_type get_p_value() const  { return (p_value_); }

    ShapiroWilkTestVisitor()  {   };

private:

    // Auxiliary procedure in algorithm AS 181, Journal of the Royal
    // Statistical Society Series C (Applied Statistics) vol. 31, no. 2,
    // pp. 176-180 (1982).
    //
    static inline result_type
    poly_(const result_type *cc, size_type nord, result_type x)  {

        result_type ret_val { cc[0] };

        if (nord == 1)  return (ret_val);

        size_type   n2 { 0 }, j { 0 };
        result_type p { x * cc[nord-1] };

        if (nord != 2)  {
            n2 = nord - 2;
            j = n2 + 1;

            for (size_type i { 1 }; i <= n2; ++i)  {
                p = (p + cc[j - 1]) * x;
                j -= 1;
            }
        }
        ret_val = ret_val + p;
        return (ret_val);
    }

    // Algorithm AS 241, Journal of the Royal Statistical Society Series C
    // (Applied Statistics) vol. 26, no. 3, pp. 118-121 (1977).
    //
    static inline result_type
    ppnd7_(result_type p)  {

        constexpr   result_type half { 0.5 };
        constexpr   result_type split1 { 0.425 };
        constexpr   result_type split2 { 5 };
        constexpr   result_type const1 { 0.180625 };
        constexpr   result_type const2 { 1.6 };
        constexpr   result_type a0 { 3.3871327179E+00 };
        constexpr   result_type a1 { 5.0434271938E+01 };
        constexpr   result_type a2 { 1.5929113202E+02 };
        constexpr   result_type a3 { 5.9109374720E+01 };
        constexpr   result_type b1 { 1.7895169469E+01 };
        constexpr   result_type b2 { 7.8757757664E+01 };
        constexpr   result_type b3 { 6.7187563600E+01 };
        constexpr   result_type c0 { 1.4234372777E+00 };
        constexpr   result_type c1 { 2.7568153900E+00 };
        constexpr   result_type c2 { 1.3067284816E+00 };
        constexpr   result_type c3 { 1.7023821103E-01 };
        constexpr   result_type d1 { 7.3700164250E-01 };
        constexpr   result_type d2 { 1.2021132975E-01 };
        constexpr   result_type e0 { 6.6579051150E+00 };
        constexpr   result_type e1 { 3.0812263860E+00 };
        constexpr   result_type e2 { 4.2868294337E-01 };
        constexpr   result_type e3 { 1.7337203997E-02 };
        constexpr   result_type f1 { 2.4197894225E-01 };
        constexpr   result_type f2 { 1.2258202635E-02 };

        result_type normal_dev { 0 };
        result_type q { 0 };
        result_type r { 0 };

        q = p - half;
        if (std::abs(q) <= split1)  {
            r = const1 - q * q;
            normal_dev = q * (((a3 * r + a2) * r + a1) * r + a0) /
                         (((b3 * r + b2) * r + b1) * r + 1.0);
            return (normal_dev);
        }

        if (q < 0)
            r = p;
        else
            r = 1.0 - p;

        if (r <= 0)  {
            normal_dev = 0;
            return (normal_dev);
        }
        r = std::sqrt(-std::log(r));
        if (r <= split2)  {
            r = r - const2;
            normal_dev =
                (((c3 * r + c2) * r + c1) * r + c0) /
                ((d2 * r + d1) * r + 1.0);
        }
        else  {
            r = r - split2;
            normal_dev =
                (((e3 * r + e2) * r + e1) * r + e0) /
                ((f2 * r + f1) * r + 1.0);
        }
        if (q < 0)  { normal_dev = -normal_dev; }
        return (normal_dev);
    }

    // Algorithm AS 66, Journal of the Royal Statistical Society Series C
    // (Applied Statistics) vol. 22, pp. 424-427 (1973).
    //
    static inline result_type
    alnorm_(result_type x, bool upper)  {

        constexpr result_type   half { 0.5 };
        constexpr result_type   con { 1.28 };
        constexpr result_type   ltone { 7.0 };
        constexpr result_type   utzero { 18.66 };
        constexpr result_type   p { 0.398942280444 };
        constexpr result_type   q { 0.39990348504 };
        constexpr result_type   r { 0.398942280385 };
        constexpr result_type   a1 { 5.75885480458 };
        constexpr result_type   a2 { 2.62433121679 };
        constexpr result_type   a3 { 5.92885724438 };
        constexpr result_type   b1 { -29.8213557807 };
        constexpr result_type   b2 { 48.6959930692 };
        constexpr result_type   c1 { -3.8052E-8 };
        constexpr result_type   c2 { 3.98064794E-4 };
        constexpr result_type   c3 { -0.151679116635 };
        constexpr result_type   c4 { 4.8385912808 };
        constexpr result_type   c5 { 0.742380924027 };
        constexpr result_type   c6 { 3.99019417011 };
        constexpr result_type   d1 { 1.00000615302 };
        constexpr result_type   d2 { 1.98615381364 };
        constexpr result_type   d3 { 5.29330324926 };
        constexpr result_type   d4 { -15.1508972451 };
        constexpr result_type   d5 { 30.789933034 };
        result_type             alnorm {0 };
        result_type             z { x };
        result_type             y { 0 };
        bool                    up { upper };

        if (z < 0)  {
            up = ! up;
            z = -z;
        }
        if (z <= ltone || (up && z <= utzero))  {
            y = half * z * z;
            if (z > con)  {
                alnorm =
                    r * std::exp(-y) /
                    (z + c1 + d1 /
                     (z + c2 + d2 /
                      (z + c3 + d3 /
                       (z + c4 + d4 /
                        (z + c5 + d5 / (z + c6))))));
            }
            else  {
                alnorm =
                    half - z *
                    (p - q * y / (y + a1 + b1 / (y + a2 + b2 / (y + a3))));
            }
        }
        else  {
            alnorm = 0;
        }

        if (! up)  { alnorm = 1.0 - alnorm; }
        return (alnorm);
    }

    static inline long
    sign_(long x, long y)  { return (y < 0 ? -std::labs(x) : std::labs(x)); }

    // The goto section of the algorithm
    //
    inline void
    l70_(result_type w1,
         long col_s,
         result_type an,
         long ncens,
         result_type delta)  {

        constexpr result_type   bf1 { 0.8378 };
        constexpr result_type   pi6 { 1.909859 };
        constexpr result_type   z90 { 1.2816 };
        constexpr result_type   z95 { 1.6449 };
        constexpr result_type   xx90 { 0.556 };
        constexpr result_type   z99 { 2.3263 };
        constexpr result_type   zss { 0.56268 };
        constexpr result_type   zm { 1.7509 };
        constexpr result_type   xx95 { 0.622 };
        constexpr result_type   stqr { 1.047198 };

        // polynomial coefficients
        //
        constexpr result_type   g[2] = { -2.273, 0.459 };
        constexpr result_type   c3[4] =
            { 0.544, -0.39978, 0.025054, -6.714e-4 };
        constexpr result_type   c4[4] =
            { 1.3822, -0.77857, 0.062767, -0.0020322 };
        constexpr result_type   c5[4] =
            { -1.5861, -0.31082, -0.083751, 0.0038915 };
        constexpr result_type   c6[3] = { -0.4803, -0.082676, 0.0030302 };
        constexpr result_type   c7[2] = { 0.164, 0.533 };
        constexpr result_type   c8[2] = { 0.1736, 0.315 };
        constexpr result_type   c9[2] = { 0.256, -0.00635 };

        result_ = 1.0 - w1;

        // Calculate significance level for W

        if (col_s == 3)  {  // exact P value
            p_value_ = pi6 * (std::asin(std::sqrt(result_)) - stqr);
            return;
        }

        result_type         y { std::log(w1) };
        const result_type   xx2 { std::log(an) };
        result_type         m { 0 };
        result_type         s { 1 };

        if (col_s <= 11)  {
            const result_type   gamma { poly_(g, 2, an) };

            if (y >= gamma)  {
                p_value_ = std::numeric_limits<result_type>::epsilon();
                return;
            }
            y = -std::log(gamma - y);
            m = poly_(c3, 4, an);
            s = std::exp(poly_(c4, 4, an));
        }
        else  {  // col_s >= 12
            m = poly_(c5, 4, xx2);
            s = std::exp(poly_(c6, 3, xx2));
        }

        if (ncens > 0)  {  // <==>  col_s > n1
            // Censoring by proportion NCENS/N.
            // Calculate mean and sd of normal equivalent deviate of W.
            //
            const result_type   ld { -std::log(delta) };
            const result_type   bf { 1.0 + xx2 * bf1 };
            result_type         r__1 { std::pow(xx90, xx2)};
            const result_type   z90f {
                z90 + bf * std::pow(poly_(c7, 2, r__1), ld)
            };

            r__1 = pow(xx95, xx2);

            const result_type   z95f {
                z95 + bf * std::pow(poly_(c8, 2, r__1), ld)
            };
            const result_type   z99f {
                z99 + bf * std::pow(poly_(c9, 2, xx2), ld)
            };

            // Regress Z90F,...,Z99F on normal deviates Z90,...,Z99 to get
            // pseudo-mean and pseudo-sd of z as the slope and intercept
            //
            const result_type   zfm { (z90f + z95f + z99f) / 3.0 };
            const result_type   zsd {
                (z90 * (z90f - zfm) +
                 z95 * (z95f - zfm) + z99 * (z99f - zfm)) / zss
            };
            const result_type   zbar { zfm - zsd * zm };

            m += zbar * s;
            s *= zsd;
        }
        p_value_ = alnorm_((y - m) / s, true);
    }

    result_type result_ { 0 };  // W
    result_type p_value_ { 0 };
};

template<typename T, typename I = unsigned long>
using swilk_test_v = ShapiroWilkTestVisitor<T, I>;

// ----------------------------------------------------------------------------

// Cramer-von Mises Test
//
template<arithmetic T, typename I = unsigned long>
struct  CramerVonMisesTestVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = double;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        const long  col_s { long(std::distance(column_begin, column_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 3)
            throw DataFrameError("CramerVonMisesTestVisitor: "
                                 "Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        StdVisitor<T, I>    sv;

        sv.pre();
        sv(idx_begin, idx_end, column_begin, column_end);
        sv.post();

        std::vector<value_type> sorted(column_begin, column_end);
        const auto              thread_level =
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level();
        result_type             sum { 0 };
        auto                    lbd =
            [&sorted, col_s,
             mean = sv.get_mean(), stdev = sv.get_result()]
            (auto begin, auto end) -> result_type {
                result_type res { 0 };

                for (long i { begin }; i < end; ++i)  {
                    const result_type   fi =
                        normal_cdf_(sorted[i], mean, stdev);
                    const result_type   ui =
                        (2.0 * (i + 1) - 1.0) / (2.0 * col_s);

                    res += ((fi - ui) * (fi - ui));
                }
                return (res);
            };

        if (thread_level > 2)  {
            ThreadGranularity::thr_pool_.parallel_sort(sorted.begin(),
                                                       sorted.end());

           auto    futures =
               ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                   long(0), col_s, std::move(lbd));

            for (auto &fut : futures)  sum += fut.get();
        }
        else  {
            std::sort(sorted.begin(), sorted.end());
            sum = lbd(long(0), col_s);
        }

        result_ = sum + 1.0 / (12.0 * col_s);
        p_value_ = get_p_value_(result_);
    }

    inline void pre()  { result_ = p_value_ = 0; }
    inline void post()  {  }
    inline result_type get_result() const  { return (result_); }
    inline result_type get_p_value() const  { return (p_value_); }

    CramerVonMisesTestVisitor()  {   };

private:

    // Standard normal CDF using the error function
    //
    static inline result_type
    normal_cdf_(result_type x, value_type mean, value_type stdev)  {

        return (0.5 * std::erfc(-(x - mean) / (stdev * std::numbers::sqrt2)));
    }

    static inline result_type get_p_value_(result_type w2)  {

        // Approximation formula (Anderson 1962)
        //
        if (w2 < 0.0275)  return (1.0);
        else if (w2 < 0.051)  return (0.99);
        else if (w2 < 0.092)  return (0.95);
        else if (w2 < 0.126)  return (0.9);
        else if (w2 < 0.152)  return (0.85);
        else if (w2 < 0.195)  return (0.8);
        else if (w2 < 0.220)  return (0.75);
        else if (w2 < 0.275)  return (0.7);
        else if (w2 < 0.319)  return (0.65);
        else if (w2 < 0.347)  return (0.6);
        else if (w2 < 0.393)  return (0.55);
        else if (w2 < 0.429)  return (0.5);
        else return (std::numeric_limits<result_type>::epsilon());
    }

    result_type result_ { 0 };  // W^2
    result_type p_value_ { 0 };
};

template<typename T, typename I = unsigned long>
using cvonm_test_v = CramerVonMisesTestVisitor<T, I>;

// ----------------------------------------------------------------------------

template<std::floating_point T,
         typename I = unsigned long,
         typename L = std::string,
         std::size_t A = 0>
struct  DivideToBinsVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    using label_type = L;
    using pair_t = std::pair<T, T>;
    using result_type =
        std::vector<pair_t, typename allocator_declare<pair_t, A>::type>;
    using label_vec_t =
        std::vector<label_type,
                    typename allocator_declare<label_type, A>::type>;

    template<typename K, typename H>
    inline void
    operator() (const K &/*idx_begin*/, const K &/*idx_end*/,
                const H &column_begin, const H &column_end)  {

        const size_type col_s = std::distance(column_begin, column_end);

        if (bins_ > 0 && bins_list_.empty())  {  // Equal-width bins
#ifdef HMDF_SANITY_EXCEPTIONS
            if (bins_ >= col_s)
                throw DataFrameError("DivideToBinsVisitor: "
                                     "Number of bins must be < data size");
            if (bins_ < 2)
                throw DataFrameError("DivideToBinsVisitor: "
                                     "Number of bins must be > 1");
#endif // HMDF_SANITY_EXCEPTIONS

            const auto  [min_val, max_val] {
                std::minmax_element(column_begin, column_end)
            };

            // Extend range slightly to include min/max in the first/last bin
            //
            const auto  range_extension { (*max_val - *min_val) * T(0.0001) };
            const auto  adjusted_min { *min_val - range_extension };
            const auto  adjusted_max { *max_val + range_extension };
            const auto  bin_width = (adjusted_max - adjusted_min) / T(bins_);

            bins_list_.resize(bins_ + 1);
            for (size_type i { 0 }; i <= bins_; ++i)
                bins_list_[i] =
                    value_type(size_type(adjusted_min + T(i) * bin_width));
        }

        const bool  labels { ! input_lbls_.empty() };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (labels && (input_lbls_.size() != (bins_list_.size() - 1)))
            throw DataFrameError("DivideToBinsVisitor: "
                                 "Number of bins must be = number of labels");
#endif // HMDF_SANITY_EXCEPTIONS

        result_.reserve(col_s);
        if (labels)  labels_.reserve(col_s);
        for (size_type i { 0 }; i < col_s; ++i)  {
            const auto  val { *(column_begin + i) };
            bool        assigned { false };

            for (size_type j { 0 }; j < bins_list_.size() - 1; ++j)  {
                const auto   lower_bound { bins_list_[j] };
                const auto   upper_bound { bins_list_[j + 1] };

                // Special handling for the first interval if include_lowest
                // is true
                //
                if (include_lowest_ && j == 0)  {
                    if (right_)  {  // [lower, upper]
                        if (val >= lower_bound && val <= upper_bound)  {
                            result_.emplace_back(lower_bound, upper_bound);
                            if (labels)  labels_.emplace_back(input_lbls_[j]);
                            assigned = true;
                            break;
                        }
                    }
                    else  {  // [lower, upper)
                        if (val >= lower_bound && val < upper_bound)  {
                            result_.emplace_back(lower_bound, upper_bound);
                            if (labels)  labels_.emplace_back(input_lbls_[j]);
                            assigned = true;
                            break;
                        }
                    }
                }
                else  {  // Standard interval handling
                    if (right_)  {  // (lower, upper]
                        if (val > lower_bound && val <= upper_bound)  {
                            result_.emplace_back(lower_bound, upper_bound);
                            if (labels)  labels_.emplace_back(input_lbls_[j]);
                            assigned = true;
                            break;
                        }
                    }
                    else  {  // [lower, upper)
                        if (val >= lower_bound && val < upper_bound)  {
                            result_.emplace_back(lower_bound, upper_bound);
                            if (labels)  labels_.emplace_back(input_lbls_[j]);
                            assigned = true;
                            break;
                        }
                    }
                }
            }
            if (! assigned)  {
                result_.emplace_back(std::numeric_limits<T>::quiet_NaN(),
                                     std::numeric_limits<T>::quiet_NaN());
                if (labels)  labels_.emplace_back("~N/A~");
            }
        }
    }

    inline void pre()  { result_.clear(); labels_.clear(); }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline const label_vec_t &get_labels() const  { return (labels_); }
    inline label_vec_t &get_labels()  { return (labels_); }

    explicit
    DivideToBinsVisitor(size_type bins,
                        label_vec_t &&labels = {  },
                        bool right = true,
                        bool include_lowest = false)
        : input_lbls_(labels),
          bins_(bins),
          right_(right),
          include_lowest_(include_lowest)  {   }

    explicit
    DivideToBinsVisitor(std::vector<value_type> &&edges,
                        label_vec_t &&labels = {  },
                        bool right = true,
                        bool include_lowest = false)
        : bins_list_(edges),
          input_lbls_(labels),
          bins_(0),
          right_(right),
          include_lowest_(include_lowest)  {   }

    DivideToBinsVisitor() = delete;
    DivideToBinsVisitor(const DivideToBinsVisitor &) = default;
    DivideToBinsVisitor(DivideToBinsVisitor &&) = default;
    DivideToBinsVisitor &operator= (const DivideToBinsVisitor &) = default;
    DivideToBinsVisitor &operator= (DivideToBinsVisitor &&) = default;
    ~DivideToBinsVisitor() = default;

private:

    result_type             result_ { };
    label_vec_t             labels_ { };
    std::vector<value_type> bins_list_ { };
    const label_vec_t       input_lbls_;
    const size_type         bins_;
    const bool              right_;
    const bool              include_lowest_;
};

template<std::floating_point T,
         typename I = unsigned long,
         typename L = std::string,
         std::size_t A = 0>
using cut_v = DivideToBinsVisitor<T, I, L, A>;

// ----------------------------------------------------------------------------

template<std::floating_point T,
         typename I = unsigned long,
         typename L = std::string,
         std::size_t A = 0>
struct  DivideToQuantilesVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    using label_type = L;
    using pair_t = std::pair<T, T>;
    using result_type =
        std::vector<pair_t, typename allocator_declare<pair_t, A>::type>;
    using label_vec_t =
        std::vector<label_type,
                    typename allocator_declare<label_type, A>::type>;

    template<typename K, typename H>
    inline void
    operator() (const K &/*idx_begin*/, const K &/*idx_end*/,
                const H &column_begin, const H &column_end)  {

        const size_type         col_s = std::distance(column_begin, column_end);
        std::vector<value_type> sorted(column_begin, column_end);
        const auto              thread_level =
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level();

        if (thread_level > 2)
            ThreadGranularity::thr_pool_.parallel_sort(
                sorted.begin(), sorted.end());
        else
            std::sort(sorted.begin(), sorted.end());


        const bool  labels { ! input_lbls_.empty() };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 4)
            throw DataFrameError("DivideToQuantilesVisitor: "
                                 "Input column is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        std::vector<value_type> edges;

        result_.resize(col_s);
        if (labels)  labels_.resize(col_s);
        if (quantiles_ > 0)  {  // Number of Q's
#ifdef HMDF_SANITY_EXCEPTIONS
            if (quantiles_ < 2)
                throw DataFrameError("DivideToQuantilesVisitor: "
                                     "Number of quantiles must be > 1");
            if (labels && input_lbls_.size() != quantiles_)
                throw DataFrameError("DivideToQuantilesVisitor: "
                                     "Number of quantiles must be == number "
                                     "of labels");
#endif // HMDF_SANITY_EXCEPTIONS

            edges.resize(quantiles_ + 1);
            for (size_type i { 0 }; i <= quantiles_; ++i)
                edges[i] = percentile_(sorted, T(i) / T(quantiles_), col_s);

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  val = *(column_begin + i);
                size_type   bin =
                    (std::upper_bound(edges.begin(), edges.end(), val) -
                     edges.begin()) - 1;

                if (bin == quantiles_)
                    bin = quantiles_ - 1;
                result_[i] = { edges[bin], edges[bin + 1] };
                if (labels)  labels_[i] = input_lbls_[bin];
            }
        }
        else  {  // Explicit quantiles
#ifdef HMDF_SANITY_EXCEPTIONS
            if (labels && input_lbls_.size() != (quantiles_list_.size() - 1))
                throw DataFrameError("DivideToQuantilesVisitor: "
                                     "Number of labels must be == number "
                                     "of quantiles - 1");
#endif // HMDF_SANITY_EXCEPTIONS

            edges.resize(quantiles_list_.size());
            for (size_type i { 0 }; const auto q : quantiles_list_)
                edges[i++] = percentile_(sorted, q, col_s);

            for (size_type i { 0 }; i < col_s; ++i)  {
                const auto  val = *(column_begin + i);
                size_type   bin =
                    (std::upper_bound(edges.begin(), edges.end(), val) -
                     edges.begin()) - 1;

                if (bin == quantiles_list_.size() - 1)
                    bin = quantiles_list_.size() - 2;
                result_[i] = { edges[bin], edges[bin + 1] };
                if (labels)  labels_[i] = input_lbls_[bin];
            }
        }
    }

    inline void pre()  { result_.clear(); labels_.clear(); }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }
    inline const label_vec_t &get_labels() const  { return (labels_); }
    inline label_vec_t &get_labels()  { return (labels_); }

    explicit
    DivideToQuantilesVisitor(size_type quantiles, label_vec_t &&labels = {  })
        : input_lbls_(labels),
          quantiles_(quantiles)  {   }

    explicit
    DivideToQuantilesVisitor(std::vector<value_type> &&quantiles,
                             label_vec_t &&labels = {  })
        : quantiles_list_(quantiles),
          input_lbls_(labels),
          quantiles_(0)  {   }

    DivideToQuantilesVisitor() = delete;
    DivideToQuantilesVisitor(const DivideToQuantilesVisitor &) = default;
    DivideToQuantilesVisitor(DivideToQuantilesVisitor &&) = default;
    DivideToQuantilesVisitor &
    operator= (const DivideToQuantilesVisitor &) = default;
    DivideToQuantilesVisitor &
    operator= (DivideToQuantilesVisitor &&) = default;
    ~DivideToQuantilesVisitor() = default;

private:

    inline static value_type
    percentile_(const std::vector<value_type> &data,
                value_type q,
                size_type col_s)  {

        const value_type    pos = q * T(col_s - 1);
        const size_type     idx = static_cast<size_type>(pos);
        const value_type    frac = pos - T(idx);

        if (idx < (col_s - 1))
            return (data[idx] * (1 - frac) + data[idx + 1] * frac);
        return (data.back());
    }

    result_type             result_ { };
    label_vec_t             labels_ { };
    std::vector<value_type> quantiles_list_ { };
    const label_vec_t       input_lbls_;
    const size_type         quantiles_;
};

template<std::floating_point T,
         typename I = unsigned long,
         typename L = std::string,
         std::size_t A = 0>
using qcut_v = DivideToQuantilesVisitor<T, I, L, A>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  ConfIntervalVisitor   {

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type  = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_,
                                    std::pair<data_t, data_t>,
                                    std::pair<std::vector<data_t>,
                                              std::vector<data_t>>>;
    using stats_t =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end) {

        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 4)
            throw DataFrameError("ConfIntervalVisitor: "
                                 "Input column is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        StdVisitor<T, I>    sv;

        sv.pre();
        sv(idx_begin, idx_end, column_begin, column_end);
        sv.post();

        error_m_ = (sv.get_result() * data_t(z_score_(clvl_))) /
                   data_t(std::sqrt(double(col_s)));
        upper_bound_ = sv.get_mean() + error_m_;
        lower_bound_ = sv.get_mean() - error_m_;
    }

    inline void pre()  {

        if constexpr (! is_md_)  {
            upper_bound_ = lower_bound_ = error_m_ = 0;
        }
        else  {
            upper_bound_.clear();
            lower_bound_.clear();
            error_m_.clear();
        }
    }
    inline void post()  {  }
    inline const stats_t &get_error_margin() const  { return (error_m_); }
    inline stats_t &get_error_margin()  { return (error_m_); }
    inline result_type get_result() const  {

        return (result_type { lower_bound_, upper_bound_ });
    }

    explicit
    ConfIntervalVisitor (double conf_level = 0.95) // 95% confidence level
        : clvl_ (conf_level)  {

#ifdef HMDF_SANITY_EXCEPTIONS
        if (clvl_ < 0.8 || clvl_ > 0.999)
            throw DataFrameError("ConfIntervalVisitor: "
                "Confidence level must be between 80% and 99.9% inclusive");
#endif // HMDF_SANITY_EXCEPTIONS
    }

private:

    static inline double
    z_score_(double confidence_level)  {

        const static std::map<double, double>    z_table {
            { 0.80, 1.2816 },
            { 0.85, 1.4395 },
            { 0.90, 1.6449 },
            { 0.95, 1.96 },
            { 0.98, 2.3263 },
            { 0.99, 2.5758 },
            { 0.999, 3.2905 }
        };

        const auto  it = z_table.find(confidence_level);

        if (it != z_table.end()) [[likely]]
            return (it->second);

        auto        low_it { z_table.lower_bound(confidence_level) };
        const auto  high_it { z_table.upper_bound(confidence_level) };

        if (low_it != z_table.end() &&
            high_it != z_table.end() &&
            low_it != z_table.begin())  { [[likely]]
            --low_it;
            return (low_it->second + ((confidence_level - low_it->first) /
                                      (high_it->first - low_it->first)) *
                    (high_it->second - low_it->second));
        }
        return (std::numeric_limits<double>::quiet_NaN());
    }

    stats_t         upper_bound_ { };
    stats_t         lower_bound_ { };
    stats_t         error_m_ { };
    const double    clvl_;
};

template<typename T, typename I = unsigned long>
using coni_v = ConfIntervalVisitor<T, I>;

// ----------------------------------------------------------------------------

template<typename T, typename I = unsigned long>
struct  CoeffVariationVisitor   {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type  = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    template <typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end) {

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type col_s {
            size_type(std::distance(column_begin, column_end))
        };

        if (col_s < 4)
            throw DataFrameError("CoeffVariationVisitor: "
                                 "Input column is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        StdVisitor<T, I>    sv;

        sv.pre();
        sv(idx_begin, idx_end, column_begin, column_end);
        sv.post();

        result_ = sv.get_result() / sv.get_mean();
    }

    inline void pre()  {

        if constexpr (is_md_)  result_.clear();
        else  result_ = 0;
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

private:

    result_type result_ { };
};

template<arithmetic T, typename I = unsigned long>
using cffv_v = CoeffVariationVisitor<T, I>;

// ----------------------------------------------------------------------------

// Chi-squared test
//
template<typename T, typename I = unsigned long>
struct  ChiSquaredTestVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    using data_t =
        typename std::conditional_t<! is_md_,
                                    lazy_type<T>,
                                    value_type_of<T>>::type;

public:

    using value_type = T;
    using index_type = I;
    using size_type  = std::size_t;
    using result_type =
        typename std::conditional_t<! is_md_, data_t, std::vector<data_t>>;

    template<typename K, typename H>
    inline void
    operator()(const K & /*idx_begin*/, const K & /*idx_end*/,
               const H &observed_begin, const H &observed_end,
               const H &expected_begin, const H &expected_end)  {

        const size_type col_s {
            size_type(std::distance(observed_begin, observed_end))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type col2_s {
            size_type(std::distance(expected_begin, expected_end))
        };

        if (col_s < 4 || col2_s < 4)
            throw DataFrameError("ChiSquaredTestVisitor: "
                                 "Time-series is too short");
        if (col_s != col2_s)
            throw DataFrameError("ChiSquaredTestVisitor: "
                                 "Observed and expected time-series must "
                                 "have the same length");
#endif // HMDF_SANITY_EXCEPTIONS

        const auto  thread_level {
            (col_s < ThreadPool::MUL_THR_THHOLD)
                ? 0L : ThreadGranularity::get_thread_level()
        };
        auto        lbd =
            [observed_begin = std::as_const(observed_begin),
             expected_begin = std::as_const(expected_begin)]
            (auto begin, auto end) -> result_type {
                result_type res;

                if constexpr (! is_md_)  {  // Scalar path
                    res = 0;
                    for (size_type i { begin }; i < end; ++i)  {
                        const result_type   expt { *(expected_begin + i) };

                        if (expt == result_type(0))  continue;

                        const result_type   diff {
                            *(observed_begin + i) - expt
                        };

                        res += (diff * diff) / expt;
                    }
                    return res;
                }
                else  {  // MD path
                    const size_type dim { expected_begin->size() };

                    res.resize(dim, 0);
                    for (size_type i { begin }; i < end; ++i)  {
                        const auto  &expt { *(expected_begin + i) };
                        const auto  &obsv { *(observed_begin + i) };

                        for (size_type j { 0 }; j < dim; ++j)  {
                            if (expt[j] == data_t(0))  continue;

                            const data_t    diff { obsv[j] - expt[j] };

                            res[j] += (diff * diff) / expt[j];
                        }
                    }
                }
                return (res);
            };

        if (thread_level > 2)  {
            auto    futures =
                ThreadGranularity::thr_pool_.parallel_loop<value_type>(
                    size_type(0), col_s, std::move(lbd));

            if constexpr (is_md_)
                result_.resize(expected_begin->size(), 0);
            for (auto &fut : futures)  result_ += fut.get();
        }
        else  {
            result_ = lbd(size_type(0), col_s);
        }
    }

    inline void pre()  {

        if constexpr (! is_md_)
            result_ = 0;
        else
            result_.clear();  // will be re-sized in operator()
    }
    inline void post()  {  }
    inline const result_type &get_result() const  { return (result_); }
    inline result_type &get_result()  { return (result_); }

    inline result_type get_p_value(size_type deg_of_freedom) const  {

        if constexpr (! is_md_)  {
            const result_type   dof  { result_type(deg_of_freedom) };
            const result_type   val  {
                (result_ - dof) / std::sqrt(T(2.0) * dof)
            };
            return (T(0.5) * std::erfc(val / T(M_SQRT2)));
        }
        else  {
            const data_t    dof { data_t(deg_of_freedom) };
            result_type     p_vals;

            p_vals.resize(result_.size());
            for (size_type i { 0 }; const data_t chi : result_)  {
                const data_t    val {
                    (chi - dof) / std::sqrt(data_t(2.0) * dof)
                };

                p_vals[i++] = data_t(0.5) * std::erfc(val / data_t(M_SQRT2));
            }
            return (p_vals);
        }
    }
    inline result_type
    get_p_value(const std::vector<size_type> &dofs) const requires is_md_  {

        result_type p_vals;

        p_vals.resize(result_.size());
        for (size_type j { 0 }; j < result_.size(); ++j)  {
            const data_t    dof { data_t(dofs[j]) };
            const data_t    val {
                (result_[j] - dof) / std::sqrt(data_t(2.0) * dof)
            };

            p_vals[j] = data_t(0.5) * std::erfc(val / data_t(M_SQRT2));
        }
        return (p_vals);;
    }

private:

    result_type result_ { };  // Chi squared
};

template<typename T, typename I = unsigned long>
using chis_test_v = ChiSquaredTestVisitor<T, I>;

// ----------------------------------------------------------------------------

// Jarque-Bera Test for Normality
//
template<arithmetic T, typename I = unsigned long>
struct  JarqueBeraTestVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    using result_type = double;
    using data_t = double;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        const size_type col_s {
            size_type(std::min(std::distance(idx_begin, idx_end),
                               std::distance(column_begin, column_end)))
        };

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 8)
            throw DataFrameError(
                "JarqueBeraTestVisitor: Time-series is too short");
#endif // HMDF_SANITY_EXCEPTIONS

        // Single-pass accumulation of skew and excess kurtosis.
        //
        // NOTE: stats_ is always StatsVisitor<double, I> regardless of T.
        //       If T is an integral type, accumulating the higher moments in
        //       T would silently truncate every intermediate division
        //       (StatsVisitor's recurrence divides by n_ in value_type), and
        //       produce garbage skew/kurtosis instead of an error.  We avoid
        //       that entirely by always feeding double-converted values into
        //       a double-typed accumulator, one element at a time.
        //
        auto    idx_it { idx_begin };
        auto    col_it { column_begin };

        stats_.pre();
        for (size_type i { 0 }; i < col_s; ++i, ++idx_it, ++col_it)
            stats_(*idx_it, static_cast<data_t>(*col_it));
        stats_.post();

        const result_type   data_s { result_type(stats_.get_count()) };
        const result_type   var { stats_.get_variance() };

        // Degenerate (zero-variance / constant) input makes both skewness
        // and kurtosis mathematically 0/0.  A constant series has no
        // asymmetry and no tail behaviour to speak of, so we define both as
        // 0 rather than propagating NaN through the rest of the pipeline.
        //
        if (var <= result_type(0) || ! std::isfinite(var)) [[unlikely]]  {
            skew_ = 0;
            xkurt_ = 0;
        }
        else  {
            skew_ = stats_.get_skew();
            xkurt_ = stats_.get_kurtosis();   // excess kurtosis
        }

        result_  = (data_s / 6.0) * (skew_ * skew_ + (xkurt_ * xkurt_) / 4.0);

        // χ²(2) survival function: p = exp(-JB/2) — exact for 2 d.o.f.
        //
        p_value_ = std::exp(-result_ / 2.0);
    }

    inline void pre()  {

        result_ = p_value_ = skew_ = xkurt_ = 0;
        stats_.pre();
    }
    inline void post()  {  }

    // Returns the JB test statistic (χ^2 under H0).
    //
    inline result_type get_result()  const  { return (result_); }

    // Returns the p-value of the test. Small values give evidence against
    // the null hypothesis of normality.
    //
    inline result_type get_p_value() const  { return (p_value_); }

    // Returns the sample skewness used in the computation.
    //
    inline result_type get_skewness() const  { return (skew_); }

    // Returns the sample excess kurtosis used in the computation.
    //
    inline result_type
    get_excess_kurtosis() const  { return (xkurt_); }

    explicit
    JarqueBeraTestVisitor(bool skipnan = false) : stats_(skipnan)  {   }

private:

    StatsVisitor<data_t, I>  stats_ { };
    result_type              result_ { 0 };
    result_type              p_value_ { 0 };
    result_type              skew_ { 0 };
    result_type              xkurt_ { 0 };
};

template<typename T, typename I = unsigned long>
using jb_test_v = JarqueBeraTestVisitor<T, I>;

// ----------------------------------------------------------------------------

// Ljung-Box Test for Residual Autocorrelation
//
template<arithmetic T, typename I = unsigned long>
struct  LjungBoxTestVisitor  {

    DEFINE_VISIT_BASIC_TYPES

    using result_type = double;
    using data_t = double;
    using vec_result_type = std::vector<result_type>;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < max_lag_ + 3)
            throw DataFrameError(
                "LjungBoxTestVisitor: Time-series is too short for the "
                "requested number of lags");
        if (max_lag_ < 1)
            throw DataFrameError(
                "LjungBoxTestVisitor: max_lag must be >= 1");
#endif // HMDF_SANITY_EXCEPTIONS

        // 1. Compute the sample mean (needed for lag-0 variance below)
        //
        data_t  mean { 0 };

        for (size_type i { 0 }; i < col_s; ++i)
            mean += *(column_begin + i);
        mean /= static_cast<data_t>(col_s);

        // 2. Compute lag-0 variance (denominator of all &rho;&#770;̂(k))
        //    using the biased estimator: Σ(xᵢ − x̄)<sup>2</sup> / n
        //    This matches the convention in Ljung & Box (1978) and
        //    produces the same p^ that the ACF plot in standard
        //    statistical packages uses.
        //
        data_t  var0 { 0 };

        for (size_type i { 0 }; i < col_s; ++i)  {
            const data_t    d { *(column_begin + i) - mean };

            var0 += d * d;
        }
        var0 /= static_cast<data_t>(col_s);  // biased variance

        if (var0 <= std::numeric_limits<data_t>::epsilon() *
                    (mean * mean + 1.0) ||
            ! std::isfinite(var0)) [[unlikely]]  {
            // Constant series: p^ (k) = 0 for all k, Q = 0, p = 1
            //
            acf_.assign(max_lag_, 0.0);
            q_stats_.assign(max_lag_, 0.0);
            p_values_.assign(max_lag_, 1.0);
            q_stat_ = 0.0;
            p_value_ = 1.0;
            return;
        }

        // 3. Compute &rho;&#770;̂(k) for k = 1 … max_lag_
        //    ρ̂(k) = [Σᵢ₌₁ⁿ⁻ᵏ (xᵢ − x̄)(xᵢ₊ₖ − x̄)] / (col_s · var0)
        //
        //    We compute this directly (no CorrVisitor) so that we
        //    can use the same mean and var0 for all lags, matching
        //    the formula in Ljung & Box (1978) exactly.  CorrVisitor
        //    re-estimates mean separately per window, which would
        //    produce subtly different — and for this test, incorrect
        //    — autocorrelations.
        //
        acf_.resize(max_lag_);

        for (size_type k { 1 }; k <= max_lag_; ++k)  {
            data_t  c_k { 0 };

            for (size_type i { 0 }; i < (col_s - k); ++i)  {
                c_k += (*(column_begin + i) - mean) *
                       (*(column_begin + (i + k)) - mean);
            }
            acf_[k - 1] = c_k / (static_cast<data_t>(col_s) * var0);
        }

        // 4. Accumulate Q(k) for k = 1 … max_lag_
        //    Q(k) = col_s(n+2) · Σⱼ₌₁ᵏ ρ̂<sup>2</sup>(j) / (col_s − j)
        //
        const data_t    col_s_d { static_cast<data_t>(col_s) };
        const data_t    coeff { col_s_d * (col_s_d + 2.0) };

        q_stats_.resize(max_lag_);
        p_values_.resize(max_lag_);

        data_t  q_accum { 0 };

        for (size_type k { 1 }; k <= max_lag_; ++k)  {
            const data_t    rho { acf_[k - 1] };

            q_accum += (rho * rho) / (col_s_d - static_cast<data_t>(k));
            q_stats_[k - 1] = coeff * q_accum;

            // 6. p-value from χ<sup>2</sup>(dof) survival function
            //    Use the regularised upper incomplete gamma:
            //      p = Γ(dof/2, Q/2) / Γ(dof/2)
            //        = 1 − regularised lower incomplete gamma
            //        = std::erfc is only exact for dof=2; for general
            //          dof we need the series expansion.  We implement
            //          the standard continued-fraction / series
            //          algorithm (same approach as ChiSquaredTestVisitor).
            //
            const size_type dof_k {
                (k > dof_adjust_) ? (k - dof_adjust_) : size_type(1)
            };
            const data_t    q_k { q_stats_[k - 1] };
            const data_t    half_k { static_cast<data_t>(dof_k) / 2.0 };
            const data_t    half_q { q_k / 2.0 };

            p_values_[k - 1] = chi2_survival_(half_k, half_q);
        }

        q_stat_ = q_stats_.back();
        p_value_ = p_values_.back();
    }

    inline void pre()  {
        acf_.clear();
        q_stats_.clear();
        p_values_.clear();
        q_stat_ = 0.0;
        p_value_ = 0.0;
    }
    inline void post()  {  }

    // Overall Q(m) statistic
    //
    inline result_type get_result() const  { return (q_stat_); }

    // χ<sup>2</sup>(dof) p-value of the overall Q(m)
    //
    inline result_type get_p_value() const  { return (p_value_); }

    // Per-lag autocorrelations ρ̂(1) … ρ̂(m), size == max_lag
    //
    inline const vec_result_type &get_acf() const  { return (acf_); }

    // Cumulative Q(k) statistics k=1…m, size == max_lag
    //
    inline const vec_result_type &get_q_stats() const  { return (q_stats_); }

    // Per-lag p-values for each Q(k), size == max_lag
    //
    inline const vec_result_type &get_p_values() const  { return (p_values_); }

    explicit
    LjungBoxTestVisitor(size_type max_lag, size_type dof_adjust = 0)
        : max_lag_(max_lag), dof_adjust_(dof_adjust)  {  }

private:

    // Number of lags m to include in the Q statistic. The rule of thumb is
    // min(10, n/5) for non-seasonal data (Hyndman & Athanasopoulos).
    //
    const size_type max_lag_;

    // Subtract this from max_lag to get the &Chi;<sup>2</sup> degrees of
    // freedom.
    // Set to p+q when testing ARIMA(p,d,q) residuals. Default is 0
    // (raw series / white-noise test).
    //
    const size_type dof_adjust_;

    result_type     q_stat_ { 0 };
    result_type     p_value_ { 0 };
    vec_result_type acf_ {  };
    vec_result_type q_stats_ {  };
    vec_result_type p_values_ {  };

    // a = shape; x = z = value
    // Regularised upper incomplete gamma function:
    //   Γ(a, x) / Γ(a) = 1 − P(a, x)
    // i.e. the χ<sup>2</sup>(2a) survival function evaluated at 2x.
    //
    // Uses the series representation for x < a+1 and the
    // continued-fraction representation otherwise, following the
    // algorithm in Numerical Recipes (Press et al., §6.2).
    //
    static result_type
    chi2_survival_(data_t shape, data_t value)  {

        if (value <= 0.0) [[unlikely]]
            return (1.0);
        if (! std::isfinite(value)) [[unlikely]]
            return (0.0);

        // log-gamma via std::lgamma
        //
        const data_t    log_gam_shape { std::lgamma(shape) };

        if (value < shape + 1.0)  {
            // Series expansion for the lower incomplete gamma P(shape, value),
            // then return 1 − P.
            //
            data_t  ap { shape };
            data_t  sum { 1.0 / shape };
            data_t  del { sum };

            for (int n { 0 }; n < 200; ++n)  {
                ap += 1.0;
                del *= value / ap;
                sum += del;
                if (std::abs(del) < std::abs(sum) * 3e-15)
                    break;
            }
            const data_t    p_lower {
                std::exp(-value +
                         shape * std::log(value) - log_gam_shape) *
                sum
            };

            return (1.0 - p_lower);
        }
        else  {
            // Continued-fraction expansion for the upper incomplete gamma
            // (Lentz's method).
            //
            constexpr data_t    FPMIN { 1e-300 };

            data_t  b { value + 1.0 - shape };
            data_t  c { 1.0 / FPMIN };
            data_t  d { 1.0 / b };
            data_t  h { d };

            for (int n { 1 }; n <= 200; ++n)  {
                const data_t    shape_n  {
                    -static_cast<data_t>(n) * (static_cast<data_t>(n) - shape)
                };

                b += 2.0;
                d = shape_n * d + b;
                if (std::abs(d) < FPMIN)  d = FPMIN;
                c = b + shape_n / c;
                if (std::abs(c) < FPMIN)  c = FPMIN;
                d = 1.0 / d;
                h *= d * c;

                if (std::abs(d * c - 1.0) < 3e-15)  break;
            }
            return (std::exp(-value +
                             shape * std::log(value) - log_gam_shape) *
                    h);
        }
    }
};

template<typename T, typename I = unsigned long>
using lb_test_v = LjungBoxTestVisitor<T, I>;

// ----------------------------------------------------------------------------

// Durbin-Watson Test for First-Order Serial Autocorrelation in Residuals
//
template<arithmetic T, typename I = unsigned long>
struct  DurbinWatsonVisitor  {

    DEFINE_VISIT_BASIC_TYPES
    using result_type = T;

    template<typename K, typename H>
    inline void
    operator()(const K &idx_begin, const K &idx_end,
               const H &column_begin, const H &column_end)  {

        GET_COL_SIZE

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < 3)
            throw DataFrameError(
                "DurbinWatsonVisitor: Too few non-NaN observations "
                "(need >= 3)");
#endif // HMDF_SANITY_EXCEPTIONS

        // 1. Numerator: Σ (eᵢ − eᵢ₋₁)² (col_s−1 terms)
        //    Denominator: Σ eᵢ² (col_s terms)
        // Both accumulated in one pass.
        //
        value_type  num { 0 };
        value_type  den { *column_begin * *column_begin };

        for (size_type i { 1 }; i < col_s; ++i)  {
            const auto  i_data { *(column_begin + i) };
            const auto  diff { i_data - *(column_begin + (i - 1)) };

            num += diff * diff;
            den += i_data * i_data;
        }

        // 2. Guard: zero denominator means all residuals are 0 (perfect fit
        //    or constant series).  DW is undefined; we return 2 (no autocorr)
        //    and set rho = 0, mirroring JarqueBeraTestVisitor's treatment of
        //    degenerate input.
        //
        const value_type    eps_den {
            std::numeric_limits<value_type>::epsilon() *
            static_cast<value_type>(col_s)
        };

        if (den <= eps_den) [[unlikely]]  {
            d_ = T(2);
            rho_ = 0;
            cat_ = dw_autocorr_t::no_autocorr;
            return;
        }

        d_ = num / den;

        // ρ̂ ≈ 1 − d/2  (first-order autocorrelation estimate)
        //
        rho_ = T(1) - d_ / T(2);

        // 3. Classify against the user-supplied (or default) bounds
        //
        const auto  d_upper_mirror { T(4) - d_upper_ };
        const auto  d_lower_mirror { T(4) - d_lower_ };

        if (d_ < d_lower_)
            cat_ = dw_autocorr_t::positive_autocorr;
        else if (d_ > d_lower_mirror)
            cat_ = dw_autocorr_t::negative_autocorr;
        else if (d_ > d_upper_ && d_ < d_upper_mirror)
            cat_ = dw_autocorr_t::no_autocorr;
        else
            cat_ = dw_autocorr_t::inconclusive;
    }

    inline void pre()  { d_ = rho_ = 0; cat_ = dw_autocorr_t::inconclusive; }
    inline void post()  {  }

    // The Durbin-Watson d statistic ∈ [0, 4]
    //
    inline result_type get_result() const  { return (d_); }

    // Approximate lag-1 autocorrelation ρ̂ = 1 − d/2 ∈ [−1, 1]
    //
    inline result_type get_rho() const  { return (rho_); }

    // Bounds-test classification of d (see dw_autocorr_t)
    //
    inline dw_autocorr_t get_result_category() const  { return (cat_); }

    explicit
    DurbinWatsonVisitor(result_type d_lower = result_type(1.5),
                        result_type d_upper = result_type(2.5))
        : d_lower_(d_lower), d_upper_(d_upper)  {  }

private:

    // Lower Durbin-Watson critical bound dL. Defaults to 1.5.
    //
    const result_type   d_lower_;

    // Upper Durbin-Watson critical bound dU. Defaults to 2.5.
    //
    const result_type   d_upper_;

    result_type         d_ { 0.0 };
    result_type         rho_ { 0.0 };
    dw_autocorr_t       cat_ { dw_autocorr_t::inconclusive };
};

template<typename T, typename I = unsigned long>
using dw_test_v = DurbinWatsonVisitor<T, I>;

// ----------------------------------------------------------------------------

// Divergence of a Vector Field (&nabla;.F)
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  DivergenceVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    DEFINE_VISIT_BASIC_TYPES

    using result_type = vec_t<double>;

    // Two-column operator: field column (T) and coordinate column (T).
    //
    template<typename K, typename HF, typename HX>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const HF &f_begin, const HF &f_end,
               const HX &c_begin, const HX &c_end [[maybe_unused]])  {

        const size_type col_s { size_type(std::distance(f_begin, f_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type c_sz { size_type(std::distance(c_begin, c_end)) };

        if (col_s != c_sz)
            throw DataFrameError(
                "DivergenceVisitor: Two columns Field and Coordinate must "
                "have the same size.");
#endif // HMDF_SANITY_EXCEPTIONS

        if (col_s < 2) [[unlikely]]
            return;   // single sample: derivative undefined -> 0

        result_.resize(col_s, 0.0);

        // Scalar T: ordinary 1-D finite difference dF/dx
        //
        if constexpr (! is_md_)  {
            // Left boundary: forward difference
            //
            {
                const double    df {
                    static_cast<double>(*(f_begin + 1)) -
                    static_cast<double>(*(f_begin))
                };
                const double    dx {
                    static_cast<double>(*(c_begin + 1)) -
                    static_cast<double>(*(c_begin))
                };

                result_[0] = (dx != 0.0) ? (df / dx) : 0.0;
            }

            // Interior: central differences
            //
            for (size_type i { 1 }; i < (col_s - 1); ++i)  {
                const double    df {
                    static_cast<double>(*(f_begin + (i + 1))) -
                    static_cast<double>(*(f_begin + (i - 1)))
                };
                const double    dx {
                    static_cast<double>(*(c_begin + (i + 1))) -
                    static_cast<double>(*(c_begin + (i - 1)))
                };

                result_[i] = (dx != 0.0) ? (df / dx) : 0.0;
            }

            // Right boundary: backward difference
            //
            {
                const size_type last { col_s - 1 };
                const double    df {
                    static_cast<double>(*(f_begin + last)) -
                    static_cast<double>(*(f_begin + (last - 1)))
                };
                const double    dx {
                    static_cast<double>(*(c_begin + last)) -
                    static_cast<double>(*(c_begin + (last - 1)))
                };

                result_[last] = (dx != 0.0) ? (df / dx) : 0.0;
            }
        }

        // Container T: N-D field.
        // Element k of the container is the k-th component.
        // Accumulate dFk/dxk for every k into result_[i].
        //
        else  {
            const size_type dim { size_type((f_begin)->size()) };

            for (size_type k { 0 }; k < dim; ++k)  {
                // Left boundary
                //
                {
                    const double    fk0 {
                        static_cast<double>((*(f_begin))[k])
                    };
                    const double    fk1 {
                        static_cast<double>((*(f_begin + 1))[k])
                    };
                    const double    xk0 {
                        static_cast<double>((*(c_begin))[k])
                    };
                    const double    xk1 {
                        static_cast<double>((*(c_begin + 1))[k])
                    };
                    const double    dx { xk1 - xk0 };

                    result_[0] += (dx != 0.0) ? ((fk1 - fk0) / dx) : 0.0;
                }

                // Interior
                //
                for (size_type i { 1 }; i < col_s - 1; ++i)  {
                    const double    fkp {
                        static_cast<double>((*(f_begin + (i + 1)))[k])
                    };
                    const double    fkm {
                        static_cast<double>((*(f_begin + (i - 1)))[k])
                    };
                    const double    xkp {
                        static_cast<double>((*(c_begin + (i + 1)))[k])
                    };
                    const double    xkm {
                        static_cast<double>((*(c_begin + (i - 1)))[k])
                    };
                    const double    dx { xkp - xkm };

                    result_[i] += (dx != 0.0) ? ((fkp - fkm) / dx) : 0.0;
                }

                // Right boundary
                //
                {
                    const size_type last { col_s - 1 };
                    const double    fkL {
                        static_cast<double>((*(f_begin + last))[k])
                    };
                    const double    fkLm {
                        static_cast<double>((*(f_begin + (last - 1)))[k])
                    };
                    const double    xkL {
                        static_cast<double>((*(c_begin + last))[k])
                    };
                    const double    xkLm {
                        static_cast<double>((*(c_begin + (last - 1)))[k])
                    };
                    const double    dx { xkL - xkLm };

                    result_[last] += (dx != 0.0) ? ((fkL - fkLm) / dx) : 0.0;
                }
            }
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }

    // Per-row divergence. Length equals the input column length.
    //
    DEFINE_RESULT

    DivergenceVisitor() = default;

private:

    result_type result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using div_v = DivergenceVisitor<T, I, A>;

// ----------------------------------------------------------------------------

// Gradient of a Scalar Field  (&nabla;&phi;)
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  GradientVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // Per-row result element:
    //   scalar T -> double (the single derivative)
    //   container T -> T (the full gradient vector)
    //
    using grad_elem_t = std::conditional_t<! is_md_, double, T>;

public:

    DEFINE_VISIT_BASIC_TYPES

    using result_type = vec_t<grad_elem_t>;

    // Two-column operator:
    //   column 1 — scalar field &phi; (arithmetic type, not T for the MD case)
    //   column 2 — spatial coordinates (type T)
    //
    // For scalar T both columns have the same element type.
    // For container T column 1 has element type double, column 2 has type T.
    //
    template<typename K, typename HF, typename HC>
    inline void
    operator()(const K &, const K &,
               const HF &f_begin, const HF &f_end,
               const HC &c_begin, const HC &c_end [[maybe_unused]])  {

        const size_type col_s { size_type(std::distance(f_begin, f_end)) };

        if constexpr (! is_md_)
            result_.assign(col_s, grad_elem_t(0));
        else
            result_.assign(col_s, grad_elem_t { });  // zero-init array/vector

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type c_sz { size_type(std::distance(c_begin, c_end)) };

        if (col_s != c_sz)
            throw DataFrameError(
                "GradientVisitor: Two columns Field and Coordinate must "
                "have the same size.");
#endif // HMDF_SANITY_EXCEPTIONS

        if (col_s < 2) [[unlikely]]
            return;   // single sample: derivative undefined -> 0

        // Scalar T: 1-D finite difference d&phi;/dx
        //
        if constexpr (! is_md_)  {
            // Left boundary: forward difference
            //
            {
                const double    dphi {
                    static_cast<double>(*(f_begin + 1)) -
                    static_cast<double>(*(f_begin))
                };
                const double    dx {
                    static_cast<double>(*(c_begin + 1)) -
                    static_cast<double>(*(c_begin))
                };

                result_[0] = (dx != 0.0) ? (dphi / dx) : 0.0;
            }

            // Interior: central differences
            //
            for (size_type i { 1 }; i < col_s - 1; ++i)  {
                const double    dphi {
                    static_cast<double>(*(f_begin + (i + 1))) -
                    static_cast<double>(*(f_begin + (i - 1)))
                };
                const double    dx {
                    static_cast<double>(*(c_begin + (i + 1))) -
                    static_cast<double>(*(c_begin + (i - 1)))
                };

                result_[i] = (dx != 0.0) ? (dphi / dx) : 0.0;
            }

            // Right boundary: backward difference
            //
            {
                const size_type last { col_s - 1 };
                const double    dphi {
                    static_cast<double>(*(f_begin + last)) -
                    static_cast<double>(*(f_begin + (last - 1)))
                };
                const double    dx {
                    static_cast<double>(*(c_begin + last)) -
                    static_cast<double>(*(c_begin + (last - 1)))
                };

                result_[last] = (dx != 0.0) ? (dphi / dx) : 0.0;
            }
        }

        // Container T: N-D field.
        // The scalar field differences are the same for all k at row i;
        // only the coordinate denominators differ by component.
        //
        else  {
            const size_type dim { size_type((c_begin)->size()) };

            // Left boundary: forward difference
            //
            {
                const double    dphi {
                    static_cast<double>(*(f_begin + 1)) -
                    static_cast<double>(*(f_begin))
                };

                for (size_type k { 0 }; k < dim; ++k)  {
                    const double    dx {
                        static_cast<double>((*(c_begin + 1))[k]) -
                        static_cast<double>((*(c_begin))[k])
                    };

                    result_[0][k] =
                        static_cast<typename T::value_type>(
                            (dx != 0.0) ? (dphi / dx) : 0.0);
                }
            }

            // Interior: central differences
            //
            for (size_type i { 1 }; i < col_s - 1; ++i)  {
                const double    dphi {
                    static_cast<double>(*(f_begin + (i + 1))) -
                    static_cast<double>(*(f_begin + (i - 1)))
                };

                for (size_type k { 0 }; k < dim; ++k)  {
                    const double    dx {
                        static_cast<double>((*(c_begin + (i + 1)))[k]) -
                        static_cast<double>((*(c_begin + (i - 1)))[k])
                    };

                    result_[i][k] =
                        static_cast<typename T::value_type>(
                            (dx != 0.0) ? (dphi / dx) : 0.0);
                }
            }

            // Right boundary: backward difference
            //
            {
                const size_type last { col_s - 1 };
                const double    dphi {
                    static_cast<double>(*(f_begin + last)) -
                    static_cast<double>(*(f_begin + (last - 1)))
                };

                for (size_type k { 0 }; k < dim; ++k)  {
                    const double    dx {
                        static_cast<double>((*(c_begin + last))[k]) -
                        static_cast<double>((*(c_begin + (last - 1)))[k])
                    };

                    result_[last][k] =
                        static_cast<typename T::value_type>(
                            (dx != 0.0) ? (dphi / dx) : 0.0);
                }
            }
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }

    // Per-row gradient &nabla;&phi;.
    //   Scalar T -> vec_t<double>: result_[i] = d&phi;/dx at row i
    //   Container T -> vec_t<T>: result_[i][k] = &part;&phi;/&part;x at row i
    //
    DEFINE_RESULT

    GradientVisitor() = default;

private:

    result_type     result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using grad_v = GradientVisitor<T, I, A>;

// ----------------------------------------------------------------------------

/*
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  GradientVisitor  {

public:

    DEFINE_VISIT_BASIC_TYPES

private:

    static constexpr bool   is_md_ { random_acc_cont<T> };

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // Per-row result element:
    //   scalar T -> double (the single derivative)
    //   container T -> T (the full gradient vector)
    //
    using grad_elem_t = std::conditional_t<! is_md_, double, T>;
    using matrix_t = Matrix<double, matrix_orient::row_major>;

    // Only used for the MD (container T) case: the local regression
    // window at each row grows to at least min_window_mult_ * (dim + 1)
    // points (clamped to the data size) before it's considered wide
    // enough to fit. dim+1 is the bare minimum for a solvable system;
    // the multiplier gives some over-determination for a more stable
    // least-squares fit.
    //
    size_type   min_window_mult_ { 2 };

public:

    using result_type = vec_t<grad_elem_t>;

    explicit
    GradientVisitor(size_type min_window_mult = 2)
        : min_window_mult_(min_window_mult)  {   }

    // Two-column operator:
    //   column 1 — scalar field &phi; (arithmetic type, not T for the MD case)
    //   column 2 — spatial coordinates (type T)
    //
    // For scalar T both columns have the same element type.
    // For container T column 1 has element type double, column 2 has type T.
    //
    template<typename K, typename HF, typename HC>
    inline void
    operator()(const K &, const K &,
               const HF &f_begin, const HF &f_end,
               const HC &c_begin, const HC &c_end [[maybe_unused]])  {

        const size_type col_s { size_type(std::distance(f_begin, f_end)) };

        if constexpr (! is_md_)
            result_.assign(col_s, grad_elem_t(0));
        else
            result_.assign(col_s, grad_elem_t { });  // Zero-init array/vector

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type c_sz { size_type(std::distance(c_begin, c_end)) };

        if (col_s != c_sz)
            throw DataFrameError(
                "GradientVisitor: Two columns Field and Coordinate must "
                "have the same size.");
#endif // HMDF_SANITY_EXCEPTIONS

        if (col_s < 2) [[unlikely]]
            return;   // single sample: derivative undefined -> 0

        // Scalar T: 1-D finite difference d&phi;/dx
        //
        if constexpr (! is_md_)  {
            // Left boundary: forward difference
            //
            {
                const double    dphi {
                    double(*(f_begin + 1)) - double(*(f_begin))
                };
                const double    dx {
                    double(*(c_begin + 1)) - double(*(c_begin))
                };

                result_[0] = (dx != 0.0) ? (dphi / dx) : 0.0;
            }

            // Interior: central differences
            //
            for (size_type i { 1 }; i < col_s - 1; ++i)  {
                const double    dphi {
                    double(*(f_begin + (i + 1))) - double(*(f_begin + (i - 1)))
                };
                const double    dx {
                    double(*(c_begin + (i + 1))) - double(*(c_begin + (i - 1)))
                };

                result_[i] = (dx != 0.0) ? (dphi / dx) : 0.0;
            }

            // Right boundary: backward difference
            //
            {
                const size_type last { col_s - 1 };
                const double    dphi {
                    double(*(f_begin + last)) - double(*(f_begin + (last - 1)))
                };
                const double    dx {
                    double(*(c_begin + last)) - double(*(c_begin + (last - 1)))
                };

                result_[last] = (dx != 0.0) ? (dphi / dx) : 0.0;
            }
        }

        // Container T: N-D field.
        //
        // A shared two-point finite difference cannot isolate one
        // coordinate's contribution to phi from another's: dividing the
        // SAME total delta-phi by each dimension's own delta-x (the
        // previous approach here) attributes phi's change to every
        // coordinate, even ones phi does not actually depend on. Instead,
        // fit a local multivariate linear regression
        // phi ~ b0 + b1*x1 + ... + bdim*xdim over a small window of
        // nearby rows and read off (b1..bdim) as this row's gradient --
        // the coefficients of a local linear model ARE the local partial
        // derivatives, and only they correctly separate each coordinate's
        // own contribution.
        //
        else  {
            const size_type dim { size_type((c_begin)->size()) };

#ifdef HMDF_SANITY_EXCEPTIONS
            if (col_s < dim + 1)
                throw DataFrameError(
                    "GradientVisitor: need at least dim + 1 rows to fit a "
                    "gradient in dim dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

            const size_type needed_pts {
                std::min(col_s, (dim + 1) * min_window_mult_)
            };

            for (size_type i { 0 }; i < col_s; ++i)  {
                size_type   left { i };
                size_type   right { i };
                size_type   npts { 1 };
                bool        left_done { left == 0 };
                bool        right_done { right == (col_s - 1) };

                // Grow the window outward, alternating sides, until it
                // covers at least needed_pts rows (or the whole column,
                // whichever comes first).
                //
                while (npts < needed_pts && (! (left_done && right_done)))  {
                    if (! left_done)  {
                        left -= 1;
                        npts += 1;
                        left_done = left == 0;
                    }
                    if (npts >= needed_pts)  break;
                    if (! right_done)  {
                        right += 1;
                        npts += 1;
                        right_done = right == (col_s - 1);
                    }
                }

                matrix_t    X { long(npts), long(dim + 1), 0.0 };
                matrix_t    y_mat { long(npts), 1L, 0.0 };

                for (size_type r { 0 }; r < npts; ++r)  {
                    const auto  &coord { *(c_begin + (left + r)) };

                    X(long(r), 0) = 1.0;  // intercept
                    for (size_type k { 0 }; k < dim; ++k)
                        X(long(r), long(k + 1)) = double(coord[k]);
                    y_mat(long(r), 0) = double(*(f_begin + (left + r)));
                }

                const matrix_t  Xt { X.transpose2() };
                const matrix_t  beta { (Xt * X).solve(Xt * y_mat) };

                for (size_type k { 0 }; k < dim; ++k)
                    result_[i][k] =
                        static_cast<typename T::value_type>(
                            beta(long(k + 1), 0));
            }
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }

    // Per-row gradient &nabla;&phi;.
    //   Scalar T -> vec_t<double>: result_[i] = d&phi;/dx at row i
    //   Container T -> vec_t<T>: result_[i][k] = &part;&phi;/&part;x at row i
    //   (container T: local multivariate-regression estimate, see above)
    //
    DEFINE_RESULT

private:

    result_type     result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using grad_v = GradientVisitor<T, I, A>;
*/

// ----------------------------------------------------------------------------

// Jacobian Matrix of a Vector Field (J = &part;F/&part;x<sup>g</sup>)
//
template<random_acc_cont FT, random_acc_cont XT = FT,
         typename I = unsigned long, std::size_t A = 0>
struct  JacobianVisitor  {

private:

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

public:

    using value_type = FT;
    using index_type = I;
    using size_type = std::size_t;

    // Full m×n Jacobian
    //
    using matrix_t = Matrix<double, matrix_orient::row_major>;
    using result_type = vec_t<matrix_t>;

    // Two-column operator: field column (FT) and coordinate column (XT).
    //
    template<typename K, typename HF, typename HX>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const HF &f_begin, const HF &f_end,
               const HX &c_begin, const HX &c_end [[maybe_unused]])  {

        const size_type col_s { size_type(std::distance(f_begin, f_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type c_sz { size_type(std::distance(c_begin, c_end)) };

        if (col_s != c_sz)
            throw DataFrameError(
                "JacobianVisitor: Two columns Field and Coordinate must "
                "have the same size.");
#endif // HMDF_SANITY_EXCEPTIONS

        if (col_s < 2) [[unlikely]]
            return;

        const size_type f_dim { size_type((f_begin)->size()) };
        const size_type c_dim { size_type((c_begin)->size()) };

        // Every row starts as an m×n zero matrix. If n < 2 the derivative
        // is undefined and rows stay zero-filled.
        //
        result_.resize(col_s, matrix_t(f_dim, c_dim, 0));

        // Fills result_[i] using neighbour rows lo, hi (lo < hi).
        // dF[p] and dX[q] are each computed ONCE per row and then combined
        // via an outer division — the field and coordinate differences
        // both reference the same (lo, hi) pair, mirroring the shared-
        // numerator trick in GradientVisitor and shared-row trick in
        // DivergenceVisitor.
        //
        auto    fill_row =
            [this, f_dim, c_dim,
             &f_begin = std::as_const(f_begin),
             &c_begin = std::as_const(c_begin)]
            (size_type i, size_type lo, size_type hi)  {
                std::vector<double> dF(f_dim);
                std::vector<double> dX(c_dim);

                for (size_type p { 0 }; p < f_dim; ++p)
                    dF[p] = static_cast<double>((*(f_begin + hi))[p]) -
                            static_cast<double>((*(f_begin + lo))[p]);

                for (size_type q { 0 }; q < c_dim; ++q)
                    dX[q] = static_cast<double>((*(c_begin + hi))[q]) -
                            static_cast<double>((*(c_begin + lo))[q]);

                for (long p { 0 }; p < long(f_dim); ++p)
                    for (long q { 0 }; q < long(c_dim); ++q)
                        result_[i](p, q) = dX[q] != 0 ? dF[p] / dX[q] : 0.0;
            };

        fill_row(0, 0, 1);  // Left boundary: forward FD
        for (size_type i { 1 }; i < col_s - 1; ++i)
            fill_row(i, i - 1, i + 1);  // Interior: central FD

        // Right boundary: backward FD
        //
        fill_row(col_s - 1, col_s - 2, col_s - 1);
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }

    // Per-row Jacobian matrix.
    // result[i](p, q) = &part;F/&part;x<sup>g</sup> at row i.
    // Dimensions: m rows (field components) × n columns (coordinates).
    //
    DEFINE_RESULT

    // Trace of the Jacobian per row:
    // &Sigma; J[k][k] for k = 0 ... min(m, n) − 1.
    // Equals the divergence &nabla;&middot;F when field component k is
    // naturally paired with coordinate k (the standard convention used by
    // DivergenceVisitor).
    //
    inline vec_t<double>
    get_trace() const  {

        vec_t<double>   tr(result_.size());

        for (size_type i { 0 }; const auto &mat : result_)  {
            const long  k_max { std::min(mat.rows(), mat.cols()) };
            double      sum { 0 };

            for (long k { 0 }; k < k_max; ++k)
                sum += mat(k, k);
            tr[i++] = sum;
        }
        return (tr);
    }

    JacobianVisitor() = default;

private:

    result_type result_ { };
};

template<typename FT, typename XT = FT, typename I = unsigned long,
         std::size_t A = 0>
using jacobian_v = JacobianVisitor<FT, XT, I, A>;

// ----------------------------------------------------------------------------

/*
template<random_acc_cont FT, random_acc_cont XT = FT,
         typename I = unsigned long, std::size_t A = 0>
struct  JacobianVisitor  {

private:

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // See GradientVisitor for why this exists: the local regression
    // window at each row grows to at least min_window_mult_ * (dim + 1)
    // points (clamped to the data size) before it's wide enough to fit.
    //
    std::size_t min_window_mult_ { 2 };

public:

    using value_type = FT;
    using index_type = I;
    using size_type = std::size_t;

    // Full m×n Jacobian
    //
    using matrix_t = Matrix<double, matrix_orient::row_major>;
    using result_type = vec_t<matrix_t>;

    explicit
    JacobianVisitor(size_type min_window_mult = 2)
        : min_window_mult_(min_window_mult)  {   }

    // Two-column operator: field column (FT) and coordinate column (XT).
    //
    template<typename K, typename HF, typename HX>
    inline void
    operator()(const K &, const K &,
               const HF &f_begin, const HF &f_end,
               const HX &c_begin, const HX &c_end [[maybe_unused]])  {

        const size_type col_s { size_type(std::distance(f_begin, f_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type c_sz { size_type(std::distance(c_begin, c_end)) };

        if (col_s != c_sz)
            throw DataFrameError(
                "JacobianVisitor: Two columns Field and Coordinate must "
                "have the same size.");
#endif // HMDF_SANITY_EXCEPTIONS

        if (col_s < 2) [[unlikely]]
            return;

        const size_type f_dim { size_type((f_begin)->size()) };
        const size_type c_dim { size_type((c_begin)->size()) };

        // Every row starts as an m×n zero matrix. If n < 2 the derivative
        // is undefined and rows stay zero-filled.
        //
        result_.resize(col_s, matrix_t(f_dim, c_dim, 0));

#ifdef HMDF_SANITY_EXCEPTIONS
        if (col_s < c_dim + 1)
            throw DataFrameError(
                "JacobianVisitor: need at least c_dim + 1 rows to fit a "
                "Jacobian in c_dim coordinate dimensions");
#endif // HMDF_SANITY_EXCEPTIONS

        // A two-point outer division dF[p]/dX[q] (one shared (lo, hi) row
        // pair for every (p, q)) cannot isolate coordinate q's actual
        // contribution to field component p: dF[p] reflects every
        // coordinate's change between lo and hi, not just x_q's, so a
        // field component that doesn't depend on x_q at all would still
        // get a nonzero J[p][q]. Instead, fit ONE local multivariate
        // regression per row that predicts all f_dim field components at
        // once from the same c_dim coordinates: solving
        // (XᵀX)·BETA = XᵀY for the (c_dim+1) × f_dim coefficient matrix
        // BETA in a single solve() reuses the same design matrix X for
        // every field component, so this costs one solve per row
        // regardless of f_dim, not one per (row, component) pair. Column
        // p of BETA (rows 1..c_dim) is field component p's own isolated
        // set of partial derivatives -- exactly row p of the Jacobian.
        //
        const size_type needed_pts {
            std::min(col_s, (c_dim + 1) * min_window_mult_)
        };

        for (size_type i { 0 }; i < col_s; ++i)  {
            size_type   left { i };
            size_type   right { i };
            size_type   npts { 1 };
            bool        left_done { left == 0 };
            bool        right_done { right == col_s - 1 };

            while (npts < needed_pts && ! (left_done && right_done))  {
                if (! left_done)  {
                    --left;
                    ++npts;
                    left_done = (left == 0);
                }
                if (npts >= needed_pts)  break;
                if (! right_done)  {
                    ++right;
                    ++npts;
                    right_done = (right == col_s - 1);
                }
            }

            matrix_t    X { long(npts), long(c_dim + 1), 0.0 };
            matrix_t    Y { long(npts), long(f_dim), 0.0 };

            for (size_type r { 0 }; r < npts; ++r)  {
                const auto  &coord { *(c_begin + (left + r)) };
                const auto  &field { *(f_begin + (left + r)) };

                X(long(r), 0) = 1.0;  // intercept
                for (size_type q { 0 }; q < c_dim; ++q)
                    X(long(r), long(q + 1)) = static_cast<double>(coord[q]);
                for (size_type p { 0 }; p < f_dim; ++p)
                    Y(long(r), long(p)) = static_cast<double>(field[p]);
            }

            const matrix_t  Xt { X.transpose2() };
            const matrix_t  beta { (Xt * X).solve(Xt * Y) };

            for (size_type p { 0 }; p < f_dim; ++p)
                for (size_type q { 0 }; q < c_dim; ++q)
                    result_[i](long(p), long(q)) = beta(long(q + 1), long(p));
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }

    // Per-row Jacobian matrix (local multivariate-regression estimate,
    // see above).
    // result[i](p, q) = &part;F/&part;x<sup>g</sup> at row i.
    // Dimensions: m rows (field components) × n columns (coordinates).
    //
    DEFINE_RESULT

    // Trace of the Jacobian per row:
    // &Sigma; J[k][k] for k = 0 ... min(m, n) − 1.
    // Equals the divergence &nabla;&middot;F when field component k is
    // naturally paired with coordinate k (the standard convention used by
    // DivergenceVisitor).
    //
    inline vec_t<double>
    get_trace() const  {

        vec_t<double>   tr(result_.size());

        for (size_type i { 0 }; const auto &mat : result_)  {
            const long  k_max { std::min(mat.rows(), mat.cols()) };
            double      sum { 0 };

            for (long k { 0 }; k < k_max; ++k)
                sum += mat(k, k);
            tr[i++] = sum;
        }
        return (tr);
    }

private:

    result_type result_ { };
};

template<typename FT, typename XT = FT, typename I = unsigned long,
         std::size_t A = 0>
using jacobian_v = JacobianVisitor<FT, XT, I, A>;
*/

// ----------------------------------------------------------------------------

// Laplacian of a Scalar Field (&nabla;<sup>2</sup>&phi;)
//
template<typename T, typename I = unsigned long, std::size_t A = 0>
struct  LaplacianVisitor  {

private:

    static constexpr bool   is_md_ = random_acc_cont<T>;

    template<typename U>
    using vec_t = std::vector<U, typename allocator_declare<U, A>::type>;

    // Three-point quadratic-curvature second-derivative formula.
    // h1 = x1-x0, h2 = x2-x1 (spacings between consecutive samples).
    // Degenerate spacing (h1 or h2 == 0, or h1+h2 == 0) contributes 0.
    //
    static inline double
    second_deriv_(double f0, double f1, double f2, double h1, double h2)  {

        if (h1 == 0.0 || h2 == 0.0) [[unlikely]]
            return (0.0);

        const double    hsum { h1 + h2 };

        if (hsum == 0.0) [[unlikely]]
            return (0.0);
        return (2.0 * (f0 / (h1 * hsum) - f1 / (h1 * h2)  + f2 / (h2 * hsum)));
    }

public:

    DEFINE_VISIT_BASIC_TYPES

    using result_type = vec_t<double>;

    // Two-column operator:
    //   column 1 — scalar field &phi; (arithmetic type)
    //   column 2 — spatial coordinates (type T)
    //
    template<typename K, typename HF, typename HC>
    inline void
    operator()(const K &/*idx_begin*/, const K &/*idx_end*/,
               const HF &f_begin, const HF &f_end,
               const HC &c_begin, const HC &c_end [[maybe_unused]])  {

        const size_type col_s { size_type(std::distance(f_begin, f_end)) };

#ifdef HMDF_SANITY_EXCEPTIONS
        const size_type c_sz { size_type(std::distance(c_begin, c_end)) };

        if (col_s != c_sz)
            throw DataFrameError(
                "LaplacianVisitor: Two columns Field and Coordinate must "
                "have the same size.");
#endif // HMDF_SANITY_EXCEPTIONS

        if (col_s < 3) [[unlikely]]
            return;  // second derivative undefined with < 3 samples

        result_.resize(col_s, 0);
        if constexpr (! is_md_)  {
            // Scalar T: ordinary 1-D second derivative d^2phi/dx^2
            //
            auto    fill_row =
                [this,
                 f_begin = std::as_const(f_begin),
                 c_begin = std::as_const(c_begin)]
                (size_type i, size_type i0, size_type i1, size_type i2)  {
                    const double    f0 { double(*(f_begin + i0)) };
                    const double    f1 { double(*(f_begin + i1)) };
                    const double    f2 { double(*(f_begin + i2)) };
                    const double    x0 { double(*(c_begin + i0)) };
                    const double    x1 { double(*(c_begin + i1)) };
                    const double    x2 { double(*(c_begin + i2)) };

                    result_[i] = second_deriv_(f0, f1, f2, x1 - x0, x2 - x1);
                };

            fill_row(0, 0, 1, 2);  // left boundary
            for (size_type i { 1 }; i < col_s - 1; ++i)
                fill_row(i, i - 1, i, i + 1);  // interior

            // right boundary
            //
            fill_row(col_s - 1, col_s - 3, col_s - 2, col_s - 1);
        }
        else  {
            // Container T: N-D field.
            // The field-value triple (f0,f1,f2) is the SAME for every
            // dimension k at a given row; only the per-k coordinate
            // spacings h1,h2 differ. Sum the per-dimension curvatures.
            //
            const size_type dim { size_type((c_begin)->size()) };

            auto    fill_row =
                [this, dim,
                 f_begin = std::as_const(f_begin),
                 c_begin = std::as_const(c_begin)]
                (size_type i, size_type i0, size_type i1, size_type i2)  {
                    const double    f0 { double(*(f_begin + i0)) };
                    const double    f1 { double(*(f_begin + i1)) };
                    const double    f2 { double(*(f_begin + i2)) };
                    double          sum { 0.0 };

                    for (size_type k { 0 }; k < dim; ++k)  {
                        const double    x0 { double((*(c_begin + i0))[k]) };
                        const double    x1 { double((*(c_begin + i1))[k]) };
                        const double    x2 { double((*(c_begin + i2))[k]) };

                        sum += second_deriv_(f0, f1, f2, x1 - x0, x2 - x1);
                    }
                    result_[i] = sum;
                };

            fill_row(0, 0, 1, 2);  // Left boundary
            for (size_type i { 1 }; i < col_s - 1; ++i)
                fill_row(i, i - 1, i, i + 1);  // Interior

            // Right boundary
            //
            fill_row(col_s - 1, col_s - 3, col_s - 2, col_s - 1);
        }
    }

    inline void pre()  { result_.clear(); }
    inline void post()  {  }

    // Per-row Laplacian &nabla;<sup>2</sup>&phi;.
    // Always a scalar, regardless of T.
    //
    DEFINE_RESULT

    LaplacianVisitor() = default;

private:

    result_type result_ { };
};

template<typename T, typename I = unsigned long, std::size_t A = 0>
using laplacian_v = LaplacianVisitor<T, I, A>;

} // namespace hmdf

// ----------------------------------------------------------------------------

// Local Variables:
// mode:C++
// tab-width:4
// c-basic-offset:4
// End:
